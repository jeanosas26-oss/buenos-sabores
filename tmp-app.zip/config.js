// Configuración de esta instalación de JEANO Gestión.
// cloudUrl: dirección de la nube (Worker de Cloudflare) de este comercio. Vacío = la pide al conectar.
window.JG_CONFIG = { cloudUrl: 'https://jeano-gestion.jeanosas26.workers.dev' };
