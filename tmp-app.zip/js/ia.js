// =====================================================================
// ia.js — IA en la nube desde la app: achicar las fotos en el navegador, leer comprobantes y vencimientos, el asistente,
// el estado (gratis X de Y hoy / Claude activado) y los avisos de límite. La clave de Claude nunca pasa por acá: se carga
// en Ajustes → IA y queda cifrada en la nube.
// =====================================================================
import * as sync from './sync.js';
import { ctx } from './ops.js';
import { html, ic, modal, toast } from './ui.js';
import { can } from './logic.js';

/** Máximo por foto para leer (la nube acepta 1,5 MB) */
export const AI_MAX_BYTES = 1.5 * 1024 * 1024;
/** Imagen del comprobante que queda guardada con la compra (purchase_docs.photo admite 200.000 caracteres) */
export const DOC_MAX_CHARS = 190000;

let lastStatus = null;
export const cachedStatus = () => lastStatus;

/** Estado de la IA en la nube (motor, uso de hoy). null si no hay nube o no responde. */
export async function aiStatus({ fresh = false } = {}) {
  if (!sync.isConfigured()) return null;
  if (!fresh && lastStatus && Date.now() - lastStatus._at < 30000) return lastStatus;
  try {
    const s = await sync.cloudApi('/api/ai/status', { timeout: 10000 });
    lastStatus = { ...s, _at: Date.now() };
    return lastStatus;
  } catch (e) { return lastStatus; }
}
function noteUsage(r) {
  if (!r || !lastStatus) return;
  if (r.engine === 'free' && r.used !== null && r.used !== undefined) lastStatus = { ...lastStatus, used: { ...lastStatus.used, [r.kind || 'image']: r.used } };
}

/** "Gratis (12 de 30 hoy)" / "Claude activado" / "IA desactivada" */
export function statusLabel(s, kind = 'image') {
  if (!s) return sync.isConfigured() ? 'IA: sin conexión' : 'IA: necesita la nube';
  if (s.engine === 'claude') return 'Claude activado';
  if (s.engine === 'off') return 'IA desactivada';
  return `Gratis (${(s.used || {})[kind] || 0} de ${(s.limits || {})[kind] || 0} hoy)`;
}

// ---------- Fotos ----------

async function loadBitmap(src) {
  if (typeof src === 'string') {
    const img = new Image();
    await new Promise((res, rej) => { img.onload = res; img.onerror = () => rej(new Error('No se pudo leer la imagen.')); img.src = src; });
    return img;
  }
  if (!src || !/^image\//.test(src.type || 'image/')) throw new Error('Elegí una foto (JPG o PNG).');
  if (/heic|heif/i.test(src.type || src.name || '')) {
    try { return await createImageBitmap(src); } catch (e) { throw new Error('Formato HEIC del iPhone: este navegador no lo puede leer. Sacala con la cámara desde la app o pasala a JPG.'); }
  }
  if (typeof createImageBitmap === 'function') {
    try { return await createImageBitmap(src, { imageOrientation: 'from-image' }); } catch (e) { /* sigue */ }
    try { return await createImageBitmap(src); } catch (e) { /* sigue */ }
  }
  const url = URL.createObjectURL(src);
  try { return await loadBitmap(url); } finally { setTimeout(() => URL.revokeObjectURL(url), 1000); }
}

/**
 * Achica y comprime una foto en el navegador (JPEG): lado mayor ≤ maxPx y hasta maxChars caracteres de data URL.
 * Las fotos del celu (4000 px, 4 MB) quedan en ~300-900 KB: alcanza para leer letra chica.
 */
export async function compressImage(src, { maxPx = 1600, maxChars = Math.floor(AI_MAX_BYTES * 4 / 3) - 100, q = 0.82, gray = false } = {}) {
  const img = await loadBitmap(src);
  try {
    const w0 = img.width || img.naturalWidth, h0 = img.height || img.naturalHeight;
    if (!w0 || !h0) throw new Error('No se pudo leer la imagen.');
    let px = Math.min(maxPx, Math.max(w0, h0));
    const c = document.createElement('canvas');
    const paint = () => {
      const k = px / Math.max(w0, h0);
      c.width = Math.max(1, Math.round(w0 * k)); c.height = Math.max(1, Math.round(h0 * k));
      const g = c.getContext('2d');
      g.fillStyle = '#fff'; g.fillRect(0, 0, c.width, c.height);
      if (gray) g.filter = 'grayscale(1) contrast(1.15)';
      g.drawImage(img, 0, 0, c.width, c.height);
    };
    paint();
    let out = c.toDataURL('image/jpeg', q);
    while (out.length > maxChars && q > 0.45) { q -= 0.08; out = c.toDataURL('image/jpeg', q); }
    while (out.length > maxChars && px > 500) { px = Math.round(px * 0.8); paint(); out = c.toDataURL('image/jpeg', Math.max(0.5, q)); }
    if (!out.startsWith('data:image/jpeg')) throw new Error('Este navegador no pudo comprimir la foto.');
    if (out.length > maxChars) throw new Error('La foto quedó muy pesada. Probá con otra.');
    return out;
  } finally { if (img.close) img.close(); }
}
/** Versión chica (en gris) del comprobante para guardar con la compra */
export const docImage = src => compressImage(src, { maxPx: 1300, maxChars: DOC_MAX_CHARS, q: 0.62, gray: true });

/**
 * Pide fotos con la cámara o del equipo. Hay que llamarla durante el toque (si no, el navegador no abre nada).
 * multiple: varias páginas. Devuelve [File] (vacío si se canceló).
 */
export function pickImages({ capture = false, multiple = false, root = document.body } = {}) {
  return new Promise(resolve => {
    const i = document.createElement('input');
    i.type = 'file';
    i.accept = 'image/*';
    if (multiple) i.multiple = true;
    if (capture) i.setAttribute('capture', 'environment');
    i.style.display = 'none';
    i.dataset.aiInput = capture ? 'cam' : 'file';
    let done = false;
    const end = f => { if (done) return; done = true; i.remove(); resolve(f ? [...f] : []); };
    i.addEventListener('change', () => end(i.files));
    i.addEventListener('cancel', () => end(null));
    root.appendChild(i);
    i.click();
  });
}

// ---------- Llamadas ----------

/** Lee un comprobante (1 a 4 fotos ya comprimidas) → {data, engine, used, limit} */
export async function readInvoice(images) {
  const r = await sync.cloudApi('/api/ai/leer-comprobante', { method: 'POST', body: { images }, timeout: 150000 });
  noteUsage({ ...r, kind: 'image' });
  return r;
}
/** Lee la fecha de vencimiento de una foto → {fecha_vencimiento, lote, ean} */
export async function readExpiry(image, ean = '') {
  const r = await sync.cloudApi('/api/ai/leer-vencimiento', { method: 'POST', body: { image, ean: ean || undefined }, timeout: 60000 });
  noteUsage({ ...r, kind: 'image' });
  return r;
}
/** Pregunta al asistente con el resumen de datos del comercio */
export async function ask(question, context, history = [], business = '') {
  const r = await sync.cloudApi('/api/ai/asistente', { method: 'POST', body: { question, context, history, business }, timeout: 60000 });
  noteUsage({ ...r, kind: 'text' });
  return r;
}

// ---------- Avisos ----------

/** Oferta de Claude al llegar al límite gratis (con link a Ajustes → IA para el dueño) */
export async function limitOffer(message) {
  const owner = ctx.user && can(ctx.user, 'comercio');
  const r = await modal({
    title: 'Llegaste al límite gratis de hoy',
    body: html`<div id="ia-limit"><p class="lead">${message || 'Llegaste al límite gratis de hoy.'}</p>
      <p class="muted">Mañana vuelve a haber lecturas gratis. Con Claude no hay límite diario: Anthropic le cobra al comercio lo que use (unos pocos pesos por comprobante).</p>
      ${owner ? '' : html`<p><b>Pedile al dueño que active Claude</b> en Ajustes → IA.</p>`}</div>`,
    actions: owner ? [{ label: 'Más tarde', value: null }, { label: 'Activar Claude en Ajustes → IA', kind: 'primary', value: 'go', id: 'ia-limit-go' }] : [{ label: 'Entendido', kind: 'primary', value: null }],
  });
  if (r === 'go') goToAiSettings();
}

/** Ir a Ajustes → IA (si ya está en Ajustes, la vuelve a dibujar con el estado nuevo) */
export function goToAiSettings() {
  if (/^#\/ajustes/.test(location.hash)) window.dispatchEvent(new Event('jg-rerender'));
  else location.hash = '#/ajustes';
  setTimeout(() => { const el = document.getElementById('aj-ia'); if (el) el.scrollIntoView(); }, 450);
}

/** Muestra el error de la IA como corresponde (límite → oferta de Claude; IA apagada → cómo activarla) */
export async function showAiError(e) {
  if (!e) return;
  if (e.code === 'AI_LIMIT') return limitOffer(e.message);
  if (e.code === 'AI_OFF' || e.code === 'NO_CLOUD') {
    const owner = ctx.user && can(ctx.user, 'comercio');
    const r = await modal({
      title: e.code === 'NO_CLOUD' ? 'La IA necesita la nube' : 'La IA no está activada',
      body: html`<p class="lead" id="ia-off">${e.message}</p>`,
      actions: owner ? [{ label: 'Cerrar', value: null }, { label: 'Ir a Ajustes', kind: 'primary', value: 'go' }] : [{ label: 'Entendido', kind: 'primary', value: null }],
    });
    if (r === 'go') location.hash = '#/ajustes';
    return;
  }
  if (e.needPin) { toast(e.message, 'warn', 6000); return; }
  toast(e.message || 'La IA no pudo responder.', e.offline || e.network ? 'warn' : 'error', 7000);
}

/** Ventana "Leyendo…" mientras trabaja la IA (devuelve la función para cerrarla) */
export function busy(text = 'Leyendo con IA…') {
  let closeFn = () => {};
  modal({
    title: 'IA',
    dismissable: false,
    body: html`<div class="ia-busy" id="ia-busy" role="status" aria-live="polite"><span class="spinner" aria-hidden="true"></span><p class="lead">${text}</p>
      <p class="muted small">Puede tardar unos segundos. No cierres la app.</p></div>`,
    onMount(m, close) { closeFn = close; },
  });
  return () => closeFn(null);
}

export { ic };
