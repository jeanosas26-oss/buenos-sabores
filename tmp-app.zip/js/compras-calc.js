// =====================================================================
// compras-calc.js — Cuentas puras de compras (como SGI Libra) y de los Libros IVA.
// Sin DOM ni IndexedDB: se prueba con node --test (tests/compras.test.mjs).
// Todo en CENTAVOS ENTEROS; las multiplicaciones con porcentajes van con BigInt (sin errores de coma flotante).
// =====================================================================
import { round2, round3 } from './logic.js';

export const toCents = x => Math.round(round2(Number(x) || 0) * 100);
export const fromCents = c => round2(Math.round(Number(c) || 0) / 100);

/** Alícuotas de IVA de compras (ARCA) */
export const PURCHASE_RATES = [21, 10.5, 27, 5, 2.5];
export const DOC_TYPES = [['FC', 'Factura'], ['NC', 'Nota de crédito'], ['ND', 'Nota de débito']];
export const LETTERS = ['A', 'B', 'C', 'X'];
/** Condiciones de pago de una compra */
export const PURCHASE_PAYMENTS = [
  ['contado', 'Contado (efectivo)'], ['cuenta_corriente', 'Cta. cte.'], ['mercadopago', 'Mercado Pago'],
  ['transferencia', 'Transferencia'], ['cheque', 'Cheque'],
];
export function paymentLabel(id) {
  const m = PURCHASE_PAYMENTS.find(x => x[0] === (id || 'contado'));
  return m ? m[1].replace(' (efectivo)', '') : String(id || '');
}

/** División entera redondeada (mitad hacia arriba, simétrica) con BigInt */
function bdiv(n, d) {
  const neg = (n < 0n) !== (d < 0n);
  const a = n < 0n ? -n : n, b = d < 0n ? -d : d;
  const q = (a * 2n + b) / (2n * b);
  return neg ? -q : q;
}
/** Número decimal → entero escalado (x * 10^k) */
const scaled = (x, k) => BigInt(Math.round((Number(x) || 0) * 10 ** k));

/**
 * Importe de un renglón en centavos: cantidad × unitario × (1 − dto1%) × (1 − dto2%), redondeado una sola vez.
 * Cantidad con 3 decimales; descuentos con 3 decimales.
 */
export function lineCents(qty, unitCost, disc1 = 0, disc2 = 0) {
  const q = scaled(round3(qty), 3), u = BigInt(toCents(unitCost));
  const f1 = 100000n - scaled(disc1, 3), f2 = 100000n - scaled(disc2, 3);
  return Number(bdiv(q * u * f1 * f2, 1000n * 100000n * 100000n));
}

/** Descuentos generales encadenados sobre un importe en centavos: [{pct, amount (centavos)}] y lo que queda */
export function chainDiscounts(cents, pcts = []) {
  let rest = cents;
  const out = [];
  for (const p of pcts) {
    const pct = Number(p) || 0;
    if (!pct) continue;
    const amount = Number(bdiv(BigInt(rest) * scaled(pct, 3), 100000n));
    out.push({ pct, amount });
    rest -= amount;
  }
  return { list: out, rest };
}

/** Reparte `total` (centavos) en proporción a `weights` por mayor resto: la suma da exactamente total */
export function allocate(total, weights) {
  const w = weights.reduce((a, x) => a + x, 0);
  if (!w) return weights.map(() => 0);
  const parts = weights.map((x, i) => {
    const exact = (total * x) / w;
    const fl = Math.floor(exact);
    return { i, cents: fl, frac: exact - fl };
  });
  let rest = total - parts.reduce((a, p) => a + p.cents, 0);
  [...parts].sort((a, b) => b.frac - a.frac || a.i - b.i).forEach(p => { if (rest > 0) { p.cents += 1; rest -= 1; } });
  return parts.map(p => p.cents);
}

/** ¿La letra discrimina IVA? Solo la A (la M no se usa) */
export const discriminates = letter => letter === 'A';

/** Letra que corresponde según el comercio (comprador) y el proveedor (emisor) */
export function defaultLetter(businessIva, supplierIva) {
  if (supplierIva === 'RI') return businessIva === 'RI' ? 'A' : 'B';
  if (supplierIva === 'MT' || supplierIva === 'EX') return 'C';
  return 'X';
}

/**
 * Cálculo completo de un comprobante de compra (como el panel de totales de SGI).
 * input: {
 *   items: [{qty, unit_cost, disc1, disc2, iva_rate}], discounts: [pct1, pct2, pct3], letter,
 *   iva_override: {"21": pesos, ...} (IVA editado a mano para cuadrar con la factura),
 *   non_taxed, perc_iva, perc_iibb, other_taxes, ret_iva, ret_gan, ret_iibb (pesos),
 *   invoice_total (TOTAL FACTURA tipeado; opcional), tolerance (centavos que se ajustan solos, 100 = $ 1)
 * }
 * Devuelve pesos: {lines:[{cents, net_unit}], neto, discounts:[{pct, amount}], subtotal, iva_lines:[{rate, base, amount}],
 *   exempt, gravado, iva, non_taxed, perc_iva, perc_iibb, other_taxes, ret, total, to_pay, invoice_total, diff, adjusted, ok}
 * Con letra A el IVA se calcula por alícuota sobre la base de cada una (los descuentos generales prorrateados).
 * Con B, C y X no se discrimina: todo es "subtotal" (el IVA está incluido en los precios).
 * diff = TOTAL FACTURA − calculado. Si |diff| ≤ tolerance se ajusta (en el IVA mayor con A, en el neto con B/C/X).
 */
export function computePurchase(input = {}) {
  const items = input.items || [];
  const letter = LETTERS.includes(input.letter) ? input.letter : 'X';
  const disc = discriminates(letter);
  const tolerance = input.tolerance === undefined ? 100 : input.tolerance;
  const lines = items.map(it => lineCents(it.qty, it.unit_cost, it.disc1, it.disc2));
  const neto = lines.reduce((a, c) => a + c, 0);
  const d = chainDiscounts(neto, input.discounts || []);
  const subtotal = d.rest;
  // Base por alícuota: el subtotal (con los descuentos generales) repartido en proporción a cada renglón
  const groups = new Map();
  items.forEach((it, i) => {
    const r = disc ? Number(it.iva_rate) || 0 : 0;
    groups.set(r, (groups.get(r) || 0) + lines[i]);
  });
  const rates = [...groups.keys()].sort((a, b) => b - a);
  const shares = allocate(subtotal, rates.map(r => Math.max(0, groups.get(r))));
  const base = new Map(rates.map((r, i) => [r, shares[i]]));
  const ov = input.iva_override || {};
  let ivaLines = [];
  let exempt = 0;
  for (const r of rates) {
    if (!r) { exempt += base.get(r); continue; }
    const auto = Number(bdiv(BigInt(base.get(r)) * scaled(r, 3), 100000n));
    const o = ov[String(r)];
    const amount = o !== undefined && o !== null && o !== '' && Number.isFinite(Number(o)) ? toCents(o) : auto;
    ivaLines.push({ rate: r, base: base.get(r), amount, auto });
  }
  // IVA cargado a mano en una alícuota que no tiene renglones (p. ej. un flete al 10,5)
  if (disc) {
    for (const [k, v] of Object.entries(ov)) {
      const r = Number(k);
      if (!PURCHASE_RATES.includes(r) || base.has(r) || v === '' || v === null || !Number.isFinite(Number(v)) || !toCents(v)) continue;
      ivaLines.push({ rate: r, base: 0, amount: toCents(v), auto: 0 });
    }
  }
  ivaLines.sort((a, b) => b.rate - a.rate);
  const c = k => toCents(input[k] || 0);
  const extra = c('non_taxed') + c('perc_iva') + c('perc_iibb') + c('other_taxes');
  const gravado = disc ? subtotal - exempt : subtotal;
  let iva = ivaLines.reduce((a, l) => a + l.amount, 0);
  let total = subtotal + iva + extra;
  let netAdj = 0;
  const hasInvoice = input.invoice_total !== undefined && input.invoice_total !== null && input.invoice_total !== '' && Number.isFinite(Number(input.invoice_total));
  const invoice = hasInvoice ? toCents(input.invoice_total) : null;
  let diff = hasInvoice ? invoice - total : 0;
  let adjusted = 0;
  if (hasInvoice && diff !== 0 && Math.abs(diff) <= tolerance) {
    // Diferencia de redondeo: se ajusta para que cuadre con la factura
    const big = ivaLines.filter(l => l.amount).sort((a, b) => b.amount - a.amount)[0];
    if (disc && big) { big.amount += diff; iva += diff; } else netAdj = diff;
    total += diff;
    adjusted = diff;
    diff = 0;
  }
  const ret = c('ret_iva') + c('ret_gan') + c('ret_iibb');
  // Costo neto por unidad de cada renglón (con los descuentos del renglón y los generales)
  const factor = neto ? subtotal / neto : 1;
  const netUnits = items.map((it, i) => {
    const q = round3(it.qty);
    return q ? round2((lines[i] * factor) / 100 / q) : 0;
  });
  return {
    letter, discriminates: disc,
    lines: lines.map((cents, i) => ({ cents: fromCents(cents), net_unit: netUnits[i] })),
    neto: fromCents(neto),
    discounts: d.list.map(x => ({ pct: x.pct, amount: fromCents(x.amount) })),
    subtotal: fromCents(subtotal + netAdj),
    exempt: fromCents(exempt),
    gravado: fromCents(gravado + netAdj),
    iva_lines: ivaLines.map(l => ({ rate: l.rate, base: fromCents(l.base), amount: fromCents(l.amount), auto: fromCents(l.auto) })),
    iva: fromCents(iva),
    non_taxed: fromCents(c('non_taxed')), perc_iva: fromCents(c('perc_iva')), perc_iibb: fromCents(c('perc_iibb')),
    other_taxes: fromCents(c('other_taxes')),
    ret_iva: fromCents(c('ret_iva')), ret_gan: fromCents(c('ret_gan')), ret_iibb: fromCents(c('ret_iibb')),
    ret: fromCents(ret),
    total: fromCents(total),
    to_pay: fromCents(total - ret),
    invoice_total: hasInvoice ? fromCents(invoice) : null,
    diff: fromCents(diff), adjusted: fromCents(adjusted),
    ok: !hasInvoice || diff === 0,
  };
}

/** +1 factura / nota de débito, −1 nota de crédito */
export const purchaseSign = p => (p && p.doc_type === 'NC' ? -1 : 1);
export const isVoidPurchase = p => !p || p.deleted || p.status === 'anulada';

/** Lo que hay que pagarle al proveedor por un comprobante (total − retenciones), con signo (NC negativa) */
export function purchaseToPay(p) {
  if (isVoidPurchase(p)) return 0;
  const ret = toCents(p.ret_iva || 0) + toCents(p.ret_gan || 0) + toCents(p.ret_iibb || 0);
  return fromCents(purchaseSign(p) * (toCents(p.total) - ret));
}

/**
 * Costo que queda en el producto al "actualizar costos".
 * Comercio RI: el IVA de una factura A es crédito fiscal → costo NETO. Monotributo o exento: costo CON IVA.
 * Con B/C/X el unitario ya trae el IVA incluido (no se discrimina).
 */
export function costForProduct({ netUnit, ivaRate = 0, letter = 'X', businessIva = 'MT' }) {
  if (letter === 'A' && businessIva !== 'RI') return round2(netUnit * (1 + (Number(ivaRate) || 0) / 100));
  return round2(netUnit);
}

/**
 * Precio de venta recalculado al cambiar el costo.
 * mode "keep": mantiene el margen actual (precio × costo nuevo / costo viejo). Sin costo viejo, no cambia.
 * mode "pct": costo × (1 + margen %) y, si el costo es neto (comercio RI), más el IVA del producto.
 * Redondea a centavos.
 */
export function recalcPrice({ price = 0, oldCost = 0, newCost = 0, ivaRate = 21, mode = 'keep', pct = 0, businessIva = 'MT' }) {
  if (!(newCost > 0)) return round2(price);
  if (mode === 'pct') {
    const withIva = businessIva === 'RI' ? 1 + (Number(ivaRate) || 0) / 100 : 1;
    return round2(newCost * (1 + (Number(pct) || 0) / 100) * withIva);
  }
  if (!(oldCost > 0) || !(price > 0)) return round2(price);
  return round2((price * newCost) / oldCost);
}

/** Normaliza "5-42169" / "00005-00042169" / "0005 42169" → "00005-00042169" (4 o 5 dígitos de punto de venta) */
export function fmtDocNumber(s) {
  const m = String(s || '').trim().match(/^(\d{1,5})\D+(\d{1,8})$/);
  if (!m) return String(s || '').trim();
  return `${m[1].padStart(5, '0')}-${m[2].padStart(8, '0')}`;
}

/** "FC A 00005-00042169" */
export function purchaseDocLabel(p) {
  if (!p) return '';
  const t = p.doc_type || (p.letter || p.doc_number ? 'FC' : '');
  const parts = [t, p.letter, p.doc_number || p.invoice_ref].filter(Boolean);
  return parts.join(' ');
}

// ---------- Libro IVA Compras ----------

export const IVA_BOOK_PURCHASE_COLS = [
  ['n21', 'Neto 21%'], ['i21', 'IVA 21%'], ['n105', 'Neto 10,5%'], ['i105', 'IVA 10,5%'], ['n27', 'Neto 27%'], ['i27', 'IVA 27%'],
  ['notras', 'Neto otras alíc.'], ['iotras', 'IVA otras alíc.'], ['nograv', 'No grav. / exento / sin CF'],
  ['perc_iva', 'Percep. IVA'], ['perc_iibb', 'Percep. IIBB'], ['otros', 'Otros imp.'], ['total', 'Total'],
  ['ret_iva', 'Ret. IVA'], ['ret_gan', 'Ret. Ganancias'], ['ret_iibb', 'Ret. IIBB'],
];
const KEY_OF = { 21: ['n21', 'i21'], 10.5: ['n105', 'i105'], 27: ['n27', 'i27'] };

/**
 * Fila del Libro IVA Compras de un comprobante (pesos, NC en negativo).
 * Con letra A: neto e IVA por alícuota (de iva_lines). B, C, X y las compras viejas (sin letra): todo a "sin crédito fiscal".
 * Siempre: n + i + nograv + percepciones + otros = total (lo que falte por redondeo va a "no gravado").
 */
export function purchaseIvaRow(p) {
  const sign = purchaseSign(p);
  const cents = {};
  for (const [k] of IVA_BOOK_PURCHASE_COLS) cents[k] = 0;
  const total = toCents(p.total);
  if (discriminates(p.letter) && Array.isArray(p.iva_lines)) {
    for (const l of p.iva_lines) {
      const [nk, ik] = KEY_OF[Number(l.rate)] || ['notras', 'iotras'];
      cents[nk] += toCents(l.base);
      cents[ik] += toCents(l.amount);
    }
  }
  cents.perc_iva = toCents(p.perc_iva || 0);
  cents.perc_iibb = toCents(p.perc_iibb || 0);
  cents.otros = toCents(p.other_taxes || 0);
  const known = Object.entries(cents).reduce((a, [k, v]) => a + (k === 'nograv' ? 0 : v), 0);
  cents.nograv = total - known;
  cents.total = total;
  cents.ret_iva = toCents(p.ret_iva || 0);
  cents.ret_gan = toCents(p.ret_gan || 0);
  cents.ret_iibb = toCents(p.ret_iibb || 0);
  const out = {};
  for (const [k, v] of Object.entries(cents)) out[k] = fromCents(sign * v);
  return out;
}

/** Fecha contable de una compra: la del comprobante (doc_date "AAAA-MM-DD") o, si no tiene, la de carga */
export function purchaseDate(p) {
  if (p && /^\d{4}-\d{2}-\d{2}$/.test(String(p.doc_date || ''))) {
    const [y, m, d] = p.doc_date.split('-').map(Number);
    const [hh, mm] = /^\d{1,2}:\d{2}$/.test(String(p.time || '')) ? p.time.split(':').map(Number) : [12, 0];
    return new Date(y, m - 1, d, hh, mm).getTime();
  }
  return Number(p && p.created_at) || 0;
}

// ---------- Libro IVA Ventas (mismo reparto que ARCA) ----------

/** Id de alícuota de ARCA → tasa */
export const RATE_OF_IVA_ID = { 3: 0, 4: 10.5, 5: 21, 6: 27, 8: 5, 9: 2.5 };

/**
 * Neto e IVA por alícuota de una venta o devolución, igual que el Worker al pedir el CAE (server/src/arca/invoice.js →
 * computeAmounts): se agrupan los subtotales por alícuota, el TOTAL se reparte entre ellas por mayor resto y
 * neto = round(importe / (1 + tasa)). Si el comprobante autorizado trae su IVA (doc.iva), se usa ese (lo que informó ARCA).
 * discrimina = false (emisor MT/EX, factura C): todo va a la alícuota 0 (no gravado).
 * Devuelve {"21": {net, iva, total}, ...} en pesos.
 */
export function ivaBookBreakdown(items, total, discrimina = true, docIva = null) {
  const out = {};
  const add = (rate, net, iva) => {
    const k = String(rate);
    out[k] = out[k] || { net: 0, iva: 0, total: 0 };
    out[k].net = fromCents(toCents(out[k].net) + net);
    out[k].iva = fromCents(toCents(out[k].iva) + iva);
    out[k].total = fromCents(toCents(out[k].total) + net + iva);
  };
  const totalC = toCents(total);
  if (!discrimina) { add(0, totalC, 0); return out; }
  if (Array.isArray(docIva) && docIva.length) {
    let sum = 0;
    for (const a of docIva) {
      const rate = RATE_OF_IVA_ID[a.id] ?? 0;
      const net = toCents(a.base), iva = toCents(a.importe);
      sum += net + iva;
      add(rate, net, iva);
    }
    if (sum !== totalC) add(0, totalC - sum, 0);
    return out;
  }
  const groups = new Map();
  for (const it of items || []) {
    const r = Number(it.iva_rate) || 0;
    groups.set(r, (groups.get(r) || 0) + toCents(it.subtotal));
  }
  const positive = [...groups.entries()].filter(([, v]) => v > 0);
  if (!positive.length) { if (totalC) add(0, totalC, 0); return out; }
  // Mismo desempate que el Worker: mayor resto y, a igual resto, la alícuota más alta
  const weight = positive.reduce((a, [, v]) => a + v, 0);
  const shares = positive.map(([rate, v]) => { const exact = (totalC * v) / weight; return { rate, cents: Math.floor(exact), frac: exact - Math.floor(exact) }; });
  let rest = totalC - shares.reduce((a, s) => a + s.cents, 0);
  [...shares].sort((a, b) => b.frac - a.frac || b.rate - a.rate).forEach(s => { if (rest > 0) { s.cents += 1; rest -= 1; } });
  for (const s of shares) {
    const net = Math.round(s.cents / (1 + s.rate / 100));
    add(s.rate, net, s.cents - net);
  }
  return out;
}

// ---------- Precios de venta al cambiar el costo (Ajustes → Precios, carga con foto) ----------

/** Redondeo del precio de venta: hacia arriba al múltiplo de step ($1, $10, $50, $100); 0 o vacío = a centavos */
export function roundPrice(x, step = 0) {
  const v = Number(x) || 0;
  const s = Number(step) || 0;
  if (!(v > 0)) return 0;
  if (!(s > 0)) return round2(v);
  return round2(Math.ceil(round2(v / s) - 1e-9) * s);
}

/** Margen actual del producto sobre el costo (precio / costo − 1), en %. null si falta precio o costo. */
export function productMarginPct(p) {
  const price = Number(p && p.price) || 0, cost = Number(p && p.cost) || 0;
  if (!(price > 0) || !(cost > 0)) return null;
  return round2((price / cost - 1) * 100);
}

/**
 * Margen a usar para un producto: settings.price_margin_mode "producto" (por defecto: el margen que ya tiene; si no tiene, el de su
 * rubro y si no el general) o "rubro" (siempre el del rubro o el general de Ajustes → Precios).
 * Devuelve {pct, source: 'producto'|'rubro'|'general'} o null si no hay ninguno.
 */
export function marginFor(p, st = {}) {
  const own = productMarginPct(p);
  const mode = st.price_margin_mode === 'rubro' ? 'rubro' : 'producto';
  if (mode === 'producto' && own !== null) return { pct: own, source: 'producto' };
  const cat = String((p && p.category) || '').trim().toLowerCase();
  const byCat = (Array.isArray(st.category_margins) ? st.category_margins : []).find(x => x && String(x.category || '').trim().toLowerCase() === cat && Number(x.pct) >= 0 && x.pct !== null && x.pct !== '');
  if (cat && byCat) return { pct: Number(byCat.pct), source: 'rubro' };
  if (st.price_margin !== null && st.price_margin !== undefined && st.price_margin !== '' && Number(st.price_margin) >= 0) return { pct: Number(st.price_margin), source: 'general' };
  if (own !== null) return { pct: own, source: 'producto' };
  return null;
}

/**
 * Precio nuevo = costo nuevo × (1 + margen). Con el margen propio del producto (precio/costo) el IVA ya está adentro; con el del
 * rubro o el general (margen sobre el costo), si el comercio es RI (costo neto) se suma el IVA del producto. Redondeo de Ajustes.
 * Devuelve {price, pct, source, from, change_pct} o null si no hay margen o costo.
 */
export function suggestPrice({ product, newCost, settings: st = {}, businessIva = 'MT' }) {
  const m = marginFor(product, st);
  const cost = Number(newCost) || 0;
  if (!m || !(cost > 0)) return null;
  const iva = m.source !== 'producto' && businessIva === 'RI' ? 1 + (Number(product.iva_rate ?? 21) || 0) / 100 : 1;
  const price = roundPrice(cost * (1 + m.pct / 100) * iva, st.price_round);
  const from = round2(Number(product.price) || 0);
  return { price, pct: m.pct, source: m.source, from, change_pct: from > 0 ? round2((price / from - 1) * 100) : null };
}

/** % de cambio de un valor (costo viejo → nuevo). null si no había valor. */
export function changePct(oldV, newV) {
  const o = Number(oldV) || 0;
  return o > 0 ? round2(((Number(newV) || 0) / o - 1) * 100) : null;
}
/** Suba que conviene mirar dos veces (posible error de lectura o de tipeo) */
export const BIG_RISE_PCT = 30;
