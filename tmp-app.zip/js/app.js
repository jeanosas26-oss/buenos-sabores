// =====================================================================
// app.js — Arranque, navegación, menú y barra de estado.
// =====================================================================
import * as db from './db.js';
import * as sync from './sync.js';
import { ctx, settings, branches, currentBranch, multiBranch, resolveDeviceBranch, setDeviceBranch, openSession, retryPendingArca } from './ops.js';
import { initStorage } from './durability.js';
import { html, $, on, ic, icon, modal, toast, esc } from './ui.js';
import { can, ROLES, isSensitive } from './logic.js';
import * as login from './views/login.js';
import * as backup from './backup.js';
import { initAtajos, helpDialog } from './atajos.js';
import { daysSince } from './logic.js';
import { unlockAudio, audioReady } from './scanner.js';

// El sonido del lector se destraba con el primer toque (iPhone no deja hacerlo después, sin un toque)
const AUDIO_EVENTS = ['touchend', 'pointerup', 'keydown'];
function unlockOnTap() {
  unlockAudio();
  setTimeout(() => { if (audioReady()) AUDIO_EVENTS.forEach(t => window.removeEventListener(t, unlockOnTap, true)); }, 50);
}
AUDIO_EVENTS.forEach(t => window.addEventListener(t, unlockOnTap, true));

// Pantallas (se cargan cuando se usan)
const ROUTES = {
  // Tablero del día (dueño y encargado). La pantalla de inicio sigue siendo Vender: arriba se ve el resumen de hoy.
  hoy: { title: 'Hoy', icon: 'chart', perm: 'tablero', load: () => import('./views/hoy.js') },
  vender: { title: 'Vender', icon: 'cart', load: () => import('./views/vender.js') },
  caja: { title: 'Caja', icon: 'cash', load: () => import('./views/caja.js') },
  productos: { title: 'Productos', icon: 'box', load: () => import('./views/productos.js') },
  ventas: { title: 'Ventas', icon: 'receipt', load: () => import('./views/ventas.js') },
  clientes: { title: 'Clientes', icon: 'users', load: () => import('./views/clientes.js') },
  // Compras: cajero y vendedor entran solo a cargar compras (sin proveedores, Libro IVA ni liquidación)
  compras: { title: 'Compras', short: 'Compras', icon: 'truck', perm: 'cargar_compras', load: () => import('./views/compras.js') },
  proveedores: { title: 'Proveedores', icon: 'users', perm: 'compras', load: () => import('./views/compras.js') },
  // Gastos (cajero y vendedor: solo en efectivo que sale de su caja) y Tesorería: balance, cheques, bancos, cajas cerradas,
  // caja diaria y recalcular stock y saldos (solo el dueño)
  gastos: { title: 'Gastos', icon: 'receipt', perm: ['gastos', 'compras'], load: () => import('./views/gastos.js') },
  tesoreria: { title: 'Tesorería', icon: 'cash', perm: 'reportes', load: () => import('./views/tesoreria.js') },
  reportes: { title: 'Reportes', icon: 'chart', perm: 'reportes', load: () => import('./views/reportes.js') },
  // Comisiones de vendedores (por venta o por cobranza)
  comisiones: { title: 'Comisiones', icon: 'users', perm: 'reportes', load: () => import('./views/comisiones.js') },
  // Ventas como SGI: presupuestos y pedidos, promociones, pedidos a proveedores, vencimientos, informes,
  // y (desde Productos / Ajustes) rubros, etiquetas de góndola, tarjetas y medios de pago
  presupuestos: { title: 'Presupuestos', icon: 'receipt', load: () => import('./views/presupuestos.js') },
  promociones: { title: 'Promociones', icon: 'tag', perm: 'editar_productos', load: () => import('./views/promociones.js') },
  pedidos_prov: { title: 'Pedidos a proveedores', short: 'Pedidos', icon: 'truck', perm: 'compras', load: () => import('./views/pedidos-prov.js') },
  vencimientos: { title: 'Vencimientos', icon: 'alert', perm: ['editar_productos', 'ajustar_stock'], load: () => import('./views/vencimientos.js') },
  informes: { title: 'Informes', icon: 'chart', perm: 'reportes', load: () => import('./views/informes.js') },
  rubros: { title: 'Rubros y subrubros', icon: 'box', perm: 'editar_productos', hidden: true, load: () => import('./views/rubros.js') },
  etiquetas: { title: 'Etiquetas de góndola', icon: 'tag', perm: 'editar_productos', hidden: true, load: () => import('./views/etiquetas.js') },
  medios: { title: 'Tarjetas y medios de pago', icon: 'cash', perm: 'usuarios', hidden: true, load: () => import('./views/medios.js') },
  // Remitos entre sucursales: solo con más de una sucursal (recibir lo puede hacer cualquiera)
  remitos: { title: 'Remitos', icon: 'truck', when: () => multiBranch(), load: () => import('./views/remitos.js') },
  ajustes: { title: 'Ajustes', icon: 'gear', perm: 'ajustes', load: () => import('./views/ajustes.js') },
  // Se entra desde Productos → "Contar stock" (no va en el menú)
  conteo: { title: 'Contar stock', icon: 'scale', perm: 'ajustar_stock', hidden: true, load: () => import('./views/conteo.js') },
  // Fotos faltantes: sacar en góndola las fotos de los productos que no tienen (dueño y encargado, como las fotos)
  fotos: { title: 'Fotos faltantes', icon: 'camera', perm: 'fotos', hidden: true, load: () => import('./views/fotos.js') },
  // Registro de acciones sensibles y faltantes por cajero (solo el dueño)
  auditoria: { title: 'Auditoría', icon: 'lock', perm: 'auditoria', load: () => import('./views/auditoria.js') },
};
const BOTTOM = ['vender', 'caja', 'productos', 'ventas'];

const root = $('#root');
let current = { name: null, cleanup: null };
let installEvt = null;

export const app = {
  navigate(name) { location.hash = '#/' + name; },
  rerender() { renderRoute(true); },
  logout,
  /** El usuario de esta sesión pasa a ser otro (p. ej. el dueño local enlazado con su usuario de la nube) */
  switchUser(u) { if (!u) return; ctx.user = u; saveUserId(u.id); sync.setUser(u); },
  isIOS: /iphone|ipad|ipod/i.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1),
  isStandalone: () => window.matchMedia('(display-mode: standalone)').matches || navigator.standalone === true,
  canInstall: () => !!installEvt,
  install,
  changeBranch,
  loggedIn: () => !!ctx.user && !!document.querySelector('#main'),
  current: () => current.name,
};

// ---------- Instalación como app ----------

window.addEventListener('beforeinstallprompt', e => {
  e.preventDefault();
  installEvt = e;
  updateInstallButtons();
});
window.addEventListener('appinstalled', () => { installEvt = null; updateInstallButtons(); toast('¡App instalada!'); });

function updateInstallButtons() {
  const show = !app.isStandalone() && (installEvt || app.isIOS);
  document.querySelectorAll('[data-install]').forEach(b => b.classList.toggle('hidden', !show));
}

async function install() {
  if (installEvt) {
    installEvt.prompt();
    await installEvt.userChoice.catch(() => null);
    installEvt = null;
    updateInstallButtons();
    return;
  }
  await modal({
    title: 'Instalar en iPhone / iPad',
    body: html`<ol class="lead stack">
      <li>Abrí esta página en <b>Safari</b>.</li>
      <li>Tocá el botón <b>Compartir</b> (el cuadrado con la flecha hacia arriba).</li>
      <li>Elegí <b>“Agregar a inicio”</b> y después <b>Agregar</b>.</li>
      <li>Listo: abrila desde el ícono verde del carrito.</li></ol>`,
    actions: [{ label: 'Entendido', kind: 'primary', value: true }],
  });
}

// ---------- Sesión ----------

function savedUserId() { try { return localStorage.getItem('jg_user'); } catch (e) { return null; } }
function saveUserId(id) {
  try { if (id) localStorage.setItem('jg_user', id); else localStorage.removeItem('jg_user'); } catch (e) { /* sin almacenamiento: se pide PIN cada vez */ }
  // También en la base (se guarda en disco enseguida): después de un corte de luz, localStorage puede no haberse escrito
  db.setMeta('current_user', id || null).catch(() => {});
}

export async function startSession(user) {
  ctx.user = user;
  saveUserId(user.id);
  // La nube aplica el rol de quien entró: la sincronización usa la sesión de este usuario (equipo autorizado)
  sync.setUser(user);
  // Cada equipo trabaja en una sucursal: si hay varias y este equipo todavía no eligió, se pregunta
  const b = await resolveDeviceBranch();
  if (!b) {
    if (current.cleanup) { try { current.cleanup(); } catch (e) { console.warn(e); } }
    current = { name: null, cleanup: null };
    login.chooseBranch(root, branches(), async id => { await setDeviceBranch(id); enterApp(); });
    return;
  }
  enterApp();
}

function enterApp() {
  renderShell();
  if (!location.hash || location.hash === '#/' || location.hash === '#') location.hash = '#/vender';
  renderRoute(true);
}

// ---------- Sucursal de este equipo ----------

function branchChip() {
  const b = $('#branch-chip');
  if (!b) return;
  const cur = currentBranch();
  const show = !!cur && multiBranch();
  b.classList.toggle('hidden', !show);
  b.parentElement.classList.toggle('has-branch', show);
  if (!show) return;
  b.innerHTML = icon('store') + `<span>${esc(cur.name)}</span>`;
  b.title = `Sucursal: ${cur.name}`;
  b.setAttribute('aria-label', `Sucursal ${cur.name}. Tocá para cambiar`);
}

/** Cambiar la sucursal de este equipo (dueño o encargado) */
async function changeBranch() {
  const cur = currentBranch();
  if (!can(ctx.user, 'cambiar_sucursal')) {
    toast(`Este equipo trabaja en ${cur ? cur.name : 'una sucursal'}. Para cambiarla pedile al dueño o al encargado.`, 'warn', 5000);
    return false;
  }
  const list = branches();
  const id = await modal({
    title: 'Sucursal de este equipo',
    body: html`<p class="muted">Las ventas, la caja, las compras y el stock que cargues en este equipo van a ser de la sucursal que elijas. Los productos y precios son los mismos en todas.</p>
      <div class="stack">${list.map(b => html`<button type="button" class="btn ${cur && b.id === cur.id ? 'primary' : 'ghost'} big block" data-branch="${b.id}" aria-pressed="${!!cur && b.id === cur.id}">
        ${ic('store')} ${b.name} <span class="small" style="font-weight:400">· Pto. vta. ${b.pos_number}</span></button>`)}</div>`,
    onMount(m, close) { m.addEventListener('click', e => { const el = e.target.closest('[data-branch]'); if (el) close(el.dataset.branch); }); },
    actions: [{ label: 'Cancelar', value: null }],
  });
  if (!id || (cur && id === cur.id)) return false;
  await setDeviceBranch(id);
  const b = currentBranch();
  branchChip();
  toast(`Ahora este equipo trabaja en ${b.name}.${openSession() ? '' : ' La caja de esta sucursal está cerrada.'}`, 'ok', 4500);
  renderRoute(true);
  return true;
}

function logout() {
  ctx.user = null;
  saveUserId(null);
  sync.setUser(null);
  if (current.cleanup) { try { current.cleanup(); } catch (e) { console.warn(e); } }
  current = { name: null, cleanup: null };
  login.render(root, { onLogin: startSession, app });
}

// ---------- Estructura ----------

/** ¿El usuario puede entrar a la pantalla? (perm: un permiso o una lista: alcanza con uno) */
function allowed(r) { return !r.perm || [].concat(r.perm).some(p => can(ctx.user, p)); }

function navItems() {
  return Object.entries(ROUTES).filter(([, r]) => !r.hidden && allowed(r) && (!r.when || r.when()));
}

function navList() {
  return html`<ul class="navlist">
    ${navItems().map(([k, r]) => html`<li><a href="#/${k}" data-route="${k}">${ic(r.icon)}<span>${r.title}</span></a></li>`)}
    ${can(ctx.user, 'reportes') ? html`<li><button type="button" data-ia>${ic('chart')}<span>Asistente IA</span></button></li>` : ''}
    <li class="kbd-only"><button type="button" data-atajos>${ic('menu')}<span>Atajos de teclado (F1)</span></button></li>
    <li><button type="button" data-install class="hidden">${ic('install')}<span>Instalar app</span></button></li>
  </ul>
  <div class="nav-user">
    <div class="row" style="border:0;min-height:0;padding:.3rem .9rem">
      <div class="avatar" aria-hidden="true">${(ctx.user.name || '?')[0].toUpperCase()}</div>
      <div class="grow"><div class="title">${ctx.user.name}</div><div class="sub">${ROLES[ctx.user.role] || ''}</div></div>
    </div>
    <ul class="navlist"><li><button type="button" data-logout>${ic('lock')}<span>Cambiar usuario</span></button></li></ul>
  </div>`;
}

function brand() {
  const st = settings();
  return html`<div class="brand"><img src="icons/icon-192.png" alt=""><div><b>${st.business_name || 'JEANO Gestión'}</b><small>JEANO Gestión</small></div></div>`;
}

function renderShell() {
  root.innerHTML = String(html`
    <a href="#main" class="sr-only">Saltar al contenido</a>
    <div class="app">
      <nav class="sidenav" aria-label="Menú principal">${brand()}${navList()}</nav>
      <div class="content">
        <header class="topbar">
          <button type="button" class="icon-btn menu-btn" data-menu aria-label="Abrir menú">${ic('menu')}</button>
          <h1 id="page-title">JEANO Gestión</h1>
          <time id="clock" class="clock" aria-live="off"></time>
          <button type="button" class="branch-chip hidden" id="branch-chip"></button>
          <button type="button" class="ia-btn hidden" id="ia-btn" aria-label="Asistente IA: preguntale a la IA sobre tu comercio" title="Asistente IA">IA</button>
          <button type="button" class="sync-pill" id="sync-pill" aria-live="polite"></button>
        </header>
        <div id="backup-banner" class="banner-slot" aria-live="polite"></div>
        <div id="cloud-banner" class="banner-slot" aria-live="polite"></div>
        <main class="main" id="main" tabindex="-1"></main>
      </div>
      <nav class="bottomnav" aria-label="Accesos rápidos">
        ${BOTTOM.map(k => html`<a href="#/${k}" data-route="${k}">${ic(ROUTES[k].icon)}<span>${ROUTES[k].short || ROUTES[k].title}</span></a>`)}
        <button type="button" data-menu aria-label="Más opciones">${ic('more')}<span>Más</span></button>
      </nav>
    </div>`);
  updateInstallButtons();
  syncPill(sync.status);
  branchChip();
  iaButton();
  backupBanner();
}

/** Abre el asistente IA */
function openIA() { import('./views/ia.js').then(m => m.openAssistant()).catch(e => toast(e.message, 'error')); }

/** Botón "IA" (asistente) de la barra: para quien tiene el permiso de reportes */
function iaButton() {
  const b = $('#ia-btn');
  if (b) b.classList.toggle('hidden', !(ctx.user && can(ctx.user, 'reportes')));
}

// ---------- Aviso de copia de seguridad (solo dueño) ----------

let bannerLater = false; // "Más tarde": no se vuelve a mostrar hasta que se abra de nuevo la app

async function backupBanner() {
  const el = $('#backup-banner');
  if (!el) return;
  let body = '';
  if (ctx.user && ctx.user.role === 'dueno' && !bannerLater) {
    if (backup.state.status === 'needs-permission') {
      body = html`<div class="notice notice-warn banner"><p><b>La copia automática diaria está en pausa.</b> El navegador pide permiso otra vez para guardar en la carpeta
        “${backup.state.folder || 'de respaldo'}”. Es un clic.</p>
        <div class="btn-row"><button type="button" class="btn primary sm" data-bk="regrant">${ic('check')} Volver a permitir</button>
        <button type="button" class="btn ghost sm" data-bk="later">Más tarde</button></div></div>`;
    } else if (await backup.reminderDue()) {
      const last = await db.getMeta('last_backup', 0);
      body = html`<div class="notice notice-warn banner"><p><b>${last ? `Hace ${daysSince(last)} días que no hacés una copia de seguridad.` : 'Todavía no hiciste ninguna copia de seguridad.'}</b>
        Bajala y guardala en el mail, Drive o un pendrive.${backup.supported() ? ' En Ajustes podés hacer que se guarde sola todos los días en una carpeta de esta PC.' : ''}</p>
        <div class="btn-row"><button type="button" class="btn primary sm" data-bk="download">${ic('download')} Descargar copia</button>
        <button type="button" class="btn ghost sm" data-bk="later">Más tarde</button></div></div>`;
    }
  }
  if (!$('#backup-banner')) return;
  el.innerHTML = String(body);
}

async function bannerAct(name) {
  if (name === 'later') { bannerLater = true; return backupBanner(); }
  if (name === 'download') { await backup.downloadBackup(); toast('Copia descargada. Guardala en un lugar seguro.'); }
  if (name === 'regrant') {
    const r = await backup.regrant();
    if (r.status === 'done') toast(`Listo: copia guardada (${r.file}).`);
    else if (r.status === 'needs-permission') toast('El navegador no dio permiso. Podés volver a intentar o elegir la carpeta otra vez en Ajustes.', 'warn', 5000);
    else if (r.status === 'error') toast('No se pudo guardar la copia: ' + r.error, 'error', 6000);
  }
  backupBanner();
  if (current.name === 'ajustes') renderRoute(true);
}

function openDrawer() {
  const wrap = document.createElement('div');
  wrap.className = 'drawer-wrap';
  wrap.innerHTML = String(html`<nav class="drawer" aria-label="Menú">${brand()}${navList()}</nav>`);
  document.body.appendChild(wrap);
  markCurrent(wrap);
  updateInstallButtons();
  const close = () => { wrap.remove(); document.removeEventListener('keydown', k); };
  const k = e => { if (e.key === 'Escape') close(); };
  document.addEventListener('keydown', k);
  wrap.addEventListener('click', e => {
    if (e.target === wrap || e.target.closest('a')) close();
    if (e.target.closest('[data-logout]')) { close(); logout(); }
    if (e.target.closest('[data-install]')) { close(); install(); }
    if (e.target.closest('[data-ia]')) { close(); openIA(); }
  });
  const first = wrap.querySelector('a');
  if (first) first.focus();
}

function markCurrent(scope = document) {
  scope.querySelectorAll('[data-route]').forEach(a => {
    if (a.dataset.route === current.name) a.setAttribute('aria-current', 'page');
    else a.removeAttribute('aria-current');
  });
}

/** Aviso fijo si el dueño le quitó el acceso a este equipo o si hace falta el PIN para subir lo cargado */
function cloudBanner(s) {
  const el = $('#cloud-banner');
  if (!el) return;
  let body = '';
  if (s.configured && s.revoked) {
    body = html`<div class="notice notice-error banner" id="cb-revoked"><p><b>Este equipo ya no tiene acceso a la nube.</b> Lo que cargues queda guardado acá${s.pending ? ` (${s.pending} cambios esperando)` : ''}; para volver a sincronizar, el dueño lo tiene que conectar de nuevo con su email y contraseña (Ajustes → Nube).</p></div>`;
  } else if (s.configured && s.needPin && s.online && s.pending) {
    body = html`<div class="notice notice-warn banner" id="cb-pin"><p><b>Hay ${s.pending} cambios sin subir a la nube.</b> ${s.pinError || 'Ingresá tu PIN para sincronizar.'}</p>
      <div class="btn-row"><button type="button" class="btn primary sm" data-cloudpin>${ic('cloud')} Ingresar PIN</button></div></div>`;
  }
  if (el.dataset.html !== String(body)) { el.dataset.html = String(body); el.innerHTML = String(body); }
}

function syncPill(s) {
  cloudBanner(s);
  const b = $('#sync-pill');
  if (!b) return;
  const text = sync.statusText(s);
  b.className = 'sync-pill ' + (!s.configured ? '' : s.error || s.authError ? 'err' : s.pending || !s.online ? '' : 'ok');
  b.innerHTML = icon(s.configured ? 'cloud' : 'device') + `<span>${esc(text)}</span>`;
  b.title = s.error || text;
}

// ---------- Rutas ----------

async function renderRoute(force = false) {
  if (!ctx.user) return;
  let name = (location.hash.replace(/^#\/?/, '').split('?')[0]) || 'vender';
  if (!ROUTES[name]) name = 'vender';
  const r = ROUTES[name];
  if (!allowed(r)) {
    toast('Tu usuario no tiene permiso para entrar ahí.', 'warn');
    name = 'vender';
    location.replace('#/vender');
  }
  if (!force && name === current.name) return;
  if (current.cleanup) { try { current.cleanup(); } catch (e) { console.warn(e); } }
  const changed = name !== current.name;
  current = { name, cleanup: null };
  document.body.classList.remove('has-paybar');
  $('#page-title').textContent = ROUTES[name].title;
  document.title = `${ROUTES[name].title} · JEANO Gestión`;
  markCurrent();
  let main = $('#main');
  try {
    // Vender abre ya; las otras pantallas esperan a que terminen de leerse los movimientos de stock y la auditoría
    if (name !== 'vender' && !db.isLoaded()) await db.whenLoaded();
    const mod = await ROUTES[name].load();
    if (current.name !== name) return; // el usuario ya se fue a otra pantalla
    // Contenedor nuevo en cada pantalla: así no quedan escuchando eventos de la pantalla anterior
    // (por ejemplo, el "Nuevo" de Clientes respondiendo en Productos)
    const fresh = main.cloneNode(false);
    main.replaceWith(fresh);
    main = fresh;
    current.cleanup = (await mod.render(main, app)) || null;
  } catch (e) {
    console.error(e);
    main.innerHTML = String(html`<div class="notice notice-error"><p><b>No se pudo abrir esta pantalla.</b></p><p>${e.message}</p></div>`);
  }
  if (changed) { window.scrollTo(0, 0); main.focus({ preventScroll: true }); }
  db.loadRest(); // primera pantalla lista: ahora se leen los movimientos de stock, la auditoría y las fotos
}

window.addEventListener('hashchange', () => renderRoute());
// Una pantalla pide volver a dibujar la actual (p. ej. el asistente manda a Ajustes → IA estando ya en Ajustes)
window.addEventListener('jg-rerender', () => renderRoute(true));

// Si llegan datos de la nube, refrescamos la pantalla (salvo que haya una ventana abierta)
let refreshTimer = null;
db.onChange((colls, info) => {
  if (colls.includes('branches') && ctx.user) branchChip();
  if (!info.fromSync || !ctx.user) return;
  clearTimeout(refreshTimer);
  refreshTimer = setTimeout(() => {
    if (document.querySelector('.modal-wrap, .scan-wrap')) return;
    const a = document.activeElement;
    if (a && a.tagName === 'INPUT' && a.value) return; // no interrumpir mientras escribe
    if (colls.includes('users') && ctx.user) {
      const u = db.get('users', ctx.user.id);
      if (!u || u.deleted || !u.active) { logout(); return; }
      ctx.user = u;
      sync.setUser(u);
      iaButton();
    }
    if (colls.includes('branches')) {
      // Si desde otro equipo desactivaron la sucursal de este, hay que elegir otra
      const cur = currentBranch();
      if (!cur || cur.deleted || cur.active === 0) { startSession(ctx.user); return; }
    }
    renderRoute(true);
  }, 400);
});

// ---------- Arranque ----------

async function boot() {
  window.__jgBooted = true; // index.html: la app arrancó (si no, a los segundos ofrece reintentar)
  // Errores inesperados: aviso amable en vez de pantalla rota
  window.addEventListener('unhandledrejection', e => { console.warn(e.reason); toast((e.reason && e.reason.message) || 'Ocurrió un error inesperado.', 'error'); });
  try {
    await db.open();
  } catch (e) {
    root.innerHTML = String(html`<div class="login"><div class="login-box notice notice-error"><p><b>No se pudo abrir la base de datos.</b></p><p>${e.message}</p>
      <p><button type="button" class="btn primary" onclick="location.reload()">Reintentar</button></p></div></div>`);
    return;
  }
  try { performance.mark('jg-db'); } catch (e) { /* sin performance */ }
  // Pedimos al navegador que no borre los datos (si lo permite); Ajustes muestra si quedó persistente
  initStorage();
  // Auditoría que quedó guardada en el equipo antes de que existiera la colección: se pasa ahora
  import('./seguridad.js').then(m => m.flushAuditQueue()).catch(e => console.warn('auditoría', e));
  await sync.init();
  try { performance.mark('jg-sync'); } catch (e) { /* sin performance */ }
  sync.onStatus(syncPill);
  // Comprobantes ARCA pendientes: se reintentan solos al volver internet y después de cada sincronización
  let wasSyncing = false, arcaTimer = null;
  const arcaSoon = (ms = 1500) => { clearTimeout(arcaTimer); arcaTimer = setTimeout(() => { if (ctx.user) retryPendingArca().then(r => { if (r && r.ok) toast(r.ok === 1 ? 'ARCA volvió: 1 factura pendiente quedó autorizada. Mandásela al cliente desde Hoy → Facturas para mandar.' : `ARCA volvió: ${r.ok} facturas pendientes quedaron autorizadas. Mandalas desde Hoy → Facturas para mandar.`, 'ok', 6000); }).catch(e => console.warn(e)); }, ms); };
  sync.onStatus(s => { if (wasSyncing && !s.syncing && !s.error && s.online) arcaSoon(); wasSyncing = s.syncing; });
  window.addEventListener('online', () => arcaSoon(4000));
  setInterval(() => arcaSoon(0), 5 * 60 * 1000);

  on(document.body, 'click', '[data-menu]', () => openDrawer());
  on(document.body, 'click', '.sidenav [data-logout]', () => logout());
  on(document.body, 'click', '.sidenav [data-install]', () => install());
  on(document.body, 'click', '#branch-chip', () => changeBranch());
  on(document.body, 'click', '#ia-btn, .sidenav [data-ia]', () => openIA());
  on(document.body, 'click', '[data-atajos]', () => helpDialog());
  initAtajos(app);
  on(document.body, 'click', '[data-bk]', (e, el) => bannerAct(el.dataset.bk));
  on(document.body, 'click', '[data-cloudpin]', () => { if (ctx.user) login.cloudPin(ctx.user); });
  backup.onChange(() => backupBanner());
  backup.startAuto();
  on(document.body, 'click', '#sync-pill', () => {
    if (!sync.status.configured) { if (can(ctx.user, 'ajustes')) app.navigate('ajustes'); else toast('Los datos se guardan solo en este dispositivo.'); return; }
    if (sync.status.revoked) {
      toast('El dueño le quitó el acceso a la nube a este equipo. Lo cargado queda guardado acá; para volver a sincronizar, el dueño lo tiene que conectar de nuevo (Ajustes → Nube).', 'warn', 8000);
      return;
    }
    if (sync.status.needPin && sync.status.online) { login.cloudPin(ctx.user); return; }
    sync.syncNow().then(ok => toast(ok ? 'Sincronizado' : (sync.status.error || 'No se pudo sincronizar'), ok ? 'ok' : 'warn'));
  });

  const uid = savedUserId() || (await db.getMeta('current_user', null).catch(() => null));
  const u = uid ? db.get('users', uid) : null;
  // Dueño, encargado o permisos sensibles con la nube: se vuelve a entrar solo si su sesión de la nube sigue vigente
  // (su PIN se valida en la nube; recargar la página no alcanza para entrar como ellos)
  const si = sync.sessionInfo();
  const okRestore = u && (!sync.isDevice() || !isSensitive(u) || (si && si.uid === u.id));
  if (u && !u.deleted && u.active && db.count('users') && okRestore) startSession(u);
  else { login.render(root, { onLogin: startSession, app }); db.loadRest(); }

  if ('serviceWorker' in navigator && location.protocol !== 'file:') setupUpdates();
}

// ---------- Actualización de la app (service worker) ----------
// La versión nueva se baja entera en segundo plano y queda esperando. Se activa (y la app se recarga sola) en un
// momento tranquilo: sin ventanas abiertas, sin venta a medio cargar y sin estar escribiendo. Nunca se mezclan
// archivos de dos versiones.

/** ¿Se puede recargar ahora sin molestar? */
function quietMoment() {
  if (document.querySelector('.modal-wrap, .scan-wrap, .drawer-wrap')) return false;
  const a = document.activeElement;
  if (a && /^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName) && a.value) return false;
  if (current.name === 'conteo') return false;
  if (current.name === 'vender' && document.querySelector('#cart .cart-item')) return false;
  return true;
}

function setupUpdates() {
  const sw = navigator.serviceWorker;
  let reloading = false;
  let controlled = !!sw.controller;
  sw.addEventListener('controllerchange', () => {
    // La primera instalación también toma el control: ahí no hace falta recargar (las siguientes sí)
    if (!controlled) { controlled = true; return; }
    if (reloading) return;
    reloading = true;
    try { sessionStorage.setItem('jg_updated', '1'); } catch (e) { /* nada */ }
    location.reload();
  });
  try { if (sessionStorage.getItem('jg_updated')) { sessionStorage.removeItem('jg_updated'); setTimeout(() => toast('JEANO Gestión se actualizó a la última versión.', 'ok', 3500), 800); } } catch (e) { /* nada */ }
  let waitTimer = null;
  let sawUpdate = false;
  const applyWhenQuiet = reg => {
    clearTimeout(waitTimer);
    if (!sw.controller) return;
    if (!reg.waiting) {
      // Había una versión nueva esperando y el navegador la descartó: se vuelve a pedir (se aplica al instalarse)
      if (sawUpdate) reg.update().catch(() => {});
      return;
    }
    sawUpdate = true;
    // Recién abierta (todavía sin usuario o sin tocar nada) se aplica enseguida; si no, se espera un momento tranquilo
    if (quietMoment()) { reg.waiting.postMessage({ type: 'SKIP_WAITING' }); return; }
    waitTimer = setTimeout(() => applyWhenQuiet(reg), 20000);
  };
  sw.register('sw.js').then(reg => {
    applyWhenQuiet(reg);
    reg.addEventListener('updatefound', () => {
      const nw = reg.installing;
      if (nw) nw.addEventListener('statechange', () => { if (nw.state === 'installed') applyWhenQuiet(reg); });
    });
    // Una app que queda abierta todo el día también se entera de las versiones nuevas
    setInterval(() => { if (navigator.onLine) reg.update().catch(() => {}); }, 60 * 60 * 1000);
  }).catch(e => console.warn('Service worker:', e.message));
}

boot();

// ---------- Reloj: fecha y hora siempre a la vista ----------
function tickClock() {
  const el = document.getElementById('clock');
  if (!el) return;
  const d = new Date();
  const fecha = d.toLocaleDateString('es-AR', { weekday: 'short', day: '2-digit', month: '2-digit', year: 'numeric' });
  const hora = d.toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false });
  el.dateTime = d.toISOString();
  const corta = d.toLocaleDateString('es-AR', { day: '2-digit', month: '2-digit' });
  const horaCorta = hora.slice(0, 5);
  el.innerHTML = `<span class="clock-d">${fecha}</span><span class="clock-ds">${corta}</span> <b class="clock-t">${hora}</b><b class="clock-ts">${horaCorta}</b>`;
}
setInterval(tickClock, 1000);
new MutationObserver(() => { if (document.getElementById('clock') && !document.getElementById('clock').textContent) tickClock(); })
  .observe(document.getElementById('root'), { childList: true });
