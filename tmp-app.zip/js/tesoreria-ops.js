// =====================================================================
// tesoreria-ops.js — Gastos, tipos de gasto, bancos, cartera de cheques, movimientos de caja con varios medios
// (efectivo, cheques, Mercado Pago) y "recalcular stock y saldos". Cada operación en UNA transacción.
// =====================================================================
import * as db from './db.js';
import { ctx, openSession, mainBranchId } from './ops.js';
import { uuid, round2, can, branchOf } from './logic.js';
import { toCents, fromCents } from './cuentas.js';
import { DEFAULT_EXPENSE_TYPES, expenseTypeId, nextNumber, canMoveCheque, chequeStatusLabel, applyRecalcStock } from './tesoreria-calc.js';
import { auditOps } from './seguridad.js';

const manager = () => !!ctx.user && can(ctx.user, 'compras');
const branchId = () => ctx.branchId || mainBranchId();
const addCents = (a, b) => fromCents(toCents(a || 0) + toCents(b || 0));
const txt = v => String(v ?? '').trim();
const isActive = r => !!r && !r.deleted && r.active !== 0;

// ---------- Tipos de gasto ----------

/** Tipos de gasto activos (si todavía no hay ninguno guardado, los de SGI con su id fijo) */
export function expenseTypes({ includeInactive = false } = {}) {
  const list = db.all('expense_types');
  const src = list.length ? list : DEFAULT_EXPENSE_TYPES.map(name => ({ id: expenseTypeId(name), name, active: 1 }));
  return src.filter(t => includeInactive || t.active !== 0).sort((a, b) => String(a.name).localeCompare(String(b.name), 'es'));
}
export function expenseTypeName(id) {
  const t = id ? db.get('expense_types', id) || expenseTypes({ includeInactive: true }).find(x => x.id === id) : null;
  return t ? t.name : '';
}

/** Precarga los tipos de SGI la primera vez (solo dueño o encargado; ids fijos: no se duplican entre equipos) */
export async function seedExpenseTypes() {
  if (!manager() || db.all('expense_types', { includeDeleted: true }).length) return 0;
  const ops = DEFAULT_EXPENSE_TYPES.map(name => ({ coll: 'expense_types', rec: { id: expenseTypeId(name), name, active: 1 } }));
  await db.putBatch(ops);
  return ops.length;
}

export async function saveExpenseType({ id, name, active = 1 }) {
  if (!manager()) throw new Error('Solo el dueño o el encargado cambian los tipos de gasto.');
  const n = txt(name).toUpperCase();
  if (!n) throw new Error('Escribí el nombre del tipo de gasto.');
  const dup = db.all('expense_types').find(t => t.id !== id && String(t.name).toUpperCase() === n);
  if (dup) throw new Error('Ya existe ese tipo de gasto.');
  return db.put('expense_types', { id: id || expenseTypeId(n), name: n, active: active ? 1 : 0 });
}

// ---------- Gastos ----------

/**
 * Carga un gasto. to_cash = 1: sale de la caja abierta de esta sucursal (cash_movements "egreso"; si es con Mercado Pago o
 * cheque el movimiento queda con ese medio y no resta del efectivo). Cajero y vendedor solo cargan gastos en efectivo a caja.
 */
export async function saveExpense({ type_id, amount, method = 'efectivo', detail = '', purchase_id = null, to_cash = true, cheque_id = null, created_at = null }) {
  if (!ctx.user) throw new Error('Entrá con tu usuario.');
  if (!can(ctx.user, 'gastos') && !can(ctx.user, 'compras')) throw new Error('Tu usuario no puede cargar gastos.');
  const a = round2(amount);
  if (!(a > 0)) throw new Error('El importe tiene que ser mayor a cero.');
  if (a >= 1e10) throw new Error('Ese importe es demasiado alto: revisalo.');
  if (!type_id) throw new Error('Elegí el tipo de gasto.');
  if (!['efectivo', 'transferencia', 'mercadopago', 'cheque', 'otro'].includes(method)) throw new Error('Elegí la condición (medio de pago).');
  if (!manager() && (!to_cash || method !== 'efectivo')) throw new Error('Cajero y vendedor solo cargan gastos en efectivo que salen de la caja.');
  const cashable = ['efectivo', 'mercadopago', 'cheque'].includes(method);
  const toCash = !!to_cash && cashable;
  const session = toCash ? openSession() : null;
  if (toCash && !session) throw new Error('Para que salga de la caja abrí la caja de esta sucursal (o marcá a Caja = No).');
  const cheque = method === 'cheque' ? db.get('cheques', cheque_id) : null;
  if (method === 'cheque') {
    if (!cheque || cheque.deleted || cheque.status !== 'en_cartera') throw new Error('Elegí un cheque en cartera.');
    if (toCents(cheque.amount) !== toCents(a)) throw new Error('El importe del gasto tiene que ser el del cheque.');
  }
  const now = Date.now();
  // Fecha: la de hoy salvo que el dueño/encargado cargue uno atrasado (a Caja = No)
  const at = created_at && manager() && !toCash ? Number(created_at) : now;
  const typeName = expenseTypeName(type_id);
  const ops = [];
  // Si el tipo es uno precargado que todavía no está guardado, se guarda (solo dueño/encargado)
  if (!db.get('expense_types', type_id) && manager() && typeName) ops.push({ coll: 'expense_types', rec: { id: type_id, name: typeName, active: 1 } });
  const exp = {
    id: uuid(), number: nextNumber(db.all('expenses', { includeDeleted: true })), created_at: at, branch_id: session ? branchOf(session, mainBranchId()) : branchId(),
    session_id: session ? session.id : null, user_id: ctx.user.id, type_id, amount: a, method, detail: txt(detail), purchase_id: purchase_id || null,
    to_cash: toCash ? 1 : 0, cash_movement_id: null, cheque_id: cheque ? cheque.id : null, status: 'ok',
  };
  ops.push({ coll: 'expenses', rec: exp });
  if (session) {
    const mov = {
      id: uuid(), session_id: session.id, branch_id: branchOf(session, mainBranchId()), type: 'egreso', amount: a, method,
      mp_amount: method === 'mercadopago' ? a : 0, cheque_id: cheque ? cheque.id : null, category: 'gasto',
      reason: `Gasto ${typeName}${exp.detail ? ': ' + exp.detail : ''}`, detail: exp.detail, ref_id: exp.id, created_at: now, user_id: ctx.user.id,
      number: nextNumber(db.all('cash_movements', { includeDeleted: true })),
    };
    exp.cash_movement_id = mov.id;
    ops.push({ coll: 'cash_movements', rec: mov });
  }
  if (cheque) ops.push({ coll: 'cheques', rec: chequeMove(cheque, 'entregado', `Gasto N° ${exp.number} ${typeName}`, { delivered_to: exp.detail || typeName, ref: 'expense:' + exp.id }) });
  await db.putBatch(ops);
  return db.get('expenses', exp.id);
}

/** Anula un gasto (dueño o encargado). Si salió de una caja que sigue abierta, vuelve a la caja. */
export async function voidExpense(id, reason = '') {
  if (!manager()) throw new Error('Solo el dueño o el encargado anulan gastos.');
  const e = db.get('expenses', id);
  if (!e || e.deleted || e.status === 'anulado') throw new Error('Ese gasto ya está anulado.');
  const now = Date.now();
  const ops = [{ coll: 'expenses', rec: { id, status: 'anulado', detail: [e.detail, `ANULADO${reason ? ': ' + reason : ''}`].filter(Boolean).join(' · ') } }];
  let note = '';
  if (e.cash_movement_id) {
    const m = db.get('cash_movements', e.cash_movement_id);
    const s = m && db.get('cash_sessions', m.session_id);
    if (s && !s.closed_at) {
      ops.push({ coll: 'cash_movements', rec: { id: uuid(), session_id: s.id, branch_id: m.branch_id, type: 'ingreso', amount: m.amount, method: m.method, mp_amount: m.mp_amount || 0, cheque_id: m.cheque_id || null, category: 'gasto', reason: `Anulación gasto N° ${e.number}`, ref_id: e.id, created_at: now, user_id: ctx.user.id, number: nextNumber(db.all('cash_movements', { includeDeleted: true })) } });
    } else note = 'La caja de ese gasto ya está cerrada: no se devuelve a la caja.';
  }
  if (e.cheque_id) {
    const c = db.get('cheques', e.cheque_id);
    if (c && c.status === 'entregado') ops.push({ coll: 'cheques', rec: chequeMove(c, 'en_cartera', `Gasto N° ${e.number} anulado`, { delivered_to: null }) });
  }
  ops.push(...auditOps('anular_gasto', 'expenses', id, { amount: e.amount, reason }));
  await db.putBatch(ops);
  return { note };
}

// ---------- Bancos ----------

const DEFAULT_BANKS = ['Banco de la Nación Argentina', 'Banco de Galicia', 'Banco Santander', 'BBVA', 'Banco Macro', 'Banco Credicoop', 'Banco Patagonia',
  'ICBC', 'Banco Supervielle', 'Banco Hipotecario', 'Banco Provincia de Buenos Aires', 'Banco Ciudad', 'HSBC', 'Banco Comafi', 'Mercado Pago'];
export const bankId = name => 'bk-' + String(name).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 50);
export function banks({ includeInactive = false } = {}) {
  const list = db.all('banks');
  const src = list.length ? list : DEFAULT_BANKS.map(name => ({ id: bankId(name), name, active: 1 }));
  return src.filter(b => includeInactive || b.active !== 0).sort((a, b) => String(a.name).localeCompare(String(b.name), 'es'));
}
export function bankName(id) {
  const b = id ? db.get('banks', id) || banks({ includeInactive: true }).find(x => x.id === id) : null;
  return b ? b.name : '';
}
export async function seedBanks() {
  if (!manager() || db.all('banks', { includeDeleted: true }).length) return 0;
  await db.putBatch(DEFAULT_BANKS.map(name => ({ coll: 'banks', rec: { id: bankId(name), name, active: 1 } })));
  return DEFAULT_BANKS.length;
}
export async function saveBank({ id, name, active = 1 }) {
  if (!manager()) throw new Error('Solo el dueño o el encargado cambian los bancos.');
  const n = txt(name);
  if (!n) throw new Error('Escribí el nombre del banco.');
  if (db.all('banks').some(b => b.id !== id && String(b.name).toLowerCase() === n.toLowerCase())) throw new Error('Ese banco ya está cargado.');
  return db.put('banks', { id: id || bankId(n), name: n, active: active ? 1 : 0 });
}

// ---------- Cheques ----------

function chequeMove(c, status, note, extra = {}) {
  const now = Date.now();
  return { id: c.id, status, status_at: now, ...extra, history: [...(c.history || []), { at: now, status, user_id: ctx.user ? ctx.user.id : null, note: note || '' }] };
}

/** Valida y arma un cheque nuevo (recibido de un tercero, o propio) */
export function newCheque(c, { ref = '', received_from = '' } = {}) {
  const amount = round2(c.amount);
  if (!(amount > 0)) throw new Error('El importe del cheque tiene que ser mayor a cero.');
  if (!txt(c.number)) throw new Error('Escribí el número del cheque.');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(c.due_date || ''))) throw new Error('Poné la fecha de cobro (vencimiento) del cheque.');
  if (c.issue_date && !/^\d{4}-\d{2}-\d{2}$/.test(String(c.issue_date))) throw new Error('La fecha de emisión no es válida.');
  const now = Date.now();
  const kind = c.kind === 'propio' ? 'propio' : 'tercero';
  const status = kind === 'propio' ? 'entregado' : 'en_cartera';
  return {
    id: uuid(), kind, status, bank_id: c.bank_id || null, branch_name: txt(c.branch_name), account: txt(c.account), number: txt(c.number),
    cuit: String(c.cuit || '').replace(/\D/g, ''), holder: txt(c.holder), amount, issue_date: c.issue_date || null, due_date: c.due_date,
    received_from: received_from || txt(c.received_from) || null, delivered_to: txt(c.delivered_to) || null, ref: ref || txt(c.ref) || null,
    notes: txt(c.notes), created_at: now, user_id: ctx.user ? ctx.user.id : null, branch_id: branchId(), session_id: null, status_at: now,
    history: [{ at: now, status, user_id: ctx.user ? ctx.user.id : null, note: kind === 'propio' ? 'Cheque propio emitido' : 'Recibido' }],
  };
}

/** Carga un cheque a la cartera (sin caja) o uno propio emitido (solo dueño/encargado) */
export async function saveCheque(c) {
  if (!manager()) throw new Error('Solo el dueño o el encargado cargan cheques fuera de la caja.');
  const rec = newCheque(c);
  await db.putBatch([{ coll: 'cheques', rec }, ...auditOps('cheque_alta', 'cheques', rec.id, { amount: rec.amount, number: rec.number })]);
  return db.get('cheques', rec.id);
}

/**
 * Cambia el estado de un cheque (depositar, entregar, cobrar, rechazar, anular). Solo dueño o encargado.
 * Rechazado: si vino de un cobro de un cliente vuelve a su cuenta (ajuste +); si se le entregó a un proveedor, vuelve a
 * lo que le debemos (ajuste +).
 */
export async function moveCheque(id, status, { note = '', delivered_to = null, bank_id = null } = {}) {
  if (!manager()) throw new Error('Solo el dueño o el encargado cambian el estado de los cheques.');
  const c = db.get('cheques', id);
  if (!c || c.deleted) throw new Error('Cheque no encontrado.');
  if (!canMoveCheque(c.status, status)) throw new Error(`Un cheque ${chequeStatusLabel(c.status).toLowerCase()} no puede pasar a ${chequeStatusLabel(status).toLowerCase()}.`);
  const extra = {};
  if (status === 'entregado') { if (!txt(delivered_to)) throw new Error('Escribí a quién se lo entregás.'); extra.delivered_to = txt(delivered_to); }
  if (status === 'depositado' && bank_id) extra.notes = [c.notes, `Depositado en ${bankName(bank_id)}`].filter(Boolean).join(' · ');
  if (status === 'en_cartera') extra.delivered_to = null;
  const ops = [{ coll: 'cheques', rec: chequeMove(c, status, note, extra) }];
  const now = Date.now();
  if (status === 'rechazado') {
    const cust = c.received_from && db.get('customers', c.received_from);
    if (cust && String(c.ref || '').startsWith('customer_payment:')) {
      ops.push({ coll: 'customer_payments', rec: { id: uuid(), customer_id: cust.id, branch_id: branchId(), session_id: null, created_at: now, user_id: ctx.user.id, kind: 'ajuste', amount: round2(c.amount), method: 'cheque', reference: `Cheque ${c.number} rechazado`, notes: note, seller_id: cust.seller_id || null, cash_movement_id: null, cheque_ids: [c.id] } });
      ops.push({ coll: 'customers', rec: { id: cust.id, balance: addCents(cust.balance, c.amount) } });
    }
    const sup = c.delivered_to && db.get('suppliers', c.delivered_to);
    if (sup) {
      ops.push({ coll: 'supplier_payments', rec: { id: uuid(), supplier_id: sup.id, branch_id: branchId(), session_id: null, created_at: now, user_id: ctx.user.id, kind: 'ajuste', amount: round2(c.amount), method: 'cheque', reference: `Cheque ${c.number} rechazado`, notes: note, applies_to: [], cash_movement_id: null, cheque_ids: [c.id] } });
      ops.push({ coll: 'suppliers', rec: { id: sup.id, balance: addCents(sup.balance, c.amount) } });
    }
  }
  ops.push(...auditOps('cheque_' + status, 'cheques', id, { amount: c.amount, number: c.number, note }));
  await db.putBatch(ops);
  return db.get('cheques', id);
}

/** Cheques en cartera (para elegir al pagar) */
export const chequesInWallet = () => db.all('cheques').filter(c => c.status === 'en_cartera').sort((a, b) => String(a.due_date).localeCompare(String(b.due_date)));

// ---------- Movimientos de caja (como SGI) ----------

/**
 * Movimiento de caja con varios medios a la vez: efectivo, Mercado Pago y cheques de terceros. Queda un registro por medio, todos
 * con el mismo número correlativo. Entrada con cheque: el cheque entra a la cartera. Salida con cheque: se elige de la cartera y
 * queda "entregado" (a quien diga el detalle). Solo el efectivo cambia el arqueo.
 * Devuelve {number, records}.
 */
export async function saveCashMovement({ type, cash = 0, mp = 0, newCheques = [], chequeIds = [], detail = '', category = '' }, extraOps = []) {
  if (!ctx.user) throw new Error('Entrá con tu usuario.');
  if (!['ingreso', 'egreso'].includes(type)) throw new Error('Elegí entrada o salida.');
  const s = openSession();
  if (!s) throw new Error('La caja está cerrada.');
  const d = txt(detail);
  if (!d) throw new Error('Escribí el detalle del movimiento.');
  const c = round2(cash || 0), m = round2(mp || 0);
  if (c < 0 || m < 0) throw new Error('Los importes no pueden ser negativos.');
  const now = Date.now();
  const number = nextNumber(db.all('cash_movements', { includeDeleted: true }));
  const base = { session_id: s.id, branch_id: branchOf(s, mainBranchId()), type, created_at: now, user_id: ctx.user.id, number, detail: d, category: txt(category) || null };
  const ops = [];
  if (c > 0) ops.push({ coll: 'cash_movements', rec: { ...base, id: uuid(), amount: c, method: 'efectivo', reason: d } });
  if (m > 0) ops.push({ coll: 'cash_movements', rec: { ...base, id: uuid(), amount: m, method: 'mercadopago', mp_amount: m, reason: `${d} (Mercado Pago)` } });
  if (type === 'ingreso') {
    for (const ch of newCheques) {
      const rec = { ...newCheque({ ...ch, kind: 'tercero' }, { ref: 'cash:' + number }), session_id: s.id };
      ops.push({ coll: 'cheques', rec });
      ops.push({ coll: 'cash_movements', rec: { ...base, id: uuid(), amount: rec.amount, method: 'cheque', cheque_id: rec.id, reason: `${d} (cheque ${rec.number})` } });
    }
  } else {
    if (chequeIds.length && !manager()) throw new Error('Solo el dueño o el encargado entregan cheques de la cartera.');
    for (const id of chequeIds) {
      const ch = db.get('cheques', id);
      if (!ch || ch.status !== 'en_cartera') throw new Error('Alguno de los cheques ya no está en cartera.');
      ops.push({ coll: 'cheques', rec: chequeMove(ch, 'entregado', `Salida de caja N° ${number}: ${d}`, { delivered_to: d, ref: 'cash:' + number }) });
      ops.push({ coll: 'cash_movements', rec: { ...base, id: uuid(), amount: round2(ch.amount), method: 'cheque', cheque_id: ch.id, reason: `${d} (cheque ${ch.number})` } });
    }
  }
  const movs = ops.filter(o => o.coll === 'cash_movements');
  if (!movs.length) throw new Error('Poné algún importe (efectivo, Mercado Pago o un cheque).');
  const total = movs.reduce((a, o) => a + toCents(o.rec.amount), 0);
  ops.push(...extraOps);
  ops.push(...auditOps(type === 'ingreso' ? 'caja_ingreso' : 'caja_egreso', 'cash_movements', movs[0].rec.id, { number, amount: fromCents(total), reason: d, session_id: s.id }));
  await db.putBatch(ops);
  return { number, records: movs.map(o => db.get('cash_movements', o.rec.id)) };
}

// ---------- Recalcular stock y saldos (solo el dueño) ----------

/**
 * Corrige lo elegido: stock por sucursal (queda en lo que dan los movimientos; no se crean movimientos nuevos porque ya
 * suman eso) y saldos de clientes y proveedores (quedan en lo que dan sus movimientos). Deja registro en auditoría.
 * fixes: {stock: [{product_id, branch_id, computed, current}], customers: [{id, computed, current}], suppliers: [...]}
 */
export async function applyRecalc({ stock = [], customers = [], suppliers = [] }) {
  if (!ctx.user || ctx.user.role !== 'dueno') throw new Error('Solo el dueño puede recalcular stock y saldos.');
  const ops = [];
  const mainId = mainBranchId();
  const byProd = new Map();
  for (const f of stock) { const l = byProd.get(f.product_id) || []; l.push(f); byProd.set(f.product_id, l); }
  for (const [pid, fixes] of byProd) {
    const p = db.get('products', pid);
    if (p) ops.push({ coll: 'products', rec: { id: pid, ...applyRecalcStock(p, fixes, mainId) } });
  }
  for (const f of customers) if (db.get('customers', f.id)) ops.push({ coll: 'customers', rec: { id: f.id, balance: round2(f.computed) } });
  for (const f of suppliers) if (db.get('suppliers', f.id)) ops.push({ coll: 'suppliers', rec: { id: f.id, balance: round2(f.computed) } });
  if (!ops.length) return 0;
  ops.push(...auditOps('recalcular', 'products', '', {
    stock: stock.slice(0, 300).map(f => ({ p: f.product_id, b: f.branch_id, de: f.current, a: f.computed })),
    customers: customers.slice(0, 300).map(f => ({ id: f.id, de: f.current, a: f.computed })),
    suppliers: suppliers.slice(0, 300).map(f => ({ id: f.id, de: f.current, a: f.computed })),
  }));
  await db.putBatch(ops); // todo o nada
  return stock.length + customers.length + suppliers.length;
}

export { isActive };
