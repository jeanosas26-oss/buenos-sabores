// =====================================================================
// ia-context.js — Resumen de los datos del comercio para el asistente IA (sin DOM: se prueba con node --test).
// A la nube NO va la base: va un resumen de pocos KB armado en el equipo (ventas por día y semana, más vendidos, stock bajo,
// por vencer, caja de hoy y compras recientes). Sin datos de clientes (nombres, documentos ni teléfonos).
// =====================================================================
import { round2, round3, computeArqueo, toISODate } from './logic.js';
import { reorderList, expiringLots } from './comercial.js';

export const MAX_CONTEXT_CHARS = 12000;
const DAY = 86400000;
const dayStartMs = ms => { const d = new Date(ms); return new Date(d.getFullYear(), d.getMonth(), d.getDate()).getTime(); };
const ok = s => s && !s.deleted && s.status === 'ok' && !s.test;
const short = (s, n = 48) => String(s || '').slice(0, n);

/**
 * data: {sales, returns, products, lots, sessions, movements, purchases, suppliers}
 * opts: {now, branchId (null = todas), stockOf(product, branchId), business}
 */
export function assistantContext(data, { now = Date.now(), branchId = null, stockOf = p => Number(p.stock) || 0, business = '', branchName = '' } = {}) {
  const inBranch = r => !branchId || !r.branch_id || r.branch_id === branchId;
  const today = dayStartMs(now);
  const from14 = today - 13 * DAY;
  const sales = (data.sales || []).filter(s => ok(s) && inBranch(s) && s.created_at >= today - 34 * DAY);
  const returns = (data.returns || []).filter(r => r && !r.deleted && !r.test && inBranch(r) && r.created_at >= today - 34 * DAY);
  const byDay = new Map();
  const addDay = (ms, total, n) => {
    const k = toISODate(ms);
    const d = byDay.get(k) || { total: 0, tickets: 0 };
    d.total = round2(d.total + total); d.tickets += n;
    byDay.set(k, d);
  };
  for (const s of sales) addDay(s.created_at, Number(s.total) || 0, 1);
  for (const r of returns) addDay(r.created_at, -(Number(r.total) || 0), 0);
  const days = [];
  for (let t = from14; t <= today; t += DAY) {
    const k = toISODate(t);
    const d = byDay.get(k) || { total: 0, tickets: 0 };
    days.push({ dia: k, dia_semana: new Date(t).toLocaleDateString('es-AR', { weekday: 'short' }), total: d.total, tickets: d.tickets });
  }
  const sum = (from, to) => {
    let total = 0, tickets = 0;
    for (const [k, d] of byDay) { const t = new Date(k + 'T12:00:00').getTime(); if (t >= from && t < to) { total += d.total; tickets += d.tickets; } }
    return { total: round2(total), tickets };
  };
  // Más vendidos (cantidad e importe; las devoluciones restan)
  const top = from => {
    const m = new Map();
    for (const s of sales) {
      if (s.created_at < from) continue;
      for (const it of s.items || []) {
        const k = it.product_id || it.name;
        const x = m.get(k) || { nombre: short(it.name), cantidad: 0, total: 0 };
        x.cantidad = round3(x.cantidad + (Number(it.qty) || 0)); x.total = round2(x.total + (Number(it.subtotal) || 0));
        m.set(k, x);
      }
    }
    for (const r of returns) {
      if (r.created_at < from) continue;
      for (const it of r.items || []) {
        const x = m.get(it.product_id || it.name);
        if (x) { x.cantidad = round3(x.cantidad - (Number(it.qty) || 0)); x.total = round2(x.total - (Number(it.subtotal) || 0)); }
      }
    }
    return [...m.values()].filter(x => x.cantidad > 0).sort((a, b) => b.total - a.total).slice(0, 10);
  };
  const products = (data.products || []).filter(p => p && !p.deleted && p.active !== 0);
  const low = reorderList(products, { stockOf, branchId }).slice(0, 20).map(r => ({ nombre: short(r.product.name), stock: r.stock, minimo: r.min, pedir: r.suggested, proveedor: short(((data.suppliers || []).find(s => s.id === r.product.supplier_id) || {}).name, 30) || undefined }));
  const noStock = products.filter(p => p.unit !== 'kg' && Number(stockOf(p, branchId)) <= 0).length;
  const exp = expiringLots(data.lots || [], products, { days: 15, now, branchId, productOf: id => products.find(p => p.id === id) })
    .slice(0, 15).map(r => ({ nombre: short(r.product.name), vence: r.expires_at, dias: r.days, cantidad: r.qty ?? undefined, vencido: r.expired || undefined }));
  // Caja de hoy: la abierta de la sucursal (o la última de hoy)
  const sessions = (data.sessions || []).filter(s => s && !s.deleted && inBranch(s) && (s.opened_at >= today || !s.closed_at)).sort((a, b) => b.opened_at - a.opened_at);
  let caja = { abierta: false };
  const ses = sessions[0];
  if (ses) {
    const ar = computeArqueo({
      opening: ses.opening_amount, sales: (data.sales || []).filter(s => s.session_id === ses.id),
      movements: (data.movements || []).filter(m => m.session_id === ses.id), returns: (data.returns || []).filter(r => r.session_id === ses.id),
    });
    caja = { abierta: !ses.closed_at, apertura: ar.opening, ventas: ar.salesTotal, tickets: ar.count, efectivo_ventas: ar.cashSales, ingresos: ar.ingresos, egresos: ar.egresos, efectivo_esperado: ar.expected, por_medio: ar.byMethod };
  }
  const supName = id => short(((data.suppliers || []).find(s => s.id === id) || {}).name, 30) || 'sin proveedor';
  const purchases = (data.purchases || []).filter(p => p && !p.deleted && p.status !== 'anulada' && inBranch(p)).sort((a, b) => b.created_at - a.created_at).slice(0, 8)
    .map(p => ({ fecha: toISODate(p.created_at), proveedor: supName(p.supplier_id), comprobante: [p.doc_type || 'FC', p.letter].filter(Boolean).join(' '), total: round2(p.total), renglones: (p.items || []).length }));
  const weekday = new Date(now).getDay() || 7; // lunes = 1
  const weekStart = today - (weekday - 1) * DAY;
  const out = {
    comercio: short(business, 60), sucursal: branchName ? short(branchName, 40) : undefined, fecha: toISODate(now),
    hora: new Date(now).toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit', hour12: false }),
    hoy: byDay.get(toISODate(now)) || { total: 0, tickets: 0 },
    ayer: byDay.get(toISODate(today - DAY)) || { total: 0, tickets: 0 },
    ventas_por_dia: days,
    esta_semana: sum(weekStart, today + DAY), semana_pasada: sum(weekStart - 7 * DAY, weekStart),
    ultimos_30_dias: sum(today - 29 * DAY, today + DAY),
    top_semana: top(weekStart), top_30_dias: top(today - 29 * DAY),
    stock_bajo: low, productos_sin_stock: noStock, productos_activos: products.length,
    por_vencer: exp, caja_hoy: caja, compras_recientes: purchases,
  };
  return fitContext(out);
}

/** Si el resumen pasa del máximo, se acortan las listas (nunca se manda más) */
export function fitContext(ctx, max = MAX_CONTEXT_CHARS) {
  let c = JSON.parse(JSON.stringify(ctx));
  const lists = ['top_30_dias', 'stock_bajo', 'por_vencer', 'compras_recientes', 'top_semana', 'ventas_por_dia'];
  let guard = 0;
  while (JSON.stringify(c).length > max && guard++ < 200) {
    const k = lists.find(x => Array.isArray(c[x]) && c[x].length > 3) || lists.find(x => Array.isArray(c[x]) && c[x].length);
    if (!k) break;
    c[k] = c[k].slice(0, Math.max(0, c[k].length - (c[k].length > 6 ? Math.ceil(c[k].length / 4) : 1)));
  }
  return c;
}
