// =====================================================================
// backup.js — Copias de seguridad: descarga manual y copia automática
// diaria a una carpeta de la PC (File System Access API: Chrome y Edge de
// escritorio). Una copia por día "jeano-gestion-AAAA-MM-DD.json"; se
// conservan las últimas 30 de la carpeta.
// =====================================================================
import * as db from './db.js';
import { download } from './ui.js';
import { backupFileName, backupsToDelete, dailyBackupDue, backupReminderDue, toISODate, BACKUP_KEEP } from './logic.js';

const HOUR = 60 * 60 * 1000;

let dir = null;        // carpeta elegida (FileSystemDirectoryHandle)
let loaded = false;
let busy = null;
const subs = new Set();

/** Estado visible: 'none' (sin carpeta) | 'ok' | 'needs-permission' | 'error' */
export const state = { status: 'none', error: '', folder: '' };

function notify() { for (const fn of subs) { try { fn({ ...state }); } catch (e) { console.warn(e); } } }
export function onChange(fn) { subs.add(fn); return () => subs.delete(fn); }

/** ¿Este navegador puede guardar solo en una carpeta? (Chrome/Edge de escritorio) */
export function supported() {
  return typeof window !== 'undefined' && typeof window.showDirectoryPicker === 'function';
}

async function load() {
  if (loaded) return;
  loaded = true;
  try {
    const h = await db.getMeta('backup_dir', null);
    if (h && typeof h.getFileHandle === 'function') dir = h;
  } catch (e) { dir = null; }
  state.folder = dir ? dir.name : '';
  if (dir && state.status === 'none') state.status = 'ok';
}

/** Copia completa (la misma que "Descargar copia") */
async function backupJson() { await db.whenLoaded(); return JSON.stringify(db.exportAll()); }

/** Descarga manual de la copia completa */
export async function downloadBackup() {
  const now = Date.now();
  download(`jeano-gestion-copia-${toISODate(now)}.json`, await backupJson());
  await db.setMeta('last_backup', now);
  notify();
  return now;
}

/** Datos para la pantalla de Ajustes */
export async function info() {
  await load();
  let permission = null;
  if (dir) { try { permission = await dir.queryPermission({ mode: 'readwrite' }); } catch (e) { permission = 'prompt'; } }
  return {
    supported: supported(),
    configured: !!dir,
    folder: dir ? dir.name : '',
    permission,
    status: state.status,
    error: state.error,
    lastAuto: await db.getMeta('auto_backup', null),
    lastBackup: await db.getMeta('last_backup', 0),
    keep: BACKUP_KEEP,
  };
}

/** El dueño elige la carpeta (necesita un clic). Hace la primera copia en el momento. */
export async function chooseFolder() {
  if (!supported()) throw new Error('Este navegador no permite elegir una carpeta. Usá “Descargar copia”.');
  let h;
  try {
    h = await window.showDirectoryPicker({ id: 'jeano-respaldo', mode: 'readwrite', startIn: 'documents' });
  } catch (e) {
    if (e && e.name === 'AbortError') return null; // cerró la ventana sin elegir
    throw new Error('No se pudo usar esa carpeta. Probá con otra (por ejemplo, una dentro de Documentos u OneDrive).');
  }
  loaded = true;
  dir = h;
  state.folder = h.name;
  try { await db.setMeta('backup_dir', h); } catch (e) { console.warn('No se pudo recordar la carpeta:', e.message); }
  return runDaily({ force: true });
}

/** Deja de copiar en la carpeta */
export async function forgetFolder() {
  dir = null;
  loaded = true;
  state.status = 'none';
  state.folder = '';
  state.error = '';
  await db.setMeta('backup_dir', null);
  notify();
}

/** "Volver a permitir": el navegador pide permiso de nuevo (necesita un clic del usuario) */
export async function regrant({ force = false } = {}) {
  await load();
  if (!dir) return { status: 'no-folder' };
  let p = 'denied';
  try { p = await dir.requestPermission({ mode: 'readwrite' }); } catch (e) { p = 'denied'; }
  if (p !== 'granted') { state.status = 'needs-permission'; notify(); return { status: 'needs-permission' }; }
  state.status = 'ok';
  const r = await runDaily({ force });
  notify();
  return r;
}

async function writeDaily(now) {
  const name = backupFileName(now);
  const fh = await dir.getFileHandle(name, { create: true });
  const w = await fh.createWritable();
  await w.write(await backupJson());
  await w.close();
  // Rotación: quedan las últimas 30 copias diarias (solo se tocan archivos con ese nombre)
  const names = [];
  for await (const [n, h] of dir.entries()) if (h.kind === 'file') names.push(n);
  const removed = [];
  for (const n of backupsToDelete(names)) {
    try { await dir.removeEntry(n); removed.push(n); } catch (e) { console.warn('No se pudo borrar la copia vieja', n, e.message); }
  }
  const rec = { date: toISODate(now), at: now, file: name };
  await db.setMeta('auto_backup', rec);
  await db.setMeta('last_backup', now);
  return { ...rec, removed };
}

/**
 * Copia diaria: si hay carpeta elegida, hay permiso y todavía no se hizo hoy (o force), escribe el archivo.
 * Devuelve {status: 'done'|'skipped'|'no-folder'|'needs-permission'|'error', ...}
 */
export function runDaily({ force = false, now = Date.now() } = {}) {
  if (busy) return busy;
  busy = (async () => {
    await load();
    if (!dir) { state.status = 'none'; return { status: 'no-folder' }; }
    const last = await db.getMeta('auto_backup', null);
    if (!force && !dailyBackupDue(last && last.date, now)) return { status: 'skipped', last };
    let perm = 'prompt';
    try { perm = await dir.queryPermission({ mode: 'readwrite' }); } catch (e) { perm = 'prompt'; }
    if (perm !== 'granted') { state.status = 'needs-permission'; notify(); return { status: 'needs-permission' }; }
    try {
      const rec = await writeDaily(now);
      state.status = 'ok';
      state.error = '';
      notify();
      return { status: 'done', ...rec };
    } catch (e) {
      if (e && (e.name === 'NotAllowedError' || e.name === 'SecurityError')) { state.status = 'needs-permission'; notify(); return { status: 'needs-permission' }; }
      state.status = 'error';
      state.error = (e && e.message) || 'Error al guardar la copia';
      notify();
      return { status: 'error', error: state.error };
    }
  })().finally(() => { busy = null; });
  return busy;
}

/** ¿Recordar que haga una copia? (más de 7 días sin copia y sin copia automática funcionando) */
export async function reminderDue(now = Date.now()) {
  await load();
  if (dir && state.status === 'ok') return false;
  let since = await db.getMeta('first_seen', 0);
  if (!since) { since = now; await db.setMeta('first_seen', now); }
  return backupReminderDue(await db.getMeta('last_backup', 0), since, now);
}

let started = false;
/** Arranca la copia automática: al abrir la app, cada hora y al volver a la pestaña */
export function startAuto() {
  if (started) return;
  started = true;
  runDaily().catch(e => console.warn(e));
  setInterval(() => runDaily().catch(e => console.warn(e)), HOUR);
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') runDaily().catch(e => console.warn(e)); });
}
