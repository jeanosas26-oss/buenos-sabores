// =====================================================================
// seguridad.js — Registro de auditoría (audit_log), cierre de caja con
// arqueo ciego y faltante, reabrir caja, eliminar / restaurar productos y
// cambios en lote. Usa db.js y ops.js; la lógica pura está en control.js.
// =====================================================================
import * as db from './db.js';
import * as ops from './ops.js';
import { ctx, mainBranchId, openSession, sessionData, stockOf } from './ops.js';
import { uuid, round2, round3, branchOf, can } from './logic.js';
import { isManager, closingReport, shortageOf, soldProductIds, productUsage, bulkPricePreview, clockBehind } from './control.js';

// ---------- Auditoría ----------

/** ¿Esta versión de la base ya tiene la colección audit_log? (la agrega la migración de la nube) */
export function auditAvailable() { return db.COLLECTIONS.includes('audit_log'); }

let queueBusy = Promise.resolve();
/** Si todavía no existe audit_log, el registro queda guardado en el equipo y se pasa apenas exista */
function queueAudit(rec) {
  queueBusy = queueBusy.then(async () => {
    const q = (await db.getMeta('audit_queue', [])) || [];
    q.push(rec);
    await db.setMeta('audit_queue', q.slice(-2000));
  }).catch(e => console.warn('auditoría', e));
}

/** Pasa a audit_log lo que quedó en la cola del equipo (al arrancar, cuando la colección ya existe) */
export async function flushAuditQueue() {
  if (!auditAvailable()) return 0;
  await queueBusy;
  const q = (await db.getMeta('audit_queue', [])) || [];
  if (!q.length) return 0;
  for (let i = 0; i < q.length; i += 400) await db.putBatch(q.slice(i, i + 400).map(rec => ({ coll: 'audit_log', rec })));
  await db.setMeta('audit_queue', []);
  return q.length;
}

/**
 * Registro de auditoría listo para ir en la MISMA transacción que la acción (putBatch).
 * detail: datos de la acción; auth: {by: usuario que autorizó con su PIN} (si hubo autorización).
 * Devuelve [] si todavía no existe la colección (queda en la cola del equipo).
 */
export function auditOps(action, entity, entityId, detail = {}, auth = null) {
  const d = { ...(detail || {}) };
  if (ctx.user) d.user_name = ctx.user.name;
  if (auth && auth.by && (!ctx.user || auth.by.id !== ctx.user.id)) { d.authorized_by = auth.by.id; d.authorized_name = auth.by.name; }
  const rec = {
    id: uuid(), created_at: Date.now(), user_id: ctx.user ? ctx.user.id : null, branch_id: ctx.branchId || mainBranchId(),
    action, entity: entity || '', entity_id: entityId || '', detail: d,
  };
  if (!auditAvailable()) { queueAudit(rec); return []; }
  return [{ coll: 'audit_log', rec }];
}

/** Registra una acción sola (sin otra cosa en la transacción) */
export async function audit(action, entity, entityId, detail = {}, auth = null) {
  const o = auditOps(action, entity, entityId, detail, auth);
  if (o.length) await db.putBatch(o);
}

/** Registros de auditoría (los de la base y los que esperan en la cola del equipo) */
export async function auditEntries() {
  await db.whenLoaded();
  const list = auditAvailable() ? db.all('audit_log') : [];
  const q = (await db.getMeta('audit_queue', [])) || [];
  return list.concat(q);
}

// ---------- Permisos: o lo hace un dueño/encargado, o tiene autorización con PIN ----------

export function authorizedFor(auth, perm = null) {
  const ok = u => !!u && (perm ? can(u, perm) : isManager(u.role));
  return ok(ctx.user) || !!(auth && auth.by && ok(auth.by));
}

// ---------- Reloj del equipo ----------

let clockMax = 0;
/** Minutos que el reloj está atrasado respecto de lo último que vio este equipo (0 = bien). Actualiza la marca. */
export async function clockCheck() {
  clockMax = Math.max(clockMax, Number(await db.getMeta('clock_max', 0)) || 0);
  const now = Date.now();
  const behind = clockBehind(now, clockMax);
  if (!behind && now > clockMax) { clockMax = now; db.setMeta('clock_max', now).catch(() => {}); }
  return behind;
}
/** Después de autorizar seguir con el reloj atrasado: se toma la hora actual como referencia */
export async function clockAccept() { clockMax = Date.now(); await db.setMeta('clock_max', clockMax); }
/** Solo para pruebas: olvida la marca en memoria */
export function _clockReset() { clockMax = 0; }

// ---------- Caja: cierre ciego, faltante e informe ----------

/** Informe de cierre de una caja (abierta: con lo de ahora; cerrada: el guardado si lo tiene) */
export function sessionReport(session, counted = null, closedAt = Date.now()) {
  if (session.closed_at && session.closing_report && typeof session.closing_report === 'object') return session.closing_report;
  const { sales, movements, returns } = sessionData(session);
  const r = closingReport({
    session, sales, movements, returns, stockMoves: db.all('stock_moves'), products: db.all('products', { includeDeleted: true }),
    counted: session.closed_at ? session.counted_amount : counted, closedAt: session.closed_at || closedAt, mainId: mainBranchId(),
  });
  // Caja vieja (cerrada antes del informe): manda lo que quedó guardado al cerrar. Si después se anuló una venta de
  // esa caja, la cuenta de hoy daría otro esperado; el cierre no cambia para atrás.
  if (session.closed_at && session.expected_amount !== null && session.expected_amount !== undefined) {
    r.expected = round2(session.expected_amount);
    r.difference = session.difference === null || session.difference === undefined ? null : round2(session.difference);
  }
  return r;
}

/**
 * Cierra la caja de este equipo: guarda contado, esperado, diferencia, si fue a ciegas, el faltante a cargo
 * de quién y el informe de cierre; y lo registra en la auditoría. Devuelve la caja cerrada.
 */
export async function closeCashSession(counted, notes = '') {
  await db.whenLoaded(); // el informe de cierre lleva los ajustes de stock del turno
  const s = openSession();
  if (!s) throw new Error('No hay caja abierta.');
  const c = round2(counted);
  if (!Number.isFinite(Number(counted)) || c < 0) throw new Error('Escribí cuánto efectivo contaste (puede ser 0).');
  const now = Date.now();
  const report = sessionReport(s, c, now);
  const blind = can(ctx.user, 'ver_esperado') ? 0 : 1;
  const sh = shortageOf(report.difference, { closer: ctx.user, opener: db.get('users', s.opened_by) });
  const extra = { blind, shortage_amount: sh.shortage_amount, shortage_user_id: sh.shortage_user_id, closing_report: report };
  const detail = { counted: report.counted, expected: report.expected, difference: report.difference, blind, sales: report.sales_count };
  const aud = [...auditOps('caja_cierre', 'cash_sessions', s.id, detail)];
  if (sh.shortage_amount > 0) aud.push(...auditOps('caja_faltante', 'cash_sessions', s.id, { amount: sh.shortage_amount, shortage_user_id: sh.shortage_user_id }));
  return ops.closeCash(c, notes, extra, aud, now);
}

/** Reabre una caja cerrada (dueño/encargado o con autorización). Tiene que ser la última de la sucursal y no tiene que haber otra abierta. */
export async function reopenCash(sessionId, { auth = null, reason = '' } = {}) {
  if (!authorizedFor(auth, 'reabrir_caja')) throw new Error('Para reabrir una caja hace falta la autorización del dueño o del encargado.');
  const s = db.get('cash_sessions', sessionId);
  if (!s || s.deleted || !s.closed_at) throw new Error('Esa caja no está cerrada.');
  const branch = branchOf(s, mainBranchId());
  if (openSession(branch)) throw new Error('Ya hay una caja abierta en esa sucursal: cerrala antes de reabrir otra.');
  const later = db.all('cash_sessions').some(x => x.id !== s.id && ops.inBranch(x, branch) && x.opened_at > s.opened_at);
  if (later) throw new Error('Solo se puede reabrir la última caja de la sucursal.');
  const prev = { closed_at: s.closed_at, closed_by: s.closed_by, counted: s.counted_amount, expected: s.expected_amount, difference: s.difference, shortage_amount: s.shortage_amount || 0 };
  await db.putBatch([
    { coll: 'cash_sessions', rec: { id: s.id, closed_at: null, closed_by: null, counted_amount: null, expected_amount: null, difference: null, shortage_amount: 0, shortage_user_id: null, closing_report: null, blind: 0 } },
    ...auditOps('caja_reabierta', 'cash_sessions', s.id, { reason: String(reason || '').trim(), previous: prev }, auth),
  ]);
  return db.get('cash_sessions', s.id);
}

/** Marca un faltante como descontado / justificado / pendiente (solo dueño) */
export async function markShortage(sessionId, status, note = '') {
  if (!ctx.user || ctx.user.role !== 'dueno') throw new Error('Solo el dueño puede marcar los faltantes.');
  const s = db.get('cash_sessions', sessionId);
  if (!s) throw new Error('Caja no encontrada.');
  const action = { descontado: 'faltante_descontado', justificado: 'faltante_justificado', pendiente: 'faltante_pendiente' }[status];
  if (!action) throw new Error('Estado no válido.');
  await audit(action, 'cash_sessions', sessionId, { amount: Number(s.shortage_amount) || round2(-(Number(s.difference) || 0)), shortage_user_id: s.shortage_user_id || s.closed_by, note: String(note || '').trim() });
}

// ---------- Productos: eliminar, desactivar, restaurar y lote ----------

/** Uso del producto (ventas y stock en alguna sucursal) para avisar antes de eliminar */
export function usageOf(productIds) {
  const sold = soldProductIds(db.all('sales'));
  const mainId = mainBranchId();
  return productIds.map(id => { const p = db.get('products', id); return { p, ...productUsage(p, sold, mainId) }; }).filter(x => x.p);
}

function mustManage() {
  if (!ctx.user || !can(ctx.user, 'editar_productos')) throw new Error('Tu usuario no puede cambiar productos.');
}

async function batchPut(ops_) {
  for (let i = 0; i < ops_.length; i += 500) await db.putBatch(ops_.slice(i, i + 500));
}

/** Borrado lógico (deleted = 1, se sincroniza) de uno o varios productos. Quedan 30 días en la papelera. */
export async function deleteProducts(ids) {
  mustManage();
  const list = ids.map(id => db.get('products', id)).filter(p => p && !p.deleted);
  if (!list.length) return 0;
  const recs = list.map(p => ({ coll: 'products', rec: { id: p.id, deleted: 1 } }));
  const one = list.length === 1;
  const detail = one ? { name: list[0].name, barcode: list[0].barcode || '', stock: Number(list[0].stock) || 0 } : { count: list.length, names: list.slice(0, 30).map(p => p.name), ids: list.slice(0, 200).map(p => p.id) };
  await batchPut([...recs, ...auditOps(one ? 'producto_eliminado' : 'lote_eliminar', 'products', one ? list[0].id : '', detail)]);
  return list.length;
}

/** Activa o desactiva productos (los desactivados no aparecen para vender) */
export async function setProductsActive(ids, active) {
  mustManage();
  const list = ids.map(id => db.get('products', id)).filter(p => p && !p.deleted && (p.active !== 0) !== !!active);
  if (!list.length) return 0;
  const one = list.length === 1;
  const action = one ? (active ? 'producto_activado' : 'producto_desactivado') : (active ? 'lote_activar' : 'lote_desactivar');
  const detail = one ? { name: list[0].name } : { count: list.length, names: list.slice(0, 30).map(p => p.name), ids: list.slice(0, 200).map(p => p.id) };
  await batchPut([...list.map(p => ({ coll: 'products', rec: { id: p.id, active: active ? 1 : 0 } })), ...auditOps(action, 'products', one ? list[0].id : '', detail)]);
  return list.length;
}

/**
 * Restaura un producto de la papelera. Si su código de barras ya lo usa otro producto vivo, vuelve sin código
 * (para no tener dos productos con el mismo código). Devuelve {product, barcodeCleared}.
 */
export async function restoreProduct(id) {
  mustManage();
  const p = db.get('products', id);
  if (!p || !p.deleted) throw new Error('Ese producto no está en la papelera.');
  const clash = p.barcode && db.all('products').find(x => x.barcode === p.barcode);
  const rec = { id, deleted: 0 };
  if (clash) rec.barcode = '';
  await db.putBatch([{ coll: 'products', rec }, ...auditOps('producto_restaurado', 'products', id, { name: p.name, barcode_cleared: clash ? p.barcode : '' })]);
  return { product: db.get('products', id), barcodeCleared: clash ? clash.name : '' };
}

/** Cambia la categoría de varios productos */
export async function setProductsCategory(ids, category) {
  mustManage();
  const cat = String(category || '').trim();
  if (!cat) throw new Error('Escribí la categoría.');
  const list = ids.map(id => db.get('products', id)).filter(p => p && !p.deleted && (p.category || 'General') !== cat);
  if (!list.length) return 0;
  await batchPut([...list.map(p => ({ coll: 'products', rec: { id: p.id, category: cat } })),
    ...auditOps('lote_categoria', 'products', '', { count: list.length, category: cat, names: list.slice(0, 30).map(p => p.name), ids: list.slice(0, 200).map(p => p.id) })]);
  return list.length;
}

/** Cambia el precio de varios productos por porcentaje (con la misma cuenta que la vista previa) */
export async function bulkPrice(ids, pct, step = 0) {
  mustManage();
  const prods = ids.map(id => db.get('products', id)).filter(p => p && !p.deleted);
  const pv = bulkPricePreview(prods, pct, step);
  if (pv.error) throw new Error(pv.error);
  const rows = pv.rows.filter(r => r.price !== r.old);
  if (!rows.length) return 0;
  await batchPut([...rows.map(r => ({ coll: 'products', rec: { id: r.id, price: r.price } })),
    ...auditOps('lote_precio', 'products', '', { count: rows.length, pct: Number(pct), step: Number(step) || 0, sample: rows.slice(0, 40).map(r => ({ id: r.id, name: r.name, old: r.old, price: r.price })) })]);
  return rows.length;
}

/** Ajuste de stock con motivo y auditoría (dueño/encargado o con autorización) */
export async function adjustStockAudited(productId, newStock, reason, auth = null) {
  if (!authorizedFor(auth, 'ajustar_stock')) throw new Error('Para ajustar el stock hace falta la autorización del dueño o del encargado.');
  const p = db.get('products', productId);
  if (!p) throw new Error('Producto no encontrado.');
  const t = Number(newStock);
  if (!Number.isFinite(t)) throw new Error('Escribí una cantidad.');
  const before = stockOf(p);
  const after = round3(t);
  if (after === before) return p;
  const r = String(reason || '').trim() || 'Ajuste manual';
  return ops.adjustStock(productId, after, r, auditOps('ajuste_stock', 'products', productId, { name: p.name, before, after, qty: round3(after - before), reason: r }, auth));
}
