// =====================================================================
// sync.js — Sincronización con la nube (Cloudflare Worker del contrato).
// Local-first: la app siempre guarda primero en el dispositivo. Si hay
// servidor + sesión, cada 30 s (y al volver internet) manda los cambios
// pendientes (push) y trae los nuevos (pull since).
// =====================================================================
import * as db from './db.js';
import { uuid, can, isSensitive } from './logic.js';
import { isLocalVerifier } from './pin.js';

/** Versión de la app (sw.js jg-v26): la nube deja de mandar el verificador viejo cuando todos los equipos están en 26+ */
export const APP_VERSION = 26;

const INTERVAL = 30000;
const CHUNK = 400; // registros por envío

let timer = null;
let running = null;
const subs = new Set();

/** Estado visible para la interfaz */
export const status = {
  configured: false,   // hay URL + token
  online: typeof navigator !== 'undefined' ? navigator.onLine : true,
  syncing: false,
  pending: 0,
  lastSync: 0,
  error: '',
  authError: false,
  // Falla pasajera (500, se cortó internet, tardó demasiado): se reintenta sola con espera creciente y recién se
  // muestra como error si dura más de ERROR_AFTER. retrying = hay un reintento programado.
  retrying: false,
  failingSince: 0,
  // Equipo autorizado: hace falta que el usuario ingrese su PIN (con internet) para subir y bajar cambios
  needPin: false,
  pinError: '',
  // El dueño le quitó el acceso a este equipo (los datos quedan en el equipo; hay que volver a conectarlo)
  revoked: false,
  // Cambios de otros usuarios que esta sesión no sube (esperan a su autor o al dueño/encargado)
  waiting: 0,
};

const ERROR_AFTER = 2 * 60 * 1000;          // aviso visible recién después de 2 minutos fallando
const BACKOFF = [2000, 5000, 10000, 20000, 30000, 60000, 120000, 300000]; // espera creciente (con algo de azar)
let failCount = 0;
let retryTimer = null;
let nextTryAt = 0;

/** Error que conviene reintentar (la nube o la red se van a recuperar solas) */
export function isTransient(e) {
  if (!e) return false;
  if (e.offline || e.network) return true;
  const st = Number(e.status || 0);
  return !st || st >= 500 || st === 408 || st === 429;
}

/** Espera antes del intento n (1, 2, …): crece hasta 5 minutos, ±20 % para que los equipos no golpeen juntos */
export function backoffDelay(n, rnd = Math.random()) {
  const base = BACKOFF[Math.min(Math.max(n, 1), BACKOFF.length) - 1];
  return Math.round(base * (0.8 + 0.4 * rnd));
}

// ---------- Acceso a la nube (equipos autorizados) ----------
// Dos formas de estar conectado:
// - "equipo autorizado" (desde v24): cfg.token es el token del EQUIPO (no lee ni escribe datos) y cfg.session la
//   sesión del usuario que entró con su PIN (la nube aplica SU rol). La contraseña del dueño nunca se guarda.
// - "sesión vieja" (hasta v23): cfg.token era el token del dueño (con contraseña). Sigue andando igual; la próxima vez
//   que alguien entra con su PIN y hay internet, el equipo sube todo y se convierte solo en equipo autorizado.
// device: {id, name} del equipo autorizado. session: {token, uid, role, sid, exp}.
let cfg = { url: '', token: '', tenant_id: '', user: null, last_pull: 0, device: null, session: null };

// Usuario que está usando la app en este equipo (el que entró con su PIN) y, solo en memoria, su PIN mientras dure
// el ingreso: sirve para pedirle a la nube su sesión cuando vuelve internet o vence (12 h) sin volver a preguntarlo.
// Nunca se guarda en el equipo ni se manda a ningún lado que no sea /api/device/session (por HTTPS).
let localUser = null;
let memPin = null; // {uid, pin}

const MANAGER_ROLES = ['dueno', 'encargado'];

function notify() { for (const fn of subs) { try { fn({ ...status }); } catch (e) { console.warn(e); } } }
export function onStatus(fn) { subs.add(fn); fn({ ...status }); return () => subs.delete(fn); }

export function config() { return { ...cfg }; }
export function isConfigured() { return !!(cfg.url && cfg.token); }
/** ¿Este equipo es un equipo autorizado (token de equipo + sesiones por usuario)? */
export function isDevice() { return isConfigured() && !!cfg.device; }
/** Sesión de la nube vigente para el usuario que está usando la app (o null) */
function liveSession() {
  const s = cfg.session;
  if (!s || !s.token) return null;
  if (s.exp && s.exp <= Date.now() + 60000) return null; // vencida (o por vencer en un minuto)
  if (localUser && s.uid !== localUser.id) return null;
  return s;
}
/** Token con el que se leen y escriben datos: la sesión del usuario (equipo autorizado) o la sesión vieja */
function dataToken() {
  if (!isDevice()) return cfg.token;
  const s = liveSession();
  return s ? s.token : cfg.token;
}
/** Usuario con el que la nube trata los cambios de este equipo ({role, perms}) */
function cloudUser() {
  if (isDevice()) {
    const s = liveSession();
    if (localUser && (!s || s.uid === localUser.id)) return localUser;
    return s ? { role: s.role } : null;
  }
  return cfg.user || null;
}
function cloudRole() { const u = cloudUser(); return (u && u.role) || ''; }
/**
 * La nube no le acepta a este equipo lo que necesita el permiso `perm` (por defecto "compras"): p. ej. una sesión de
 * cajero no escribe proveedores (a cuenta corriente, la deuda de sus compras se la suma la nube al proveedor).
 * La nube aplica los mismos permisos (rol + los que cambió el dueño).
 */
export function cloudRestricted(perm = 'compras') { const u = cloudUser(); return isConfigured() && !!u && !!u.role && !can(u, perm); }

/** Normaliza la URL del servidor (sin barra final) */
export function cleanUrl(u) {
  let s = String(u || '').trim();
  if (s && !/^https?:\/\//i.test(s)) s = 'https://' + s;
  return s.replace(/\/+$/, '');
}

async function saveCfg() { await db.setMeta('cloud', cfg); }

/** Identificador de este equipo (se genera una vez y queda en el equipo) */
export async function deviceId() {
  let id = await db.getMeta('device_id', '');
  if (!id) { id = (cfg.device && cfg.device.id) || uuid(); await db.setMeta('device_id', id); }
  return id;
}
/** Nombre que se propone para este equipo ("Celular", "PC") */
export function defaultDeviceName() {
  const ua = typeof navigator !== 'undefined' ? navigator.userAgent || '' : '';
  return /Mobi|Android|iPhone|iPod/i.test(ua) ? 'Celular' : /iPad|Tablet/i.test(ua) ? 'Tablet' : 'PC';
}
async function deviceInfo(name) {
  const branch = await db.getMeta('branch_id', null).catch(() => null);
  return { id: await deviceId(), name: String(name || (cfg.device && cfg.device.name) || defaultDeviceName()).slice(0, 80), branch_id: branch || null, app: APP_VERSION };
}

/** La nube dijo 401: según el token y el motivo, se descarta la sesión del usuario o hay que volver a conectar */
function unauthorized(err, token) {
  if (err.code === 'BAD_PIN') return;
  if (err.code === 'DEVICE_REVOKED') {
    status.revoked = true; status.authError = true;
    cfg.session = null; saveCfg().catch(() => {});
  } else if (isDevice() && cfg.session && token === cfg.session.token) {
    // La sesión del usuario terminó (cerró sesión en otro lado, le cambiaron el PIN, venció): se pide otra
    cfg.session = null; saveCfg().catch(() => {});
    status.needPin = !memPin;
  } else {
    status.authError = true;
  }
  notify();
}

/** Llamada a la API. Lanza Error con mensaje en castellano si falla. */
export async function api(path, { method = 'GET', body = null, url = cfg.url, token = undefined, timeout = 20000, quiet = false } = {}) {
  if (token === undefined) token = dataToken();
  if (!url) throw new Error('No hay servidor configurado.');
  if (typeof navigator !== 'undefined' && navigator.onLine === false) { const e = new Error('No hay conexión a internet.'); e.offline = true; throw e; }
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeout);
  let res;
  try {
    res = await fetch(url + path, {
      method,
      headers: { 'Content-Type': 'application/json', ...(token ? { Authorization: 'Bearer ' + token } : {}) },
      body: body ? JSON.stringify(body) : undefined,
      signal: ctrl.signal,
    });
  } catch (e) {
    const err = new Error(e.name === 'AbortError' ? 'El servidor tardó demasiado en responder.' : 'No se pudo conectar con el servidor.');
    err.network = true;
    throw err;
  } finally {
    clearTimeout(t);
  }
  let data = null;
  try { data = await res.json(); } catch (e) { data = null; }
  if (!res.ok) {
    const msg = (data && (data.error || data.message)) || `Error del servidor (${res.status})`;
    const err = new Error(msg);
    err.status = res.status;
    err.code = data && data.code;
    if (data && data.detail) err.detail = data.detail;
    if (data && data.attempts_left !== undefined) err.attemptsLeft = data.attempts_left;
    if (res.status === 401 && token && !quiet) unauthorized(err, token);
    throw err;
  }
  return data;
}

/**
 * Llamada a la nube con la sesión del usuario que está usando la app (la IA, por ejemplo): si la sesión venció, la pide
 * de nuevo con el PIN en memoria. Sin nube conectada: error con code NO_CLOUD.
 */
export async function cloudApi(path, opts = {}) {
  if (!isConfigured()) {
    const e = new Error('Esto funciona con la nube: conectala en Ajustes → Nube.');
    e.code = 'NO_CLOUD';
    throw e;
  }
  const token = isDevice() ? await ensureSession() : cfg.token;
  return api(path, { ...opts, token });
}

// ---------- Sesión del usuario en este equipo ----------

/** Guarda en memoria el PIN con el que entró el usuario (para pedir su sesión de la nube) */
export function rememberPin(uid, pin) { memPin = uid && pin ? { uid, pin: String(pin) } : null; }
/** PIN en memoria de ese usuario (solo para pasarlo a su usuario de la nube al conectar) */
export function pinFor(uid) { return memPin && memPin.uid === uid ? memPin.pin : ''; }

/**
 * Quién está usando la app (startSession / logout). Si cambia el usuario, la sesión de la nube del anterior se
 * descarta (y se avisa a la nube para que deje de servir).
 */
export function setUser(user) {
  if (user && localUser && localUser.id === user.id) { localUser = { id: user.id, role: user.role, name: user.name, perms: user.perms || null }; return; }
  localUser = user ? { id: user.id, role: user.role, name: user.name, perms: user.perms || null } : null;
  db.setAuthor(localUser ? localUser.id : '');
  if (memPin && (!localUser || memPin.uid !== localUser.id)) memPin = null;
  const s = cfg.session;
  if (s && (!localUser || s.uid !== localUser.id)) {
    // Cerrar sesión / cambiar de usuario: la sesión se descarta
    cfg.session = null;
    saveCfg().catch(() => {});
    if (s.token && navigator.onLine !== false) api('/api/device/logout', { method: 'POST', body: {}, token: s.token, timeout: 8000, quiet: true }).catch(() => {});
  }
  status.needPin = false;
  status.pinError = '';
  refreshPending();
  if (localUser && isConfigured()) syncSoon(500);
}

function rejectPin(e) {
  // Los avisos de PIN de la nube se muestran en el estado (la venta sigue: el PIN ya se validó en el equipo)
  status.pinError = e.message;
  if (e.code === 'PIN_LOCKED' || e.code === 'BAD_PIN' || e.code === 'NO_PIN' || e.code === 'USER_INACTIVE' || e.code === 'NOT_FOUND') {
    memPin = null; // no se insiste con un PIN que la nube no acepta
    status.needPin = true;
  }
}

/**
 * Pide a la nube la sesión del usuario (equipo autorizado) con su PIN. Devuelve la respuesta de la nube.
 * Lo usan el ingreso (con internet), el aviso "Ingresá tu PIN para sincronizar" y la sincronización.
 */
export async function openSession(user, pin) {
  if (!isDevice()) throw new Error('Este equipo no está autorizado en la nube.');
  const branch = await db.getMeta('branch_id', null).catch(() => null);
  const data = await api('/api/device/session', { method: 'POST', body: { user_id: user.id, pin: String(pin), branch_id: branch || undefined, app: APP_VERSION }, token: cfg.token });
  cfg.session = { token: data.token, uid: data.session.user_id, role: data.session.role, sid: data.session.id, exp: data.session.expires_at };
  if (data.device_token) cfg.token = data.device_token;
  status.needPin = false; status.pinError = ''; status.authError = false;
  await saveCfg();
  if (!localUser || localUser.id === user.id) rememberPin(user.id, pin);
  notify();
  return data;
}

/**
 * Autorización de supervisor (anular, devolver, descuento…): el PIN se valida en la nube (con el límite de intentos y
 * que tenga el permiso). Sin internet no se puede (la venta sigue). Devuelve true o lanza el error de la nube.
 */
export async function verifySupervisor(user, pin, perm = '') {
  if (typeof navigator !== 'undefined' && navigator.onLine === false) {
    const e = new Error('Sin internet no se puede autorizar; se puede seguir vendiendo.'); e.offline = true; throw e;
  }
  await api('/api/device/verify-pin', { method: 'POST', body: { user_id: user.id, pin: String(pin), perm: perm || undefined }, token: cfg.token, timeout: 15000 });
  return true;
}

/**
 * Carga o cambia el PIN de un usuario en la nube (solo el dueño, con internet). Primero sube el usuario (si es nuevo) y
 * después baja lo que calculó la nube (el verificador para entrar sin internet, si corresponde, y el largo del PIN).
 */
export async function setUserPin(uid, pin) {
  if (typeof navigator !== 'undefined' && navigator.onLine === false) throw new Error('Para cargar o cambiar un PIN hace falta internet.');
  await syncNow();
  const call = () => api('/api/users/pin', { method: 'POST', body: { user_id: uid, pin: String(pin) }, timeout: 20000 });
  try { await call(); } catch (e) {
    if (e.code !== 'NOT_FOUND') throw e;
    await syncNow(); // el usuario todavía no había subido
    await call();
  }
  if (localUser && localUser.id === uid) rememberPin(uid, pin);
  await syncNow();
}

/**
 * Con la nube: este equipo no guarda verificadores que no hacen falta. Dueño, encargado y quien tenga permisos
 * sensibles: ninguno (entran validando en la nube). Cajero y vendedor: solo el nuevo (PBKDF2); el viejo (sha256) se
 * conserva hasta que llegue el nuevo o hasta su primer ingreso correcto.
 */
export async function scrubLocalUsers() {
  if (!isConfigured()) return 0;
  const ops = [];
  for (const u of db.all('users', { includeDeleted: true })) {
    const sens = isSensitive(u) || u.deleted;
    const patch = {};
    if (sens && u.pin_hash) patch.pin_hash = null;
    if (sens && u.pin_local) patch.pin_local = null;
    if (!sens && u.pin_hash && isLocalVerifier(u.pin_local)) patch.pin_hash = null;
    if (Object.keys(patch).length) ops.push({ coll: 'users', rec: { ...u, ...patch } });
  }
  if (ops.length) await db.putBatch(ops, { fromSync: true });
  return ops.length;
}

/** Sesión vigente del usuario actual; si no hay, la pide con el PIN en memoria. Lanza un error needPin si no puede. */
async function ensureSession() {
  const s = liveSession();
  if (s) return s.token;
  if (!localUser) {
    // Recién autorizado (todavía nadie eligió usuario): sirve la sesión del dueño que dio la contraseña
    if (cfg.session && cfg.session.token && (!cfg.session.exp || cfg.session.exp > Date.now() + 60000)) return cfg.session.token;
  } else if (memPin && memPin.uid === localUser.id) {
    try {
      await openSession(localUser, memPin.pin);
      return cfg.session.token;
    } catch (e) {
      if (isTransient(e)) throw e;
      rejectPin(e);
    }
  }
  status.needPin = !!localUser;
  const err = new Error(localUser ? 'Ingresá tu PIN para sincronizar con la nube.' : 'Elegí tu usuario y entrá con tu PIN para sincronizar.');
  err.needPin = true;
  throw err;
}

/**
 * Equipo con la sesión vieja del dueño: ya subió todo con esa sesión → se convierte en equipo autorizado
 * (la nube le da un token de equipo) y se pide la sesión del usuario que está usando la app.
 */
let convertFailedAt = 0;
async function convertLegacy() {
  if (isDevice() || !memPin || !localUser || memPin.uid !== localUser.id) return false;
  if (!cfg.user || cfg.user.role !== 'dueno') return false;
  // Nube todavía sin equipos autorizados (404) u otro rechazo: se vuelve a probar en una hora (mientras, todo sigue igual)
  if (convertFailedAt && Date.now() - convertFailedAt < 60 * 60 * 1000) return false;
  let data;
  try {
    data = await api('/api/devices/convert', { method: 'POST', body: { device: await deviceInfo() }, token: cfg.token });
  } catch (e) {
    if (!isTransient(e)) { convertFailedAt = Date.now(); console.warn('No se pudo autorizar el equipo:', e.message); }
    return false;
  }
  cfg.token = data.device_token;
  cfg.device = { id: data.device.id, name: data.device.name };
  cfg.session = null;
  await saveCfg();
  try { await openSession(localUser, memPin.pin); } catch (e) { if (!isTransient(e)) rejectPin(e); }
  return true;
}

/** Cambios pendientes que esta sesión puede subir: dueño y encargado, todos; cajero y vendedor, solo los suyos */
function canPush(entry, role, uid) {
  if (!isDevice()) return true;
  if (MANAGER_ROLES.includes(role)) return true;
  return !!entry.by && entry.by === uid;
}

/**
 * Pendientes por autor que esperan (no los puede subir quien está usando el equipo):
 * [{uid, name, count}] (uid '' = sin autor: los sube el dueño o el encargado).
 */
export async function waitingByAuthor() {
  if (!isDevice()) return [];
  const s = liveSession();
  const role = cloudRole();
  const uid = (s && s.uid) || (localUser && localUser.id) || '';
  const m = new Map();
  for (const e of await db.outboxList()) {
    if (localUser && canPush(e, role, uid)) continue;
    const k = e.by || '';
    m.set(k, (m.get(k) || 0) + 1);
  }
  return [...m.entries()].map(([id, count]) => { const u = id ? db.get('users', id) : null; return { uid: id, name: u ? u.name : '', count }; });
}

/** Lista de usuarios activos según la nube (solo nombre y rol, sin secretos): para la pantalla de ingreso */
export async function cloudUsers() {
  if (!isDevice() || navigator.onLine === false) return [];
  try { return (await api('/api/device/users', { token: cfg.token, timeout: 8000 })).users || []; } catch (e) { return []; }
}

/** Clase de token (sin verificar la firma: eso lo hace la nube): 'd' equipo, 's' sesión, 'p' con contraseña */
export function tokenKind(t) {
  try {
    const p = JSON.parse(atob(String(t).split('.')[1].replace(/-/g, '+').replace(/_/g, '/')));
    return p.k === 'd' ? 'd' : p.k === 's' ? 's' : 'p';
  } catch (e) { return ''; }
}

/** Arranca: lee la configuración y programa la sincronización */
export async function init() {
  const saved = await db.getMeta('cloud', null);
  if (saved) cfg = { ...cfg, ...saved };
  // Configuración guardada a mano o por una versión vieja con un token con contraseña: se usa como sesión vieja
  if (cfg.device && cfg.token && tokenKind(cfg.token) === 'p') { cfg.device = null; cfg.session = null; }
  status.configured = isConfigured();
  status.lastSync = (await db.getMeta('last_sync', 0)) || 0;
  await refreshPending();
  window.addEventListener('online', () => { status.online = true; failCount = 0; nextTryAt = 0; notify(); syncNow(); });
  if (cfg.device) await db.setMeta('device_id', cfg.device.id).catch(() => {});
  window.addEventListener('offline', () => { status.online = false; notify(); });
  db.onChange(() => { schedulePending(); });
  if (status.configured) db.whenLoaded().then(() => scrubLocalUsers()).catch(e => console.warn(e));
  if (timer) clearInterval(timer);
  // Cada 30 s, salvo que haya un reintento con espera programado (no se golpea a la nube mientras falla)
  timer = setInterval(() => { if (Date.now() >= nextTryAt) syncNow(); }, INTERVAL);
  // La primera sincronización arranca cuando la app ya está en pantalla (no compite con la lectura del arranque)
  if (status.configured) db.restStarted.then(() => syncNow());
}

let pendTimer = null;
function schedulePending() {
  clearTimeout(pendTimer);
  pendTimer = setTimeout(async () => {
    await refreshPending();
    // Un cambio local se sube a los pocos segundos, sin esperar los 30 s
    if (status.configured && status.online) syncSoon();
  }, 300);
}
let soonTimer = null;
function syncSoon(ms = 3000) { clearTimeout(soonTimer); soonTimer = setTimeout(() => { if (Date.now() >= nextTryAt) syncNow(); }, ms); }

export async function refreshPending() {
  status.pending = await db.outboxCount();
  status.waiting = status.pending ? (await waitingByAuthor()).reduce((a, w) => a + w.count, 0) : 0;
  notify();
}

/** Limpia campos internos antes de mandar a la nube */
function clean(rec) {
  const out = {};
  for (const [k, v] of Object.entries(rec)) if (!k.startsWith('_')) out[k] = v;
  return out;
}

const CHUNK_BYTES = 1500000; // la nube acepta hasta 4 MB por envío; las fotos pesan ~120 KB cada una

/** Un pedido a la nube con dos reintentos rápidos ante una falla pasajera (un 500 de un momento no frena la sincronización) */
async function apiRetry(path, opts, quick = [1000, 3000]) {
  for (let k = 0; ; k++) {
    try { return await api(path, opts); } catch (e) {
      if (k >= quick.length || !isTransient(e) || e.offline || (typeof navigator !== 'undefined' && navigator.onLine === false)) throw e;
      await new Promise(r => setTimeout(r, quick[k]));
    }
  }
}

async function push(token) {
  // Los registros pendientes se leen del equipo: hay que esperar a que estén leídas todas las colecciones
  // (si no, un movimiento de stock pendiente se tomaría como inexistente y se sacaría de la bandeja sin subir)
  await db.whenLoaded();
  // Equipo autorizado: cajero y vendedor suben solo lo que cargaron ellos; dueño y encargado, todo
  const s = isDevice() ? cfg.session : null;
  const entries = (await db.outboxList()).filter(e => canPush(e, s ? s.role : '', s ? s.uid : ''));
  let i = 0;
  let maxRecs = CHUNK, maxBytes = CHUNK_BYTES;
  while (i < entries.length) {
    // Tandas de hasta CHUNK registros y ~1,5 MB (con fotos de productos entran menos)
    const start = i;
    const chunk = [];
    const changes = {};
    let bytes = 0;
    while (i < entries.length && chunk.length < maxRecs) {
      const e = entries[i];
      const r = db.get(e.coll, e.id);
      const rec = r ? clean(r) : null;
      const size = rec ? JSON.stringify(rec).length : 0;
      if (chunk.length && bytes + size > maxBytes) break;
      chunk.push(e); i++;
      if (!rec) continue;
      bytes += size;
      (changes[e.coll] = changes[e.coll] || []).push(rec);
    }
    let res;
    try {
      res = await apiRetry('/api/sync/push', { method: 'POST', body: { changes }, token });
    } catch (e) {
      // La nube dice que el envío es muy grande: se manda en tandas más chicas
      if (e.status === 413 && chunk.length > 1) { maxRecs = Math.max(1, Math.floor(chunk.length / 2)); maxBytes = Math.max(50000, Math.floor(maxBytes / 2)); i = start; continue; }
      throw e;
    }
    // Los que la nube no pudo guardar por un problema suyo (retry) quedan en la bandeja para la próxima vez.
    // Los rechazados por datos o permisos no se reintentan (la nube ya devolvió su versión o no los acepta).
    const rej = (res && res.rejected) || [];
    const keep = new Set(rej.filter(x => x && (x.retry || x.hold)).map(x => x.collection + '|' + x.id));
    // Los que cargó otro usuario (hold) quedan esperando a su autor o al dueño/encargado: no se pierden
    const hold = new Set(rej.filter(x => x && x.hold).map(x => x.collection + '|' + x.id));
    if (hold.size) await db.outboxHold(chunk.filter(e => hold.has(e.key)));
    await db.outboxAck(keep.size ? chunk.filter(e => !keep.has(e.key)) : chunk);
  }
}

async function pull(token) {
  // Si la nube tiene más de una página (has_more), se sigue bajando en la misma sincronización
  // (con miles de fotos son muchas páginas: se sigue hasta el final, cortando solo si la nube no avanza)
  let stuck = 0;
  for (let i = 0; i < 2000; i++) {
    const since = cfg.last_pull || 0;
    const data = await apiRetry('/api/sync/pull?since=' + encodeURIComponent(since), { timeout: 60000, token });
    if (data && data.changes) await db.applyRemote(data.changes);
    // Se guarda hasta dónde se bajó DESPUÉS de guardar los datos: si se cierra la pestaña en el medio, se vuelve a pedir
    if (data && data.server_time) { cfg.last_pull = data.server_time; await saveCfg(); }
    if (!data || !data.has_more) break;
    if (!(data.server_time > since) && ++stuck >= 3) break;
  }
  await scrubLocalUsers();
}

function scheduleRetry() {
  clearTimeout(retryTimer);
  const ms = backoffDelay(failCount);
  nextTryAt = Date.now() + ms;
  retryTimer = setTimeout(() => { retryTimer = null; syncNow(); }, ms);
}

/** Sincroniza ahora (si no hay nube configurada no hace nada) */
let again = null;
export function syncNow() {
  if (!isConfigured() || !navigator.onLine || status.authError || status.revoked) return Promise.resolve(false);
  // Ya hay una sincronización en curso que pudo empezar ANTES del último cambio (p. ej. la venta que se quiere
  // facturar): se encadena otra al terminar, así quien espera tiene la garantía de que lo suyo ya subió.
  if (running) {
    if (!again) again = running.catch(() => false).then(() => { again = null; return syncNow(); });
    return again;
  }
  running = (async () => {
    status.syncing = true; notify();
    try {
      if (isDevice()) {
        const token = await ensureSession();
        await push(token);
        await pull(token);
      } else {
        await push(cfg.token);
        await pull(cfg.token);
        // Sesión vieja del dueño: con todo ya subido, el equipo se convierte en equipo autorizado
        if (memPin && await convertLegacy()) { const s = liveSession(); if (s) { await push(s.token); await pull(s.token); } }
      }
      status.needPin = false;
      status.error = '';
      status.retrying = false;
      status.failingSince = 0;
      failCount = 0; nextTryAt = 0;
      clearTimeout(retryTimer); retryTimer = null;
      status.lastSync = Date.now();
      await db.setMeta('last_sync', status.lastSync);
      return true;
    } catch (e) {
      if (e.needPin || (e.status === 401 && isDevice() && !status.authError)) {
        // Equipo autorizado sin sesión del usuario (o la sesión terminó): lo cargado queda en el equipo y sube
        // cuando ingrese su PIN (si el PIN está en memoria, se pide otra sesión enseguida)
        status.retrying = false;
        status.error = '';
        if (!e.needPin && memPin) syncSoon(1000);
        return false;
      }
      if (isTransient(e)) {
        // Falla pasajera: los datos siguen guardados en el equipo; se reintenta sola y no se asusta a nadie
        // salvo que dure (más de 2 minutos).
        failCount++;
        if (!status.failingSince) status.failingSince = Date.now();
        status.retrying = true;
        status.lastError = e.detail ? `${e.message} (${e.detail})` : e.message;
        status.error = Date.now() - status.failingSince >= ERROR_AFTER ? `La nube no responde (${e.message}). Los datos quedan guardados en este equipo y se suben solos cuando vuelva.` : '';
        if (!e.offline) scheduleRetry();
      } else {
        status.retrying = false;
        status.failingSince = 0;
        status.error = e.message;
      }
      return false;
    } finally {
      status.syncing = false;
      running = null;
      await refreshPending();
    }
  })();
  return running;
}

/**
 * Conecta este dispositivo a la nube (el dueño, con su email y contraseña).
 * mode 'login' → /api/auth/login ; mode 'register' → /api/auth/register. En los dos casos el equipo queda
 * AUTORIZADO: la nube le da un token de equipo y una sesión del dueño. La contraseña no se guarda.
 */
export async function connect({ url, email, password, mode = 'login', name = '', business_name = '', device_name = '' }) {
  const u = cleanUrl(url);
  if (!u) throw new Error('Escribí la dirección del servidor.');
  const path = mode === 'register' ? '/api/auth/register' : '/api/auth/login';
  const device = await deviceInfo(device_name);
  const body = mode === 'register' ? { business_name, email, password, name, device } : { email, password, device };
  const data = await api(path, { method: 'POST', body, url: u, token: '' });
  if (!data || !data.token) throw new Error('El servidor no devolvió una sesión válida.');
  const user = data.user || null;
  if (data.device_token) {
    cfg = {
      url: u, token: data.device_token, tenant_id: data.tenant_id || '', user, last_pull: 0,
      device: { id: data.device.id, name: data.device.name },
      session: { token: data.token, uid: data.session.user_id, role: data.session.role, sid: data.session.id, exp: data.session.expires_at },
    };
  } else {
    // Servidor de antes de los equipos autorizados: sesión vieja (se convierte sola cuando el servidor se actualice)
    cfg = { url: u, token: data.token, tenant_id: data.tenant_id || '', user, last_pull: 0, device: null, session: null };
  }
  // Quien estaba usando la app pasa a ser el usuario de la nube que dio la contraseña (lo enlaza la pantalla con
  // setUser): mientras tanto se sincroniza con la sesión del dueño recién dada
  if (cfg.session && localUser && localUser.id !== cfg.session.uid) { localUser = null; db.setAuthor(''); }
  // Equipo recién autorizado desde la pantalla de ingreso (nadie adentro): la sesión del dueño queda guardada solo 15
  // minutos (para la primera sincronización y para que elija su usuario); después cada uno entra con su PIN.
  else if (cfg.session && !localUser) cfg.session.exp = Math.min(cfg.session.exp || Infinity, Date.now() + 15 * 60 * 1000);
  status.authError = false;
  status.revoked = false;
  status.needPin = false;
  status.configured = true;
  status.error = '';
  resetRetry();
  await saveCfg();
  // Todo lo local se sube en la primera sincronización
  await db.markAllPending();
  await refreshPending();
  return data;
}

/** Sesión de la nube actual (para mostrar en Ajustes): {uid, role, exp} o null */
export function sessionInfo() { const s = liveSession(); return s ? { uid: s.uid, role: s.role, exp: s.exp } : null; }

function resetRetry() {
  failCount = 0; nextTryAt = 0;
  clearTimeout(retryTimer); retryTimer = null;
  status.retrying = false; status.failingSince = 0;
}

export async function disconnect() {
  resetRetry();
  const s = cfg.session;
  if (s && s.token && cfg.url && navigator.onLine !== false) api('/api/device/logout', { method: 'POST', body: {}, token: s.token, timeout: 8000, quiet: true }).catch(() => {});
  cfg = { url: '', token: '', tenant_id: '', user: null, last_pull: 0, device: null, session: null };
  memPin = null;
  status.configured = false;
  status.error = '';
  status.authError = false;
  status.revoked = false;
  status.needPin = false;
  await saveCfg();
  notify();
}

/** Texto corto para mostrar el estado */
export function statusText(s = status) {
  if (!s.configured) return 'Solo en este dispositivo';
  if (s.revoked) return 'Equipo sin acceso a la nube';
  if (s.authError) return 'Volvé a conectar la nube';
  if (s.needPin && s.online) return `Ingresá tu PIN para sincronizar${s.pending ? ` · ${s.pending} pendientes` : ''}`;
  if (!s.online) return `Sin internet${s.pending ? ` · ${s.pending} pendientes` : ''}`;
  if (s.syncing) return 'Sincronizando…';
  if (s.error && s.retrying) return `Nube sin respuesta${s.pending ? ` · ${s.pending} pendientes` : ''}`;
  if (s.error) return 'Error de sincronización';
  if (s.pending) return `${s.pending} cambios por subir`;
  return 'Sincronizado';
}
