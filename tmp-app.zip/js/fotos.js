// =====================================================================
// fotos.js — Fotos de productos: sacar con la cámara o elegir archivo,
// dejarlas cuadradas de 400 px con fondo blanco y comprimir en el navegador
// (JPEG ≤ PHOTO_MAX_CHARS). Se guardan en la colección "product_photos"
// (id = id del producto), aparte del producto: así vender (que cambia el stock)
// no vuelve a subir la foto.
// Los productos sin foto muestran un cuadro de reemplazo (color según el rubro e
// iniciales del nombre) que se arma en el momento: no se guarda ni se sincroniza.
// =====================================================================
import * as db from './db.js';
import { html, raw, esc, ic, toast } from './ui.js';
import { norm } from './logic.js';

export const PHOTO_PX = 400;
export const PHOTO_MAX_CHARS = 160000; // ~120 KB en binario
export const PHOTO_MARGIN = 0.06;      // margen blanco alrededor del producto (contain)

/** Foto (data URL) de un producto, o '' */
export function photoOf(productId) {
  const r = productId ? db.get('product_photos', productId) : null;
  return r && !r.deleted && r.photo ? r.photo : '';
}
/** ¿Tiene foto? */
export const hasPhoto = productId => !!photoOf(productId);

// ---------- Cuadro de reemplazo (sin foto) ----------

// 12 tonos pastel; cada rubro cae siempre en el mismo (hash del nombre del rubro). Los colores están en app.css (.pph-N)
export const PH_COLORS = 12;
const hueCache = new Map();
/** Número de color (0..11) estable para un rubro */
export function rubroColor(category) {
  const k = norm(category || 'General');
  let c = hueCache.get(k);
  if (c === undefined) {
    let h = 2166136261; // FNV-1a
    for (let i = 0; i < k.length; i++) { h ^= k.charCodeAt(i); h = Math.imul(h, 16777619); }
    c = (h >>> 0) % PH_COLORS;
    if (hueCache.size > 500) hueCache.clear();
    hueCache.set(k, c);
  }
  return c;
}

// Palabras que no sirven de inicial (medidas, cantidades, conectores)
const SKIP = /^(de|del|la|las|el|los|y|con|sin|en|x|por|para|kg|kgs|g|gr|grs|mg|l|lt|lts|ml|cc|cm|mm|m|u|un|unid|uds)$/i;
/** Iniciales del nombre (2 letras): "Coca Cola 2,25 L" → "CC", "Yerba Playadito 1 kg" → "YP" */
export function initialsOf(name) {
  const words = String(name || '').trim().split(/[\s/\-_.,()]+/).filter(Boolean);
  const good = words.filter(w => /^\p{L}/u.test(w) && !SKIP.test(w));
  const pick = good.length ? good : words;
  if (!pick.length) return '?';
  const s = pick.length === 1 ? [...pick[0]].slice(0, 2).join('') : [...pick[0]][0] + [...pick[1]][0];
  return s.toLocaleUpperCase('es');
}
/** Primeras palabras del nombre para el cuadro grande (hasta ~28 letras) */
function shortName(name) {
  const words = String(name || '').trim().split(/\s+/).filter(Boolean);
  let out = '';
  for (const w of words) { if ((out + ' ' + w).trim().length > 28 && out) break; out = (out + ' ' + w).trim(); }
  return out;
}

/** Cuadro de reemplazo de un producto sin foto. size: 'sm' | 'md' | 'lg' */
export function photoPlaceholder(p, size = 'sm', alt = '') {
  const name = (p && p.name) || '';
  const cls = `pthumb pthumb-${size} pph pph-${rubroColor(p && p.category)}`;
  const label = alt ? `role="img" aria-label="${esc('Sin foto: ' + alt)}"` : 'aria-hidden="true"';
  if (size === 'lg') {
    return raw(`<span class="${cls}" ${label} data-pph><b class="pph-ini">${esc(initialsOf(name))}</b><span class="pph-name">${esc(shortName(name))}</span><span class="pph-cat">${esc((p && p.category) || 'General')}</span></span>`);
  }
  return raw(`<span class="${cls}" ${label} data-pph>${esc(initialsOf(name))}</span>`);
}

/**
 * Foto chica para listas. Si el producto no tiene foto, el cuadro de reemplazo (placeholder: false → nada).
 * product: id del producto o el producto. size: 'sm' | 'md' | 'lg'
 */
export function photoThumb(product, size = 'sm', alt = '', { placeholder = true } = {}) {
  const id = product && typeof product === 'object' ? product.id : product;
  const src = photoOf(id);
  if (src) return raw(`<img class="pthumb pthumb-${size}" src="${esc(src)}" alt="${esc(alt)}" loading="lazy" decoding="async">`);
  if (!placeholder) return '';
  const p = product && typeof product === 'object' ? product : db.get('products', id);
  return photoPlaceholder(p, size, alt);
}

// ---------- Procesar la imagen ----------

async function loadImage(file) {
  if (typeof createImageBitmap === 'function') {
    try { return await createImageBitmap(file, { imageOrientation: 'from-image' }); } catch (e) { /* algunos navegadores no aceptan la opción */ }
    try { return await createImageBitmap(file); } catch (e) { /* sigue con <img> */ }
  }
  const url = URL.createObjectURL(file);
  try {
    const img = new Image();
    img.decoding = 'async';
    await new Promise((res, rej) => { img.onload = res; img.onerror = () => rej(new Error(unreadable(file))); img.src = url; });
    return img;
  } finally { setTimeout(() => URL.revokeObjectURL(url), 1000); }
}
function unreadable(file) {
  return /heic|heif/i.test((file && (file.type || file.name)) || '') ? 'Formato HEIC del iPhone: este navegador no lo puede leer. Pasala a JPG.' : 'No se pudo leer la imagen.';
}

// Lienzos reutilizados (en una importación de miles de fotos no se crea uno por foto). Todo lo que dibuja y
// comprime es sincrónico: dos fotos procesándose a la vez no se pisan.
let workCanvas = null, outCanvas = null;
const canvas2d = (c, opts) => c.getContext('2d', opts);

/**
 * Mira la imagen en chico (≤ 320 px) sobre blanco: dónde está el producto (lo que no es blanco ni transparente)
 * y cuánto del borde es blanco (para saber si es una foto "de catálogo" o una foto con fondo).
 */
function analyze(img, w, h) {
  const k = Math.min(1, 320 / Math.max(w, h));
  const aw = Math.max(1, Math.round(w * k)), ah = Math.max(1, Math.round(h * k));
  if (!workCanvas) workCanvas = document.createElement('canvas');
  workCanvas.width = aw; workCanvas.height = ah;
  const g = canvas2d(workCanvas, { willReadFrequently: true });
  g.fillStyle = '#fff'; g.fillRect(0, 0, aw, ah);
  g.drawImage(img, 0, 0, aw, ah);
  const d = g.getImageData(0, 0, aw, ah).data;
  const rows = new Uint16Array(ah), cols = new Uint16Array(aw);
  let border = 0, borderWhite = 0;
  for (let y = 0; y < ah; y++) {
    for (let x = 0; x < aw; x++) {
      const i = (y * aw + x) * 4;
      const white = d[i] >= 236 && d[i + 1] >= 236 && d[i + 2] >= 236;
      if (!white) { rows[y]++; cols[x]++; }
      if (x < 2 || y < 2 || x >= aw - 2 || y >= ah - 2) { border++; if (white) borderWhite++; }
    }
  }
  const minHits = aw * ah > 400 ? 2 : 1; // ruido del JPEG: un píxel suelto no cuenta
  let y0 = 0, y1 = ah - 1, x0 = 0, x1 = aw - 1;
  while (y0 < ah && rows[y0] < minHits) y0++;
  while (y1 > y0 && rows[y1] < minHits) y1--;
  while (x0 < aw && cols[x0] < minHits) x0++;
  while (x1 > x0 && cols[x1] < minHits) x1--;
  let box = { x: 0, y: 0, w, h };
  if (y0 < ah && x0 < aw) {
    const sx = w / aw, sy = h / ah;
    const bx = Math.max(0, Math.floor(x0 * sx)), by = Math.max(0, Math.floor(y0 * sy));
    const bw = Math.min(w, Math.ceil((x1 + 1) * sx)) - bx, bh = Math.min(h, Math.ceil((y1 + 1) * sy)) - by;
    if (bw > w * 0.04 && bh > h * 0.04) box = { x: bx, y: by, w: bw, h: bh }; // si es casi todo blanco, la imagen entera
  }
  return { box, borderWhite: border ? borderWhite / border : 0 };
}

/**
 * Dibuja la foto cuadrada en un lienzo de px × px con fondo blanco.
 * fit 'contain': el producto entero y centrado (se recortan solo los bordes blancos/transparentes) con un margen
 *   de PHOTO_MARGIN; nunca se corta el producto. Es lo de "Importar fotos" y "Elegir archivo".
 * fit 'cover': recorte cuadrado del centro (foto sacada con la cámara, con fondo de góndola).
 * fit 'auto': 'contain' si la imagen ya tiene fondo blanco en el borde (foto de catálogo), si no 'cover'.
 */
function drawSquare(img, w, h, { fit, px, margin }) {
  if (!outCanvas) outCanvas = document.createElement('canvas');
  const c = outCanvas;
  let mode = fit;
  let a = null;
  if (mode !== 'cover') { a = analyze(img, w, h); if (mode === 'auto') mode = a.borderWhite >= 0.85 ? 'contain' : 'cover'; }
  let size, draw;
  if (mode === 'cover') {
    const side = Math.min(w, h);
    size = Math.min(px, side);
    draw = s => { const g = canvas2d(c); g.drawImage(img, (w - side) / 2, (h - side) / 2, side, side, 0, 0, s, s); };
  } else {
    const b = a.box;
    size = px;
    draw = s => {
      const inner = s * (1 - 2 * margin);
      const k = inner / Math.max(b.w, b.h);
      const dw = b.w * k, dh = b.h * k;
      canvas2d(c).drawImage(img, b.x, b.y, b.w, b.h, (s - dw) / 2, (s - dh) / 2, dw, dh);
    };
  }
  const paint = s => {
    c.width = s; c.height = s;
    const g = canvas2d(c);
    g.fillStyle = '#fff'; g.fillRect(0, 0, s, s); // fondo blanco (los PNG transparentes también)
    g.imageSmoothingEnabled = true;
    g.imageSmoothingQuality = 'high';
    draw(s);
  };
  return { size, paint, mode };
}

/**
 * Deja la foto cuadrada, la achica a PHOTO_PX y la comprime en JPEG hasta que entre en PHOTO_MAX_CHARS.
 * opts.fit: 'contain' (por defecto: producto entero sobre blanco) | 'cover' (recorte del centro) | 'auto'.
 * Devuelve el data URL.
 */
export async function compressPhoto(file, { px = PHOTO_PX, maxChars = PHOTO_MAX_CHARS, fit = 'contain', margin = PHOTO_MARGIN } = {}) {
  if (!file || !/^image\//.test(file.type || 'image/')) throw new Error('Elegí una imagen (foto JPG o PNG).');
  let img;
  try { img = await loadImage(file); } catch (e) { throw new Error(unreadable(file)); }
  try {
    const w = img.width || img.naturalWidth, h = img.height || img.naturalHeight;
    if (!w || !h) throw new Error(unreadable(file));
    const sq = drawSquare(img, w, h, { fit, px, margin });
    let size = sq.size;
    sq.paint(size);
    let q = 0.82;
    let out = outCanvas.toDataURL('image/jpeg', q);
    while (out.length > maxChars && q > 0.4) { q -= 0.08; out = outCanvas.toDataURL('image/jpeg', q); }
    while (out.length > maxChars && size > 160) { size = Math.round(size * 0.8); sq.paint(size); out = outCanvas.toDataURL('image/jpeg', 0.6); }
    if (!out.startsWith('data:image/jpeg')) throw new Error('Este navegador no pudo comprimir la foto.');
    if (out.length > maxChars) throw new Error('La foto quedó muy pesada. Probá con otra.');
    return out;
  } finally { if (img.close) img.close(); }
}

/** Guarda o borra (photo vacío) la foto de un producto */
export async function savePhoto(productId, photo) {
  await db.whenLoaded(); // las fotos se leen en segundo plano: hay que tenerlas para comparar
  const cur = db.get('product_photos', productId);
  if (!photo) {
    if (cur && !cur.deleted) await db.remove('product_photos', productId);
    return null;
  }
  if (cur && !cur.deleted && cur.photo === photo) return cur;
  return db.put('product_photos', { id: productId, product_id: productId, photo, deleted: 0 });
}

/**
 * Abre la cámara (capture) o el selector de archivos. Hay que llamarla durante el toque del usuario (si no, el
 * navegador no abre nada). Devuelve el archivo elegido o null si se canceló.
 */
export function pickPhotoFile({ capture = false, root = document.body } = {}) {
  return new Promise(resolve => {
    const i = document.createElement('input');
    i.type = 'file';
    i.accept = 'image/*';
    if (capture) i.setAttribute('capture', 'environment');
    i.style.display = 'none';
    i.dataset.photoInput = capture ? 'cam' : 'file';
    let done = false;
    const end = f => { if (done) return; done = true; i.remove(); resolve(f || null); };
    i.addEventListener('change', () => end(i.files && i.files[0]));
    i.addEventListener('cancel', () => end(null));
    root.appendChild(i);
    i.click();
  });
}

// ---------- Formulario del producto ----------

/** Bloque del formulario de producto: vista previa y botones */
export function photoField(productId) {
  const src = photoOf(productId);
  return html`<div class="field photo-field" data-photo-field>
    <span class="label">Foto</span>
    <div class="photo-row">
      <div class="photo-preview" data-photo-preview>${src ? raw(`<img src="${esc(src)}" alt="Foto del producto">`) : html`<span class="muted small">Sin foto</span>`}</div>
      <div class="btn-row">
        <button type="button" class="btn soft" data-photo-cam>${ic('camera')} Sacar foto</button>
        <button type="button" class="btn ghost" data-photo-file>${ic('upload')} Elegir archivo</button>
        <button type="button" class="btn ghost ${src ? '' : 'hidden'}" data-photo-del>${ic('trash')} Quitar foto</button>
      </div>
    </div>
    <div class="hint">Queda cuadrada sobre fondo blanco y se achica sola (400 px) para que no ocupe lugar.</div>
  </div>`;
}

/**
 * Engancha los botones del bloque. Devuelve {changed(), value()}: value() es el data URL nuevo,
 * '' si se quitó, o null si no se tocó.
 */
export function mountPhotoField(root) {
  const box = root.querySelector('[data-photo-field]');
  let value = null;
  if (!box) return { changed: () => false, value: () => null };
  const preview = box.querySelector('[data-photo-preview]');
  const del = box.querySelector('[data-photo-del]');
  const show = src => {
    preview.innerHTML = src ? `<img src="${esc(src)}" alt="Foto del producto">` : '<span class="muted small">Sin foto</span>';
    del.classList.toggle('hidden', !src);
  };
  const pick = async capture => {
    const f = await pickPhotoFile({ capture, root: box });
    if (!f) return;
    preview.innerHTML = '<span class="muted small">Procesando…</span>';
    try {
      // Con la cámara: recorte cuadrado del centro (salvo que la foto ya tenga fondo blanco).
      // Un archivo (foto de catálogo del proveedor): el producto entero sobre blanco, sin recortar.
      value = await compressPhoto(f, { fit: capture ? 'auto' : 'contain' });
      show(value);
      toast(`Foto lista (${Math.round(value.length * 0.75 / 1024)} KB). Tocá Guardar.`, 'ok', 2200);
    } catch (e) { show(value || photoOfCurrent()); toast(e.message, 'error'); }
  };
  const initial = preview.querySelector('img') ? preview.querySelector('img').getAttribute('src') : '';
  const photoOfCurrent = () => (value === null ? initial : value);
  box.querySelector('[data-photo-cam]').onclick = () => pick(true);
  box.querySelector('[data-photo-file]').onclick = () => pick(false);
  del.onclick = () => { value = ''; show(''); };
  return { changed: () => value !== null, value: () => value };
}
