// =====================================================================
// durability.js — Que no se pierda nada con un corte de luz o de internet.
// - Pide al navegador almacenamiento PERSISTENTE (no lo borra aunque falte lugar).
// - Guarda el estado para mostrarlo en Ajustes.
// Las escrituras ya van "strict" (db.js) y la bandeja de salida (outbox) vive en IndexedDB.
// =====================================================================

/** Estado del almacenamiento de este equipo (lo muestra Ajustes → Aplicación) */
export const storageState = {
  supported: typeof navigator !== 'undefined' && !!(navigator.storage && navigator.storage.persist),
  persisted: null,   // true / false / null (no se sabe)
  usage: 0,          // bytes usados
  quota: 0,          // bytes disponibles para la app
  checkedAt: 0,
};

/** Pide almacenamiento persistente (si todavía no lo es) y actualiza storageState. Nunca lanza. */
export async function initStorage() {
  if (!storageState.supported) return storageState;
  try {
    let p = navigator.storage.persisted ? await navigator.storage.persisted() : false;
    if (!p) p = await navigator.storage.persist();
    storageState.persisted = !!p;
  } catch (e) { storageState.persisted = null; }
  try {
    if (navigator.storage.estimate) {
      const est = await navigator.storage.estimate();
      storageState.usage = est.usage || 0;
      storageState.quota = est.quota || 0;
    }
  } catch (e) { /* sin estimación */ }
  storageState.checkedAt = Date.now();
  return storageState;
}

/** Texto para Ajustes */
export function storageText(s = storageState) {
  const mb = b => (b / 1048576).toLocaleString('es-AR', { maximumFractionDigits: 1 });
  const uso = s.quota ? ` Usa ${mb(s.usage)} MB.` : '';
  if (!s.supported) return { ok: false, text: 'Este navegador no permite pedir almacenamiento persistente. Hacé copias de seguridad seguido.' + uso };
  if (s.persisted === true) return { ok: true, text: 'Almacenamiento persistente: el navegador no va a borrar los datos de la app aunque se llene el disco.' + uso };
  if (s.persisted === false) {
    return { ok: false, text: 'El navegador todavía no dio almacenamiento persistente (pasa en Chrome hasta que instalás la app o la usás seguido). Los datos se guardan igual; instalá la app y hacé copias de seguridad.' + uso };
  }
  return { ok: false, text: 'No se pudo saber si el almacenamiento es persistente.' + uso };
}
