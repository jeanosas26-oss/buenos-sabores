// =====================================================================
// cierre.js — Informe de cierre de caja (imprimible), conteo de billetes
// y revisión del stock que quedó negativo o raro después del turno.
// =====================================================================
import * as db from './db.js';
import { ctx, settings, userName, multiBranch, mainBranchId, stockOf } from './ops.js';
import { html, $, modal, toast, fieldError } from './ui.js';
import { fmtMoney, fmtQty, fmtDateTime, fmtTime, payLabel, parseNum, round2, branchOf, can } from './logic.js';
import { stockIssues, isManager } from './control.js';
import { adjustStockAudited } from './seguridad.js';
import { authorize } from './autoriza.js';

/** Billetes y monedas de pesos para contar el cajón */
export const BILLS = [20000, 10000, 2000, 1000, 500, 200, 100, 50, 20, 10];

/** HTML del conteo por billetes (inputs data-bill) + "monedas u otro importe" */
export function billsHTML() {
  return html`<div class="bills" id="bills">${BILLS.map(b => html`<div class="bill-row">
      <label for="bl-${b}">${fmtMoney(b).replace(',00', '')}</label>
      <span class="x" aria-hidden="true">×</span>
      <input id="bl-${b}" data-bill="${b}" inputmode="numeric" autocomplete="off" placeholder="0" aria-label="Cantidad de billetes de ${b} pesos">
      <span class="money sub" data-bsub="${b}">$ 0</span></div>`)}
    <div class="bill-row other"><label for="bl-other">Monedas u otro importe</label><span></span>
      <input id="bl-other" data-bill-other inputmode="decimal" autocomplete="off" placeholder="0,00"><span></span></div></div>`;
}

/** Lee el conteo: {total, error, input (el campo con error)} */
export function readBills(root) {
  let total = 0;
  for (const inp of root.querySelectorAll('[data-bill]')) {
    const raw = inp.value.trim();
    if (!raw) continue;
    const n = Number(raw.replace(/\D/g, ''));
    if (!/^\d+$/.test(raw) || !Number.isFinite(n)) return { error: 'Escribí cuántos billetes hay (solo números).', input: inp };
    if (n > 5000) return { error: `¿${n} billetes de ${fmtMoney(Number(inp.dataset.bill))}? Revisá la cantidad.`, input: inp };
    total += n * Number(inp.dataset.bill);
  }
  const o = root.querySelector('[data-bill-other]');
  if (o && o.value.trim()) {
    const v = parseNum(o.value);
    if (!Number.isFinite(v) || v < 0) return { error: 'Importe inválido.', input: o };
    if (v >= 1e9) return { error: 'Ese importe es demasiado alto: revisalo.', input: o };
    total += v;
  }
  return { total: round2(total), error: '' };
}

/** Pinta los subtotales de cada billete */
export function paintBills(root) {
  for (const inp of root.querySelectorAll('[data-bill]')) {
    const n = Number(inp.value.replace(/\D/g, '')) || 0;
    const el = root.querySelector(`[data-bsub="${inp.dataset.bill}"]`);
    if (el) el.textContent = fmtMoney(n * Number(inp.dataset.bill)).replace(/,00$/, '');
  }
}

const ln = (a, b, cls = '') => html`<div class="ln ${cls}"><span>${a}</span><span>${b}</span></div>`;

/** Informe de cierre imprimible (formato ticket). r = closing_report */
export function closingReportHTML(session, r) {
  const st = settings();
  const br = db.get('branches', session.branch_id || mainBranchId());
  const diff = Number(r.difference);
  return html`<div class="ticket" id="closing-report">
    <div class="c big">${st.business_name || 'Comercio'}</div>
    ${multiBranch() && br ? html`<div class="c">Sucursal ${br.name}</div>` : ''}
    <div class="c b">INFORME DE CIERRE DE CAJA</div><hr>
    ${ln('Apertura', fmtDateTime(session.opened_at))}
    ${ln('Abrió', userName(session.opened_by))}
    ${session.closed_at ? ln('Cierre', fmtDateTime(session.closed_at)) : ''}
    ${session.closed_by ? ln('Cerró', userName(session.closed_by)) : ''}
    ${session.blind ? html`<div class="c">Arqueo ciego (sin ver el esperado)</div>` : ''}<hr>
    <div class="b">Ventas por medio de pago</div>
    ${ln('Ventas', String(r.sales_count))}
    ${Object.entries(r.by_method || {}).map(([m, v]) => ln('  ' + payLabel(m), fmtMoney(v)))}
    ${ln('Total vendido', fmtMoney(r.sales_total), 'b')}<hr>
    ${ln('Inicial', fmtMoney(r.opening))}
    ${ln('+ Efectivo de ventas', fmtMoney(r.cash_sales))}
    ${ln('+ Ingresos', fmtMoney(r.ingresos.total))}
    ${(r.ingresos.items || []).map(x => ln(`   ${fmtTime(x.at)} ${x.reason}`, fmtMoney(x.amount)))}
    ${ln('- Egresos', fmtMoney(r.egresos.total))}
    ${(r.egresos.items || []).map(x => ln(`   ${fmtTime(x.at)} ${x.reason}`, fmtMoney(x.amount)))}
    ${r.returns.cash ? ln('- Devoluciones en efectivo', fmtMoney(r.returns.cash)) : ''}
    ${ln('Esperado en efectivo', fmtMoney(r.expected), 'b')}
    ${r.counted !== null && r.counted !== undefined ? ln('Contado', fmtMoney(r.counted), 'b') : ''}
    ${r.difference !== null && r.difference !== undefined ? ln(Math.abs(diff) < 0.005 ? 'Diferencia (justo)' : diff < 0 ? 'FALTANTE' : 'SOBRANTE', fmtMoney(Math.abs(diff)), 'big') : ''}
    ${session.shortage_amount > 0 ? html`<div>Faltante a cargo de: ${userName(session.shortage_user_id)}</div>` : ''}
    <hr><div class="b">Devoluciones: ${r.returns.count}${r.returns.count ? ` · ${fmtMoney(r.returns.total)}` : ''}</div>
    ${(r.returns.items || []).map(x => ln(`   N° ${x.number} · ${userName(x.user_id)}`, fmtMoney(x.total)))}
    <div class="b">Ventas anuladas: ${r.voided.count}${r.voided.count ? ` · ${fmtMoney(r.voided.total)}` : ''}</div>
    ${(r.voided.items || []).map(x => html`${ln(`   N° ${x.number}`, fmtMoney(x.total))}${x.reason || x.voided_by ? html`<div style="padding-left:1.5em">${x.voided_by ? `anuló ${userName(x.voided_by)}` : ''}${x.reason ? ` · ${x.reason}` : ''}</div>` : ''}`)}
    <div class="b">Ventas de monto libre: ${r.free.count}${r.free.count ? ` · ${fmtMoney(r.free.total)}` : ''}</div>
    ${(r.free.items || []).map(x => ln(`   Venta ${x.sale} · ${x.name}`, fmtMoney(x.amount)))}
    <hr><div class="b">Stock negativo después del turno: ${r.negatives_count || 0}</div>
    ${(r.negatives || []).map(x => ln(`   ${x.name}`, `${fmtQty(x.stock)}${x.unit === 'kg' ? ' kg' : ''}`))}
    <div class="b">Ajustes y conteos de stock en el turno: ${r.adjustments_count || 0}</div>
    ${(r.adjustments || []).map(x => ln(`   ${x.name}${x.note ? ` (${x.note})` : ''}`, `${x.qty > 0 ? '+' : ''}${fmtQty(x.qty)}`))}
    ${session.notes ? html`<hr><div>Notas: ${session.notes}</div>` : ''}
    <hr><div style="margin-top:1.4em">Firma cajero: ____________________</div><div style="margin-top:1.4em">Firma encargado: _________________</div>
  </div>`;
}

/** Productos para revisar después del turno: negativos o con decimales (siendo por unidad), de los que se movieron en la caja */
export function sessionStockIssues(session, report) {
  const mainId = mainBranchId();
  const branch = branchOf(session, mainId);
  const ids = new Set((report.negatives || []).map(x => x.product_id));
  for (const s of db.all('sales')) if (s.session_id === session.id) for (const it of s.items || []) if (it.product_id) ids.add(it.product_id);
  for (const a of report.adjustments || []) ids.add(a.product_id);
  return stockIssues(db.all('products'), branch, mainId, { onlyIds: ids });
}

/** Lista de stock para revisar, con "Ajustar" (dueño/encargado, o con autorización) */
export function stockIssuesHTML(issues, { canFix = true } = {}) {
  if (!issues.length) return html`<p class="muted" id="si-none">No quedó ningún producto con stock negativo ni con decimales raros.</p>`;
  return html`<ul class="list" id="si-list">${issues.map(x => html`<li class="row"><span class="grow"><span class="title">${x.product.name}</span>
      <span class="sub" style="display:block">${x.kind === 'negativo' ? 'Stock negativo' : 'Unidades con decimales'}: <b>${fmtQty(x.stock)}${x.product.unit === 'kg' ? ' kg' : ''}</b></span></span>
      ${canFix ? html`<button type="button" class="btn sm ghost" data-fix="${x.product.id}">Ajustar</button>` : ''}</li>`)}</ul>`;
}

/** Engancha los botones "Ajustar" de la lista: pide lo contado y el motivo (y autorización si hace falta) */
export function bindStockFix(root, refresh) {
  root.addEventListener('click', async e => {
    const b = e.target.closest('[data-fix]');
    if (!b) return;
    const p = db.get('products', b.dataset.fix);
    if (!p) return;
    const r = await modal({
      title: `Ajustar stock · ${p.name}`,
      body: html`<p class="muted">Stock en el sistema: <b>${fmtQty(stockOf(p))}${p.unit === 'kg' ? ' kg' : ''}</b>. Contá lo que hay en la góndola y escribilo.</p>
        <form id="fx" novalidate><div class="field"><label for="fx-q">Hay (contado)</label><input id="fx-q" class="money-input" inputmode="decimal" autocomplete="off"></div>
        <div class="field"><label for="fx-r">Motivo</label><input id="fx-r" list="fx-sug" placeholder="Ej: recuento al cierre"><datalist id="fx-sug"><option value="Recuento al cierre"></option><option value="Se vendió sin stock cargado"></option><option value="Rotura"></option><option value="Vencido"></option></datalist></div></form>`,
      onMount(m) { $('#fx', m).addEventListener('submit', ev => { ev.preventDefault(); m.parentElement.querySelector('.modal-foot .primary').click(); }); },
      actions: [{ label: 'Cancelar', value: null }, {
        label: 'Guardar ajuste', kind: 'primary', id: 'fx-go', onClick: (close, w) => {
          const q = parseNum($('#fx-q', w).value);
          if (!Number.isFinite(q)) return fieldError($('#fx-q', w), 'Escribí cuánto hay.');
          if (q < 0) return fieldError($('#fx-q', w), 'Lo contado no puede ser negativo.');
          const reason = $('#fx-r', w).value.trim();
          if (!reason) return fieldError($('#fx-r', w), 'Escribí el motivo.');
          close({ q, reason });
        },
      }],
    });
    if (!r) return;
    const auth = await authorize(`ajustar el stock de “${p.name}”`, { action: 'ajuste_stock', entity: 'products', entityId: p.id, perm: 'ajustar_stock' });
    if (!auth) return;
    try {
      await adjustStockAudited(p.id, r.q, r.reason, auth);
      toast('Stock ajustado.');
      refresh();
    } catch (err) { toast(err.message, 'error', 5000); }
  });
}

export const canSeeExpected = () => !!ctx.user && can(ctx.user, 'ver_esperado');
