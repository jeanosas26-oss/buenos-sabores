// =====================================================================
// print.js — Ticket de venta (58/80 mm) y resumen de cierre de caja.
// Se imprime con window.print(); el CSS @media print muestra solo #print-area.
// =====================================================================
import * as db from './db.js';
import { html, loadScript, $ } from './ui.js';
import { settings, userName, multiBranch, mainBranchId, branchName } from './ops.js';
import {
  fmtMoney, fmtQty, fmtDateTime, fmtDate, payLabel, cbteNombre, fmtCbteNro, ivaBreakdown, discriminaIva, arcaQrUrl,
} from './logic.js';
import { docTitle } from './comercial.js';

const QR_LIB = 'https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js';

const IVA_NAMES = { RI: 'IVA Responsable Inscripto', MT: 'Responsable Monotributo', EX: 'IVA Exento', CF: 'Consumidor Final' };
export const ivaName = c => IVA_NAMES[c] || c || '';

/** HTML del ticket de una venta */
export function ticketHTML(sale) {
  const st = settings();
  const d = sale.doc || {};
  const cust = sale.customer_id ? db.get('customers', sale.customer_id) : null;
  const fiscal = d.kind === 'factura' && d.status === 'autorizado';
  const letra = fiscal ? cbteNombre(d.cbte_tipo) : '';
  const br = ivaBreakdown(sale.items, discriminaIva(st.iva_condition));
  const ln = (a, b, cls = '') => html`<div class="ln ${cls}"><span>${a}</span><span>${b}</span></div>`;
  // Con varias sucursales, el ticket muestra la sucursal y su dirección (la del punto de venta)
  const branch = db.get('branches', sale.branch_id || mainBranchId());
  const multi = multiBranch();
  const address = (branch && branch.address) || st.address;
  return html`<div class="ticket">
    ${st.ticket_logo ? html`<div class="c tk-logo-box"><img class="tk-logo" src="${st.ticket_logo}" alt=""></div>` : ''}
    <div class="c big">${st.business_name || 'Comercio'}</div>
    ${multi && branch ? html`<div class="c">Sucursal ${branch.name}</div>` : ''}
    ${st.legal_name ? html`<div class="c">${st.legal_name}</div>` : ''}
    ${address ? html`<div class="c">${address}</div>` : ''}
    ${st.cuit ? html`<div class="c">CUIT ${String(st.cuit).replace(/^(\d{2})(\d{8})(\d)$/, "$1-$2-$3")}</div>` : ''}
    ${st.iva_condition ? html`<div class="c">${ivaName(st.iva_condition)}</div>` : ''}
    ${fiscal && st.iibb ? html`<div class="c">IIBB ${st.iibb}${st.start_date ? html` · Inicio act. ${st.start_date}` : ''}</div>` : ''}
    <hr>
    ${fiscal
      ? html`<div class="c b">${letra}</div><div class="c">N° ${fmtCbteNro(d.pto_vta, d.cbte_nro)}</div>`
      : html`<div class="c b">COMPROBANTE NO FISCAL</div><div class="c b">${docTitle(sale).toUpperCase()}</div><div class="c">N° ${fmtCbteNro(posOf(sale), sale.number)}</div><div class="c">No válido como factura</div>`}
    <div class="c">Venta N° ${sale.number} · ${fmtDateTime(sale.created_at)}</div>
    <div class="c">Atendió: ${userName(sale.user_id)}</div>
    ${cust ? html`<div>Cliente: ${cust.name}${cust.doc_number ? html` · ${cust.doc_type} ${cust.doc_number}` : ''}</div><div>${ivaName(cust.iva_condition)}</div>` : ''}
    ${sale.status === 'anulada' ? html`<div class="c b">*** VENTA ANULADA ***</div>` : ''}
    <hr>
    ${sale.items.map(it => html`<div class="it">
      <div>${it.name}</div>
      ${ln(`${fmtQty(it.qty)} x ${fmtMoney(it.unit_price)}`, fmtMoney(it.subtotal + (it.discount || 0) - (it.surcharge || 0)))}
      ${it.promo_discount ? ln(`  Promo ${it.promo_name || ''}`, '-' + fmtMoney(it.promo_discount)) : ''}
    </div>`)}
    <hr>
    ${promoTotal(sale) > 0 || sale.discount > 0 || sale.surcharge > 0 ? ln('Subtotal', fmtMoney(sale.total + (sale.discount || 0) - (sale.surcharge || 0))) : ''}
    ${promoTotal(sale) > 0 ? ln('Promociones', '-' + fmtMoney(promoTotal(sale))) : ''}
    ${sale.discount - promoTotal(sale) > 0.004 ? ln('Descuento', '-' + fmtMoney(sale.discount - promoTotal(sale))) : ''}
    ${sale.surcharge > 0 ? ln('Intereses / recargo tarjeta', fmtMoney(sale.surcharge)) : ''}
    ${ln('TOTAL', fmtMoney(sale.total), 'big')}
    ${fiscal && d.cbte_tipo === 1 ? Object.entries(br).filter(([r]) => Number(r) > 0).map(([r, v]) => html`${ln(`Neto gravado ${r}%`, fmtMoney(v.net))}${ln(`IVA ${r}%`, fmtMoney(v.iva))}`) : ''}
    ${fiscal && d.cbte_tipo === 6 ? ln('IVA contenido (Ley 27.743)', fmtMoney(sale.iva)) : ''}
    <hr>
    ${(sale.payments || []).map(p => html`${ln(p.card_name ? `${p.card_name} (${payLabel(p.method)})` : payLabel(p.method), fmtMoney(p.tendered ?? p.amount))}${Number(p.installments) > 1 ? html`<div>  ${p.installments} cuotas de ${fmtMoney(p.installment_amount)}${Number(p.surcharge) > 0 ? ` · recargo ${String(p.surcharge_pct).replace('.', ',')}% ${fmtMoney(p.surcharge)}` : ''}</div>` : (Number(p.surcharge) > 0 ? html`<div>  recargo ${String(p.surcharge_pct).replace('.', ',')}% ${fmtMoney(p.surcharge)}</div>` : '')}`)}
    ${sale.change > 0 ? ln('Vuelto', fmtMoney(sale.change), 'b') : ''}
    ${fiscal ? html`<hr><div>CAE: ${d.cae}</div><div>Vto. CAE: ${d.cae_vto}</div><div class="qr" data-qr="${arcaQrUrl(sale, st, cust)}"></div>` : ''}
    ${d.kind === 'factura' && !fiscal ? html`<hr><div class="c b">Factura pendiente de autorización</div>` : ''}
    ${sale.observations ? html`<hr><div>Obs.: ${sale.observations}</div>` : ''}
    ${sale.seller_id ? html`<div>Vendedor: ${userName(sale.seller_id)}</div>` : ''}
    ${st.ticket_footer ? html`<hr><div class="c">${st.ticket_footer}</div>` : ''}
  </div>`;
}
/** Promociones aplicadas en una venta (suma de los renglones) */
function promoTotal(sale) { return Math.round((sale.items || []).reduce((a, it) => a + Math.round((Number(it.promo_discount) || 0) * 100), 0)) / 100; }
/** Punto de venta de la sucursal de la venta (para el número del comprobante interno) */
function posOf(sale) { const b = db.get('branches', sale.branch_id || mainBranchId()); return Number(b && b.pos_number) || Number(settings().pos_number) || 1; }

/** Dibuja los códigos QR de ARCA dentro de un contenedor (si hay internet para la librería) */
export async function drawQRs(root) {
  const boxes = [...root.querySelectorAll('[data-qr]')];
  if (!boxes.length) return;
  try {
    await loadScript(QR_LIB);
    for (const b of boxes) {
      b.innerHTML = '';
      new window.QRCode(b, { text: b.dataset.qr, width: 120, height: 120, correctLevel: window.QRCode.CorrectLevel.M });
    }
  } catch (e) {
    for (const b of boxes) b.textContent = 'QR ARCA: se imprime con conexión a internet.';
  }
}

/** Imprime un HTML de ticket en el ancho elegido en Ajustes (58 u 80 mm) */
export async function printHTML(content) {
  const area = $('#print-area');
  const width = (await db.getMeta('ticket_width', '80')) || '80';
  area.className = width === 'a4' ? 'a4' : 'w' + width;
  area.innerHTML = String(content);
  await drawQRs(area);
  // Pequeña espera para que el navegador pinte el QR antes del diálogo de impresión
  await new Promise(r => setTimeout(r, 150));
  window.print();
}

export function printSale(sale) { return printHTML(ticketHTML(sale)); }

/** Resumen de cierre de caja para imprimir */
export function cashCloseHTML(session, a) {
  const st = settings();
  const ln = (x, y, cls = '') => html`<div class="ln ${cls}"><span>${x}</span><span>${y}</span></div>`;
  const br = db.get('branches', session.branch_id || mainBranchId());
  return html`<div class="ticket">
    <div class="c big">${st.business_name || 'Comercio'}</div>
    ${multiBranch() && br ? html`<div class="c">Sucursal ${br.name}</div>` : ''}
    <div class="c b">CIERRE DE CAJA</div><hr>
    ${ln('Apertura', fmtDateTime(session.opened_at))}
    ${ln('Abrió', userName(session.opened_by))}
    ${session.closed_at ? ln('Cierre', fmtDateTime(session.closed_at)) : ''}
    ${session.closed_by ? ln('Cerró', userName(session.closed_by)) : ''}<hr>
    ${ln('Ventas', String(a.count))}
    ${ln('Total vendido', fmtMoney(a.salesTotal))}
    ${Object.entries(a.byMethod).map(([m, v]) => ln('  ' + payLabel(m), fmtMoney(v)))}<hr>
    ${ln('Inicial', fmtMoney(a.opening))}
    ${ln('+ Efectivo ventas', fmtMoney(a.cashSales))}
    ${ln('+ Ingresos', fmtMoney(a.ingresos))}
    ${ln('- Egresos', fmtMoney(a.egresos))}
    ${a.devoluciones ? ln('- Devoluciones efectivo', fmtMoney(a.devoluciones)) : ''}
    ${ln('Esperado', fmtMoney(a.expected), 'b')}
    ${a.counted !== null ? ln('Contado', fmtMoney(a.counted), 'b') : ''}
    ${a.difference !== null ? ln('Diferencia', fmtMoney(a.difference), 'big') : ''}
    ${session.notes ? html`<hr><div>${session.notes}</div>` : ''}
  </div>`;
}

/** Encabezado común (comercio, sucursal, CUIT) */
function headHTML(branchId) {
  const st = settings();
  const branch = db.get('branches', branchId || mainBranchId());
  const address = (branch && branch.address) || st.address;
  return html`<div class="c big">${st.business_name || 'Comercio'}</div>
    ${multiBranch() && branch ? html`<div class="c">Sucursal ${branch.name}</div>` : ''}
    ${st.legal_name ? html`<div class="c">${st.legal_name}</div>` : ''}
    ${address ? html`<div class="c">${address}</div>` : ''}
    ${st.cuit ? html`<div class="c">CUIT ${String(st.cuit).replace(/^(\d{2})(\d{8})(\d)$/, '$1-$2-$3')}</div>` : ''}
    ${st.iva_condition ? html`<div class="c">${ivaName(st.iva_condition)}</div>` : ''}`;
}

/** Ticket de una devolución: nota de crédito de ARCA (si la venta tenía CAE) o comprobante no fiscal de devolución */
export function returnTicketHTML(ret) {
  const st = settings();
  const d = ret.doc || {};
  const sale = db.get('sales', ret.sale_id) || {};
  const sd = sale.doc || {};
  const cust = ret.customer_id ? db.get('customers', ret.customer_id) : null;
  const fiscal = d.kind === 'nota_credito' && d.status === 'autorizado' && d.cae;
  const ln = (a, b, cls = '') => html`<div class="ln ${cls}"><span>${a}</span><span>${b}</span></div>`;
  const br = ivaBreakdown(ret.items, discriminaIva(st.iva_condition));
  return html`<div class="ticket">
    ${headHTML(ret.branch_id)}
    <hr>
    ${fiscal
      ? html`<div class="c b">${cbteNombre(d.cbte_tipo).toUpperCase()}</div><div class="c">N° ${fmtCbteNro(d.pto_vta, d.cbte_nro)}</div>`
      : d.kind === 'nota_credito'
        ? html`<div class="c b">NOTA DE CRÉDITO PENDIENTE</div><div class="c">Todavía sin CAE de ARCA</div>`
        : html`<div class="c b">DEVOLUCIÓN</div><div class="c">Comprobante no fiscal · No válido como nota de crédito</div>`}
    <div class="c">Devolución N° ${ret.number} · ${fmtDateTime(ret.created_at)}</div>
    <div class="c">De la venta N° ${sale.number || '—'}${sale.created_at ? ` del ${fmtDate(sale.created_at)}` : ''}</div>
    ${sd.kind === 'factura' && sd.status === 'autorizado' ? html`<div class="c">Asociada a ${cbteNombre(sd.cbte_tipo)} N° ${fmtCbteNro(sd.pto_vta, sd.cbte_nro)}</div>` : ''}
    <div class="c">Atendió: ${userName(ret.user_id)}</div>
    ${cust ? html`<div>Cliente: ${cust.name}${cust.doc_number ? html` · ${cust.doc_type} ${cust.doc_number}` : ''}</div><div>${ivaName(cust.iva_condition)}</div>` : ''}
    <hr>
    ${(ret.items || []).map(it => html`<div class="it"><div>${it.name}</div>${ln(`${fmtQty(it.qty)} x ${fmtMoney(it.unit_price)}${Math.abs(it.qty * it.unit_price - it.subtotal) > 0.009 ? ' (con el descuento de la venta)' : ''}`, fmtMoney(it.subtotal))}</div>`)}
    <hr>
    ${ln('TOTAL DEVUELTO', fmtMoney(ret.total), 'big')}
    ${fiscal && d.cbte_tipo === 3 ? Object.entries(br).filter(([r]) => Number(r) > 0).map(([r, v]) => html`${ln(`Neto gravado ${r}%`, fmtMoney(v.net))}${ln(`IVA ${r}%`, fmtMoney(v.iva))}`) : ''}
    ${fiscal && d.cbte_tipo === 8 ? ln('IVA contenido (Ley 27.743)', fmtMoney(ret.iva)) : ''}
    <hr>
    <div class="b">Se devuelve:</div>
    ${(ret.refunds || []).map(p => ln(payLabel(p.method), fmtMoney(p.amount)))}
    ${ret.reason ? html`<div>Motivo: ${ret.reason}</div>` : ''}
    ${fiscal ? html`<hr><div>CAE: ${d.cae}</div><div>Vto. CAE: ${d.cae_vto}</div><div class="qr" data-qr="${arcaQrUrl({ created_at: ret.created_at, total: ret.total, doc: d }, st, cust)}"></div>` : ''}
    <hr><div style="margin-top:1.6em">Firma cliente: ____________________</div>
  </div>`;
}

export function printReturn(ret) { return printHTML(returnTicketHTML(ret)); }

const TR_STATUS = { enviado: 'ENVIADO · EN CAMINO', recibido: 'RECIBIDO', anulado: 'ANULADO' };

/** Remito interno entre sucursales (para imprimir y mandar con la mercadería) */
export function transferHTML(t) {
  const st = settings();
  const ln = (a, b, cls = '') => html`<div class="ln ${cls}"><span>${a}</span><span>${b}</span></div>`;
  const rec = t.status === 'recibido';
  const totalQty = (t.items || []).reduce((a, it) => a + Number(it.qty), 0);
  return html`<div class="ticket">
    <div class="c big">${st.business_name || 'Comercio'}</div>
    <div class="c b">REMITO INTERNO N° ${String(t.number || 0).padStart(6, '0')}</div>
    <div class="c">Documento no válido como factura · Traslado entre sucursales</div>
    <hr>
    ${ln('Sale de', branchName(t.from_branch), 'b')}
    ${ln('Va a', branchName(t.to_branch), 'b')}
    ${ln('Fecha', fmtDateTime(t.created_at))}
    ${ln('Envió', userName(t.created_by))}
    ${rec ? html`${ln('Recibido', fmtDateTime(t.received_at))}${ln('Recibió', userName(t.received_by))}` : ''}
    <div class="c b">${TR_STATUS[t.status] || t.status}</div>
    <hr>
    ${(t.items || []).map(it => html`<div class="it"><div>${it.name}</div>
      ${ln(`Enviado: ${fmtQty(it.qty)}`, rec ? `Recibido: ${fmtQty(it.qty_received ?? 0)}` : 'Recibido: ______')}</div>`)}
    <hr>
    ${ln('Renglones', String((t.items || []).length))}
    ${ln('Unidades enviadas', fmtQty(totalQty))}
    ${rec && (t.differences || []).length ? html`<hr><div class="b">Diferencias</div>${t.differences.map(x => ln(x.name, `${x.diff > 0 ? '+' : ''}${fmtQty(x.diff)} (${x.diff < 0 ? 'falta' : 'sobra'})`))}` : ''}
    ${rec && !(t.differences || []).length ? html`<div class="c">Llegó todo bien.</div>` : ''}
    ${t.notes ? html`<hr><div style="white-space:pre-line">${t.notes}</div>` : ''}
    <hr><div style="margin-top:1.6em">Firma envía: __________________</div><div style="margin-top:1.6em">Firma recibe: _________________</div>
  </div>`;
}

export function printTransfer(t) { return printHTML(transferHTML(t)); }
