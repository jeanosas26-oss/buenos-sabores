// =====================================================================
// control.js — Lógica pura de controles: validaciones anti-error de tipeo,
// filtros de búsqueda, informe de cierre de caja (anti-fraude), faltantes,
// cambios en lote y auditoría. Sin DOM ni IndexedDB: se prueba desde Node
// (tests/control.test.mjs).
// =====================================================================
import { round2, round3, norm, computeArqueo, stockIn, branchOf, fmtMoney, fmtQty } from './logic.js';

// ---------- Roles ----------

/** Dueño o encargado: ven todo y autorizan. Cajero y vendedor (o cualquier otro rol) no. */
export function isManager(role) { return role === 'dueno' || role === 'encargado'; }
/** Arqueo ciego: el cajero / vendedor cierra contando sin ver el esperado */
export function blindClose(role) { return !isManager(role); }

// ---------- Validaciones anti-error de tipeo ----------

export const LIMITS = {
  maxUnits: 999,       // más unidades en un renglón → confirmar
  maxKg: 50,           // más kilos en un renglón → confirmar
  payFactor: 10,       // un pago de más de 10 veces el total → confirmar
  priceJump: 0.5,      // cambio de precio de más del 50 % → confirmar
  maxMoney: 1e9,       // montos de mil millones o más: error de tipeo seguro
};

const finite = v => typeof v === 'number' && Number.isFinite(v);

/**
 * Revisa un producto antes de guardarlo.
 * p: {name, price, cost, stock?, stock_min, barcode, sku, id?}; prev: el producto como estaba (o null); others: los demás productos vivos.
 * Devuelve {errors: [{field, msg}], warnings: [{field, msg}]}. Los errores bloquean; las advertencias piden confirmación.
 */
export function checkProduct(p, prev = null, others = []) {
  const errors = [], warnings = [];
  const name = String(p.name || '').trim();
  if (!name) errors.push({ field: 'name', msg: 'Escribí el nombre.' });
  const price = Number(p.price), cost = Number(p.cost || 0);
  if (!finite(price) || price < 0) errors.push({ field: 'price', msg: 'El precio tiene que ser un número mayor o igual a cero (ej: 1.250,50).' });
  else if (price >= LIMITS.maxMoney) errors.push({ field: 'price', msg: 'El precio es demasiado alto: revisá que no hayas escaneado un código en el precio.' });
  if (!finite(cost) || cost < 0) errors.push({ field: 'cost', msg: 'El costo tiene que ser un número mayor o igual a cero.' });
  else if (cost >= LIMITS.maxMoney) errors.push({ field: 'cost', msg: 'El costo es demasiado alto: revisá que no hayas escaneado un código en el costo.' });
  if (p.stock !== undefined && !finite(Number(p.stock))) errors.push({ field: 'stock', msg: 'Stock inválido.' });
  if (p.stock_min !== undefined && (!finite(Number(p.stock_min)) || Number(p.stock_min) < 0)) errors.push({ field: 'stock_min', msg: 'El mínimo tiene que ser un número mayor o igual a cero.' });
  const barcode = String(p.barcode || '').trim(), sku = String(p.sku || '').trim();
  const rest = (others || []).filter(x => x && !x.deleted && x.id !== p.id);
  if (barcode) {
    const dup = rest.find(x => String(x.barcode || '').trim() === barcode);
    if (dup) errors.push({ field: 'barcode', msg: `El código ${barcode} ya lo usa “${dup.name}”${dup.active === 0 ? ' (desactivado)' : ''}. Cada producto tiene que tener su propio código.` });
  }
  if (sku) {
    const dup = rest.find(x => x.sku && norm(x.sku) === norm(sku));
    if (dup) warnings.push({ field: 'sku', msg: `El código interno ${sku} también lo tiene “${dup.name}”.` });
  }
  if (name) {
    const dup = rest.find(x => norm(x.name) === norm(name));
    if (dup) warnings.push({ field: 'name', msg: `Ya hay otro producto que se llama “${dup.name}”.` });
  }
  if (finite(price) && finite(cost) && !errors.length) {
    const old = prev ? Number(prev.price) || 0 : 0;
    if (old > 0 && Math.abs(price - old) / old > LIMITS.priceJump) {
      warnings.push({ field: 'price', msg: `El precio cambia de ${fmtMoney(old)} a ${fmtMoney(price)} (${price > old ? '+' : ''}${Math.round(((price - old) / old) * 100)} %).` });
    }
    if (price > 0 && cost > price) warnings.push({ field: 'cost', msg: `El costo (${fmtMoney(cost)}) es mayor que el precio de venta (${fmtMoney(price)}): se vende a pérdida.` });
    if (price === 0) warnings.push({ field: 'price', msg: 'El precio de venta es $ 0.' });
  }
  return { errors, warnings };
}

/** Cambio de precio de más del 50 % (para confirmar). Devuelve el texto del aviso o ''. */
export function priceJumpWarning(oldPrice, newPrice) {
  const o = Number(oldPrice) || 0, n = Number(newPrice);
  if (!(o > 0) || !finite(n)) return '';
  if (Math.abs(n - o) / o <= LIMITS.priceJump) return '';
  return `El precio cambia de ${fmtMoney(o)} a ${fmtMoney(n)} (${n > o ? '+' : ''}${Math.round(((n - o) / o) * 100)} %).`;
}

/**
 * Cantidad de un renglón de venta. unit: 'u' | 'kg'.
 * Devuelve {error, warning}: error bloquea (NaN, ≤ 0, parece un código de barras), warning pide confirmar (cantidad absurda).
 */
export function checkSaleQty(qty, unit = 'u') {
  const q = Number(qty);
  if (!finite(q) || q <= 0) return { error: unit === 'kg' ? 'Escribí los kilos (ej: 0,350).' : 'La cantidad tiene que ser mayor a cero.', warning: '' };
  // Un número de 6 o más cifras en la cantidad casi siempre es un código escaneado en el campo equivocado
  if (Number.isInteger(q) && q >= 100000) return { error: `${fmtQty(q)} parece un código de barras, no una cantidad.`, warning: '' };
  if (unit === 'kg' && q > LIMITS.maxKg) return { error: '', warning: `¿Seguro que son ${fmtQty(q)} kg? Es mucho para un renglón.` };
  if (unit !== 'kg' && q > LIMITS.maxUnits) return { error: '', warning: `¿Seguro que son ${fmtQty(q)} unidades? Es mucho para un renglón.` };
  if (unit !== 'kg' && !Number.isInteger(round3(q))) return { error: '', warning: `“${fmtQty(q)}” unidades tiene decimales: ¿no es un producto por kilo?` };
  return { error: '', warning: '' };
}

/**
 * Pagos de una venta: [{method, amount}]. Devuelve {error, warning}.
 * warning: algún importe es más de 10 veces el total (típico: se escaneó o se tipeó de más).
 */
export function checkPayments(total, payments) {
  const T = Number(total) || 0;
  for (const p of payments || []) {
    const a = Number(p.amount) || 0;
    if (a >= LIMITS.maxMoney) return { error: `${fmtMoney(a)} no puede ser un pago: revisá el importe.`, warning: '' };
  }
  const big = (payments || []).find(p => T > 0 && Number(p.amount) > T * LIMITS.payFactor);
  if (big) return { error: '', warning: `Anotaste ${fmtMoney(big.amount)} para una venta de ${fmtMoney(T)} (más de ${LIMITS.payFactor} veces el total).` };
  return { error: '', warning: '' };
}

// ---------- Búsqueda tolerante (acentos y mayúsculas) ----------

/** ¿Todas las palabras de la búsqueda están en el texto? (sin acentos ni mayúsculas) */
export function textMatch(text, query) {
  const q = norm(query);
  if (!q) return true;
  const t = norm(text);
  return q.split(/\s+/).filter(Boolean).every(w => t.includes(w));
}

// ---------- Filtros de productos ----------

export const PRODUCT_FILTERS = {
  q: '', cat: '', subcat: '', supplier: '', stock: '', unit: '', active: 'activos',
  sinCodigo: false, sinPrecio: false, conFoto: false, sort: 'nombre',
};

export const PRODUCT_SORTS = [
  ['nombre', 'Nombre (A-Z)'], ['precio', 'Precio (menor a mayor)'], ['precio_desc', 'Precio (mayor a menor)'],
  ['stock', 'Stock (menor a mayor)'], ['stock_desc', 'Stock (mayor a menor)'], ['cambio', 'Último cambio'],
];

/** Cuántos filtros (además del texto) están puestos */
export function activeProductFilters(f) {
  let n = 0;
  for (const k of ['cat', 'supplier', 'stock', 'unit']) if (f[k]) n++;
  if (f.active && f.active !== 'activos') n++;
  for (const k of ['sinCodigo', 'sinPrecio', 'conFoto']) if (f[k]) n++;
  return n;
}

/**
 * Filtra y ordena productos. f: ver PRODUCT_FILTERS. stockOf(p): stock en la sucursal del equipo.
 * Con texto: primero el código exacto, después los que empiezan con la primera palabra.
 */
export function filterProducts(list, f = {}, { stockOf = p => Number(p.stock) || 0, hasPhoto = p => !!p.photo } = {}) {
  const F = { ...PRODUCT_FILTERS, ...f };
  const q = String(F.q || '').trim();
  const nq = norm(q);
  const words = nq.split(/\s+/).filter(Boolean);
  const out = [];
  for (const p of list || []) {
    if (!p || p.deleted) continue;
    if (F.active === 'activos' && p.active === 0) continue;
    if (F.active === 'inactivos' && p.active !== 0) continue;
    if (F.cat && (p.category || 'General') !== F.cat) continue;
    if (F.subcat && norm(p.subcategory) !== norm(F.subcat)) continue; // subrubro (esquema 0006)
    if (F.supplier === '-' ? !!p.supplier_id : F.supplier && p.supplier_id !== F.supplier) continue;
    if (F.unit && (p.unit === 'kg' ? 'kg' : 'u') !== F.unit) continue;
    if (F.sinCodigo && (String(p.barcode || '').trim() || String(p.sku || '').trim())) continue;
    if (F.sinPrecio && Number(p.price) > 0) continue;
    if (F.conFoto && !hasPhoto(p)) continue;
    if (F.stock) {
      const s = stockOf(p);
      if (F.stock === 'con' && !(s > 0)) continue;
      if (F.stock === 'sin' && s !== 0) continue;
      if (F.stock === 'negativo' && !(s < 0)) continue;
      if (F.stock === 'bajo' && !(Number(p.stock_min) > 0 && s <= Number(p.stock_min))) continue;
    }
    let rank = 0;
    if (q) {
      const exact = (p.barcode && String(p.barcode) === q) || (p.sku && norm(p.sku) === nq);
      if (exact) rank = 3;
      else {
        const n = norm(p.name);
        const hay = `${n} ${norm(p.category)} ${p.barcode || ''} ${norm(p.sku)}`;
        if (!words.every(w => hay.includes(w))) continue;
        rank = n.startsWith(words[0]) ? 2 : 1;
      }
    }
    out.push({ p, rank });
  }
  const byName = (a, b) => String(a.p.name || '').localeCompare(String(b.p.name || ''), 'es');
  const cmp = {
    nombre: byName,
    precio: (a, b) => (Number(a.p.price) || 0) - (Number(b.p.price) || 0) || byName(a, b),
    precio_desc: (a, b) => (Number(b.p.price) || 0) - (Number(a.p.price) || 0) || byName(a, b),
    stock: (a, b) => stockOf(a.p) - stockOf(b.p) || byName(a, b),
    stock_desc: (a, b) => stockOf(b.p) - stockOf(a.p) || byName(a, b),
    cambio: (a, b) => (Number(b.p.updated_at) || 0) - (Number(a.p.updated_at) || 0),
  }[F.sort] || byName;
  // Con texto, lo más parecido arriba; el orden elegido desempata (si no se eligió otro que nombre)
  out.sort((a, b) => (q && F.sort === 'nombre' ? b.rank - a.rank : (b.rank === 3) - (a.rank === 3)) || cmp(a, b));
  return out.map(x => x.p);
}

// ---------- Filtros de ventas ----------

export const SALE_FILTERS = { method: '', user: '', seller: '', status: '', doc: '', min: '', max: '', q: '' };

/** ¿La venta pasa los filtros extra (comprobante, monto, vendedor, texto)? custName(id) da el nombre del cliente. */
export function saleExtraMatch(s, f = {}, { custName = () => '' } = {}) {
  const d = s.doc || {};
  if (f.doc === 'factura' && !(d.kind === 'factura' && d.status === 'autorizado')) return false;
  if (f.doc === 'no_fiscal' && d.kind === 'factura') return false;
  if (f.seller && (s.seller_id || '') !== (f.seller === '-' ? '' : f.seller)) return false;
  const min = Number(f.min), max = Number(f.max);
  if (f.min !== '' && f.min !== undefined && finite(min) && Number(s.total) < min) return false;
  if (f.max !== '' && f.max !== undefined && finite(max) && Number(s.total) > max) return false;
  if (f.q) {
    const q = String(f.q).trim();
    if (/^\d+$/.test(q)) { if (String(s.number) !== q && !(s.items || []).some(it => textMatch(it.name, q))) return false; }
    else if (!textMatch(`${custName(s.customer_id)} ${(s.items || []).map(it => it.name).join(' ')}`, q)) return false;
  }
  return true;
}

/** Total cobrado con un medio en una lista de ventas OK (para cuando se filtra por medio de pago) */
export function methodTotal(sales, method) {
  let t = 0;
  for (const s of sales || []) {
    if (s.status !== 'ok' || s.test || s.deleted) continue;
    for (const p of s.payments || []) if (p.method === method) t += Number(p.amount) || 0;
  }
  return round2(t);
}

// ---------- Historial de caja ----------

/** f: {from, to (ms), user, diff: '' | 'con' | 'faltante' | 'sobrante'} */
export function filterSessions(list, f = {}) {
  return (list || []).filter(s => {
    if (!s || s.deleted || !s.closed_at) return false;
    if (f.from && s.closed_at < f.from) return false;
    if (f.to && s.opened_at > f.to) return false;
    if (f.user && s.opened_by !== f.user && s.closed_by !== f.user) return false;
    const d = Number(s.difference) || 0;
    if (f.diff === 'con' && Math.abs(d) < 0.005) return false;
    if (f.diff === 'faltante' && !(d < -0.004)) return false;
    if (f.diff === 'sobrante' && !(d > 0.004)) return false;
    return true;
  }).sort((a, b) => b.closed_at - a.closed_at);
}

// ---------- Cierre de caja: faltante e informe ----------

/**
 * Faltante a cargo de quién: si cierra un cajero/vendedor, de él; si cierra el dueño o el encargado, de quien abrió la caja.
 * Devuelve {shortage_amount (≥ 0), shortage_user_id}.
 */
export function shortageOf(difference, { closer, opener } = {}) {
  const d = round2(difference);
  if (!(d < -0.004)) return { shortage_amount: 0, shortage_user_id: null };
  const who = closer && !isManager(closer.role) ? closer : (opener || closer);
  return { shortage_amount: round2(-d), shortage_user_id: who ? who.id : null };
}

const LIST_MAX = 60;

/**
 * Informe de cierre (se guarda en cash_sessions.closing_report).
 * d: {session, sales, movements, returns (de esta caja), stockMoves (de la sucursal), products (Map o lista), counted, closedAt, mainId}
 * Incluye ventas por medio, ingresos y egresos, esperado vs contado, devoluciones, anulaciones, ventas de "monto libre",
 * productos que quedaron con stock negativo y ajustes de stock hechos durante el turno.
 */
export function closingReport({ session, sales = [], movements = [], returns = [], stockMoves = [], products = [], counted = null, closedAt = Date.now(), mainId = 'main' }) {
  const a = computeArqueo({ opening: session.opening_amount, sales, movements, counted, returns });
  const branch = branchOf(session, mainId);
  const prodMap = products instanceof Map ? products : new Map((products || []).map(p => [p.id, p]));
  const mv = type => movements.filter(m => !m.deleted && m.type === type && (!m.method || m.method === 'efectivo')).sort((x, y) => x.created_at - y.created_at)
    .map(m => ({ amount: round2(m.amount), reason: m.reason || '', user_id: m.user_id || null, at: m.created_at }));
  const ok = sales.filter(s => !s.deleted && s.status === 'ok');
  const voided = sales.filter(s => !s.deleted && s.status === 'anulada');
  const free = [];
  for (const s of ok) for (const it of s.items || []) if (!it.product_id) free.push({ sale: s.number, name: it.name, amount: round2(it.subtotal), user_id: s.user_id });
  const rets = returns.filter(r => r && !r.deleted);
  // Productos tocados en el turno: lo vendido en esta caja y cualquier movimiento de stock de la sucursal mientras estuvo abierta
  const from = session.opened_at, to = closedAt;
  const touched = new Set();
  for (const s of sales) for (const it of s.items || []) if (it.product_id) touched.add(it.product_id);
  const adjustments = [];
  for (const m of stockMoves) {
    if (m.deleted || branchOf(m, mainId) !== branch || m.created_at < from || m.created_at > to) continue;
    touched.add(m.product_id);
    if (m.reason === 'ajuste' || m.reason === 'conteo') {
      const p = prodMap.get(m.product_id);
      adjustments.push({ product_id: m.product_id, name: p ? p.name : '—', qty: round3(m.qty), reason: m.reason, note: m.note || '', user_id: m.user_id || null, at: m.created_at });
    }
  }
  const negatives = [];
  for (const id of touched) {
    const p = prodMap.get(id);
    if (!p || p.deleted) continue;
    const st = stockIn(p, branch, mainId);
    if (st < 0) negatives.push({ product_id: id, name: p.name, stock: st, unit: p.unit === 'kg' ? 'kg' : 'u' });
  }
  negatives.sort((x, y) => x.stock - y.stock);
  const sum = list => round2(list.reduce((t, x) => t + (Number(x.amount ?? x.total) || 0), 0));
  const ing = mv('ingreso'), egr = mv('egreso');
  return {
    v: 1, branch_id: branch, opened_at: session.opened_at, closed_at: closedAt,
    opening: a.opening, sales_count: a.count, sales_total: a.salesTotal, by_method: a.byMethod, cash_sales: a.cashSales,
    ingresos: { total: a.ingresos, items: ing.slice(0, LIST_MAX) },
    egresos: { total: a.egresos, items: egr.slice(0, LIST_MAX) },
    expected: a.expected, counted: a.counted, difference: a.difference,
    returns: { count: rets.length, total: sum(rets.map(r => ({ total: r.total }))), cash: a.devoluciones, items: rets.slice(0, LIST_MAX).map(r => ({ number: r.number, total: round2(r.total), user_id: r.user_id || null })) },
    voided: { count: voided.length, total: sum(voided.map(s => ({ total: s.total }))), items: voided.slice(0, LIST_MAX).map(s => ({ number: s.number, total: round2(s.total), user_id: s.user_id || null, voided_by: s.voided_by || null, reason: s.void_reason || '' })) },
    free: { count: free.length, total: sum(free), items: free.slice(0, LIST_MAX) },
    negatives: negatives.slice(0, LIST_MAX), negatives_count: negatives.length,
    adjustments: adjustments.slice(0, LIST_MAX), adjustments_count: adjustments.length,
  };
}

/**
 * Productos de una sucursal con stock para revisar: negativo, o con decimales siendo "por unidad".
 * Devuelve [{product, stock, kind: 'negativo' | 'decimales'}], primero los negativos.
 */
export function stockIssues(products, branchId, mainId = 'main', { onlyIds = null } = {}) {
  const out = [];
  for (const p of products || []) {
    if (!p || p.deleted || p.active === 0) continue;
    if (onlyIds && !onlyIds.has(p.id)) continue;
    const s = stockIn(p, branchId, mainId);
    if (!Number.isFinite(s)) out.push({ product: p, stock: 0, kind: 'negativo' });
    else if (s < 0) out.push({ product: p, stock: s, kind: 'negativo' });
    else if (p.unit !== 'kg' && !Number.isInteger(round3(s))) out.push({ product: p, stock: s, kind: 'decimales' });
  }
  return out.sort((a, b) => (a.kind === b.kind ? a.stock - b.stock : a.kind === 'negativo' ? -1 : 1));
}

// ---------- Faltantes por cajero ----------

export const SHORTAGE_ACTIONS = { faltante_descontado: 'descontado', faltante_justificado: 'justificado', faltante_pendiente: 'pendiente' };

/** Estado de un faltante según la auditoría (gana la última marca): 'pendiente' | 'descontado' | 'justificado' */
export function shortageStatus(sessionId, audits = []) {
  let last = null;
  for (const a of audits) {
    if (!a || a.entity_id !== sessionId || !SHORTAGE_ACTIONS[a.action]) continue;
    if (!last || a.created_at >= last.created_at) last = a;
  }
  return last ? SHORTAGE_ACTIONS[last.action] : 'pendiente';
}

/** Faltantes agrupados por cajero: [{user_id, count, total, pending, pendingCount, items: [{session, amount, status}]}] (mayor pendiente primero) */
export function shortagesByCashier(sessions = [], audits = []) {
  const by = new Map();
  for (const s of sessions) {
    if (!s || s.deleted || !s.closed_at) continue;
    const amt = Number(s.shortage_amount) > 0 ? round2(s.shortage_amount) : (Number(s.difference) < -0.004 ? round2(-s.difference) : 0);
    if (!(amt > 0)) continue;
    const uid = s.shortage_user_id || s.closed_by || s.opened_by || '';
    const g = by.get(uid) || { user_id: uid, count: 0, total: 0, pending: 0, pendingCount: 0, items: [] };
    const status = shortageStatus(s.id, audits);
    g.count++; g.total = round2(g.total + amt);
    if (status === 'pendiente') { g.pending = round2(g.pending + amt); g.pendingCount++; }
    g.items.push({ session: s, amount: amt, status });
    by.set(uid, g);
  }
  const out = [...by.values()];
  for (const g of out) g.items.sort((a, b) => b.session.closed_at - a.session.closed_at);
  return out.sort((a, b) => b.pending - a.pending || b.total - a.total);
}

// ---------- Cambios en lote ----------

/** Redondea un precio: step 0 = a centavos; si no, al múltiplo de step más cercano (nunca a 0 si había precio) */
export function roundPrice(x, step = 0) {
  const v = Number(x) || 0;
  if (!(step > 0)) return round2(v);
  const r = Math.round(v / step) * step;
  return round2(r > 0 ? r : (v > 0 ? step : 0));
}

/**
 * Vista previa de un cambio de precio por porcentaje. pct: +10 = 10 % más caro.
 * Devuelve {error, rows: [{id, name, old, price}], up, down, same}.
 */
export function bulkPricePreview(products, pct, step = 0) {
  const p = Number(pct);
  if (!finite(p) || p === 0) return { error: 'Escribí el porcentaje (ej: 10 para subir 10 %, -5 para bajar 5 %).', rows: [] };
  if (p <= -90 || p > 300) return { error: 'El porcentaje tiene que estar entre -90 % y 300 %.', rows: [] };
  const rows = [];
  let up = 0, down = 0, same = 0;
  for (const x of products || []) {
    if (!x || x.deleted) continue;
    const old = round2(x.price);
    const price = roundPrice(old * (1 + p / 100), step);
    if (price > old) up++; else if (price < old) down++; else same++;
    rows.push({ id: x.id, name: x.name, old, price });
  }
  return { error: '', rows, up, down, same };
}

/** ¿El producto tiene ventas o stock? (para ofrecer "Desactivar" en vez de eliminar). soldIds: Set de product_id con ventas */
export function productUsage(p, soldIds, mainId = 'main') {
  const stocks = p && p.stocks && typeof p.stocks === 'object' && !Array.isArray(p.stocks) ? p.stocks : null;
  const withStock = stocks ? Object.entries(stocks).filter(([, v]) => Math.abs(Number(v) || 0) > 0.0005).map(([k]) => k) : (Math.abs(Number(p.stock) || 0) > 0.0005 ? [mainId] : []);
  return { hasSales: !!(soldIds && soldIds.has(p.id)), hasStock: withStock.length > 0, stock: round3(Number(p.stock) || 0), branches: withStock };
}

/** Set de product_id que aparecen en ventas (no borradas) */
export function soldProductIds(sales = []) {
  const s = new Set();
  for (const v of sales) if (v && !v.deleted) for (const it of v.items || []) if (it.product_id) s.add(it.product_id);
  return s;
}

// ---------- Papelera ----------

export const TRASH_DAYS = 30;

/** Productos borrados en los últimos 30 días (el updated_at de un borrado es cuándo se borró), el más nuevo primero */
export function trashList(products = [], now = Date.now(), days = TRASH_DAYS) {
  const since = now - days * 86400000;
  return products.filter(p => p && p.deleted && Number(p.updated_at) >= since).sort((a, b) => b.updated_at - a.updated_at);
}

// ---------- Reloj del equipo ----------

/** Minutos que el reloj del equipo está atrasado respecto del último movimiento guardado (0 si está bien) */
export function clockBehind(now, lastSeen, toleranceMin = 10) {
  const diff = (Number(lastSeen) || 0) - now;
  return diff > toleranceMin * 60000 ? Math.round(diff / 60000) : 0;
}

// ---------- Auditoría ----------

export const AUDIT_ACTIONS = {
  autorizacion: 'Autorización con PIN',
  autorizacion_fallida: 'PIN de autorización incorrecto',
  venta_anulada: 'Venta anulada',
  nota_debito: 'Nota de débito a un cliente',
  devolucion: 'Devolución / nota de crédito',
  precio_venta: 'Cambio de precio en una venta',
  descuento: 'Descuento en una venta',
  ajuste_stock: 'Ajuste de stock',
  producto_precio: 'Cambio de precio de un producto',
  producto_eliminado: 'Producto eliminado',
  producto_desactivado: 'Producto desactivado',
  producto_activado: 'Producto activado',
  producto_restaurado: 'Producto restaurado de la papelera',
  lote_precio: 'Cambio de precios en lote',
  lote_categoria: 'Cambio de categoría en lote',
  lote_eliminar: 'Productos eliminados en lote',
  lote_desactivar: 'Productos desactivados en lote',
  lote_activar: 'Productos activados en lote',
  caja_apertura: 'Apertura de caja',
  caja_ingreso: 'Ingreso de caja',
  caja_egreso: 'Egreso de caja',
  caja_cierre: 'Cierre de caja',
  caja_faltante: 'Cierre con faltante',
  caja_reabierta: 'Caja reabierta',
  faltante_descontado: 'Faltante descontado al cajero',
  faltante_justificado: 'Faltante justificado',
  faltante_pendiente: 'Faltante vuelto a pendiente',
  reloj_atrasado: 'Fecha u hora del equipo atrasada',
  conteo_stock: 'Conteo de góndola aplicado',
  fotos_importadas: 'Fotos de productos importadas',
  usuario_guardado: 'Usuario creado o cambiado',
  empezar_de_cero: 'Empezar de cero',
};
export function auditLabel(action) { return AUDIT_ACTIONS[action] || action; }

/** f: {from, to (ms), user, action, branch, q}. Más nuevo primero. */
export function filterAudit(list = [], f = {}) {
  return list.filter(a => {
    if (!a || a.deleted) return false;
    if (f.from && a.created_at < f.from) return false;
    if (f.to && a.created_at > f.to) return false;
    if (f.user && a.user_id !== f.user && !(a.detail && a.detail.authorized_by === f.user)) return false;
    if (f.action && a.action !== f.action && !(f.action === 'caja' && String(a.action).startsWith('caja_')) && !(f.action === 'lote' && String(a.action).startsWith('lote_'))) return false;
    if (f.branch && a.branch_id !== f.branch) return false;
    if (f.q && !textMatch(`${auditLabel(a.action)} ${a.entity || ''} ${JSON.stringify(a.detail || {})}`, f.q)) return false;
    return true;
  }).sort((a, b) => b.created_at - a.created_at);
}
