// =====================================================================
// cuentas.js — Lógica pura de cuentas corrientes (proveedores y clientes),
// liquidaciones, límite de crédito y comisiones de vendedores.
// Sin DOM ni IndexedDB: se prueba con node --test (tests/cuentas.test.mjs).
// Todas las cuentas se hacen en CENTAVOS ENTEROS (sin errores de coma flotante).
// =====================================================================
import { round2, parseNum } from './logic.js';

/** Pesos → centavos enteros (1.15 → 115) */
export const toCents = x => Math.round(round2(x) * 100);
/** Centavos → pesos con 2 decimales */
export const fromCents = c => round2(Math.round(Number(c) || 0) / 100);

/** División entera redondeando al centavo más cercano (mitad hacia arriba, simétrico para negativos) */
export function roundDiv(n, d) {
  const s = n < 0 ? -1 : 1;
  return s * Math.floor((Math.abs(n) * 2 + d) / (2 * d));
}

/** Porcentaje (hasta 3 decimales) de un importe en centavos: pctOf(10000, 2.5) = 250 */
export function pctOf(cents, pct) {
  const milli = Math.round((Number(pct) || 0) * 1000); // 2,5 % → 2500
  return roundDiv(Math.round(cents) * milli, 100000);
}

// ---------- Catálogos ----------

export const SUPPLIER_METHODS = [
  { id: 'efectivo', label: 'Efectivo' }, { id: 'transferencia', label: 'Transferencia' }, { id: 'cheque', label: 'Cheque' },
  { id: 'debito', label: 'Débito' }, { id: 'mercadopago', label: 'Mercado Pago' }, { id: 'otro', label: 'Otro' },
];
export const CUSTOMER_METHODS = [
  { id: 'efectivo', label: 'Efectivo' }, { id: 'transferencia', label: 'Transferencia' }, { id: 'mercadopago', label: 'Mercado Pago' },
  { id: 'debito', label: 'Débito' }, { id: 'credito', label: 'Crédito' }, { id: 'cheque', label: 'Cheque' }, { id: 'otro', label: 'Otro' },
];
export function methodLabel(id) {
  const m = [...CUSTOMER_METHODS, ...SUPPLIER_METHODS].find(x => x.id === id);
  return m ? m.label : (id === 'cuenta_corriente' ? 'Cuenta corriente' : id || '');
}
export const IVA_CONDITIONS = [['RI', 'Responsable inscripto'], ['MT', 'Monotributo'], ['EX', 'Exento'], ['CF', 'Consumidor final']];
export const PROVINCES = [
  'Mendoza', 'Buenos Aires', 'Ciudad de Buenos Aires', 'Catamarca', 'Chaco', 'Chubut', 'Córdoba', 'Corrientes', 'Entre Ríos', 'Formosa',
  'Jujuy', 'La Pampa', 'La Rioja', 'Misiones', 'Neuquén', 'Río Negro', 'Salta', 'San Juan', 'San Luis', 'Santa Cruz', 'Santa Fe',
  'Santiago del Estero', 'Tierra del Fuego', 'Tucumán',
];

/** ¿Activo? (los registros viejos no tienen el campo: null = activo) */
export const isActive = r => !!r && !r.deleted && r.active !== 0;

// ---------- Saldo del sistema anterior (SGI) ----------

/**
 * Lee "Saldo en SGI al 16/11/2026: $ 1.234,56" de las notas del proveedor.
 * Acepta "$ -6.000,00", "-$ 6.000,00", "228756.94". Devuelve {amount, date, iso} o null.
 */
export function parseSgiBalance(notes) {
  const m = String(notes || '').match(/saldo en sgi al\s*(\d{1,2})\/(\d{1,2})\/(\d{2,4})\s*:?\s*(-?)\s*\$?\s*(-?)\s*(\d[\d.,]*)/i);
  if (!m) return null;
  const n = parseNum(m[6].replace(/[.,]$/, ''));
  if (!isFinite(n)) return null;
  const neg = m[4] === '-' || m[5] === '-';
  const year = m[3].length === 2 ? 2000 + Number(m[3]) : Number(m[3]);
  const iso = `${year}-${m[2].padStart(2, '0')}-${m[1].padStart(2, '0')}`;
  return { amount: round2(neg ? -n : n), date: `${m[1].padStart(2, '0')}/${m[2].padStart(2, '0')}/${year}`, iso };
}

// ---------- Cuenta corriente de proveedores ----------

/** Lo que una compra suma a la cuenta del proveedor (0 si es de contado o está borrada) */
export function purchaseDebt(p) {
  if (!p || p.deleted || p.status === 'anulada' || p.payment !== 'cuenta_corriente') return 0;
  // Nota de crédito del proveedor: resta. Retenciones (las practica el comercio al pagar): bajan lo que se le debe.
  const sign = p.doc_type === 'NC' ? -1 : 1;
  return fromCents(sign * (toCents(p.total) - retCents(p)) - toCents(p.paid || 0));
}
const retCents = p => toCents(p.ret_iva || 0) + toCents(p.ret_gan || 0) + toCents(p.ret_iibb || 0);
const docLabel = p => {
  const d = [p.doc_type && p.doc_type !== 'FC' ? p.doc_type : '', p.letter, p.doc_number || ''].filter(Boolean).join(' ');
  return d ? ` · ${d}` : p.invoice_ref ? ` · Fact. ${p.invoice_ref}` : '';
};

/**
 * Movimientos de la cuenta de un proveedor, del más viejo al más nuevo.
 * debit = aumenta lo que le debemos (compra a cuenta, saldo inicial positivo); credit = lo baja (pagos).
 * Importes en centavos.
 */
export function supplierLedger(supplierId, { purchases = [], payments = [] } = {}) {
  const out = [];
  for (const p of purchases) {
    if (!p || p.deleted || p.status === 'anulada' || p.supplier_id !== supplierId) continue;
    const total = toCents(p.total);
    const nc = p.doc_type === 'NC';
    if (p.payment === 'cuenta_corriente') {
      if (nc) out.push({ id: p.id, at: p.created_at, kind: 'compra', label: `Nota de crédito${docLabel(p)}`, debit: 0, credit: total, ref: p });
      else out.push({ id: p.id, at: p.created_at, kind: 'compra', label: `${p.doc_type === 'ND' ? 'Nota de débito' : 'Compra a cuenta corriente'}${docLabel(p)}`, debit: total, credit: 0, ref: p, due: p.due_date || '' });
      const ret = retCents(p);
      if (ret) out.push({ id: p.id + ':ret', at: p.created_at, kind: 'pago', label: 'Retenciones', debit: nc ? ret : 0, credit: nc ? 0 : ret, ref: p });
      const paid = toCents(p.paid || 0);
      if (paid) out.push({ id: p.id + ':paid', at: p.created_at, kind: 'pago', label: 'Pagado al comprar', debit: paid < 0 ? -paid : 0, credit: paid > 0 ? paid : 0, ref: p });
    } else {
      out.push({ id: p.id, at: p.created_at, kind: 'contado', label: `${nc ? 'Nota de crédito' : 'Compra'} de contado${docLabel(p)}`, debit: 0, credit: 0, cash: nc ? -total : total, ref: p });
    }
  }
  for (const s of payments) {
    if (!s || s.deleted || s.supplier_id !== supplierId) continue;
    const a = toCents(s.amount);
    const kind = s.kind || 'pago';
    if (kind === 'pago') {
      out.push({ id: s.id, at: s.created_at, kind, label: `Pago ${methodLabel(s.method).toLowerCase()}${s.reference ? ` · ${s.reference}` : ''}`, debit: 0, credit: a, ref: s });
    } else {
      const label = kind === 'saldo_inicial' ? `Saldo inicial${s.notes ? ` (${s.notes})` : ''}` : `Ajuste${s.notes ? ` · ${s.notes}` : ''}`;
      out.push({ id: s.id, at: s.created_at, kind, label, debit: a > 0 ? a : 0, credit: a < 0 ? -a : 0, ref: s });
    }
  }
  return sortLedger(out);
}

const KIND_ORDER = { saldo_inicial: 0, compra: 1, contado: 1, venta: 1, pago: 2, cobro: 2, devolucion: 3, anulacion: 3, ajuste: 4 };
function sortLedger(list) {
  return list.sort((a, b) => (Number(a.at) || 0) - (Number(b.at) || 0) || (KIND_ORDER[a.kind] ?? 9) - (KIND_ORDER[b.kind] ?? 9));
}

// ---------- Cuenta corriente de clientes ----------

const ccOf = list => (list || []).filter(p => p.method === 'cuenta_corriente').reduce((a, p) => a + toCents(p.amount), 0);

/**
 * Movimientos de la cuenta de un cliente. debit = aumenta lo que debe (venta a cuenta corriente);
 * credit = lo baja (cobros, devoluciones a cuenta, anulaciones).
 * Compatibilidad: los cobros de antes son solo cash_movements ("Cobro cuenta corriente: <nombre>").
 */
export function customerLedger(customer, { sales = [], returns = [], payments = [], movements = [] } = {}) {
  const id = customer.id;
  const out = [];
  for (const s of sales) {
    if (!s || s.deleted || s.test || s.customer_id !== id) continue;
    const cc = ccOf(s.payments);
    if (!cc) continue;
    out.push({ id: s.id, at: s.created_at, kind: 'venta', label: `Venta N° ${s.number}`, debit: cc, credit: 0, ref: s });
    if (s.status === 'anulada') out.push({ id: s.id + ':anul', at: s.voided_at || s.updated_at || s.created_at, kind: 'anulacion', label: `Anulación venta N° ${s.number}`, debit: 0, credit: cc, ref: s });
  }
  for (const r of returns) {
    if (!r || r.deleted || r.test || r.customer_id !== id) continue;
    const cc = ccOf(r.refunds);
    if (cc) out.push({ id: r.id, at: r.created_at, kind: 'devolucion', label: `Devolución N° ${r.number}`, debit: 0, credit: cc, ref: r });
  }
  for (const p of payments) {
    if (!p || p.deleted || p.customer_id !== id) continue;
    const a = toCents(p.amount);
    if ((p.kind || 'pago') === 'ajuste') out.push({ id: p.id, at: p.created_at, kind: 'ajuste', label: `Ajuste${p.notes ? ` · ${p.notes}` : ''}`, debit: a > 0 ? a : 0, credit: a < 0 ? -a : 0, ref: p });
    else out.push({ id: p.id, at: p.created_at, kind: 'cobro', label: `Cobro ${methodLabel(p.method).toLowerCase()}${p.reference ? ` · ${p.reference}` : ''}`, debit: 0, credit: a, ref: p });
  }
  const legacyReason = `Cobro cuenta corriente: ${customer.name}`;
  for (const m of movements) {
    if (!m || m.deleted || m.ref_id || !['ingreso', 'cobro'].includes(m.type)) continue;
    if (m.customer_id ? m.customer_id !== id : m.reason !== legacyReason) continue;
    out.push({ id: m.id, at: m.created_at, kind: 'cobro', label: `Cobro ${methodLabel(m.method || (m.type === 'ingreso' ? 'efectivo' : 'otro')).toLowerCase()}`, debit: 0, credit: toCents(m.amount), ref: m });
  }
  return sortLedger(out);
}

// ---------- Estado de cuenta ----------

/**
 * Estado de cuenta de un período, a partir del saldo ACTUAL guardado (balance, en pesos):
 * saldo al cierre = saldo actual − lo que pasó después de `to`; saldo anterior = cierre − lo del período.
 * Así el último saldo coincide con el que muestra la app aunque haya saldos cargados sin movimientos.
 * Devuelve centavos: {opening, closing, debit, credit, rows: [{...mov, balance}]}.
 */
export function statement(ledger, { balance = 0, from = -Infinity, to = Infinity } = {}) {
  const net = m => m.debit - m.credit;
  let after = 0;
  const rows = [];
  for (const m of ledger) {
    const at = Number(m.at) || 0;
    if (at > to) after += net(m);
    else if (at >= from) rows.push(m);
  }
  const closing = toCents(balance) - after;
  let debit = 0, credit = 0;
  for (const m of rows) { debit += m.debit; credit += m.credit; }
  const opening = closing - (debit - credit);
  let run = opening;
  const out = rows.map(m => { run += net(m); return { ...m, balance: run }; });
  return { opening, closing, debit, credit, rows: out };
}

/** Suma de todos los movimientos (en centavos): debería dar el saldo guardado */
export const ledgerTotal = ledger => ledger.reduce((a, m) => a + m.debit - m.credit, 0);

/**
 * Liquidación de un período para varios proveedores: saldo inicial, compras a cuenta, compras de contado,
 * pagos, ajustes y saldo final (centavos). Solo los que tuvieron movimientos o tienen saldo.
 */
export function liquidacion(suppliers, { purchases = [], payments = [], from = -Infinity, to = Infinity } = {}) {
  const rows = [];
  const tot = { opening: 0, compras: 0, contado: 0, pagos: 0, ajustes: 0, closing: 0 };
  for (const s of suppliers) {
    const led = supplierLedger(s.id, { purchases, payments });
    const st = statement(led, { balance: s.balance || 0, from, to });
    const r = { supplier: s, opening: st.opening, compras: 0, contado: 0, pagos: 0, ajustes: 0, closing: st.closing, count: st.rows.length, rows: st.rows };
    for (const m of st.rows) {
      if (m.kind === 'compra') r.compras += m.debit - m.credit; // las notas de crédito restan
      else if (m.kind === 'contado') r.contado += m.cash || 0;
      else if (m.kind === 'pago') r.pagos += m.credit - m.debit;
      else r.ajustes += m.debit - m.credit;
    }
    if (!r.count && !r.opening && !r.closing) continue;
    rows.push(r);
    for (const k of Object.keys(tot)) tot[k] += r[k];
  }
  rows.sort((a, b) => String(a.supplier.name || '').localeCompare(String(b.supplier.name || ''), 'es'));
  return { rows, totals: tot };
}

// ---------- Límite de crédito ----------

/**
 * ¿Una venta a cuenta corriente de `amount` pesos supera el límite del cliente?
 * Límite 0/null = sin límite. Devuelve centavos {limit, balance, after, over, available}.
 */
export function creditCheck(customer, amount) {
  const limit = toCents((customer && customer.credit_limit) || 0);
  const balance = toCents((customer && customer.balance) || 0);
  const after = balance + toCents(amount);
  const over = limit > 0 && after > limit;
  return { limit, balance, after, over, available: limit > 0 ? limit - balance : null };
}

// ---------- Vendedores y comisiones ----------

/** Vendedores: usuarios activos con rol "vendedor" o con comisión configurada */
export function sellers(users = []) {
  return users.filter(u => !u.deleted && u.active !== 0 && (u.role === 'vendedor' || u.commission_base))
    .sort((a, b) => String(a.name || '').localeCompare(String(b.name || ''), 'es'));
}

export const COMMISSION_BASES = { venta: 'Por venta', cobranza: 'Por cobranza' };

/**
 * Comisiones de un período. Cada vendedor según su base:
 * - "venta": % sobre lo vendido (sales.total, ya con descuentos) menos devoluciones / notas de crédito del período.
 *   Las ventas anuladas no cuentan.
 * - "cobranza": % sobre lo efectivamente cobrado: lo que no fue a cuenta corriente de sus ventas (menos lo devuelto
 *   que no fue a cuenta corriente) + los cobros de cuenta corriente con su seller_id.
 * - sin base: se muestran las ventas pero la comisión es 0.
 * La comisión se calcula sobre la base total del vendedor y se redondea al centavo una sola vez.
 * Fechas: cada venta, devolución y cobro cuenta en el período de SU fecha.
 * Devuelve centavos.
 */
export function commissionReport({ sales = [], returns = [], customerPayments = [], users = [], from = -Infinity, to = Infinity, sellerId = null } = {}) {
  const inRange = t => (Number(t) || 0) >= from && (Number(t) || 0) <= to;
  const byId = new Map(sales.map(s => [s.id, s]));
  const people = new Map();
  const get = id => {
    if (!people.has(id)) {
      const u = users.find(x => x.id === id) || { id, name: 'Usuario borrado' };
      people.set(id, {
        user_id: id, name: u.name, base_kind: u.commission_base || null, pct: Number(u.commission_pct) || 0,
        ventas: 0, devoluciones: 0, cobrado_contado: 0, devuelto_contado: 0, cobros_cc: 0, salesCount: 0, base: 0, commission: 0, lines: [],
      });
    }
    return people.get(id);
  };
  for (const u of sellers(users)) get(u.id);
  const okSale = s => s && !s.deleted && !s.test && s.status === 'ok' && s.seller_id;
  for (const s of sales) {
    if (!okSale(s) || !inRange(s.created_at)) continue;
    const p = get(s.seller_id);
    const total = toCents(s.total);
    const cc = ccOf(s.payments);
    p.salesCount++;
    p.ventas += total;
    p.cobrado_contado += total - cc;
    p.lines.push({ at: s.created_at, kind: 'venta', ref: `Venta N° ${s.number}`, customer_id: s.customer_id || null, total, cc, cobrado: total - cc });
  }
  for (const r of returns) {
    if (!r || r.deleted || r.test || !inRange(r.created_at)) continue;
    const s = byId.get(r.sale_id);
    if (!okSale(s)) continue;
    const p = get(s.seller_id);
    const total = toCents(r.total);
    const cc = ccOf(r.refunds);
    p.devoluciones += total;
    p.devuelto_contado += total - cc;
    p.lines.push({ at: r.created_at, kind: 'devolucion', ref: `Devolución N° ${r.number} (venta N° ${s.number})`, customer_id: r.customer_id || null, total: -total, cc: -cc, cobrado: -(total - cc) });
  }
  for (const c of customerPayments) {
    if (!c || c.deleted || (c.kind || 'pago') !== 'pago' || !c.seller_id || !inRange(c.created_at)) continue;
    const p = get(c.seller_id);
    const a = toCents(c.amount);
    p.cobros_cc += a;
    p.lines.push({ at: c.created_at, kind: 'cobro', ref: `Cobro cuenta corriente (${methodLabel(c.method).toLowerCase()})`, customer_id: c.customer_id || null, total: 0, cc: 0, cobrado: a });
  }
  const out = [];
  for (const p of people.values()) {
    if (sellerId && p.user_id !== sellerId) continue;
    p.lines.sort((a, b) => a.at - b.at);
    if (p.base_kind === 'venta') p.base = p.ventas - p.devoluciones;
    else if (p.base_kind === 'cobranza') p.base = p.cobrado_contado - p.devuelto_contado + p.cobros_cc;
    else p.base = 0;
    p.commission = p.base_kind ? pctOf(p.base, p.pct) : 0;
    out.push(p);
  }
  out.sort((a, b) => String(a.name || '').localeCompare(String(b.name || ''), 'es'));
  const totals = { base: 0, commission: 0, ventas: 0, devoluciones: 0 };
  for (const p of out) { totals.base += p.base; totals.commission += p.commission; totals.ventas += p.ventas; totals.devoluciones += p.devoluciones; }
  return { sellers: out, totals };
}
