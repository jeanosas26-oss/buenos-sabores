// =====================================================================
// zip.js — Lector de archivos .zip en JavaScript puro (sin librerías).
// Lee solo el índice del final del archivo (directorio central) y saca cada
// archivo recién cuando se pide, con File.slice: un .zip de cientos de MB no
// se carga entero en memoria. Descomprime con DecompressionStream('deflate-raw')
// del navegador. Soporta ZIP64 (más de 65.535 archivos o más de 4 GB), nombres
// en UTF-8 y los de Windows (CP850/CP437). No soporta .zip con contraseña.
// =====================================================================

const SIG_EOCD = 0x06054b50, SIG_EOCD64 = 0x06064b50, SIG_LOC64 = 0x07064b50, SIG_CEN = 0x02014b50, SIG_LOCAL = 0x04034b50;
const MAX = 0xffffffff;

// Mitad alta de la página de códigos 850 (la que usa el Explorador de Windows en español para los nombres)
const CP850 = 'ÇüéâäàåçêëèïîìÄÅÉæÆôöòûùÿÖÜø£Ø×ƒáíóúñÑªº¿®¬½¼¡«»░▒▓│┤ÁÂÀ©╣║╗╝¢¥┐└┴┬├─┼ãÃ╚╔╩╦╠═╬¤ðÐÊËÈıÍÎÏ┘┌█▄¦Ì▀ÓßÔÒõÕµþÞÚÛÙýÝ¯´­±‗¾¶§÷¸°¨·¹³²■ ';
export const CP850_HIGH = CP850; // (para las pruebas: tiene que tener 128 caracteres)

function decodeName(bytes, utf8Flag) {
  if (utf8Flag) return new TextDecoder('utf-8').decode(bytes);
  try { return new TextDecoder('utf-8', { fatal: true }).decode(bytes); } catch (e) { /* no es UTF-8: Windows */ }
  let s = '';
  for (const b of bytes) s += b < 128 ? String.fromCharCode(b) : CP850[b - 128];
  return s;
}

async function bytesAt(blob, start, len) {
  return new Uint8Array(await blob.slice(start, start + len).arrayBuffer());
}
const u16 = (b, o) => b[o] | (b[o + 1] << 8);
const u32 = (b, o) => (b[o] | (b[o + 1] << 8) | (b[o + 2] << 16) | (b[o + 3] << 24)) >>> 0;
const u64 = (b, o) => u32(b, o) + u32(b, o + 4) * 0x100000000;

const MIME = { jpg: 'image/jpeg', jpeg: 'image/jpeg', jfif: 'image/jpeg', png: 'image/png', webp: 'image/webp', gif: 'image/gif', bmp: 'image/bmp', avif: 'image/avif', heic: 'image/heic', heif: 'image/heif' };
/** Tipo MIME de una imagen según la extensión ('' si no es imagen) */
export function imageType(name) {
  const m = /\.([a-z0-9]+)$/i.exec(String(name || ''));
  return m ? MIME[m[1].toLowerCase()] || '' : '';
}

/**
 * Lee el índice de un .zip (File o Blob). Devuelve [{name, size, compressedSize, method, encrypted, dir, blob()}]:
 * blob() saca ese archivo (Promise<Blob>, con el tipo según la extensión).
 */
export async function readZip(file) {
  const size = file.size;
  if (size < 22) throw new Error('El archivo no es un .zip válido.');
  // El fin del directorio central está en los últimos 22 bytes + comentario (hasta 64 KB)
  const tailLen = Math.min(size, 22 + 0xffff);
  const tail = await bytesAt(file, size - tailLen, tailLen);
  let eocd = -1;
  for (let i = tail.length - 22; i >= 0; i--) if (u32(tail, i) === SIG_EOCD) { eocd = i; break; }
  if (eocd < 0) throw new Error('El archivo no es un .zip válido (o está incompleto).');
  let count = u16(tail, eocd + 10), cdSize = u32(tail, eocd + 12), cdOffset = u32(tail, eocd + 16);
  if (count === 0xffff || cdSize === MAX || cdOffset === MAX) {
    // ZIP64: el localizador está justo antes
    const at = eocd - 20;
    if (at < 0 || u32(tail, at) !== SIG_LOC64) throw new Error('El .zip está dañado (ZIP64 sin localizador).');
    const off = u64(tail, at + 8);
    const z = await bytesAt(file, off, 56);
    if (u32(z, 0) !== SIG_EOCD64) throw new Error('El .zip está dañado (ZIP64).');
    count = u64(z, 32); cdSize = u64(z, 40); cdOffset = u64(z, 48);
  }
  if (cdOffset + cdSize > size) throw new Error('El .zip está incompleto (¿se terminó de bajar?).');
  const cd = await bytesAt(file, cdOffset, cdSize);
  const out = [];
  let p = 0;
  for (let n = 0; n < count && p + 46 <= cd.length; n++) {
    if (u32(cd, p) !== SIG_CEN) throw new Error('El .zip está dañado (índice).');
    const flags = u16(cd, p + 8), method = u16(cd, p + 10);
    let comp = u32(cd, p + 20), uncomp = u32(cd, p + 24);
    const nameLen = u16(cd, p + 28), extraLen = u16(cd, p + 30), commentLen = u16(cd, p + 32);
    let local = u32(cd, p + 42);
    const name = decodeName(cd.subarray(p + 46, p + 46 + nameLen), flags & 0x800).replace(/\\/g, '/');
    // Campo extra ZIP64: trae los valores que en el encabezado quedaron en 0xFFFFFFFF, en este orden
    let e = p + 46 + nameLen;
    const eEnd = e + extraLen;
    while (e + 4 <= eEnd) {
      const id = u16(cd, e), len = u16(cd, e + 2);
      if (id === 0x0001) {
        let q = e + 4;
        if (uncomp === MAX) { uncomp = u64(cd, q); q += 8; }
        if (comp === MAX) { comp = u64(cd, q); q += 8; }
        if (local === MAX) { local = u64(cd, q); q += 8; }
      }
      e += 4 + len;
    }
    p = eEnd + commentLen;
    const dir = name.endsWith('/');
    const entry = { name, size: uncomp, compressedSize: comp, method, encrypted: !!(flags & 1), dir };
    entry.blob = () => extract(file, entry, local);
    out.push(entry);
  }
  return out;
}

async function extract(file, entry, localOffset) {
  if (entry.encrypted) throw new Error('El archivo del .zip tiene contraseña.');
  const h = await bytesAt(file, localOffset, 30);
  if (u32(h, 0) !== SIG_LOCAL) throw new Error('El .zip está dañado.');
  const start = localOffset + 30 + u16(h, 26) + u16(h, 28);
  const data = file.slice(start, start + entry.compressedSize);
  const type = imageType(entry.name) || 'application/octet-stream';
  if (entry.method === 0) return new Blob([data], { type });
  if (entry.method !== 8) throw new Error('El .zip usa una compresión que no se puede leer acá.');
  if (typeof DecompressionStream !== 'function') throw new Error('Este navegador no puede abrir .zip. Descomprimilo y elegí la carpeta.');
  const stream = data.stream().pipeThrough(new DecompressionStream('deflate-raw'));
  const out = await new Response(stream).blob();
  return new Blob([out], { type });
}
