// =====================================================================
// ia-match.js — Qué es cada cosa que leyó la IA en un comprobante (sin DOM ni IndexedDB: se prueba con node --test).
// Proveedor: por CUIT; si no, por nombre parecido. Renglones: por código de barras (EAN, con sus variantes), después por lo
// aprendido de ese proveedor (supplier_items: su código o su descripción → nuestro producto) y por último por nombre
// parecido. Cada renglón lleva un semáforo: verde (seguro), amarillo (parecido: mirarlo) o rojo (no se encontró).
// =====================================================================
import { codeVariants } from './barcode.js';

const onlyDigits = s => String(s ?? '').replace(/\D/g, '');

// ---------- Texto ----------

const UNIT = { kg: 'kg', kgs: 'kg', k: 'kg', kilo: 'kg', kilos: 'kg', g: 'g', gr: 'g', grs: 'g', grm: 'g', gramos: 'g', l: 'l', lt: 'l', lts: 'l', ltr: 'l', litro: 'l', litros: 'l', ml: 'ml', cc: 'ml', cm3: 'ml', u: 'u', un: 'u', uni: 'u', unid: 'u', unidades: 'u' };
const STOP = new Set(['de', 'del', 'la', 'las', 'el', 'los', 'y', 'con', 'sin', 'en', 'x', 'por', 'para', 'a', 'al', 'p', 'c']);

/** Minúsculas, sin acentos ni signos; "1,5LT" → "1.5l", "500 GRS" → "500g", "X 12" → "x12" */
export function normText(s) {
  let t = String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
  t = t.replace(/(\d),(\d)/g, '$1.$2');
  t = t.replace(/(\d+(?:\.\d+)?)\s*(kgs|kg|kilos?|k|grs|grm|gramos|gr|g|lts|ltr|lt|litros?|l|ml|cc|cm3|unidades|unid|uni|un|u)\b/g, (m, n, u) => `${Number(n)}${UNIT[u] || u}`);
  t = t.replace(/\bx\s*(\d+)\b/g, 'x$1');
  return t.replace(/[^a-z0-9.]+/g, ' ').replace(/(?<!\d)\.|\.(?!\d)/g, ' ').replace(/\s+/g, ' ').trim();
}
/** Palabras útiles (sin conectores) */
export function tokens(s) {
  return normText(s).split(' ').filter(w => w && !STOP.has(w) && !/^\.+$/.test(w));
}
const isSize = w => /^\d+(\.\d+)?(kg|g|l|ml|u)$/.test(w);
/** Tamaño en una unidad común: 1kg = 1000g, 1.5l = 1500ml */
function sizeOf(w) {
  const m = w.match(/^(\d+(?:\.\d+)?)(kg|g|l|ml|u)$/);
  if (!m) return null;
  const n = Number(m[1]);
  return m[2] === 'kg' ? 'g' + n * 1000 : m[2] === 'l' ? 'ml' + n * 1000 : m[2] + n;
}
/** ¿Dos palabras coinciden? 1 = igual, 0,85 = una es abreviatura de la otra ("playad" / "playadito"), 0 = no */
function wordSim(a, b) {
  if (a === b) return 1;
  if (isSize(a) || isSize(b)) return isSize(a) && isSize(b) && sizeOf(a) === sizeOf(b) ? 1 : 0;
  if (/^\d+$/.test(a) || /^\d+$/.test(b)) return 0;
  const [s, l] = a.length <= b.length ? [a, b] : [b, a];
  if (s.length >= 3 && l.startsWith(s)) return 0.85;
  return 0;
}

/**
 * Parecido entre dos descripciones (0 a 1): palabras en común (las abreviaturas valen casi entero) sobre el total de las dos.
 * Si las dos dicen un tamaño y no coincide (1kg vs 500g), es otro producto: baja a la mitad.
 */
export function similarity(a, b) {
  const A = Array.isArray(a) ? a : tokens(a), B = Array.isArray(b) ? b : tokens(b);
  if (!A.length || !B.length) return 0;
  const used = new Set();
  let hit = 0;
  for (const w of A) {
    let best = 0, bi = -1;
    B.forEach((x, i) => { if (used.has(i)) return; const s = wordSim(w, x); if (s > best) { best = s; bi = i; } });
    if (bi >= 0 && best > 0) { used.add(bi); hit += best; }
  }
  let score = (2 * hit) / (A.length + B.length);
  const sa = A.filter(isSize).map(sizeOf), sb = B.filter(isSize).map(sizeOf);
  if (sa.length && sb.length && !sa.some(x => sb.includes(x))) score *= 0.5;
  return Math.round(score * 1000) / 1000;
}

// ---------- Índice de productos (miles: se arma una vez por carga) ----------

/** Índice para buscar rápido por código y por palabra */
export function buildIndex(products) {
  const byCode = new Map(), byWord = new Map(), toks = new Map();
  for (const p of products) {
    if (!p || p.deleted || p.active === 0) continue;
    for (const c of [p.barcode, p.sku].filter(Boolean)) for (const v of codeVariants(String(c).trim())) if (!byCode.has(v)) byCode.set(v, p);
    const t = tokens(p.name);
    toks.set(p.id, t);
    for (const w of t) {
      if (isSize(w) || w.length < 3) continue;
      const k = w.slice(0, 4);
      if (!byWord.has(k)) byWord.set(k, []);
      byWord.get(k).push(p);
    }
  }
  return { byCode, byWord, toks, products };
}

/** Los productos más parecidos a una descripción: [{product, score}] de mayor a menor */
export function fuzzyProducts(desc, index, limit = 5) {
  const t = tokens(desc);
  const cand = new Set();
  for (const w of t) {
    if (isSize(w) || w.length < 3) continue;
    for (const p of index.byWord.get(w.slice(0, 4)) || []) cand.add(p);
  }
  const out = [];
  for (const p of cand) {
    const s = similarity(t, index.toks.get(p.id) || tokens(p.name));
    if (s > 0.2) out.push({ product: p, score: s });
  }
  return out.sort((a, b) => b.score - a.score || String(a.product.name).localeCompare(String(b.product.name))).slice(0, limit);
}

// ---------- Proveedor ----------

/** Proveedor del comprobante: por CUIT (exacto) o por razón social / nombre parecido. → {supplier, how, score} o null */
export function matchSupplier(prov, suppliers) {
  if (!prov) return null;
  const live = suppliers.filter(s => s && !s.deleted);
  const cuit = onlyDigits(prov.cuit);
  if (cuit.length === 11) {
    const s = live.find(x => onlyDigits(x.cuit) === cuit);
    if (s) return { supplier: s, how: 'cuit', score: 1 };
  }
  const name = prov.razon_social;
  if (!name) return null;
  const clean = x => tokens(x).filter(w => !/^(sa|srl|sas|sh|sacif|saic|sociedad|anonima|cia|hnos)$/.test(w));
  const A = clean(name);
  let best = null;
  for (const s of live) {
    const sc = Math.max(similarity(A, clean(s.legal_name || '')), similarity(A, clean(s.name || '')));
    if (!best || sc > best.score) best = { supplier: s, how: 'nombre', score: sc };
  }
  return best && best.score >= 0.6 ? best : null;
}

// ---------- Lo aprendido de cada proveedor ----------

function hash(s) {
  let h1 = 2166136261, h2 = 5381;
  for (let i = 0; i < s.length; i++) { const c = s.charCodeAt(i); h1 = Math.imul(h1 ^ c, 16777619); h2 = (Math.imul(h2, 33) + c) | 0; }
  return (h1 >>> 0).toString(36) + (h2 >>> 0).toString(36);
}
/** Clave de lo aprendido: el código del proveedor si lo tiene; si no, su descripción normalizada */
export function learnKey(code, desc) {
  const c = String(code || '').trim().toLowerCase();
  return c ? 'c:' + c : 'd:' + normText(desc);
}
/** Id fijo (el mismo en todos los equipos) del registro supplier_items de ese proveedor y ese código/descripción */
export function supplierItemId(supplierId, code, desc) {
  return 'si-' + hash(String(supplierId || '') + '|' + learnKey(code, desc));
}

/**
 * Qué producto es un renglón leído.
 * ctx: {index (buildIndex), supplierId, learned (supplier_items vivos), productOf(id)}
 * → {product, how: 'ean'|'aprendido'|'nombre'|null, light: 'verde'|'amarillo'|'rojo', score, candidates: [{product, score}]}
 */
export function matchLine(line, ctx) {
  const codes = [line.ean, line.codigo].filter(Boolean).map(x => String(x).trim());
  for (const c of codes) {
    if (!/^\d{8,14}$/.test(c)) continue;
    for (const v of codeVariants(c)) {
      const p = ctx.index.byCode.get(v);
      if (p) return { product: p, how: 'ean', light: 'verde', score: 1, candidates: [] };
    }
  }
  if (ctx.supplierId) {
    const learned = (ctx.learned || []).filter(x => x && !x.deleted && x.supplier_id === ctx.supplierId && x.product_id);
    const byCode = line.codigo ? learned.find(x => x.supplier_code && String(x.supplier_code).trim().toLowerCase() === String(line.codigo).trim().toLowerCase()) : null;
    const nd = normText(line.descripcion);
    const byDesc = byCode ? null : learned.find(x => x.supplier_desc && normText(x.supplier_desc) === nd);
    const hit = byCode || byDesc;
    const p = hit && ctx.productOf(hit.product_id);
    if (p && !p.deleted) return { product: p, how: 'aprendido', light: 'verde', score: 1, candidates: [] };
  }
  const cand = fuzzyProducts(line.descripcion, ctx.index, 5);
  const top = cand[0];
  if (top && top.score >= 0.6) {
    // Si el segundo está casi igual, no es seguro cuál es: amarillo igual, pero con las opciones a la vista
    return { product: top.product, how: 'nombre', light: 'amarillo', score: top.score, candidates: cand };
  }
  return { product: null, how: null, light: 'rojo', score: top ? top.score : 0, candidates: cand };
}

/**
 * Registros supplier_items para aprender lo que el usuario confirmó al guardar (solo con proveedor y producto).
 * lines: [{codigo, ean, descripcion, product_id, unit_cost}]; existing(id) → registro actual o null.
 */
export function learnRecords(supplierId, lines, existing, { now = Date.now(), userId = null } = {}) {
  if (!supplierId) return [];
  const out = new Map();
  for (const l of lines) {
    if (!l || !l.product_id || !(l.codigo || l.descripcion)) continue;
    const id = supplierItemId(supplierId, l.codigo, l.descripcion);
    const cur = existing(id);
    if (out.has(id)) continue;
    out.set(id, {
      id, supplier_id: supplierId, supplier_code: l.codigo ? String(l.codigo).trim() : null, supplier_desc: l.descripcion || null,
      product_id: l.product_id, ean: l.ean || null, last_cost: Number(l.unit_cost) || null,
      uses: (cur && !cur.deleted && cur.product_id === l.product_id ? Number(cur.uses) || 0 : 0) + 1,
      created_at: cur && cur.created_at ? cur.created_at : now, user_id: userId, deleted: 0,
    });
  }
  return [...out.values()];
}
