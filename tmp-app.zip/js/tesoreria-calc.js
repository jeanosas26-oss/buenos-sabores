// =====================================================================
// tesoreria-calc.js — Cuentas puras de gastos, cheques, tesorería/balance,
// informes de caja y "recalcular stock y saldos".
// Sin DOM ni IndexedDB: se prueba con node --test (tests/tesoreria.test.mjs).
// Importes en centavos enteros por dentro; se devuelven en pesos.
// =====================================================================
import { round2, round3, norm, salesReport, computeArqueo, productStocks, branchOf } from './logic.js';
import { supplierLedger, customerLedger, ledgerTotal } from './cuentas.js';
import { purchaseSign, isVoidPurchase, purchaseDate } from './compras-calc.js';

const C = x => Math.round(round2(Number(x) || 0) * 100);
const P = c => round2(Math.round(Number(c) || 0) / 100);

// ---------- Gastos ----------

/** Tipos de gasto de SGI (se precargan) */
export const DEFAULT_EXPENSE_TYPES = [
  'ADELANTOS AL PERSONAL', 'ALQUILER', 'BOLSAS', 'CARPINTERIA', 'CHANGARINES', 'COMBUSTIBLE', 'CONTADOR', 'DESCARGA', 'EXPRESO',
  'FALTANTE CAJA', 'FLETES', 'IMPRENTA', 'INTRODUCCION', 'KIOSCO Y REFRIGERIO', 'LIBRERIA', 'LIMPIEZA', 'PAGO DIARIO', 'PROMOCIONES',
  'PROVEDORES', 'PROVEEDORES OTROS', 'PUBLICIDAD Y PROMOC', 'REFRIGERIO', 'RETIRO DE EFECTIVO', 'SUELDOS', 'VACIOS', 'VARIOS', 'VIATICOS',
];
/** Id fijo de un tipo precargado (dos equipos que precargan a la vez generan el mismo registro) */
export const expenseTypeId = name => 'et-' + norm(name).replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 50);
/** Tipos que no son gasto del resultado: pagos de mercadería (ya están en el costo de ventas) y retiros del dueño */
export const NOT_RESULT_TYPES = ['PROVEDORES', 'PROVEEDORES', 'PROVEEDORES OTROS', 'RETIRO DE EFECTIVO'];
export const isResultExpense = typeName => !NOT_RESULT_TYPES.includes(String(typeName || '').trim().toUpperCase());

export const EXPENSE_METHODS = [['efectivo', 'Efectivo'], ['transferencia', 'Transferencia'], ['mercadopago', 'Mercado Pago'], ['cheque', 'Cheque'], ['otro', 'Otro']];
export const expenseMethodLabel = id => (EXPENSE_METHODS.find(m => m[0] === id) || [id, id || ''])[1];

/** Próximo número correlativo de una lista de registros (incluye borrados) */
export function nextNumber(list) {
  let max = 0;
  for (const r of list || []) if (Number(r && r.number) > max) max = Number(r.number);
  return max + 1;
}

export const liveExpense = e => !!e && !e.deleted && e.status !== 'anulado';

/**
 * Informe de gastos por tipo en un período. typeName(id) → nombre.
 * Devuelve {total, count, byType: [{type_id, name, count, total, result}], result (lo que resta en el resultado)}.
 */
export function expensesReport(expenses, { from = -Infinity, to = Infinity, typeName = id => id, branch = null } = {}) {
  const by = new Map();
  let total = 0, count = 0, result = 0;
  for (const e of expenses || []) {
    if (!liveExpense(e) || e.created_at < from || e.created_at > to) continue;
    if (branch && e.branch_id && e.branch_id !== branch) continue;
    const a = C(e.amount);
    const k = e.type_id || '';
    const g = by.get(k) || { type_id: k, name: typeName(k) || 'Sin tipo', count: 0, total: 0 };
    g.count++; g.total += a;
    by.set(k, g);
    total += a; count++;
    if (isResultExpense(g.name)) result += a;
  }
  const byType = [...by.values()].map(g => ({ ...g, total: P(g.total), result: isResultExpense(g.name) })).sort((a, b) => b.total - a.total || a.name.localeCompare(b.name, 'es'));
  return { total: P(total), count, byType, result: P(result) };
}

// ---------- Cheques ----------

export const CHEQUE_STATUS = {
  en_cartera: 'En cartera', depositado: 'Depositado', entregado: 'Entregado', rechazado: 'Rechazado', cobrado: 'Cobrado', anulado: 'Anulado',
};
export const chequeStatusLabel = s => CHEQUE_STATUS[s] || s || '';

/** Días hasta el vencimiento (negativo = vencido). due "AAAA-MM-DD"; now en ms (hora local) */
export function daysToDue(due, now = Date.now()) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(due || ''))) return null;
  const [y, m, d] = due.split('-').map(Number);
  const t = new Date(now);
  const today = new Date(t.getFullYear(), t.getMonth(), t.getDate()).getTime();
  return Math.round((new Date(y, m - 1, d).getTime() - today) / 86400000);
}

/** Cheques en cartera que vencen en los próximos `days` días (o ya vencidos), del más próximo al más lejano */
export function chequesDueSoon(cheques, { now = Date.now(), days = 7 } = {}) {
  return (cheques || []).filter(c => c && !c.deleted && c.status === 'en_cartera')
    .map(c => ({ c, days: daysToDue(c.due_date, now) }))
    .filter(x => x.days !== null && x.days <= days)
    .sort((a, b) => a.days - b.days)
    .map(x => ({ ...x.c, days: x.days }));
}

/** Resumen de la cartera: {count, total, byStatus: {status: {count, total}}} (solo vivos) */
export function chequesSummary(cheques) {
  const by = {};
  let count = 0, total = 0;
  for (const c of cheques || []) {
    if (!c || c.deleted) continue;
    const s = c.status || 'en_cartera';
    by[s] = by[s] || { count: 0, total: 0 };
    by[s].count++; by[s].total += C(c.amount);
    if (s === 'en_cartera') { count++; total += C(c.amount); }
  }
  for (const v of Object.values(by)) v.total = P(v.total);
  return { count, total: P(total), byStatus: by };
}

/** Transiciones permitidas de un cheque */
export const CHEQUE_NEXT = {
  en_cartera: ['depositado', 'entregado', 'cobrado', 'rechazado', 'anulado'],
  depositado: ['cobrado', 'rechazado'],
  entregado: ['rechazado'],
  rechazado: ['en_cartera'],
  cobrado: [],
  anulado: [],
};
export const canMoveCheque = (from, to) => (CHEQUE_NEXT[from || 'en_cartera'] || []).includes(to);

// ---------- Caja: medios de un movimiento ----------

/** ¿El movimiento de caja es en efectivo? (los viejos no tienen medio: son efectivo) */
export const isCashMovement = m => !m.method || m.method === 'efectivo';

// ---------- Tesorería / balance ----------

const MEDIA = ['efectivo', 'mercadopago', 'banco', 'tarjetas', 'cheques', 'cuenta_corriente', 'otros'];
export const MEDIA_LABEL = {
  efectivo: 'Efectivo', mercadopago: 'Mercado Pago', banco: 'Bancos / transferencias', tarjetas: 'Tarjetas (débito y crédito)',
  cheques: 'Cheques de terceros', cuenta_corriente: 'Cuenta corriente (a cobrar)', otros: 'Otros medios',
};
function mediumOf(method) {
  switch (method || 'efectivo') {
    case 'efectivo': return 'efectivo';
    case 'mercadopago': case 'qr': return 'mercadopago';
    case 'transferencia': case 'debito_banco': return 'banco';
    case 'debito': case 'credito': case 'tarjeta': return 'tarjetas';
    case 'cheque': return 'cheques';
    case 'cuenta_corriente': return 'cuenta_corriente';
    default: return 'otros';
  }
}

/**
 * Tesorería y balance de un período.
 * d: {sales, returns, cash_movements, cash_sessions, purchases, expenses, supplier_payments, customer_payments, cheques,
 *     customers, suppliers, products, expense_types, branches}
 * opts: {from, to, costOf(product_id), businessIva, mainId}
 * Devuelve pesos:
 *  media: {medio: {in, out, net}}   entradas y salidas del período por medio
 *  cash: [{branch_id, open, expected, opened_at}]   efectivo en las cajas abiertas
 *  cheques: {count, total, dueSoon}
 *  receivable, payable, supplierCredit, customerCredit
 *  result: {sales (con IVA), iva, netSales, cost, gross, expenses, expensesOther, result, costKnown}
 *  purchases: {count, total}
 */
export function treasury(d, { from = -Infinity, to = Infinity, costOf = () => 0, mainId = 'main', now = Date.now() } = {}) {
  const inR = t => t >= from && t <= to;
  const m = {};
  for (const k of MEDIA) m[k] = { in: 0, out: 0 };
  const io = (method, cents, dir) => { const k = mediumOf(method); m[k][dir] += cents; };
  for (const s of d.sales || []) {
    if (s.deleted || s.test || s.status !== 'ok' || !inR(s.created_at)) continue;
    for (const p of s.payments || []) io(p.method, C(p.amount), 'in');
  }
  for (const r of d.returns || []) {
    if (r.deleted || r.test || !inR(r.created_at)) continue;
    for (const p of r.refunds || []) io(p.method, C(p.amount), 'out');
  }
  for (const mv of d.cash_movements || []) {
    if (mv.deleted || !inR(mv.created_at)) continue;
    // Los cobros de cuenta corriente se cuentan por customer_payments (abajo); los de antes eran solo movimientos
    if (mv.ref_id && (d.customer_payments || []).some(p => p.id === mv.ref_id)) continue;
    // Pagos a proveedores, gastos y compras se cuentan por su propio registro
    if (mv.ref_id && ((d.supplier_payments || []).some(p => p.id === mv.ref_id) || (d.expenses || []).some(e => e.id === mv.ref_id) || (d.purchases || []).some(p => p.id === mv.ref_id))) continue;
    if (mv.type === 'ingreso' || mv.type === 'cobro') io(mv.method, C(mv.amount), 'in');
    else if (mv.type === 'egreso') io(mv.method, C(mv.amount), 'out');
  }
  for (const p of d.customer_payments || []) {
    if (p.deleted || (p.kind || 'pago') !== 'pago' || !inR(p.created_at)) continue;
    io(p.method, C(p.amount), 'in');
  }
  for (const p of d.supplier_payments || []) {
    if (p.deleted || (p.kind || 'pago') !== 'pago' || !inR(p.created_at)) continue;
    io(p.method, C(p.amount), 'out');
  }
  let purchCount = 0, purchTotal = 0;
  for (const p of d.purchases || []) {
    if (isVoidPurchase(p) || !inR(purchaseDate(p))) continue;
    purchCount++;
    purchTotal += purchaseSign(p) * C(p.total);
    const paid = C(p.payment === 'cuenta_corriente' ? p.paid || 0 : p.paid ?? p.total);
    if (!paid) continue;
    const method = p.payment === 'contado' || !p.payment || p.payment === 'cuenta_corriente' ? 'efectivo' : p.payment;
    io(method, purchaseSign(p) * paid, 'out');
  }
  const typeName = id => { const t = (d.expense_types || []).find(x => x.id === id); return t ? t.name : ''; };
  let expResult = 0, expOther = 0;
  for (const e of d.expenses || []) {
    if (!liveExpense(e) || !inR(e.created_at)) continue;
    io(e.method, C(e.amount), 'out');
    if (isResultExpense(typeName(e.type_id))) expResult += C(e.amount); else expOther += C(e.amount);
  }
  // Cheques: los depositados/cobrados pasan al banco
  for (const c of d.cheques || []) {
    if (c.deleted) continue;
    if (['depositado', 'cobrado'].includes(c.status) && inR(Number(c.status_at) || c.created_at)) m.banco.in += C(c.amount);
  }
  const media = {};
  for (const k of MEDIA) media[k] = { in: P(m[k].in), out: P(m[k].out), net: P(m[k].in - m[k].out) };
  // Efectivo en las cajas abiertas
  const cash = [];
  for (const s of d.cash_sessions || []) {
    if (s.deleted || s.closed_at) continue;
    const a = computeArqueo({
      opening: s.opening_amount,
      sales: (d.sales || []).filter(x => x.session_id === s.id),
      movements: (d.cash_movements || []).filter(x => x.session_id === s.id),
      returns: (d.returns || []).filter(x => x.session_id === s.id),
    });
    cash.push({ branch_id: branchOf(s, mainId), session_id: s.id, opened_at: s.opened_at, expected: a.expected });
  }
  const ch = chequesSummary(d.cheques);
  let receivable = 0, customerCredit = 0, payable = 0, supplierCredit = 0;
  for (const c of d.customers || []) { if (c.deleted) continue; const b = C(c.balance); if (b > 0) receivable += b; else customerCredit -= b; }
  for (const s of d.suppliers || []) { if (s.deleted) continue; const b = C(s.balance); if (b > 0) payable += b; else supplierCredit -= b; }
  const r = salesReport(d.sales || [], { from, to, costOf, returns: d.returns || [] });
  const sales = C(r.total), iva = C(r.iva);
  const cost = sales - C(r.profit);
  const netSales = sales - iva;
  const gross = netSales - cost;
  return {
    media,
    cash,
    cashTotal: P(cash.reduce((a, x) => a + C(x.expected), 0)),
    cheques: { count: ch.count, total: ch.total, dueSoon: chequesDueSoon(d.cheques, { now }).length },
    receivable: P(receivable), customerCredit: P(customerCredit), payable: P(payable), supplierCredit: P(supplierCredit),
    purchases: { count: purchCount, total: P(purchTotal) },
    result: {
      sales: P(sales), iva: P(iva), netSales: P(netSales), cost: P(cost), gross: P(gross),
      expenses: P(expResult), expensesOther: P(expOther), result: P(gross - expResult), costKnown: r.costKnown, count: r.count,
    },
  };
}

// ---------- Informes de caja ----------

/**
 * Fila del informe "Cajas cerradas" de una caja. data: {sales, movements, returns, expenses}
 * Devuelve pesos: {opening, cashSales, salesTotal, count, ingresos, egresos, devoluciones, expected, counted, difference, byMethod,
 *   expenses (gastos a caja), cheques_in, cheques_out, mp_in, mp_out}
 */
export function sessionSummary(session, { sales = [], movements = [], returns = [], expenses = [] } = {}) {
  const a = computeArqueo({ opening: session.opening_amount, sales, movements, returns });
  let chIn = 0, chOut = 0, mpIn = 0, mpOut = 0;
  for (const mv of movements) {
    if (mv.deleted) continue;
    const dir = mv.type === 'egreso' ? -1 : mv.type === 'ingreso' ? 1 : 0;
    if (!dir) continue;
    if (mv.method === 'cheque') { if (dir > 0) chIn += C(mv.amount); else chOut += C(mv.amount); }
    if (mv.method === 'mercadopago') { if (dir > 0) mpIn += C(mv.amount); else mpOut += C(mv.amount); }
  }
  const exp = expenses.filter(e => liveExpense(e) && e.session_id === session.id && e.to_cash).reduce((s, e) => s + C(e.amount), 0);
  const closed = !!session.closed_at;
  return {
    ...a,
    expected: closed && session.expected_amount !== null && session.expected_amount !== undefined ? round2(session.expected_amount) : a.expected,
    counted: closed ? (session.counted_amount ?? null) : null,
    difference: closed ? (session.difference ?? null) : null,
    expenses: P(exp), cheques_in: P(chIn), cheques_out: P(chOut), mp_in: P(mpIn), mp_out: P(mpOut),
  };
}

// ---------- Recalcular stock y saldos ----------

/**
 * Stock por sucursal reconstruido desde stock_moves y diferencias contra lo guardado.
 * Solo productos que tienen movimientos (sin movimientos no hay de dónde reconstruir).
 * Devuelve [{product_id, name, branch_id, current, computed, diff, moves}] solo con diferencia (≠ 0).
 * OJO: el stock cargado al crear o importar un producto no deja movimiento: esos productos dan "de menos".
 */
export function recalcStock(products, moves, { mainId = 'main' } = {}) {
  const sum = new Map(); // product -> Map(branch -> {q, n})
  for (const mv of moves || []) {
    if (!mv || mv.deleted || !mv.product_id) continue;
    const b = branchOf(mv, mainId);
    const pm = sum.get(mv.product_id) || new Map();
    const x = pm.get(b) || { q: 0, n: 0 };
    x.q = round3(x.q + (Number(mv.qty) || 0)); x.n++;
    pm.set(b, x);
    sum.set(mv.product_id, pm);
  }
  const out = [];
  for (const p of products || []) {
    if (!p || p.deleted) continue;
    const pm = sum.get(p.id);
    if (!pm) continue;
    const cur = productStocks(p, mainId);
    const branchesSet = new Set([...Object.keys(cur), ...pm.keys()]);
    for (const b of branchesSet) {
      const current = round3(cur[b] || 0);
      const x = pm.get(b) || { q: 0, n: 0 };
      if (!x.n) continue; // en esa sucursal no tiene movimientos: no se toca
      const diff = round3(x.q - current);
      if (diff !== 0) out.push({ product_id: p.id, name: p.name, branch_id: b, current, computed: x.q, diff, moves: x.n });
    }
  }
  return out.sort((a, b) => Math.abs(b.diff) - Math.abs(a.diff) || String(a.name).localeCompare(String(b.name), 'es'));
}

/** Stock nuevo de un producto después de corregir algunas sucursales: {stocks, stock} */
export function applyRecalcStock(product, fixes, mainId = 'main') {
  const stocks = productStocks(product, mainId);
  for (const f of fixes) { if (f.computed) stocks[f.branch_id] = round3(f.computed); else delete stocks[f.branch_id]; }
  let t = 0;
  for (const v of Object.values(stocks)) t += Number(v) || 0;
  return { stocks, stock: round3(t) };
}

/**
 * Saldos de clientes y proveedores reconstruidos desde sus movimientos, con diferencia contra lo guardado.
 * d: {customers, suppliers, sales, returns, customer_payments, cash_movements, purchases, supplier_payments}
 * Devuelve {customers: [{id, name, current, computed, diff, moves}], suppliers: [...]} solo con diferencia.
 * Clientes sin ningún movimiento no se tocan (su saldo puede venir del sistema anterior sin movimiento).
 */
export function recalcBalances(d) {
  const customers = [];
  for (const c of d.customers || []) {
    if (!c || c.deleted) continue;
    const led = customerLedger(c, { sales: d.sales || [], returns: d.returns || [], payments: d.customer_payments || [], movements: d.cash_movements || [] });
    if (!led.length) continue;
    const computed = ledgerTotal(led), current = C(c.balance);
    if (computed !== current) customers.push({ id: c.id, name: c.name, current: P(current), computed: P(computed), diff: P(computed - current), moves: led.length });
  }
  const suppliers = [];
  for (const s of d.suppliers || []) {
    if (!s || s.deleted) continue;
    const led = supplierLedger(s.id, { purchases: d.purchases || [], payments: d.supplier_payments || [] });
    if (!led.length) continue;
    const computed = ledgerTotal(led), current = C(s.balance);
    if (computed !== current) suppliers.push({ id: s.id, name: s.name, current: P(current), computed: P(computed), diff: P(computed - current), moves: led.length });
  }
  const byDiff = (a, b) => Math.abs(b.diff) - Math.abs(a.diff);
  return { customers: customers.sort(byDiff), suppliers: suppliers.sort(byDiff) };
}
