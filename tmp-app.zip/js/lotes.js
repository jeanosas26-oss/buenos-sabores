// =====================================================================
// lotes.js — Lotes con vencimiento (product_lots) por sucursal.
// Al vender se descuenta de los lotes que vencen primero (FEFO). Solo usa db.js (lo importa ops.js).
// =====================================================================
import * as db from './db.js';
import { round3, uuid } from './logic.js';

const has = () => db.COLLECTIONS.includes('product_lots');

/** Lotes vivos con cantidad de un producto en una sucursal, el que vence primero adelante */
export function lotsOf(productId, branchId = null) {
  if (!has()) return [];
  return db.all('product_lots').filter(l => l.product_id === productId && (!branchId || !l.branch_id || l.branch_id === branchId) && Number(l.qty) > 0)
    .sort((a, b) => String(a.expires_at || '9999').localeCompare(String(b.expires_at || '9999')));
}

/** Cambios para descontar lo vendido de los lotes (FEFO). Lo que no tiene lote no hace nada. */
export function lotSaleOps(items, branchId) {
  if (!has()) return [];
  const need = new Map();
  for (const it of items || []) if (it.product_id && Number(it.qty) > 0) need.set(it.product_id, round3((need.get(it.product_id) || 0) + Number(it.qty)));
  const ops = [];
  for (const [pid, q0] of need) {
    let q = q0;
    for (const l of lotsOf(pid, branchId)) {
      if (q <= 0) break;
      const take = Math.min(q, Number(l.qty));
      ops.push({ coll: 'product_lots', rec: { id: l.id, qty: round3(Number(l.qty) - take) } });
      q = round3(q - take);
    }
  }
  return ops;
}

/** Registro de un lote nuevo (para meter en una transacción) */
export function newLotOp({ product_id, branch_id, lot = '', expires_at, qty, purchase_id = null, notes = '' }) {
  if (!product_id) throw new Error('Falta el producto del lote.');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(expires_at || ''))) throw new Error('Poné la fecha de vencimiento.');
  const n = round3(Number(qty));
  if (!(n > 0)) throw new Error('La cantidad del lote tiene que ser mayor a cero.');
  return { coll: 'product_lots', rec: { id: uuid(), product_id, branch_id, lot: String(lot || '').trim(), expires_at, qty: n, created_at: Date.now(), purchase_id, notes: String(notes || '').trim() } };
}
