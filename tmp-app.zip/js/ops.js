// =====================================================================
// ops.js — Operaciones del negocio (ventas, caja, stock, compras...).
// Usan db.js para guardar y logic.js para calcular.
// =====================================================================
import * as db from './db.js';
import * as sync from './sync.js';
import { localVerifier } from './pin.js';
import {
  round2, round3, computeSale, calcPayment, computeArqueo, cbteTipo, discriminaIva,
  normalizeImportRows, productKey, norm, validPin, pinMin, uuid, parseCSV, tableToObjects, legacyBackupToSetup,
  MAIN_BRANCH_ID, sortBranches, stockIn, applyStockDelta, setStockIn, branchOf, productStocks, stocksTotal,
  RESET_COLLECTIONS, planReset, ncTipo, hasCae, can, fmtMoney as fmtMoneyLocal,
} from './logic.js';
import { computeSaleSGI, calcPaymentsSGI, docLetter } from './comercial.js';
import { lotSaleOps } from './lotes.js';
import {
  buildReturn, refundSplit, refundEffects, canReturnMore, cleanTransferItems, transferDifferences,
} from './negocio.js';

/** Sesión actual en este dispositivo (usuario y sucursal en la que trabaja) */
export const ctx = { user: null, branchId: null };

export const DEFAULT_SETTINGS = {
  id: 'business', business_name: '', legal_name: '', cuit: '', iva_condition: 'MT', iibb: '',
  start_date: '', address: '', phone: '', pos_number: 1, arca_env: 'off',
  ticket_footer: '¡Gracias por su compra!', currency: 'ARS',
};

export function settings() {
  return { ...DEFAULT_SETTINGS, ...(db.get('settings', 'business') || {}) };
}
export async function saveSettings(patch) {
  return db.put('settings', { ...settings(), ...patch, id: 'business' });
}

export function userName(id) {
  const u = db.get('users', id);
  return u ? u.name : '—';
}

// ---------- Sucursales ----------
// Los productos y precios son de todo el comercio; el stock, la caja, las ventas y las compras son de cada sucursal.
// Cada dispositivo trabaja en UNA sucursal: se guarda en meta ("branch_id") y no se sincroniza.

/** Sucursales (no borradas), la principal primero. includeInactive: también las desactivadas. */
export function branches({ includeInactive = false } = {}) {
  return sortBranches(db.all('branches').filter(b => includeInactive || b.active !== 0));
}

/** Id de la sucursal principal: a ella va el stock de los productos que todavía no tienen stock por sucursal */
export function mainBranchId() {
  if (db.get('branches', MAIN_BRANCH_ID)) return MAIN_BRANCH_ID;
  const all = sortBranches(db.all('branches', { includeDeleted: true }));
  return all.length ? all[0].id : MAIN_BRANCH_ID;
}

/** ¿Hay más de una sucursal activa? (si hay una sola no hace falta mostrar filtros ni chips) */
export function multiBranch() { return branches().length > 1; }

export function branchName(id) {
  const b = db.get('branches', id || mainBranchId());
  return b ? b.name : '—';
}

/** Sucursal en la que trabaja este dispositivo */
export function currentBranch() { return ctx.branchId ? db.get('branches', ctx.branchId) : null; }

/** ¿El registro (venta, caja, compra, movimiento) es de esa sucursal? */
export function inBranch(rec, branchId) { return branchOf(rec, mainBranchId()) === branchId; }

/** Stock de un producto en una sucursal (por defecto, la de este dispositivo) */
export function stockOf(p, branchId = ctx.branchId) { return stockIn(p, branchId, mainBranchId()); }

/** Stock de cada sucursal de un producto: [{branch, qty}] (incluye las que tienen 0) */
export function stockByBranch(p) {
  const st = productStocks(p, mainBranchId());
  const list = branches({ includeInactive: true }).map(b => ({ branch: b, qty: st[b.id] || 0 }));
  // Stock en sucursales borradas: se muestra igual para que el total cierre
  for (const [id, q] of Object.entries(st)) if (!list.some(x => x.branch.id === id)) list.push({ branch: db.get('branches', id) || { id, name: 'Sucursal borrada' }, qty: q });
  return list;
}

/** Crea o actualiza una sucursal. Si es la principal, su punto de venta queda también en settings (para ventas viejas). */
export async function saveBranch({ id, name, pos_number, address = '', active = 1 }) {
  const n = String(name || '').trim();
  if (!n) throw new Error('Escribí el nombre de la sucursal.');
  const pos = Number(pos_number);
  if (!Number.isInteger(pos) || pos < 1 || pos > 99998) throw new Error('El punto de venta tiene que ser un número entre 1 y 99998.');
  const others = db.all('branches').filter(b => b.id !== id);
  if (others.some(b => norm(b.name) === norm(n))) throw new Error(`Ya hay una sucursal que se llama “${n}”.`);
  const dupPos = others.find(b => Number(b.pos_number) === pos && b.active !== 0);
  if (dupPos && active) throw new Error(`El punto de venta ${pos} ya lo usa “${dupPos.name}”. Cada sucursal factura con su propio punto de venta.`);
  if (id && !active) {
    if (id === ctx.branchId) throw new Error('Este equipo trabaja en esa sucursal: cambiá primero de sucursal para desactivarla.');
    if (!branches().some(b => b.id !== id)) throw new Error('Tiene que quedar al menos una sucursal activa.');
  }
  const rec = await db.put('branches', { id: id || uuid(), name: n, pos_number: pos, address: String(address || '').trim(), active: active ? 1 : 0 });
  if (rec.id === mainBranchId() && Number(settings().pos_number) !== pos) await saveSettings({ pos_number: pos });
  return rec;
}

/** Si no hay ninguna sucursal, crea la principal con los datos del comercio */
export async function ensureBranch() {
  if (branches().length) return null;
  const st = settings();
  const prev = db.get('branches', MAIN_BRANCH_ID);
  return db.put('branches', {
    id: MAIN_BRANCH_ID, name: (prev && prev.name) || st.business_name || 'Principal', pos_number: Number(st.pos_number) || 1,
    address: (prev && prev.address) || st.address || '', active: 1, deleted: 0,
  });
}

/**
 * Elige la sucursal de este dispositivo al entrar: la guardada si sigue activa,
 * o la única que hay. Devuelve null si hay varias y el dispositivo tiene que elegir.
 */
export async function resolveDeviceBranch() {
  await ensureBranch();
  const saved = await db.getMeta('branch_id', null);
  const list = branches();
  const ok = list.find(b => b.id === saved);
  if (ok) { ctx.branchId = ok.id; return ok; }
  if (list.length === 1) { await setDeviceBranch(list[0].id); return list[0]; }
  ctx.branchId = null;
  return null;
}

export async function setDeviceBranch(id) {
  const b = db.get('branches', id);
  if (!b || b.deleted || b.active === 0) throw new Error('Esa sucursal no está activa.');
  ctx.branchId = id;
  await db.setMeta('branch_id', id);
  return b;
}

/** Punto de venta ARCA de una sucursal (si no tiene, el de Ajustes) */
export function branchPos(branchId = ctx.branchId) {
  const b = db.get('branches', branchId);
  return Number(b && b.pos_number) || Number(settings().pos_number) || 1;
}

// ---------- Usuarios ----------

export async function saveUser({ id, name, role, pin, email = '', active = 1, commission_pct, commission_base, perms }) {
  const rec = { name: String(name).trim(), role, email: String(email || '').trim(), active: active ? 1 : 0 };
  // Permisos (solo las diferencias con el rol; los cambia el dueño en Ajustes → Usuarios → Permisos)
  if (perms !== undefined) rec.perms = role === 'dueno' ? null : (perms && Object.keys(perms).length ? perms : null);
  // Comisión de vendedores: % (0 a 100) y base "venta" | "cobranza" | null (sin comisión)
  if (commission_base !== undefined) {
    const pct = round2(Number(commission_pct) || 0);
    if (!(pct >= 0 && pct <= 100)) throw new Error('La comisión tiene que ser un porcentaje entre 0 y 100.');
    rec.commission_base = ['venta', 'cobranza'].includes(commission_base) ? commission_base : null;
    rec.commission_pct = rec.commission_base ? pct : 0;
  }
  if (id) rec.id = id;
  else rec.id = uuid();
  if (pin) {
    pin = String(pin);
    if (!validPin(pin)) throw new Error('El PIN tiene que tener de 4 a 8 números.');
    if (pin.length < pinMin(role)) throw new Error(`El PIN del ${role === 'dueno' ? 'dueño' : 'encargado'} tiene que tener de ${pinMin(role)} a 8 números.`);
    if (sync.isConfigured()) {
      // Con la nube, el PIN se carga en la nube (por HTTPS): ella guarda su hash fuerte y, solo para cajeros y vendedores
      // sin permisos sensibles, el verificador para entrar sin internet (lo bajan los equipos). Hace falta internet.
      if (typeof navigator !== 'undefined' && navigator.onLine === false) throw new Error('Para cargar o cambiar un PIN hace falta internet.');
      const saved = await db.put('users', rec);
      await sync.setUserPin(saved.id, pin);
      return db.get('users', saved.id) || saved;
    }
    // Sin nube: verificador local (PBKDF2, 200.000 iteraciones, sal por usuario)
    rec.pin_local = await localVerifier(pin);
    rec.pin_hash = null;
    rec.pin_len = pin.length;
  }
  return db.put('users', rec);
}

// ---------- Caja ----------

/** Caja abierta de una sucursal (por defecto, la de este dispositivo): la más reciente sin cerrar */
export function openSession(branchId = ctx.branchId) {
  return db.all('cash_sessions').filter(s => !s.closed_at && inBranch(s, branchId)).sort((a, b) => b.opened_at - a.opened_at)[0] || null;
}

function requireBranch() {
  if (!ctx.branchId || !db.get('branches', ctx.branchId)) throw new Error('Elegí en qué sucursal trabaja este equipo.');
  return ctx.branchId;
}

export async function openCash(amount, extraOps = []) {
  if (ctx.user && !can(ctx.user, 'caja')) throw new Error('Tu usuario no puede abrir la caja: pedile al dueño o al encargado que la abra.');
  const branch_id = requireBranch();
  if (openSession()) throw new Error('Ya hay una caja abierta en esta sucursal.');
  if (!Number.isFinite(Number(amount)) || Number(amount) < 0) throw new Error('El monto inicial tiene que ser un número mayor o igual a cero.');
  const [rec] = await db.putBatch([{ coll: 'cash_sessions', rec: {
    id: uuid(), branch_id, opened_at: Date.now(), opened_by: ctx.user.id, opening_amount: round2(amount),
    closed_at: null, closed_by: null, counted_amount: null, expected_amount: null, difference: null, notes: '',
  } }, ...extraOps]);
  return rec;
}

export function sessionData(session) {
  const sales = db.all('sales').filter(s => s.session_id === session.id);
  const movements = db.all('cash_movements').filter(m => m.session_id === session.id);
  // Devoluciones hechas con esta caja abierta (el efectivo devuelto sale de acá)
  const returns = db.all('returns').filter(r => r.session_id === session.id);
  return { sales, movements, returns };
}

export function sessionArqueo(session, counted = null) {
  const { sales, movements, returns } = sessionData(session);
  return computeArqueo({ opening: session.opening_amount, sales, movements, counted, returns });
}

export async function addCashMovement(type, amount, reason, extra = {}, extraOps = []) {
  const s = openSession();
  if (!s) throw new Error('La caja está cerrada.');
  if (!Number.isFinite(Number(amount))) throw new Error('El monto no es un número válido.');
  const a = round2(amount);
  if (!(a > 0)) throw new Error('El monto tiene que ser mayor a cero.');
  if (!String(reason || '').trim()) throw new Error('Escribí el motivo del movimiento.');
  const [rec] = await db.putBatch([{ coll: 'cash_movements', rec: { id: uuid(), session_id: s.id, branch_id: branchOf(s, mainBranchId()), type, amount: a, reason: String(reason || '').trim(), created_at: Date.now(), user_id: ctx.user.id, ...extra } }, ...extraOps]);
  return rec;
}

export async function closeCash(counted, notes = '', extra = {}, extraOps = [], closedAt = Date.now()) {
  if (ctx.user && !can(ctx.user, 'caja')) throw new Error('Tu usuario no puede cerrar la caja: pedile al dueño o al encargado.');
  const s = openSession();
  if (!s) throw new Error('No hay caja abierta.');
  const a = sessionArqueo(s, counted);
  const [rec] = await db.putBatch([{ coll: 'cash_sessions', rec: {
    ...extra, id: s.id, closed_at: closedAt, closed_by: ctx.user.id,
    counted_amount: a.counted, expected_amount: a.expected, difference: a.difference, notes: String(notes || ''),
  } }, ...extraOps]);
  return rec;
}

// ---------- Ventas ----------

function nextSaleNumber() { return nextNumber('sales'); }

/** Próximo número correlativo interno de una colección (ventas, devoluciones, remitos) */
function nextNumber(coll) {
  let max = 0;
  for (const s of db.all(coll, { includeDeleted: true })) if (Number(s.number) > max) max = Number(s.number);
  return max + 1;
}

/**
 * Crea una venta: guarda la venta, descuenta stock, registra movimientos y
 * cuenta corriente, todo en una sola transacción.
 * cart: [{product_id,name,qty,unit_price,iva_rate}]
 */
export async function createSale({ cart, discount = 0, payments, customer_id = null, wantFactura = false, extraOps = [], seller_id = null, allowOverLimit = false, extra = {}, requireSession = true }) {
  const branch_id = requireBranch();
  const session = openSession();
  // extra (como SGI): id (para atar presupuestos/pedidos en la misma transacción), doc_type "FC"|"ND", observations.
  // requireSession=false: nota de débito a cuenta corriente (no mueve la caja)
  if (requireSession && ctx.user && !can(ctx.user, 'vender')) throw new Error('Tu usuario no puede vender.');
  if (!session && requireSession) throw new Error('La caja está cerrada. Abrila para vender.');
  if (!cart.length) throw new Error('El carrito está vacío.');
  for (const it of cart) {
    const q = Number(it.qty), pr = Number(it.unit_price);
    if (!Number.isFinite(q) || q <= 0) throw new Error(`Revisá la cantidad de “${it.name}”.`);
    if (!Number.isFinite(pr) || pr < 0) throw new Error(`Revisá el precio de “${it.name}”.`);
  }
  if (!Number.isFinite(Number(discount)) || Number(discount) < 0) throw new Error('Revisá el descuento.');
  const st = settings();
  // Promociones (promo_discount de cada renglón) y recargo de tarjeta (sube el total y el IVA): comercial.js.
  // Sin promos ni tarjetas con recargo es exactamente computeSale + calcPayment.
  const base = computeSaleSGI(cart, { discount }, discriminaIva(st.iva_condition));
  if (!(base.total > 0)) throw new Error('El total tiene que ser mayor a cero.');
  const pay = calcPaymentsSGI(base.total, payments);
  if (!pay.ok) throw new Error(pay.error);
  const calc = pay.surcharge > 0 ? computeSaleSGI(cart, { discount, surcharge: pay.surcharge }, discriminaIva(st.iva_condition)) : base;
  if (!session && pay.applied.some(p => p.method !== 'cuenta_corriente')) throw new Error('La caja está cerrada. Abrila para cobrar.');
  const customer = customer_id ? db.get('customers', customer_id) : null;
  const cc = pay.applied.find(p => p.method === 'cuenta_corriente');
  if (cc && !customer) throw new Error('Para vender a cuenta corriente elegí un cliente.');
  if (cc && customer) {
    // Límite de crédito (0 = sin límite): el cajero no puede pasarlo; dueño o encargado sí, confirmando
    const lim = Number(customer.credit_limit) || 0;
    const after = round2((Number(customer.balance) || 0) + cc.amount);
    if (lim > 0 && after > lim) {
      const msg = `${customer.name} pasaría su límite de crédito: debe ${fmtMoneyLocal(customer.balance)}, con esta venta ${fmtMoneyLocal(after)} y el límite es ${fmtMoneyLocal(lim)}.`;
      if (!can(ctx.user, 'anular')) throw new Error(msg + ' Solo el dueño o el encargado pueden autorizarlo.');
      if (!allowOverLimit) { const e = new Error(msg); e.code = 'CREDIT_LIMIT'; throw e; }
    }
  }

  let doc;
  if (wantFactura && st.arca_env !== 'off') {
    doc = { kind: 'factura', cbte_tipo: cbteTipo(st.iva_condition, customer ? customer.iva_condition : 'CF'), pto_vta: branchPos(branch_id), cbte_nro: null, cae: '', cae_vto: '', status: 'pendiente', error: '' };
  } else {
    doc = { kind: 'no_fiscal', status: 'no_fiscal' };
  }

  const now = Date.now();
  const sale = {
    id: extra.id || uuid(), number: nextSaleNumber(), created_at: now, user_id: ctx.user.id, session_id: session ? session.id : null, branch_id,
    customer_id: customer ? customer.id : null,
    items: calc.items.map(it => ({ product_id: it.product_id || null, name: it.name, qty: it.qty, unit_price: it.unit_price, iva_rate: it.iva_rate, discount: it.discount, subtotal: it.subtotal,
      ...(it.promo_discount ? { promo_discount: it.promo_discount, promo_name: it.promo_name || '', promo_id: it.promo_id || null } : {}), ...(it.surcharge ? { surcharge: it.surcharge } : {}) })),
    discount: calc.discount, total: calc.total, net: calc.net, iva: calc.iva,
    payments: pay.applied, change: pay.change, status: 'ok', doc,
    seller_id: seller_id || null,
    doc_type: ['FC', 'ND'].includes(extra.doc_type) ? extra.doc_type : 'FC',
    letter: docLetter(st.iva_condition, customer ? customer.iva_condition : 'CF', doc.kind === 'factura'),
    observations: String(extra.observations || '').trim(), surcharge: pay.surcharge || 0,
  };
  const ops = [{ coll: 'sales', rec: sale }];
  stockOps(ops, sale.items, -1, 'venta', sale.id, now, branch_id);
  ops.push(...lotSaleOps(sale.items, branch_id)); // vencimientos: descuenta de los lotes que vencen primero
  if (cc) ops.push({ coll: 'customers', rec: { id: customer.id, balance: round2((customer.balance || 0) + cc.amount) } });
  ops.push(...extraOps.map(o => (o.coll === 'audit_log' ? { ...o, rec: { ...o.rec, entity_id: o.rec.entity_id || sale.id, detail: { ...o.rec.detail, sale_number: sale.number } } } : o)));
  await db.putBatch(ops);
  return db.get('sales', sale.id);
}

/**
 * Agrega a ops los cambios de stock de UNA sucursal y sus stock_moves
 * (signo -1 venta, +1 devolución/compra). Las otras sucursales no se tocan.
 */
function stockOps(ops, items, sign, reason, refId, now, branchId) {
  const delta = {};
  for (const it of items) if (it.product_id) delta[it.product_id] = round3((delta[it.product_id] || 0) + sign * Number(it.qty));
  for (const [pid, q] of Object.entries(delta)) {
    const p = db.get('products', pid);
    if (!p) continue;
    ops.push({ coll: 'products', rec: { id: pid, ...applyStockDelta(p, branchId, q, mainBranchId()) } });
    ops.push({ coll: 'stock_moves', rec: { product_id: pid, branch_id: branchId, qty: q, reason, ref_id: refId, created_at: now, user_id: ctx.user.id } });
  }
}

/** Pide la factura a la nube. Devuelve {ok, doc, error}. Nunca inventa un CAE. */
export async function requestInvoice(saleId) {
  const sale = db.get('sales', saleId);
  if (!sale) return { ok: false, error: 'Venta no encontrada.' };
  if (!sync.isConfigured()) {
    const doc = { ...sale.doc, status: 'pendiente', error: 'No hay nube conectada: no se puede pedir el CAE a ARCA.' };
    await db.put('sales', { id: saleId, doc });
    return { ok: false, doc, error: doc.error };
  }
  try {
    await sync.syncNow(); // el servidor necesita tener la venta
    const res = await sync.api('/api/arca/invoice', { method: 'POST', body: { sale_id: saleId }, timeout: 45000 });
    const doc = res && (res.doc || res);
    if (!doc || !doc.status) throw new Error('Respuesta inválida del servidor.');
    await db.put('sales', { id: saleId, doc });
    if (doc.status === 'autorizado' && doc.cae) return { ok: true, doc };
    return { ok: false, doc, error: doc.error || 'ARCA no autorizó el comprobante.' };
  } catch (e) {
    // http: código de la nube (400/422 = hay que corregir algo; no se reintenta solo)
    const doc = { ...sale.doc, status: 'pendiente', error: e.message, http: e.status || 0 };
    await db.put('sales', { id: saleId, doc });
    return { ok: false, doc, error: e.message };
  }
}

/**
 * Anula una venta: si estaba facturada pide la nota de crédito primero.
 * Repone stock, revierte cuenta corriente y, si la venta era de otra caja,
 * registra el egreso de la devolución en efectivo en la caja abierta.
 */
export async function voidSale(saleId, reason = '', { authorizedBy = null, extraOps = [] } = {}) {
  if (!ctx.user || !(can(ctx.user, 'anular') || (authorizedBy && can(authorizedBy, 'anular')))) throw new Error('Para anular una venta hace falta la autorización del dueño o del encargado.');
  const sale = db.get('sales', saleId);
  if (!sale || sale.status !== 'ok') throw new Error('La venta no se puede anular.');
  if (saleReturns(saleId).length) throw new Error('Esta venta ya tiene devoluciones: para devolver lo que queda usá “Nota de crédito / devolución”.');
  let doc = { ...(sale.doc || {}) };
  if (doc.kind === 'factura' && doc.status === 'autorizado') {
    if (!sync.isConfigured()) throw new Error('Esta venta tiene factura: para anularla hace falta la nube conectada (nota de crédito).');
    await sync.syncNow();
    const res = await sync.api('/api/arca/credit-note', { method: 'POST', body: { sale_id: saleId }, timeout: 45000 });
    const nc = res && (res.doc || res.credit_note || res);
    if (!nc || (nc.status && nc.status !== 'autorizado')) throw new Error((nc && nc.error) || 'ARCA no autorizó la nota de crédito.');
    doc.credit_note = nc;
  }
  const session = openSession();
  const cash = (sale.payments || []).filter(p => p.method === 'efectivo').reduce((a, p) => a + p.amount, 0);
  const otherSession = sale.session_id !== (session && session.id);
  if (otherSession && cash > 0 && !session) throw new Error('Abrí la caja para devolver el efectivo de esta venta.');
  const now = Date.now();
  const ops = [{ coll: 'sales', rec: { id: saleId, status: 'anulada', doc, void_reason: String(reason || ''), voided_at: now, voided_by: ctx.user.id } }];
  // El stock vuelve a la sucursal donde se hizo la venta (aunque se anule desde otra)
  stockOps(ops, sale.items, +1, 'anulacion', saleId, now, branchOf(sale, mainBranchId()));
  const cc = (sale.payments || []).find(p => p.method === 'cuenta_corriente');
  if (cc && sale.customer_id) {
    const c = db.get('customers', sale.customer_id);
    if (c) ops.push({ coll: 'customers', rec: { id: c.id, balance: round2((c.balance || 0) - cc.amount) } });
  }
  if (otherSession && cash > 0) {
    ops.push({ coll: 'cash_movements', rec: { session_id: session.id, branch_id: branchOf(session, mainBranchId()), type: 'egreso', amount: round2(cash), reason: `Devolución venta N° ${sale.number}`, created_at: now, user_id: ctx.user.id } });
  }
  ops.push(...extraOps);
  await db.putBatch(ops);
  return db.get('sales', saleId);
}

// ---------- Productos y stock ----------

export async function saveProduct(p, extraOps = []) {
  // Cajero y vendedor solo crean productos nuevos (desde una compra): sin stock inicial (lo pone la compra) y no cambian
  // los existentes (la nube tampoco les acepta cambios de precio ni de datos de un producto que ya está)
  if (ctx.user && !can(ctx.user, 'editar_productos')) {
    if (p.id && db.get('products', p.id)) throw new Error('Solo el dueño o el encargado pueden cambiar un producto.');
    p = { ...p, stock: 0, stocks: undefined, active: 1 };
  }
  for (const [k, label] of [['price', 'El precio'], ['cost', 'El costo'], ['stock_min', 'El stock mínimo']]) {
    const v = p[k] === undefined || p[k] === null || p[k] === '' ? 0 : Number(p[k]);
    if (!Number.isFinite(v) || v < 0) throw new Error(`${label} tiene que ser un número mayor o igual a cero.`);
  }
  if (p.stock !== undefined && p.stock !== null && !Number.isFinite(Number(p.stock))) throw new Error('El stock no es un número válido.');
  const rec = {
    ...p,
    name: String(p.name || '').trim(),
    category: String(p.category || '').trim() || 'General',
    barcode: String(p.barcode || '').trim(),
    sku: String(p.sku || '').trim(),
    price: round2(p.price), cost: round2(p.cost), iva_rate: Number(p.iva_rate ?? 21),
    stock: round3(p.stock), stock_min: round3(p.stock_min), unit: p.unit === 'kg' ? 'kg' : 'u',
    supplier_id: p.supplier_id || '', active: p.active === 0 ? 0 : 1,
  };
  if (p.stocks && typeof p.stocks === 'object') {
    // El total siempre es la suma de las sucursales
    rec.stocks = productStocks(p, mainBranchId());
    rec.stock = stocksTotal(rec.stocks);
  } else if (!p.id || !db.get('products', p.id)) {
    // Producto nuevo: el stock inicial es de la sucursal de este equipo; en las otras arranca en 0
    rec.stocks = rec.stock ? { [ctx.branchId || mainBranchId()]: rec.stock } : {};
  }
  if (!rec.name) throw new Error('Falta el nombre.');
  if (rec.barcode) {
    const dup = db.all('products').find(x => x.barcode === rec.barcode && x.id !== rec.id);
    if (dup) throw new Error(`El código ${rec.barcode} ya lo usa "${dup.name}".`);
  }
  if (!rec.id) rec.id = uuid();
  const [saved] = await db.putBatch([{ coll: 'products', rec }, ...extraOps]);
  return saved;
}

/** Ajuste manual del stock de la sucursal de este equipo: deja registro en stock_moves */
export async function adjustStock(productId, newStock, reason = 'ajuste', extraOps = []) {
  const branch_id = requireBranch();
  const p = db.get('products', productId);
  if (!p) throw new Error('Producto no encontrado.');
  if (!Number.isFinite(Number(newStock))) throw new Error('Escribí una cantidad válida.');
  const q = round3(Number(newStock) - stockOf(p, branch_id));
  if (q === 0) return p;
  await db.putBatch([
    { coll: 'products', rec: { id: productId, ...applyStockDelta(p, branch_id, q, mainBranchId()) } },
    { coll: 'stock_moves', rec: { product_id: productId, branch_id, qty: q, reason: 'ajuste', note: reason, ref_id: null, created_at: Date.now(), user_id: ctx.user.id } },
    ...extraOps,
  ]);
  return db.get('products', productId);
}

/**
 * Aplica un conteo de góndola en la sucursal de este equipo: cada producto queda con lo contado.
 * lines: [{product_id, counted}]. Una sola transacción; un stock_move "conteo" por producto que cambió
 * (con el mismo ref_id para todo el conteo). No toca el stock de las otras sucursales.
 */
export async function applyStockCount(lines, note = 'Conteo de góndola') {
  if (ctx.user && !can(ctx.user, 'ajustar_stock')) throw new Error('Tu usuario no puede ajustar el stock.');
  const branch_id = requireBranch();
  const mainId = mainBranchId();
  const ref_id = uuid(), now = Date.now();
  const ops = [];
  let changed = 0;
  for (const l of lines) {
    const p = db.get('products', l.product_id);
    if (!p) continue;
    const counted = round3(Number(l.counted));
    if (!Number.isFinite(counted)) continue;
    const q = round3(counted - stockOf(p, branch_id));
    if (q === 0) continue;
    ops.push({ coll: 'products', rec: { id: p.id, ...setStockIn(p, branch_id, counted, mainId) } });
    ops.push({ coll: 'stock_moves', rec: { product_id: p.id, branch_id, qty: q, reason: 'conteo', note, ref_id, created_at: now, user_id: ctx.user.id } });
    changed++;
  }
  await db.putBatch(ops);
  return { changed, ref_id };
}

/**
 * Importa productos (formato viejo o Excel/CSV ya convertidos a objetos).
 * Si ya existe un producto con el mismo código (o nombre si no tiene código)
 * se actualiza precio, costo, stock y categoría; si no, se crea.
 * El stock del archivo es de la sucursal de este equipo: el de las otras sucursales no se toca
 * (y en los productos nuevos arranca en 0).
 */
/** Cambios de un producto existente al importar: solo lo que trajo el archivo */
function importPatch(ex, p, branch, mainId, has) {
  const h = has || { price: true, cost: true, stock: true, stock_min: true, category: true };
  const patch = {};
  if (h.price) patch.price = p.price;
  if (h.cost && p.cost) patch.cost = p.cost;
  if (h.stock) Object.assign(patch, setStockIn(ex, branch, p.stock, mainId));
  if (h.stock_min && p.stock_min) patch.stock_min = p.stock_min;
  if (h.category && p.category && p.category !== 'General') patch.category = p.category;
  if (p.supplier_id) patch.supplier_id = p.supplier_id;
  return patch;
}

export async function importProducts(rows, onProgress = () => {}) {
  const branch = requireBranch();
  const mainId = mainBranchId();
  const { products, skipped, errors } = normalizeImportRows(rows);
  const byKey = new Map(db.all('products').map(p => [productKey(p), p]));
  // Si el código no coincide (otro sistema usa otro código), se busca por nombre exacto
  const byName = new Map(db.all('products').map(p => [norm(p.name), p]));
  const supByName = new Map(db.all('suppliers').map(s => [norm(s.name), s]));
  const ops = [];
  let created = 0, updated = 0;
  const dupCodes = [];
  for (const p of products) {
    const supName = p._supplier_name;
    delete p._supplier_name;
    const has = p._has; delete p._has;
    if (supName) {
      let s = supByName.get(norm(supName));
      if (!s) {
        s = { id: uuid(), name: supName, cuit: '', phone: '', email: '', notes: 'Creado al importar' };
        supByName.set(norm(supName), s);
        ops.push({ coll: 'suppliers', rec: s });
      }
      p.supplier_id = s.id;
    }
    const ex = byKey.get(productKey(p)) || (!byKey.has(productKey(p)) ? byName.get(norm(p.name)) : null);
    if (ex && ex._new && norm(ex.name) !== norm(p.name)) {
      // Mismo código para dos productos distintos dentro del archivo: se cargan los dos,
      // el código queda en el primero y este queda marcado para que lo corrijas.
      const code = p.barcode || p.sku;
      const rec = { id: uuid(), ...p, ...setStockIn({}, branch, p.stock, mainId), barcode: '', sku: `${code}-REPETIDO` };
      ops.push({ coll: 'products', rec });
      created++;
      dupCodes.push(`${code}: "${ex.name}" y "${p.name}"`);
    } else if (ex && ex._new) {
      // Repetido dentro del mismo archivo: se actualiza el registro que se va a crear (no un parche suelto)
      Object.assign(ex, importPatch(ex, p, branch, mainId, has));
      updated++;
    } else if (ex) {
      ops.push({ coll: 'products', rec: { id: ex.id, ...importPatch(ex, p, branch, mainId, has) } });
      updated++;
    } else {
      const rec = { id: uuid(), ...p, ...setStockIn({}, branch, p.stock, mainId) };
      Object.defineProperty(rec, '_new', { value: true, enumerable: false });
      byKey.set(productKey(rec), rec);
      ops.push({ coll: 'products', rec });
      created++;
    }
  }
  for (let i = 0; i < ops.length; i += 500) {
    await db.putBatch(ops.slice(i, i + 500));
    onProgress(Math.min(ops.length, i + 500), ops.length);
  }
  if (dupCodes.length) errors.push(`${dupCodes.length} códigos estaban repetidos en dos productos distintos: se cargaron los dos y al segundo le quedó el código con "-REPETIDO" (buscalos así para corregirlos): ` + dupCodes.slice(0, 60).join(' · '));
  return { created, updated, skipped, errors, dupCodes: dupCodes.length };
}

/** Lee un archivo de productos: .json (formato viejo), .csv/.txt o .xlsx/.xls (con xlsx de cdnjs) */
export async function readProductFile(file, loadXlsx) {
  const name = file.name.toLowerCase();
  if (name.endsWith('.json')) {
    const data = JSON.parse(await file.text());
    const rows = Array.isArray(data) ? data : (data.products || data.productos || data.data?.products || data.db?.productos || []);
    if (!Array.isArray(rows)) throw new Error('El JSON no tiene una lista de productos.');
    // Copia completa del sistema anterior: se guarda aparte para importar comercio y usuarios
    if (data && data.db && data._meta) Object.defineProperty(rows, 'legacy', { value: data, enumerable: false });
    return rows;
  }
  if (name.endsWith('.csv') || name.endsWith('.txt')) return tableToObjects(parseCSV(await file.text()));
  if (name.endsWith('.xlsx') || name.endsWith('.xls') || name.endsWith('.ods')) {
    const XLSX = await loadXlsx();
    const wb = XLSX.read(await file.arrayBuffer(), { type: 'array' });
    const sh = wb.Sheets[wb.SheetNames[0]];
    const table = XLSX.utils.sheet_to_json(sh, { header: 1, raw: true, defval: '' });
    return tableToObjects(table);
  }
  throw new Error('Formato no soportado. Usá .json, .csv o .xlsx.');
}

// ---------- Compras ----------

/** Guarda una compra en la sucursal de este equipo: suma stock ahí, actualiza el costo del producto y registra stock_moves */
export async function savePurchase({ supplier_id, items, invoice_ref = '', payment = 'contado', paid = 0, due_date = '' }) {
  const branch_id = requireBranch();
  if (!items.length) throw new Error('Agregá al menos un producto.');
  // A cuenta corriente: lo que no se pagó al comprar suma a lo que le debemos al proveedor
  const onAccount = payment === 'cuenta_corriente';
  const sup = supplier_id ? db.get('suppliers', supplier_id) : null;
  if (onAccount && !sup) throw new Error('Para comprar a cuenta corriente elegí el proveedor.');
  const now = Date.now();
  const clean = items.map(it => ({ product_id: it.product_id, name: it.name, qty: round3(it.qty), unit_cost: round2(it.unit_cost) }));
  if (clean.some(it => !(it.qty > 0))) throw new Error('Revisá las cantidades: tienen que ser mayores a cero.');
  const total = round2(clean.reduce((a, it) => a + round2(it.qty * it.unit_cost), 0));
  const paidNow = onAccount ? round2(paid || 0) : total;
  if (onAccount && !(paidNow >= 0 && paidNow <= total)) throw new Error('Lo pagado al comprar no puede ser más que el total.');
  const purchase = {
    id: uuid(), branch_id, created_at: now, supplier_id: supplier_id || null, items: clean, total, invoice_ref: String(invoice_ref || '').trim(), user_id: ctx.user.id,
    payment: onAccount ? 'cuenta_corriente' : 'contado', paid: paidNow, due_date: onAccount && due_date ? String(due_date) : null,
  };
  const ops = [{ coll: 'purchases', rec: purchase }];
  if (onAccount) ops.push({ coll: 'suppliers', rec: { id: sup.id, balance: round2(Math.round(round2(sup.balance || 0) * 100 + Math.round(total * 100) - Math.round(paidNow * 100)) / 100) } });
  const delta = {};
  for (const it of clean) {
    delta[it.product_id] = delta[it.product_id] || { q: 0, cost: it.unit_cost };
    delta[it.product_id].q = round3(delta[it.product_id].q + it.qty);
    delta[it.product_id].cost = it.unit_cost;
  }
  for (const [pid, d] of Object.entries(delta)) {
    const p = db.get('products', pid);
    if (!p) continue;
    const rec = { id: pid, ...applyStockDelta(p, branch_id, d.q, mainBranchId()) };
    if (d.cost > 0) rec.cost = d.cost;
    if (supplier_id) rec.supplier_id = supplier_id;
    ops.push({ coll: 'products', rec });
    ops.push({ coll: 'stock_moves', rec: { product_id: pid, branch_id, qty: d.q, reason: 'compra', ref_id: purchase.id, created_at: now, user_id: ctx.user.id } });
  }
  await db.putBatch(ops);
  return purchase;
}

// ---------- Clientes ----------

/** Cobro de cuenta corriente: baja el saldo y, si es en efectivo, entra a la caja */
export async function registerCustomerPayment(customerId, amount, method = 'efectivo') {
  const c = db.get('customers', customerId);
  if (!c) throw new Error('Cliente no encontrado.');
  const a = round2(amount);
  if (!(a > 0)) throw new Error('El monto tiene que ser mayor a cero.');
  const session = openSession();
  if (method === 'efectivo' && !session) throw new Error('Abrí la caja para cobrar en efectivo.');
  const now = Date.now();
  const ops = [{ coll: 'customers', rec: { id: c.id, balance: round2((c.balance || 0) - a) } }];
  ops.push({ coll: 'cash_movements', rec: {
    session_id: session ? session.id : null, branch_id: ctx.branchId || mainBranchId(), type: method === 'efectivo' ? 'ingreso' : 'cobro', amount: a, method,
    reason: `Cobro cuenta corriente: ${c.name}`, customer_id: c.id, created_at: now, user_id: ctx.user.id,
  } });
  await db.putBatch(ops);
}

/**
 * Aplica datos del comercio y usuarios de la copia del sistema anterior.
 * No pisa datos que ya cargaste en Ajustes; no crea usuarios repetidos; no copia contraseñas.
 */
export async function importLegacySetup(data) {
  const { settings: st, users, counts } = legacyBackupToSetup(data);
  const cur = settings();
  const patch = {};
  for (const [k, v] of Object.entries(st)) {
    const fiscal = ['legal_name', 'cuit', 'iva_condition', 'start_date'].includes(k);
    // Lo fiscal viene de la copia si todavía no cargaste CUIT; lo demás solo completa lo vacío
    if (!cur[k] || (fiscal && !cur.cuit)) patch[k] = v;
  }
  if (Object.keys(patch).length) await saveSettings(patch);
  const existing = new Set(db.all('users').map(u => norm(u.name)));
  let created = 0;
  for (const u of users) {
    if (existing.has(norm(u.name))) continue;
    await saveUser({ name: u.name, role: u.role });
    existing.add(norm(u.name));
    created++;
  }
  // Sucursales preparadas (jeano_setup.branches): la primera es la principal de este equipo
  let branchesSet = 0;
  const pre = (data.jeano_setup && Array.isArray(data.jeano_setup.branches)) ? data.jeano_setup.branches : [];
  for (const [i, b] of pre.entries()) {
    const found = db.all('branches').find(x => norm(x.name) === norm(b.name)) || (i === 0 ? db.get('branches', mainBranchId()) : null);
    await saveBranch({ id: found ? found.id : undefined, name: b.name, pos_number: b.pos_number, address: b.address || '', active: 1 });
    branchesSet++;
  }
  return { settingsUpdated: Object.keys(patch), usersCreated: created, branchesSet, counts };
}

// ---------- Empezar de cero ----------

function resetData() {
  const data = {};
  for (const c of [...RESET_COLLECTIONS, 'customers', 'products', 'suppliers']) data[c] = db.all(c);
  return data;
}

/** Lo que se va a borrar (para mostrarlo antes de confirmar) */
export function resetPreview({ zeroStock = false } = {}) {
  const { counts, keptInvoices, customers, products, suppliers } = planReset(resetData(), { zeroStock });
  return { counts, keptInvoices, customers, products, suppliers };
}

/**
 * Empezar de cero: borra ventas, cajas, movimientos de caja, compras y movimientos de stock; deja en 0 los saldos
 * de cuenta corriente y, si se pide, el stock de todos los productos en todas las sucursales.
 * Con nube: primero sube lo pendiente, después la nube borra TODO el comercio en una transacción
 * (POST /api/admin/reset) y este equipo baja los borrados. Los otros equipos los reciben en su próxima sincronización.
 * Las ventas con CAE no se borran: quedan como registro con test=1.
 * La copia de seguridad la hace la pantalla antes de llamar acá.
 */
export async function resetAll({ zeroStock = false, password = undefined, onProgress = () => {} } = {}) {
  if (!ctx.user || ctx.user.role !== 'dueno') throw new Error('Solo el dueño puede empezar de cero.');
  await db.whenLoaded();
  let server = null;
  if (sync.isConfigured()) {
    if (typeof navigator !== 'undefined' && navigator.onLine === false) throw new Error('Para empezar de cero hace falta internet, porque también se borra en la nube. No se borró nada.');
    onProgress('Subiendo los cambios pendientes a la nube…');
    if (!(await sync.syncNow()) || (await db.outboxCount()) > 0) {
      // Puede haber una sincronización en curso: se intenta una vez más
      if (!(await sync.syncNow()) || (await db.outboxCount()) > 0) throw new Error(`No se pudo sincronizar con la nube${sync.status.error ? ` (${sync.status.error})` : ''}. No se borró nada.`);
    }
    onProgress('Borrando en la nube…');
    server = await sync.api('/api/admin/reset', { method: 'POST', body: { confirm: 'BORRAR', zero_stock: !!zeroStock, ...(password ? { password } : {}) }, timeout: 60000 });
    onProgress('Bajando los cambios de la nube…');
    await sync.syncNow();
  }
  // En este equipo: lo que quede vivo (todo, si no hay nube) se borra con borrado lógico, en tandas
  const plan = planReset(resetData(), { zeroStock });
  for (let i = 0; i < plan.ops.length; i += 500) {
    onProgress(`Borrando en este equipo… ${Math.min(i + 500, plan.ops.length)} de ${plan.ops.length}`);
    await db.putBatch(plan.ops.slice(i, i + 500));
  }
  if (server && plan.ops.length) sync.syncNow();
  return { server, local: { counts: plan.counts, keptInvoices: plan.keptInvoices, customers: plan.customers, products: plan.products } };
}

// ---------- Devoluciones / notas de crédito ----------
// Una devolución (colección "returns") es total o parcial: la mercadería vuelve al stock de la sucursal DE LA VENTA
// (stock_moves "devolucion") y la plata sale en efectivo de la caja abierta, a la cuenta corriente o por el mismo medio
// con que se pagó. Si la venta tenía CAE, se pide a ARCA la nota de crédito asociada por el importe devuelto.

/** Devoluciones de una venta, de la más vieja a la más nueva */
export function saleReturns(saleId) {
  return db.all('returns').filter(r => r.sale_id === saleId).sort((a, b) => a.created_at - b.created_at || (a.number || 0) - (b.number || 0));
}

/** Motivo por el que no se puede hacer una devolución de la venta ('' si se puede) */
export function returnBlockReason(sale) {
  if (!sale || sale.deleted) return 'Venta no encontrada.';
  if (sale.status !== 'ok') return 'La venta está anulada.';
  if (sale.test) return 'Es una venta de la etapa de prueba: no se puede devolver.';
  const d = sale.doc || {};
  if (d.kind === 'factura' && d.status !== 'autorizado') return 'La factura de esta venta todavía no tiene CAE: reintentá la factura antes de hacer la nota de crédito.';
  if (!canReturnMore(sale, saleReturns(sale.id))) return 'Ya se devolvió todo lo de esta venta.';
  return '';
}

/**
 * Guarda una devolución en UNA transacción: el registro, el stock que vuelve, los stock_moves y la cuenta corriente.
 * picks: {renglón: cantidad}. refund_method: efectivo | cuenta_corriente | mismo_medio.
 * Si la venta tiene CAE la nota de crédito queda "pendiente": la pide requestCreditNote (la pantalla la llama enseguida).
 */
export async function createReturn({ sale_id, picks, reason = '', refund_method = 'efectivo', authorizedBy = null, extraOps = [] }) {
  if (!ctx.user || !(can(ctx.user, 'devolver') || (authorizedBy && can(authorizedBy, 'devolver')))) throw new Error('Para hacer una devolución hace falta la autorización del dueño o del encargado.');
  const sale = db.get('sales', sale_id);
  const block = returnBlockReason(sale);
  if (block) throw new Error(block);
  if (!['efectivo', 'cuenta_corriente', 'mismo_medio'].includes(refund_method)) throw new Error('Elegí cómo se devuelve la plata.');
  const st = settings();
  const calc = buildReturn(sale, saleReturns(sale_id), picks, discriminaIva(st.iva_condition));
  const refunds = refundSplit(sale, calc.total, refund_method);
  const eff = refundEffects(refunds);
  const customer = sale.customer_id ? db.get('customers', sale.customer_id) : null;
  if (eff.account > 0 && !customer) throw new Error('Para devolver a cuenta corriente la venta tiene que tener un cliente.');
  const session = openSession();
  if (eff.cash > 0 && !session) throw new Error('Abrí la caja para devolver el efectivo.');
  const d = sale.doc || {};
  const doc = hasCae(sale)
    ? { kind: 'nota_credito', cbte_tipo: ncTipo(d.cbte_tipo), pto_vta: d.pto_vta, cbte_nro: null, cae: '', cae_vto: '', status: 'pendiente', error: '' }
    : { kind: 'no_fiscal', status: 'no_fiscal' };
  const now = Date.now();
  const saleBranch = branchOf(sale, mainBranchId());
  const ret = {
    id: uuid(), number: nextNumber('returns'), sale_id, created_at: now, user_id: ctx.user.id,
    session_id: session ? session.id : null, branch_id: saleBranch, customer_id: sale.customer_id || null,
    items: calc.items, total: calc.total, net: calc.net, iva: calc.iva, refund_method, refunds,
    reason: String(reason || '').trim(), doc,
  };
  const ops = [{ coll: 'returns', rec: ret }];
  stockOps(ops, calc.items, +1, 'devolucion', ret.id, now, saleBranch);
  if (eff.account > 0) ops.push({ coll: 'customers', rec: { id: customer.id, balance: round2((customer.balance || 0) - eff.account) } });
  ops.push(...extraOps.map(o => (o.coll === 'audit_log' ? { ...o, rec: { ...o.rec, entity_id: o.rec.entity_id || ret.id, detail: { ...o.rec.detail, return_number: ret.number, total: ret.total, refunds: refunds } } } : o)));
  await db.putBatch(ops);
  return db.get('returns', ret.id);
}

/** Pide a la nube la nota de crédito de una devolución de una venta con CAE. Devuelve {ok, doc, error}. */
export async function requestCreditNote(returnId) {
  const r = db.get('returns', returnId);
  if (!r || !r.doc || r.doc.kind !== 'nota_credito') return { ok: false, error: 'Esta devolución no lleva nota de crédito de ARCA.' };
  if (r.doc.status === 'autorizado' && r.doc.cae) return { ok: true, doc: r.doc };
  if (!sync.isConfigured()) {
    const doc = { ...r.doc, status: 'pendiente', error: 'No hay nube conectada: no se puede pedir la nota de crédito a ARCA.' };
    await db.put('returns', { id: returnId, doc });
    return { ok: false, doc, error: doc.error };
  }
  try {
    await sync.syncNow(); // la nube necesita tener la devolución
    const res = await sync.api('/api/arca/credit-note', { method: 'POST', body: { sale_id: r.sale_id, return_id: r.id }, timeout: 45000 });
    const doc = res && res.doc;
    if (!doc || !doc.status) throw new Error('Respuesta inválida del servidor.');
    await db.put('returns', { id: returnId, doc: { ...doc, kind: 'nota_credito' } });
    if (doc.status === 'autorizado' && doc.cae) return { ok: true, doc };
    return { ok: false, doc, error: doc.error || 'ARCA no autorizó la nota de crédito.' };
  } catch (e) {
    const doc = { ...r.doc, status: 'pendiente', error: e.message, http: e.status || 0 };
    await db.put('returns', { id: returnId, doc });
    return { ok: false, doc, error: e.message };
  }
}

// ---------- Reintento automático de comprobantes ARCA pendientes ----------
// Al volver internet (y después de cada sincronización) se reintentan solas las facturas y notas de crédito que
// quedaron "pendientes" en este equipo (su sucursal, últimos 15 días). Cada una, como mucho cada 10 minutos.
// Las que la nube rechazó por datos (400/403/422) o ARCA rechazó no se reintentan solas: hay que corregir algo.

const arcaTried = new Map();
let arcaRunning = null;
export const ARCA_RETRY_MS = 10 * 60 * 1000;

export function pendingArcaDocs(branchId = ctx.branchId) {
  const since = Date.now() - 15 * 86400000;
  const out = [];
  const retryable = d => d && d.status === 'pendiente' && ![400, 403, 422].includes(Number(d.http));
  for (const s of db.all('sales')) {
    if (s.status !== 'ok' || s.test || s.created_at < since || (branchId && !inBranch(s, branchId))) continue;
    if (s.doc && s.doc.kind === 'factura' && retryable(s.doc)) out.push({ coll: 'sales', id: s.id });
  }
  for (const r of db.all('returns')) {
    if (r.test || r.created_at < since || (branchId && !inBranch(r, branchId))) continue;
    if (r.doc && r.doc.kind === 'nota_credito' && retryable(r.doc)) out.push({ coll: 'returns', id: r.id });
  }
  return out;
}

export function retryPendingArca({ force = false } = {}) {
  if (arcaRunning) return arcaRunning;
  if (!ctx.user || !sync.isConfigured() || (typeof navigator !== 'undefined' && navigator.onLine === false)) return Promise.resolve({ tried: 0, ok: 0 });
  arcaRunning = (async () => {
    let tried = 0, ok = 0;
    try {
      for (const it of pendingArcaDocs()) {
        const last = arcaTried.get(it.id) || 0;
        if (!force && Date.now() - last < ARCA_RETRY_MS) continue;
        arcaTried.set(it.id, Date.now());
        tried++;
        const r = it.coll === 'sales' ? await requestInvoice(it.id) : await requestCreditNote(it.id);
        if (r.ok) ok++;
        if (navigator.onLine === false) break;
      }
    } finally { arcaRunning = null; }
    return { tried, ok };
  })();
  return arcaRunning;
}

// ---------- Remitos internos entre sucursales ----------
// Enviar descuenta el stock en la sucursal de origen ("remito_salida"); la otra sucursal lo ve en "Remitos por recibir",
// controla lo que llegó y al recibir se suma en destino ("remito_entrada"). Los faltantes y sobrantes quedan en
// `differences`. Un remito enviado (no recibido) se puede anular: el stock vuelve al origen ("remito_anulado").

/** Remitos que esta sucursal tiene que recibir */
export function transfersToReceive(branchId = ctx.branchId) {
  return db.all('transfers').filter(t => t.status === 'enviado' && t.to_branch === branchId).sort((a, b) => a.created_at - b.created_at);
}

export async function createTransfer({ to_branch, items, notes = '' }) {
  const from = requireBranch();
  if (!can(ctx.user, 'remitos')) throw new Error('Solo el dueño o el encargado pueden mandar mercadería a otra sucursal.');
  const dest = db.get('branches', to_branch);
  if (!dest || dest.deleted || dest.active === 0 || to_branch === from) throw new Error('Elegí la sucursal a la que mandás la mercadería.');
  const clean = cleanTransferItems(items);
  if (!clean.length) throw new Error('Agregá al menos un producto con cantidad mayor a cero.');
  const now = Date.now();
  const t = {
    id: uuid(), number: nextNumber('transfers'), from_branch: from, to_branch, items: clean, status: 'enviado',
    created_at: now, created_by: ctx.user.id, received_at: null, received_by: null, voided_at: null, voided_by: null,
    notes: String(notes || '').trim(), differences: [],
  };
  const ops = [{ coll: 'transfers', rec: t }];
  stockOps(ops, clean, -1, 'remito_salida', t.id, now, from);
  await db.putBatch(ops);
  return db.get('transfers', t.id);
}

/** Recibe un remito en la sucursal de este equipo. received: {product_id: cantidad que llegó} */
export async function receiveTransfer(id, received, notes = '') {
  const t = db.get('transfers', id);
  if (!t || t.deleted) throw new Error('Remito no encontrado.');
  if (t.status !== 'enviado') throw new Error(t.status === 'recibido' ? 'Este remito ya se recibió.' : 'Este remito está anulado.');
  const here = requireBranch();
  if (t.to_branch !== here) throw new Error(`Este remito es para ${branchName(t.to_branch)}: recibilo desde un equipo de esa sucursal.`);
  const got = {};
  for (const it of t.items) {
    const v = received && received[it.product_id];
    const q = v === undefined || v === null || v === '' ? 0 : round3(v);
    if (!(q >= 0)) throw new Error(`Revisá la cantidad recibida de “${it.name}”.`);
    got[it.product_id] = q;
  }
  const differences = transferDifferences(t.items, got);
  const now = Date.now();
  const items = t.items.map(it => ({ ...it, qty_received: got[it.product_id] }));
  const extra = String(notes || '').trim();
  const ops = [{ coll: 'transfers', rec: {
    id, status: 'recibido', items, differences, received_at: now, received_by: ctx.user.id,
    notes: extra ? (t.notes ? `${t.notes}\nAl recibir: ${extra}` : `Al recibir: ${extra}`) : t.notes,
  } }];
  stockOps(ops, items.map(it => ({ product_id: it.product_id, qty: it.qty_received })).filter(it => it.qty > 0), +1, 'remito_entrada', id, now, here);
  await db.putBatch(ops);
  return db.get('transfers', id);
}

/** Anula un remito que todavía no se recibió: el stock vuelve a la sucursal de origen */
export async function voidTransfer(id, reason = '') {
  const t = db.get('transfers', id);
  if (!t || t.deleted || t.status !== 'enviado') throw new Error('Solo se puede anular un remito enviado que todavía no se recibió.');
  if (!can(ctx.user, 'remitos')) throw new Error('Solo el dueño o el encargado pueden anular remitos.');
  const now = Date.now();
  const r = String(reason || '').trim();
  const ops = [{ coll: 'transfers', rec: { id, status: 'anulado', voided_at: now, voided_by: ctx.user.id, notes: r ? (t.notes ? `${t.notes}\nAnulado: ${r}` : `Anulado: ${r}`) : t.notes } }];
  stockOps(ops, t.items, +1, 'remito_anulado', id, now, t.from_branch);
  await db.putBatch(ops);
  return db.get('transfers', id);
}
