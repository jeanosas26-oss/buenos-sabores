// =====================================================================
// logic.js — Lógica pura de JEANO Gestión (sin DOM ni IndexedDB).
// Se puede importar desde el navegador y desde Node (tests).
// =====================================================================

// ---------- Números y redondeo ----------

/** Redondea a 2 decimales (centavos) evitando errores de coma flotante (1.005 → 1.01). */
export function round2(x) {
  const n = Number(x);
  if (!isFinite(n)) return 0;
  if (Math.abs(n) < 1e-9) return 0;
  if (Math.abs(n) >= 1e15) return Math.round(n); // sin centavos posibles (y String() daría notación exponencial)
  const sign = n < 0 ? -1 : 1;
  const r = Number(Math.round(Number(Math.abs(n) + 'e2')) + 'e-2');
  return sign * r || 0;
}

/** Redondeo para cantidades (kg con 3 decimales). */
export function round3(x) {
  const n = Number(x);
  if (!isFinite(n) || Math.abs(n) < 1e-12) return 0;
  const sign = n < 0 ? -1 : 1;
  return sign * Number(Math.round(Number(Math.abs(n) + 'e3')) + 'e-3') || 0;
}

/**
 * Convierte un texto escrito "a la argentina" en número.
 * Acepta "12.656,00", "12656,5", "0,350", "1500", "12.5", "$ 1.200".
 * Devuelve NaN si no se puede interpretar.
 */
export function parseNum(input) {
  if (typeof input === 'number') return isFinite(input) ? input : NaN;
  if (input === null || input === undefined) return NaN;
  let s = String(input).trim().replace(/\s|\$/g, '');
  if (s === '') return NaN;
  let neg = false;
  if (/^[-−]/.test(s)) { neg = true; s = s.slice(1); }
  const hasDot = s.includes('.');
  const hasComma = s.includes(',');
  if (hasDot && hasComma) {
    // El último separador es el decimal
    if (s.lastIndexOf(',') > s.lastIndexOf('.')) s = s.replace(/\./g, '').replace(',', '.');
    else s = s.replace(/,/g, '');
  } else if (hasComma) {
    if (/^\d{1,3}(,\d{3}){2,}$/.test(s)) s = s.replace(/,/g, ''); // 1,234,567
    else s = s.replace(',', '.');
  } else if (hasDot) {
    // "12.656" o "1.234.567" son miles; "0.35", "0.350" o "12.5" son decimales (un grupo de miles nunca empieza con 0)
    if (/^[1-9]\d{0,2}(\.\d{3})+$/.test(s)) s = s.replace(/\./g, '');
  }
  if (!/^\d*\.?\d+$|^\d+\.$/.test(s)) return NaN;
  const n = Number(s);
  return neg ? -n : n;
}

// ---------- Formatos es-AR ----------

const nf2 = new Intl.NumberFormat('es-AR', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
const nfQty = new Intl.NumberFormat('es-AR', { minimumFractionDigits: 0, maximumFractionDigits: 3 });

/** $ 12.656,00 */
export function fmtMoney(n) {
  const v = round2(n);
  const s = nf2.format(Math.abs(v));
  return (v < 0 ? '-$ ' : '$ ') + s;
}

/** Número con 2 decimales sin signo $ (para inputs): 12.656,00 */
export function fmtNum2(n) { return nf2.format(round2(n)); }

/** Cantidad: 2 / 0,35 / 1,5 */
export function fmtQty(n) { return nfQty.format(round3(n)); }

const pad = (n, l = 2) => String(n).padStart(l, '0');

/** 13/11/2026 */
export function fmtDate(ms) {
  if (ms === null || ms === undefined || ms === '') return '';
  const d = new Date(ms);
  return `${pad(d.getDate())}/${pad(d.getMonth() + 1)}/${d.getFullYear()}`;
}
/** 13/11/2026 14:05 */
export function fmtDateTime(ms) {
  if (ms === null || ms === undefined || ms === '') return '';
  const d = new Date(ms);
  return `${fmtDate(ms)} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
/** 14:05 */
export function fmtTime(ms) {
  const d = new Date(ms);
  return `${pad(d.getHours())}:${pad(d.getMinutes())}`;
}
/** yyyy-mm-dd (valor para <input type=date>) en hora local */
export function toISODate(ms) {
  const d = new Date(ms);
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
}
/** Inicio del día local de un yyyy-mm-dd */
export function dayStart(iso) {
  const [y, m, d] = String(iso).split('-').map(Number);
  return new Date(y, m - 1, d, 0, 0, 0, 0).getTime();
}
/** Fin del día local (inclusive) */
export function dayEnd(iso) { return dayStart(iso) + 86400000 - 1; }

/** Rango de fechas para reportes: 'hoy' | 'semana' (lunes a hoy) | 'mes' (1 a hoy) */
export function periodRange(kind, now = Date.now()) {
  const d = new Date(now);
  const start = new Date(d.getFullYear(), d.getMonth(), d.getDate());
  if (kind === 'semana') {
    const dow = (start.getDay() + 6) % 7; // lunes = 0
    start.setDate(start.getDate() - dow);
  } else if (kind === 'mes') {
    start.setDate(1);
  }
  const end = new Date(d.getFullYear(), d.getMonth(), d.getDate() + 1).getTime() - 1;
  return { from: start.getTime(), to: end };
}

/** Normaliza texto para búsquedas: minúsculas y sin acentos */
export function norm(s) {
  return String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').trim();
}

// ---------- IVA y totales ----------

export const IVA_RATES = [21, 10.5, 27, 0];

/**
 * Calcula una línea. El precio YA incluye IVA.
 * subtotal = qty × unit_price − discount (redondeado a centavos)
 * neto = subtotal / (1 + tasa) ; iva = subtotal − neto
 * Si el emisor no discrimina IVA (monotributo/exento) neto = subtotal e iva = 0.
 */
export function lineAmounts(line, discriminaIva = true) {
  const gross = round2(Number(line.qty) * Number(line.unit_price));
  const subtotal = round2(gross - Number(line.discount || 0));
  const rate = Number(line.iva_rate || 0);
  if (!discriminaIva || rate === 0) return { gross, subtotal, net: subtotal, iva: 0, rate: discriminaIva ? rate : 0 };
  const net = round2(subtotal / (1 + rate / 100));
  return { gross, subtotal, net, iva: round2(subtotal - net), rate };
}

/**
 * Reparte un descuento global entre las líneas en proporción a su importe,
 * en centavos exactos (la suma de las partes es exactamente el descuento).
 */
export function prorateDiscount(grossList, discount) {
  const totalCents = grossList.reduce((a, g) => a + Math.round(g * 100), 0);
  let dCents = Math.round(round2(discount) * 100);
  if (dCents <= 0 || totalCents <= 0) return grossList.map(() => 0);
  if (dCents > totalCents) dCents = totalCents;
  const raw = grossList.map(g => (Math.round(g * 100) * dCents) / totalCents);
  const floors = raw.map(Math.floor);
  let rest = dCents - floors.reduce((a, b) => a + b, 0);
  // Método del mayor resto
  const order = raw.map((r, i) => [r - floors[i], i]).sort((a, b) => b[0] - a[0]);
  for (let k = 0; k < order.length && rest > 0; k++, rest--) floors[order[k][1]]++;
  return floors.map(c => c / 100);
}

/**
 * Calcula el carrito completo.
 * items: [{product_id,name,qty,unit_price,iva_rate}]
 * discount: descuento global en pesos (se prorratea a las líneas)
 * Devuelve { items (con discount y subtotal por línea), gross, discount, total, net, iva, byRate }
 * Garantía: total = Σ subtotal, net + iva = total, net = Σ net línea, iva = Σ iva línea.
 */
export function computeSale(items, discount = 0, discriminaIva = true) {
  // Con la cantidad y el precio ya redondeados (los mismos que usa cada renglón): así Σ subtotal = bruto − descuento
  const grossList = items.map(it => round2(round3(it.qty) * round2(it.unit_price)));
  const gross = round2(grossList.reduce((a, b) => a + b, 0));
  const parts = prorateDiscount(grossList, Math.min(Math.max(0, Number(discount) || 0), gross));
  let total = 0, net = 0, iva = 0;
  const byRate = {};
  const out = items.map((it, i) => {
    const line = { ...it, qty: round3(it.qty), unit_price: round2(it.unit_price), iva_rate: Number(it.iva_rate ?? 21), discount: parts[i] };
    const a = lineAmounts(line, discriminaIva);
    line.subtotal = a.subtotal;
    total += a.subtotal; net += a.net; iva += a.iva;
    const k = String(a.rate);
    byRate[k] = byRate[k] || { net: 0, iva: 0, total: 0 };
    byRate[k].net = round2(byRate[k].net + a.net);
    byRate[k].iva = round2(byRate[k].iva + a.iva);
    byRate[k].total = round2(byRate[k].total + a.subtotal);
    return line;
  });
  return {
    items: out,
    gross,
    discount: round2(parts.reduce((a, b) => a + b, 0)),
    total: round2(total),
    net: round2(net),
    iva: round2(iva),
    byRate,
  };
}

/** Desglose de IVA por alícuota de una venta ya guardada (para Libro IVA y tickets). */
export function ivaBreakdown(items, discriminaIva = true) {
  const byRate = {};
  for (const it of items || []) {
    const sub = round2(it.subtotal);
    const rate = discriminaIva ? Number(it.iva_rate || 0) : 0;
    const net = rate ? round2(sub / (1 + rate / 100)) : sub;
    const k = String(rate);
    byRate[k] = byRate[k] || { net: 0, iva: 0, total: 0 };
    byRate[k].net = round2(byRate[k].net + net);
    byRate[k].iva = round2(byRate[k].iva + (sub - net));
    byRate[k].total = round2(byRate[k].total + sub);
  }
  return byRate;
}

// ---------- Comprobantes ----------

/** Regla del contrato: emisor MT/EX → C (11). Emisor RI → cliente RI = A (1), otro = B (6). */
export function cbteTipo(emisorCond, clienteCond) {
  if (emisorCond === 'RI') return clienteCond === 'RI' ? 1 : 6;
  return 11;
}
/** Nota de crédito asociada: A=3, B=8, C=13 */
export function ncTipo(tipo) {
  return { 1: 3, 6: 8, 11: 13 }[tipo] || null;
}
export function cbteLetra(tipo) {
  return { 1: 'A', 6: 'B', 11: 'C', 3: 'A', 8: 'B', 13: 'C' }[tipo] || '';
}
export function cbteNombre(tipo) {
  const nc = [3, 8, 13].includes(tipo);
  return (nc ? 'Nota de crédito ' : 'Factura ') + cbteLetra(tipo);
}
/** 0003-00000125 */
export function fmtCbteNro(ptoVta, nro) {
  return `${pad(ptoVta || 0, 4)}-${pad(nro || 0, 8)}`;
}
/** El emisor discrimina IVA solo si es Responsable Inscripto */
export function discriminaIva(emisorCond) { return emisorCond === 'RI'; }

// ---------- Cobro y vuelto ----------

export const PAY_METHODS = [
  { id: 'efectivo', label: 'Efectivo' },
  { id: 'debito', label: 'Débito' },
  { id: 'credito', label: 'Crédito' },
  { id: 'transferencia', label: 'Transferencia' },
  { id: 'mercadopago', label: 'Mercado Pago' },
  { id: 'cuenta_corriente', label: 'Cuenta corriente' },
];
// Nombres de los medios propios del comercio (payment_methods: "Coca Cola", QR…): los registra comercial-ops.js
const EXTRA_PAY_LABELS = { qr: 'QR', cheque: 'Cheque', otro: 'Otro' };
export function setPayLabels(map) { Object.assign(EXTRA_PAY_LABELS, map || {}); }
export function payLabel(id) { const m = PAY_METHODS.find(x => x.id === id); return m ? m.label : (EXTRA_PAY_LABELS[id] || id); }

/**
 * Analiza los pagos ingresados contra el total.
 * payments: [{method, amount}] — en efectivo, amount es lo que entrega el cliente.
 * Solo el efectivo da vuelto. Devuelve:
 * { paid, cash, nonCash, missing, change, ok, error, applied: [{method,amount,tendered?}] }
 * `applied` es lo que se guarda: la suma de amounts es exactamente el total.
 */
export function calcPayment(total, payments) {
  const T = round2(total);
  const list = (payments || []).map(p => ({ method: p.method, amount: round2(p.amount) })).filter(p => p.amount > 0);
  const cash = round2(list.filter(p => p.method === 'efectivo').reduce((a, p) => a + p.amount, 0));
  const nonCash = round2(list.filter(p => p.method !== 'efectivo').reduce((a, p) => a + p.amount, 0));
  const paid = round2(cash + nonCash);
  const res = { total: T, paid, cash, nonCash, missing: 0, change: 0, ok: false, error: '', applied: [] };
  if (nonCash > T) { res.error = 'Los pagos que no son en efectivo superan el total.'; return res; }
  if (paid < T) { res.missing = round2(T - paid); res.error = `Faltan ${fmtMoney(res.missing)}`; return res; }
  res.change = round2(paid - T);
  res.ok = true;
  // Agrupa por medio y descuenta el vuelto del efectivo
  const grouped = {};
  for (const p of list) grouped[p.method] = round2((grouped[p.method] || 0) + p.amount);
  res.applied = Object.entries(grouped).map(([method, amount]) => {
    if (method === 'efectivo') return { method, amount: round2(amount - res.change), tendered: amount };
    return { method, amount };
  }).filter(p => p.amount > 0); // si el efectivo fue todo vuelto (no debería), no se guarda
  return res;
}

// ---------- Caja: arqueo ----------

/**
 * Esperado en efectivo de una sesión de caja.
 * esperado = inicial + efectivo de ventas OK + ingresos − egresos
 * diferencia = contado − esperado (negativo = falta plata)
 */
export function computeArqueo({ opening = 0, sales = [], movements = [], counted = null, returns = [] }) {
  let cashSales = 0, salesTotal = 0, count = 0;
  const byMethod = {};
  for (const s of sales) {
    if (s.status !== 'ok' || s.deleted) continue;
    count++;
    salesTotal += Number(s.total) || 0;
    for (const p of s.payments || []) {
      byMethod[p.method] = round2((byMethod[p.method] || 0) + Number(p.amount || 0));
      if (p.method === 'efectivo') cashSales += Number(p.amount) || 0;
    }
  }
  let ingresos = 0, egresos = 0;
  for (const m of movements) {
    if (m.deleted) continue;
    // Solo el efectivo suma o resta del cajón: los movimientos con cheque o Mercado Pago (esquema 0006) no
    if (m.method && m.method !== 'efectivo') continue;
    if (m.type === 'ingreso') ingresos += Number(m.amount) || 0;
    else if (m.type === 'egreso') egresos += Number(m.amount) || 0;
  }
  // Devoluciones (notas de crédito) de esta caja: el efectivo devuelto sale del cajón
  let devoluciones = 0, returnsTotal = 0, returnsCount = 0;
  for (const r of returns) {
    if (!r || r.deleted) continue;
    returnsCount++;
    returnsTotal += Number(r.total) || 0;
    for (const p of r.refunds || []) if (p.method === 'efectivo') devoluciones += Number(p.amount) || 0;
  }
  const expected = round2(Number(opening) + cashSales + ingresos - egresos - devoluciones);
  const out = {
    opening: round2(opening), cashSales: round2(cashSales), salesTotal: round2(salesTotal), count,
    byMethod, ingresos: round2(ingresos), egresos: round2(egresos), expected,
    devoluciones: round2(devoluciones), returnsTotal: round2(returnsTotal), returnsCount,
    counted: null, difference: null,
  };
  if (counted !== null && counted !== undefined && counted !== '' && isFinite(Number(counted))) {
    out.counted = round2(counted);
    out.difference = round2(out.counted - expected);
  }
  return out;
}

// ---------- Reportes ----------

/**
 * Resume ventas OK en un rango. costOf(product_id) devuelve el costo actual (para ganancia estimada).
 * returns: devoluciones / notas de crédito (se cuentan por su fecha y RESTAN: total, IVA, medios de pago,
 * cantidades y ganancia). total = gross (vendido) − returns (devuelto); avg = gross / count.
 */
export function salesReport(sales, { from = -Infinity, to = Infinity, costOf = () => 0, returns = [] } = {}) {
  const r = { total: 0, count: 0, avg: 0, byMethod: {}, top: [], profit: 0, costKnown: true, iva: 0, net: 0, gross: 0, returns: 0, returnsCount: 0 };
  const prods = {};
  for (const s of sales) {
    if (s.deleted || s.test || s.status !== 'ok' || s.created_at < from || s.created_at > to) continue;
    r.count++;
    r.total += Number(s.total) || 0;
    r.iva += Number(s.iva) || 0;
    r.net += Number(s.net) || 0;
    for (const p of s.payments || []) r.byMethod[p.method] = round2((r.byMethod[p.method] || 0) + Number(p.amount || 0));
    for (const it of s.items || []) {
      const key = it.product_id || 'libre:' + it.name;
      prods[key] = prods[key] || { product_id: it.product_id, name: it.name, qty: 0, total: 0 };
      prods[key].qty = round3(prods[key].qty + Number(it.qty));
      prods[key].total = round2(prods[key].total + Number(it.subtotal));
      const cost = it.product_id ? Number(costOf(it.product_id)) || 0 : 0;
      if (!cost) r.costKnown = false;
      r.profit += Number(it.subtotal) - cost * Number(it.qty);
    }
  }
  r.gross = round2(r.total);
  for (const d of returns) {
    if (!d || d.deleted || d.test || d.created_at < from || d.created_at > to) continue;
    r.returnsCount++;
    r.returns += Number(d.total) || 0;
    r.iva -= Number(d.iva) || 0;
    r.net -= Number(d.net) || 0;
    for (const p of d.refunds || []) r.byMethod[p.method] = round2((r.byMethod[p.method] || 0) - Number(p.amount || 0));
    for (const it of d.items || []) {
      const key = it.product_id || 'libre:' + it.name;
      prods[key] = prods[key] || { product_id: it.product_id, name: it.name, qty: 0, total: 0 };
      prods[key].qty = round3(prods[key].qty - Number(it.qty));
      prods[key].total = round2(prods[key].total - Number(it.subtotal));
      const cost = it.product_id ? Number(costOf(it.product_id)) || 0 : 0;
      r.profit -= Number(it.subtotal) - cost * Number(it.qty);
    }
  }
  for (const [k, v] of Object.entries(r.byMethod)) if (Math.abs(v) < 0.005) delete r.byMethod[k];
  r.returns = round2(r.returns);
  r.total = round2(r.gross - r.returns);
  r.iva = round2(r.iva);
  r.net = round2(r.net);
  r.profit = round2(r.profit);
  r.avg = r.count ? round2(r.gross / r.count) : 0;
  r.top = Object.values(prods).filter(p => p.qty > 0 || p.total > 0).sort((a, b) => b.total - a.total).slice(0, 10);
  return r;
}

// ---------- Sucursales y stock por sucursal ----------

/** Id fijo de la sucursal que se crea sola (dos equipos que la crean a la vez generan el mismo registro). */
export const MAIN_BRANCH_ID = 'main';

/**
 * Orden de las sucursales: la principal primero, después por punto de venta y nombre.
 * La primera de la lista es la "principal" (a la que se le asigna el stock de productos viejos).
 */
export function sortBranches(list) {
  return [...list].sort((a, b) => (a.id === MAIN_BRANCH_ID ? -1 : b.id === MAIN_BRANCH_ID ? 1 : 0)
    || (Number(a.pos_number) || 0) - (Number(b.pos_number) || 0)
    || String(a.name || '').localeCompare(String(b.name || ''), 'es'));
}

/** Suma de un objeto {branch_id: cantidad} */
export function stocksTotal(stocks) {
  let t = 0;
  for (const v of Object.values(stocks || {})) t += Number(v) || 0;
  return round3(t);
}

/**
 * Stock por sucursal de un producto como objeto nuevo {branch_id: cantidad}.
 * Compatibilidad: si el producto no tiene `stocks`, todo su `stock` es de la sucursal principal (mainId).
 */
export function productStocks(product, mainId = MAIN_BRANCH_ID) {
  const p = product || {};
  if (p.stocks && typeof p.stocks === 'object' && !Array.isArray(p.stocks)) {
    const out = {};
    for (const [k, v] of Object.entries(p.stocks)) { const n = round3(v); if (n !== 0) out[k] = n; }
    return out;
  }
  const s = round3(p.stock);
  return s !== 0 && mainId ? { [mainId]: s } : {};
}

/** Stock de un producto en una sucursal (mainId: sucursal principal, para productos sin `stocks`). */
export function stockIn(product, branchId, mainId = MAIN_BRANCH_ID) {
  return productStocks(product, mainId)[branchId] || 0;
}

/**
 * Suma (o resta) stock en una sucursal. Devuelve {stocks, stock} nuevos (stock = total de todas).
 * No modifica el producto recibido.
 */
export function applyStockDelta(product, branchId, delta, mainId = MAIN_BRANCH_ID) {
  const stocks = productStocks(product, mainId);
  stocks[branchId] = round3((stocks[branchId] || 0) + (Number(delta) || 0));
  return { stocks, stock: stocksTotal(stocks) };
}

/** Deja el stock de una sucursal en un valor exacto (recuento o importación). Devuelve {stocks, stock}. */
export function setStockIn(product, branchId, qty, mainId = MAIN_BRANCH_ID) {
  return applyStockDelta(product, branchId, round3(qty) - stockIn(product, branchId, mainId), mainId);
}

/** Sucursal de un registro (venta, caja, compra…). Los registros viejos sin branch_id son de la principal. */
export function branchOf(rec, mainId = MAIN_BRANCH_ID) {
  return (rec && rec.branch_id) || mainId;
}

/** Margen: ganancia por unidad y porcentaje sobre costo */
export function margin(price, cost) {
  const p = Number(price) || 0, c = Number(cost) || 0;
  const gain = round2(p - c);
  return { gain, pct: c > 0 ? round2((gain / c) * 100) : null };
}

// ---------- Importador de productos ----------

const HEADER_ALIASES = {
  name: ['nombre', 'name', 'nom', 'producto', 'descripcion', 'articulo', 'detalle', 'descrip'],
  price: ['precio', 'price', 'pre', 'precio venta', 'precio de venta', 'pvp', 'precio final', 'venta', 'publico', 'precio publico', 'publico por 0', 'p publico'],
  cost: ['costo', 'cost', 'precio costo', 'precio de costo', 'compra'],
  stock: ['stock', 'sto', 'cantidad', 'existencia', 'cant'],
  stock_min: ['stock minimo', 'stomin', 'minimo', 'stock_min', 'stock min'],
  code: ['codigo', 'cod', 'code', 'barcode', 'ean', 'codigo de barras', 'sku', 'cod barras', 'codart'],
  category: ['categoria', 'cat', 'rubro', 'rubros', 'category', 'familia', 'nbrerubro'],
  iva_rate: ['iva', 'alicuota', 'iva_rate', 'tasa iva'],
  unit: ['unidad', 'unit', 'medida'],
  supplier: ['proveedor', 'prov', 'supplier'],
};

/** Mapea un encabezado cualquiera ("Código de barras", "PRECIO") a un campo interno */
export function mapHeader(h) {
  const n = norm(h).replace(/[_.\-]+/g, ' ').replace(/\s+/g, ' ');
  for (const [field, aliases] of Object.entries(HEADER_ALIASES)) {
    if (aliases.includes(n)) return field;
  }
  return null;
}

/** Parser CSV simple con comillas; detecta ; , o tabulador como separador. Devuelve array de arrays. */
export function parseCSV(text) {
  const src = String(text || '').replace(/^﻿/, '');
  const first = src.split(/\r?\n/)[0] || '';
  const counts = { ';': (first.match(/;/g) || []).length, ',': (first.match(/,/g) || []).length, '\t': (first.match(/\t/g) || []).length };
  const sep = Object.entries(counts).sort((a, b) => b[1] - a[1])[0][1] > 0 ? Object.entries(counts).sort((a, b) => b[1] - a[1])[0][0] : ',';
  const rows = [];
  let row = [], field = '', q = false;
  for (let i = 0; i < src.length; i++) {
    const c = src[i];
    if (q) {
      if (c === '"') { if (src[i + 1] === '"') { field += '"'; i++; } else q = false; }
      else field += c;
    } else if (c === '"') q = true;
    else if (c === sep) { row.push(field); field = ''; }
    else if (c === '\n' || c === '\r') {
      if (c === '\r' && src[i + 1] === '\n') i++;
      row.push(field); field = '';
      if (row.some(x => x.trim() !== '')) rows.push(row);
      row = [];
    } else field += c;
  }
  row.push(field);
  if (row.some(x => x.trim() !== '')) rows.push(row);
  return rows;
}

/** Convierte una tabla (primera fila = encabezados) en objetos {campoInterno: valor} */
export function tableToObjects(rows) {
  if (!rows.length) return [];
  const headers = rows[0].map(mapHeader);
  return rows.slice(1).map(r => {
    const o = {};
    headers.forEach((f, i) => { if (f && r[i] !== undefined && o[f] === undefined) o[f] = r[i]; });
    return o;
  });
}

function guessUnit(name, unitRaw) {
  const u = norm(unitRaw);
  if (u === 'kg' || u === 'kilo' || u === 'kilos' || u === 'por kilo') return 'kg';
  if (u === 'u' || u === 'un' || u === 'unidad') return 'u';
  return /\bx\s?kg\b|\bpor kilo\b|\(kg\)|\bxkg\b/i.test(String(name)) ? 'kg' : 'u';
}

function num0(v) {
  const n = parseNum(v);
  return isFinite(n) ? n : 0;
}

/**
 * Normaliza filas de importación a productos del contrato (sin id/updated_at).
 * Acepta el formato viejo (nom, cat, pre, costo, sto, stomin, cod, prov) y
 * filas de Excel/CSV ya mapeadas con tableToObjects (name, price, stock, code, ...).
 * Devuelve { products: [...], skipped: n, errors: [texto] }.
 * Cada producto trae `_supplier_name` si venía proveedor (lo resuelve quien guarda).
 */
export function normalizeImportRows(rows) {
  const products = [];
  const errors = [];
  let skipped = 0;
  (rows || []).forEach((r, i) => {
    if (!r || typeof r !== 'object') { skipped++; return; }
    const isOld = 'nom' in r || 'pre' in r;
    const name = String((isOld ? r.nom : r.name) ?? '').trim();
    if (!name) { skipped++; return; }
    const price = num0(isOld ? r.pre : r.price);
    if (price < 0) { errors.push(`Fila ${i + 2}: precio inválido en "${name}"`); skipped++; return; }
    const code = String((isOld ? r.cod : r.code) ?? '').trim();
    const isBarcode = /^\d{6,14}$/.test(code);
    let iva = r.iva_rate !== undefined && r.iva_rate !== '' ? num0(String(r.iva_rate).replace('%', '')) : 21;
    if (!IVA_RATES.includes(iva)) iva = 21;
    products.push({
      name: name.slice(0, 200),
      category: String((isOld ? r.cat : r.category) ?? '').trim() || 'General',
      barcode: isBarcode ? code : '',
      sku: isBarcode ? '' : code,
      price: round2(price),
      cost: round2(num0(isOld ? r.costo : r.cost)),
      iva_rate: iva,
      stock: round3(num0(isOld ? r.sto : r.stock)),
      stock_min: round3(num0(isOld ? r.stomin : r.stock_min)),
      unit: guessUnit(name, r.unit),
      supplier_id: '',
      active: 1,
      _supplier_name: String((isOld ? r.prov : r.supplier) ?? '').trim(),
      // Qué columnas traía el archivo: al actualizar solo se cambia lo que vino (no se pisa stock ni costo con 0)
      _has: isOld ? { price: 'pre' in r, cost: 'costo' in r, stock: 'sto' in r, stock_min: 'stomin' in r, category: 'cat' in r } : { price: 'price' in r, cost: 'cost' in r, stock: 'stock' in r, stock_min: 'stock_min' in r, category: 'category' in r },
    });
  });
  return { products, skipped, errors };
}

/** Clave para detectar duplicados al importar: código de barras, sku o nombre normalizado */
export function productKey(p) {
  if (p.barcode) return 'b:' + p.barcode;
  if (p.sku) return 's:' + norm(p.sku);
  return 'n:' + norm(p.name);
}

/** Busca productos por texto (todas las palabras) o código exacto/prefijo. */
// Nombre y código interno ya normalizados de cada producto (se calcula una vez por versión del registro:
// cada cambio guarda un objeto nuevo, y si el nombre o el código cambian igual se recalcula). Así buscar en
// miles de productos no vuelve a sacar acentos de todos los nombres en cada tecla.
const normMemo = new WeakMap();
function normOf(p) {
  let m = normMemo.get(p);
  if (!m || m.name !== p.name || m.sku !== p.sku) {
    m = { name: p.name, sku: p.sku, n: norm(p.name), s: p.sku ? norm(p.sku) : '' };
    normMemo.set(p, m);
  }
  return m;
}

/** Precalcula los nombres normalizados (se llama cuando la pantalla queda libre: la primera tecla ya es rápida) */
export function warmSearch(products) { for (const p of products) normOf(p); }

export function searchProducts(products, query, limit = 40) {
  const q = norm(query);
  if (!q) return [];
  const raw = String(query).trim();
  const words = q.split(/\s+/).filter(Boolean);
  const exact = [], starts = [], rest = [];
  for (const p of products) {
    if (p.deleted || p.active === 0) continue;
    const k = normOf(p);
    if ((p.barcode && p.barcode === raw) || (k.s && k.s === q)) { exact.push(p); continue; }
    const n = k.n;
    if (words.every(w => n.includes(w))) (n.startsWith(words[0]) ? starts : rest).push(p);
    else if (q.length >= 3 && ((p.barcode && p.barcode.startsWith(q)) || (k.s && k.s.startsWith(q)))) rest.push(p);
  }
  return exact.concat(starts, rest).slice(0, limit);
}

/** Producto que coincide exactamente con un código escaneado */
export function findByCode(products, code) {
  const c = String(code || '').trim();
  if (!c) return null;
  const nc = norm(c);
  return products.find(p => !p.deleted && p.active !== 0 && (p.barcode === c || (p.sku && normOf(p).s === nc))) || null;
}

// ---------- Ticket / WhatsApp ----------

/** Texto plano de la venta para mandar por WhatsApp */
export function saleText(sale, settings = {}, customerName = '') {
  const L = [];
  L.push(`*${settings.business_name || 'Comercio'}*`);
  const d = sale.doc || {};
  if (d.kind === 'factura' && d.status === 'autorizado') {
    L.push(`${cbteNombre(d.cbte_tipo)} N° ${fmtCbteNro(d.pto_vta, d.cbte_nro)}`);
    L.push(`CAE ${d.cae} — vto ${d.cae_vto}`);
  } else {
    L.push(`Venta N° ${sale.number} (comprobante no fiscal)`);
  }
  L.push(fmtDateTime(sale.created_at));
  if (customerName) L.push(`Cliente: ${customerName}`);
  L.push('');
  for (const it of sale.items) L.push(`${fmtQty(it.qty)} x ${it.name} — ${fmtMoney(it.subtotal)}`);
  if (sale.discount > 0) L.push(`Descuento: -${fmtMoney(sale.discount)}`);
  L.push(`*TOTAL: ${fmtMoney(sale.total)}*`);
  if (Number(sale.surcharge) > 0) L.push(`Intereses tarjeta: ${fmtMoney(sale.surcharge)}`);
  for (const p of sale.payments || []) L.push(`${p.card_name ? p.card_name + ' ' : ''}${payLabel(p.method)}: ${fmtMoney(p.tendered ?? p.amount)}${Number(p.installments) > 1 ? ` (${p.installments} cuotas de ${fmtMoney(p.installment_amount)})` : ''}`);
  if (sale.observations) L.push(`Obs.: ${sale.observations}`);
  if (sale.change > 0) L.push(`Vuelto: ${fmtMoney(sale.change)}`);
  if (settings.ticket_footer) { L.push(''); L.push(settings.ticket_footer); }
  return L.join('\n');
}

/** Link wa.me. Si hay teléfono argentino lo normaliza a 549 + número. */
export function waLink(text, phone = '') {
  let p = String(phone || '').replace(/\D/g, '');
  if (p) {
    if (p.startsWith('0')) p = p.slice(1);
    if (!p.startsWith('54')) p = '549' + p;
    else if (!p.startsWith('549')) p = '549' + p.slice(2);
  }
  return `https://wa.me/${p}?text=${encodeURIComponent(text)}`;
}

/** URL del QR de ARCA (RG 4892) para facturas autorizadas */
export function arcaQrUrl(sale, settings, customer) {
  const d = sale.doc || {};
  const payload = {
    ver: 1,
    fecha: toISODate(sale.created_at),
    cuit: Number(String(settings.cuit || '').replace(/\D/g, '')),
    ptoVta: Number(d.pto_vta),
    tipoCmp: Number(d.cbte_tipo),
    nroCmp: Number(d.cbte_nro),
    importe: round2(sale.total),
    moneda: 'PES',
    ctz: 1,
    tipoDocRec: customer && customer.doc_type === 'CUIT' ? 80 : customer && customer.doc_type === 'DNI' ? 96 : 99,
    nroDocRec: customer && customer.doc_number ? Number(String(customer.doc_number).replace(/\D/g, '')) : 0,
    tipoCodAut: 'E',
    codAut: Number(d.cae),
  };
  const json = JSON.stringify(payload);
  const b64 = typeof btoa === 'function' ? btoa(json) : Buffer.from(json).toString('base64');
  return 'https://www.afip.gob.ar/fe/qr/?p=' + b64;
}

// ---------- Validaciones ----------

/** Valida CUIT/CUIL con dígito verificador */
export function validCuit(cuit) {
  const c = String(cuit || '').replace(/\D/g, '');
  if (c.length !== 11) return false;
  const w = [5, 4, 3, 2, 7, 6, 5, 4, 3, 2];
  const sum = w.reduce((a, x, i) => a + x * Number(c[i]), 0);
  let dv = 11 - (sum % 11);
  if (dv === 11) dv = 0;
  if (dv === 10) dv = 9;
  return dv === Number(c[10]);
}

/** PIN de 4 a 8 números */
export function validPin(pin) { return /^\d{4,8}$/.test(String(pin || '')); }
/** Mínimo de números del PIN al cargarlo o cambiarlo: dueño y encargado 6, el resto 4 (igual que la nube) */
export function pinMin(role) { return role === 'dueno' || role === 'encargado' ? 6 : 4; }

// ---------- Identificadores y hash ----------

/** UUID v4 (usa crypto.getRandomValues, disponible también fuera de HTTPS) */
export function uuid() {
  const c = globalThis.crypto;
  if (c && typeof c.randomUUID === 'function') {
    try { return c.randomUUID(); } catch (e) { /* contexto no seguro: seguimos abajo */ }
  }
  const b = new Uint8Array(16);
  if (c && c.getRandomValues) c.getRandomValues(b);
  else for (let i = 0; i < 16; i++) b[i] = Math.floor(Math.random() * 256);
  b[6] = (b[6] & 0x0f) | 0x40;
  b[8] = (b[8] & 0x3f) | 0x80;
  const h = [...b].map(x => x.toString(16).padStart(2, '0')).join('');
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`;
}

/** SHA-256 en JS puro (funciona aunque crypto.subtle no esté disponible). Devuelve hex. */
export function sha256(str) {
  const K = [0x428a2f98, 0x71374491, 0xb5c0fbcf, 0xe9b5dba5, 0x3956c25b, 0x59f111f1, 0x923f82a4, 0xab1c5ed5,
    0xd807aa98, 0x12835b01, 0x243185be, 0x550c7dc3, 0x72be5d74, 0x80deb1fe, 0x9bdc06a7, 0xc19bf174,
    0xe49b69c1, 0xefbe4786, 0x0fc19dc6, 0x240ca1cc, 0x2de92c6f, 0x4a7484aa, 0x5cb0a9dc, 0x76f988da,
    0x983e5152, 0xa831c66d, 0xb00327c8, 0xbf597fc7, 0xc6e00bf3, 0xd5a79147, 0x06ca6351, 0x14292967,
    0x27b70a85, 0x2e1b2138, 0x4d2c6dfc, 0x53380d13, 0x650a7354, 0x766a0abb, 0x81c2c92e, 0x92722c85,
    0xa2bfe8a1, 0xa81a664b, 0xc24b8b70, 0xc76c51a3, 0xd192e819, 0xd6990624, 0xf40e3585, 0x106aa070,
    0x19a4c116, 0x1e376c08, 0x2748774c, 0x34b0bcb5, 0x391c0cb3, 0x4ed8aa4a, 0x5b9cca4f, 0x682e6ff3,
    0x748f82ee, 0x78a5636f, 0x84c87814, 0x8cc70208, 0x90befffa, 0xa4506ceb, 0xbef9a3f7, 0xc67178f2];
  const bytes = new TextEncoder().encode(str);
  const l = bytes.length;
  const withPad = new Uint8Array(((l + 9 + 63) >> 6) << 6);
  withPad.set(bytes);
  withPad[l] = 0x80;
  const bits = l * 8;
  const dv = new DataView(withPad.buffer);
  dv.setUint32(withPad.length - 4, bits >>> 0);
  dv.setUint32(withPad.length - 8, Math.floor(bits / 0x100000000));
  const H = [0x6a09e667, 0xbb67ae85, 0x3c6ef372, 0xa54ff53a, 0x510e527f, 0x9b05688c, 0x1f83d9ab, 0x5be0cd19];
  const W = new Uint32Array(64);
  const rotr = (x, n) => (x >>> n) | (x << (32 - n));
  for (let o = 0; o < withPad.length; o += 64) {
    for (let i = 0; i < 16; i++) W[i] = dv.getUint32(o + i * 4);
    for (let i = 16; i < 64; i++) {
      const s0 = rotr(W[i - 15], 7) ^ rotr(W[i - 15], 18) ^ (W[i - 15] >>> 3);
      const s1 = rotr(W[i - 2], 17) ^ rotr(W[i - 2], 19) ^ (W[i - 2] >>> 10);
      W[i] = (W[i - 16] + s0 + W[i - 7] + s1) >>> 0;
    }
    let [a, b, c, d, e, f, g, h] = H;
    for (let i = 0; i < 64; i++) {
      const S1 = rotr(e, 6) ^ rotr(e, 11) ^ rotr(e, 25);
      const ch = (e & f) ^ (~e & g);
      const t1 = (h + S1 + ch + K[i] + W[i]) >>> 0;
      const S0 = rotr(a, 2) ^ rotr(a, 13) ^ rotr(a, 22);
      const maj = (a & b) ^ (a & c) ^ (b & c);
      const t2 = (S0 + maj) >>> 0;
      h = g; g = f; f = e; e = (d + t1) >>> 0; d = c; c = b; b = a; a = (t1 + t2) >>> 0;
    }
    H[0] = (H[0] + a) >>> 0; H[1] = (H[1] + b) >>> 0; H[2] = (H[2] + c) >>> 0; H[3] = (H[3] + d) >>> 0;
    H[4] = (H[4] + e) >>> 0; H[5] = (H[5] + f) >>> 0; H[6] = (H[6] + g) >>> 0; H[7] = (H[7] + h) >>> 0;
  }
  return H.map(x => x.toString(16).padStart(8, '0')).join('');
}

/** Hash del PIN: depende del id del usuario para que dos usuarios con el mismo PIN no tengan el mismo hash */
export function pinHash(userId, pin) {
  return sha256(`jeano-gestion:${userId}:${pin}`);
}

/** Roles y permisos */
export const ROLES = { dueno: 'Dueño', encargado: 'Encargado', cajero: 'Cajero', vendedor: 'Vendedor' };

/**
 * Lo que es SOLO del dueño: no se puede delegar con permisos (usuarios y sus permisos, equipos, datos del comercio,
 * nube, certificado ARCA, auditoría, sucursales y "empezar de cero").
 */
export const OWNER_ONLY = ['usuarios', 'permisos', 'equipos', 'comercio', 'nube', 'certificado', 'auditoria', 'sucursales', 'reset'];

/**
 * Mapa de permisos que el dueño puede dar o sacar a encargados, cajeros y vendedores (Ajustes → Usuarios → Permisos).
 * roles: valor por defecto de cada rol (el dueño siempre puede todo). users.perms guarda SOLO las diferencias con su rol
 * ({permiso: true|false}, más descuento_max). El MISMO mapa está en server/src/perms.js (la nube lo aplica al sincronizar):
 * si se cambia uno, hay que cambiar el otro (lo controla server/test/permisos.test.js). Ver CONTRATO.md.
 */
const E = 'encargado', C = 'cajero', V = 'vendedor';
const all = { [E]: true, [C]: true, [V]: true }, mgr = { [E]: true, [C]: false, [V]: false };
export const PERM_GROUPS = [
  ['venta', 'Ventas'], ['caja', 'Caja'], ['compras', 'Compras y gastos'], ['productos', 'Productos y stock'], ['info', 'Información'], ['otros', 'Otros'],
];
export const PERMS = [
  { key: 'vender', group: 'venta', label: 'Vender', hint: 'Cargar ventas y cobrarlas.', roles: all },
  { key: 'descuentos', group: 'venta', label: 'Hacer descuentos y recargos sin autorización', hint: 'Hasta el % máximo de abajo; más que eso pide el PIN del dueño o del encargado.', roles: mgr },
  { key: 'precio_venta', group: 'venta', label: 'Cambiar el precio en una venta', hint: 'Sin esto, cambiar el precio de un renglón pide autorización.', roles: mgr },
  { key: 'anular', group: 'venta', label: 'Anular ventas', hint: 'También borrar cobros de clientes. Sin esto, pide autorización.', roles: mgr },
  { key: 'devolver', group: 'venta', label: 'Devoluciones y notas de crédito o débito', hint: 'Sin esto, pide autorización.', roles: mgr },
  { key: 'cobrar_cc', group: 'venta', label: 'Cobrar cuentas corrientes de clientes', hint: 'Registrar cobros de lo que deben los clientes.', roles: all },
  { key: 'caja', group: 'caja', label: 'Abrir y cerrar la caja', hint: 'Sin esto, otro tiene que abrir la caja para que pueda vender.', roles: all },
  { key: 'ver_esperado', group: 'caja', label: 'Ver lo esperado en la caja', hint: 'Sin esto, el cierre es a ciegas (cuenta los billetes sin ver cuánto debería haber).', roles: mgr },
  { key: 'reabrir_caja', group: 'caja', label: 'Reabrir cajas y cambiar movimientos ya cargados', hint: 'Sin esto, pide autorización.', roles: mgr },
  { key: 'gastos', group: 'compras', label: 'Cargar gastos que salen de la caja', hint: '', roles: all },
  { key: 'cargar_compras', group: 'compras', label: 'Cargar compras (facturas de proveedores)', hint: 'Solo cargar: sin cheques, sin anular y sin ver saldos.', roles: all },
  { key: 'compras', group: 'compras', label: 'Compras completas, proveedores y pagos', hint: 'Anular compras, proveedores, saldos, pagos, Libro IVA, pedidos, cheques y gastos de todo tipo.', roles: mgr },
  { key: 'editar_productos', group: 'productos', label: 'Editar productos y precios', hint: 'También promociones, rubros, etiquetas y vencimientos.', roles: mgr },
  { key: 'ajustar_stock', group: 'productos', label: 'Ajustar stock y contar en góndola', hint: 'Sin esto, ajustar el stock pide autorización.', roles: mgr },
  { key: 'fotos', group: 'productos', label: 'Fotos de productos', hint: '', roles: mgr },
  { key: 'remitos', group: 'productos', label: 'Mandar y anular remitos entre sucursales', hint: 'Recibir un remito lo puede hacer cualquiera.', roles: mgr },
  { key: 'ver_costos', group: 'info', label: 'Ver costos', hint: '', roles: mgr },
  { key: 'reportes', group: 'info', label: 'Reportes, informes, tesorería y comisiones', hint: '', roles: mgr },
  { key: 'tablero', group: 'info', label: 'Tablero "Hoy"', hint: '', roles: mgr },
  { key: 'cambiar_sucursal', group: 'otros', label: 'Cambiar la sucursal del equipo', hint: '', roles: mgr },
  { key: 'ajustes', group: 'otros', label: 'Entrar a Ajustes', hint: 'Copias, impresora y sucursal del equipo (lo del comercio y los usuarios es solo del dueño).', roles: mgr },
];
export const PERM_INDEX = Object.fromEntries(PERMS.map(p => [p.key, p]));

/**
 * Permisos "sensibles": quien los tiene (dueño, encargado, o a quien el dueño se los dio) entra SOLO validando el PIN en
 * la nube y los equipos no guardan su verificador. Mismo criterio en server/src/perms.js (isSensitive).
 */
export const SENSITIVE = ['anular', 'devolver', 'editar_productos', 'compras', 'ver_esperado', 'ajustes', 'cambiar_sucursal'];
export function isSensitive(user) {
  if (!user) return false;
  if (user.role === 'dueno' || user.role === 'encargado') return true;
  return SENSITIVE.some(k => can(user, k));
}

/** Valor de un permiso según el rol (sin cambios del dueño) */
export function roleCan(role, what) {
  const r = role || 'cajero';
  if (r === 'dueno') return true;
  if (OWNER_ONLY.includes(what)) return false;
  const p = PERM_INDEX[what];
  return p ? !!p.roles[r] : true; // lo que no es un permiso lo puede hacer cualquiera
}

/**
 * ¿El usuario puede hacer `what`? user = {role, perms} (o el rol como texto, con los valores de su rol).
 * Primero mira los cambios que hizo el dueño para ese usuario (users.perms), después lo de su rol.
 */
export function can(user, what) {
  if (typeof user === 'string' || !user) return roleCan(user, what);
  const r = user.role || 'cajero';
  if (r === 'dueno') return true;
  if (OWNER_ONLY.includes(what)) return false;
  const pm = user.perms;
  if (pm && typeof pm[what] === 'boolean' && PERM_INDEX[what]) return pm[what];
  return roleCan(r, what);
}

/** % de descuento (o recargo) máximo que puede hacer sin autorización: 0 si no tiene "descuentos" */
export function discountMax(user) {
  if (!can(user, 'descuentos')) return 0;
  const r = typeof user === 'object' && user ? user.role : user;
  if (r === 'dueno') return 100;
  const m = user && user.perms && Number(user.perms.descuento_max);
  return Number.isFinite(m) && m >= 0 && m <= 100 ? m : 100;
}

/**
 * Deja en perms solo lo que cambia respecto del rol (y descuento_max si tiene descuentos y no es 100).
 * wanted: {permiso: true|false, descuento_max}. Devuelve un objeto (vacío = "los de su rol").
 */
export function permsDiff(role, wanted = {}) {
  const out = {};
  if (role === 'dueno') return out;
  for (const p of PERMS) {
    if (typeof wanted[p.key] !== 'boolean') continue;
    if (wanted[p.key] !== roleCan(role, p.key)) out[p.key] = wanted[p.key];
  }
  const allowed = typeof wanted.descuentos === 'boolean' ? wanted.descuentos : roleCan(role, 'descuentos');
  const m = Number(wanted.descuento_max);
  if (allowed && Number.isFinite(m) && m >= 0 && m < 100) out.descuento_max = Math.round(m * 100) / 100;
  return out;
}

/** Cambios de permisos para la auditoría: [{perm, label, from, to}] (from/to = efectivo antes y después) */
export function permsChanges(role, before = {}, after = {}) {
  const u0 = { role, perms: before || {} }, u1 = { role, perms: after || {} };
  const out = PERMS.filter(p => can(u0, p.key) !== can(u1, p.key)).map(p => ({ perm: p.key, label: p.label, from: can(u0, p.key), to: can(u1, p.key) }));
  if (discountMax(u0) !== discountMax(u1) && can(u1, 'descuentos')) out.push({ perm: 'descuento_max', label: '% máximo de descuento', from: discountMax(u0), to: discountMax(u1) });
  return out;
}


// ---------- Conteo de stock (góndola) ----------

/**
 * Cantidad contada de un producto después de una lectura.
 * mode 'replace': lo último que se contó reemplaza lo anterior de esta sesión.
 * mode 'add': se suma a lo ya contado EN ESTA SESIÓN (mismo producto en dos lugares de la góndola);
 * nunca se suma al stock viejo del sistema.
 */
export function countMerge(prevCounted, qty, mode) {
  const q = round3(Number(qty));
  if (mode === 'add' && prevCounted !== null && prevCounted !== undefined) return round3(Number(prevCounted) + q);
  return q;
}

/**
 * Resumen de un conteo. lines: [{counted, system, cost}] (system = stock de la sucursal ahora).
 * Devuelve {counted, faltantes, sobrantes, iguales, value (diferencia valorizada a costo), lines (con diff)}.
 */
export function countSummary(lines) {
  let faltantes = 0, sobrantes = 0, iguales = 0, value = 0;
  const out = lines.map(l => {
    const diff = round3(Number(l.counted) - Number(l.system || 0));
    if (diff < 0) faltantes++; else if (diff > 0) sobrantes++; else iguales++;
    value += diff * (Number(l.cost) || 0);
    return { ...l, diff };
  });
  return { counted: lines.length, faltantes, sobrantes, iguales, value: round2(value), lines: out };
}

// ---------- Copia de seguridad del sistema anterior (gestion.html) ----------

/**
 * Convierte la copia del sistema anterior ({_meta, db}) en datos del comercio y usuarios.
 * Nunca copia contraseñas: cada usuario crea su PIN la primera vez que entra.
 */
export function legacyBackupToSetup(data) {
  const db = (data && data.db) || {};
  const cfg = db.config || {};
  const fc = db.factConfig || {};
  const ivaTxt = norm(fc.iva || '');
  const iva = ivaTxt.includes('inscripto') ? 'RI' : ivaTxt.includes('exento') ? 'EX' : ivaTxt.includes('monotrib') ? 'MT' : '';
  const m = String(fc.inicio || '').match(/^(\d{1,2})\/(\d{4})$/);
  const settings = {};
  const put = (k, v) => { if (v !== undefined && v !== null && String(v).trim() !== '') settings[k] = String(v).trim(); };
  put('business_name', fc.fantasia ? titleCase(fc.fantasia) : cfg.nombre);
  put('legal_name', fc.razon);
  put('cuit', String(fc.cuit || (data._meta && data._meta.cuit) || '').replace(/\D/g, ''));
  if (iva) settings.iva_condition = iva;
  put('address', fc.domicilio || cfg.dir);
  put('phone', cfg.tel);
  if (m) settings.start_date = `${m[2]}-${m[1].padStart(2, '0')}-01`;
  put('ticket_footer', fc.leyenda);
  const users = Object.entries(db.usuarios || {})
    .filter(([, u]) => u && u.rol !== 'admin' && u.activa !== false)
    .map(([login, u]) => ({ name: String(u.nombre || login).trim(), role: u.rol === 'encargado' ? 'encargado' : 'cajero' }));
  const counts = {};
  for (const k of ['facturas', 'compras', 'gastos', 'cierresCaja', 'proveedores', 'ajustes']) counts[k] = Array.isArray(db[k]) ? db[k].length : 0;
  return { settings, users, counts, legacyPos: fc.pv ? Number(String(fc.pv).replace(/\D/g, '')) : null };
}

function titleCase(t) {
  return String(t).toLowerCase().replace(/(^|\s)\S/g, c => c.toUpperCase());
}

// ---------- Empezar de cero (fin de la prueba en paralelo con el sistema anterior) ----------

/** Movimientos que se borran al empezar de cero (los maestros —productos, clientes, proveedores, usuarios, sucursales, ajustes— quedan) */
export const RESET_COLLECTIONS = ['sales', 'cash_sessions', 'cash_movements', 'purchases', 'stock_moves', 'returns', 'transfers', 'customer_payments', 'supplier_payments',
  'expenses', 'cheques', 'quotes', 'orders', 'supplier_orders', 'purchase_docs'];

/** ¿La venta (o la nota de crédito de una devolución) tiene CAE de ARCA? (comprobante fiscal: legalmente no se puede borrar) */
export function hasCae(sale) {
  const d = (sale && sale.doc) || {};
  return (d.kind === 'factura' || d.kind === 'nota_credito') && !!String(d.cae || '').trim();
}

/**
 * Arma los cambios de "empezar de cero" sobre los registros vivos.
 * data: {sales, cash_sessions, cash_movements, purchases, stock_moves, customers, products}
 * Devuelve {ops: [{coll, rec}], counts: {coll: n}, keptInvoices, customers, products}.
 * Las ventas con CAE no se borran: quedan con test=1 (no suman en reportes).
 */
export function planReset(data, { zeroStock = false } = {}) {
  const ops = [];
  const counts = {};
  let keptInvoices = 0;
  for (const coll of RESET_COLLECTIONS) {
    counts[coll] = 0;
    for (const r of data[coll] || []) {
      if (!r || r.deleted) continue;
      // El saldo inicial de un proveedor (traído del sistema anterior) no es de la prueba: queda
      if (coll === 'supplier_payments' && r.kind === 'saldo_inicial') continue;
      if ((coll === 'sales' || coll === 'returns') && hasCae(r)) {
        keptInvoices++;
        if (!r.test) ops.push({ coll, rec: { id: r.id, test: 1 } });
        continue;
      }
      counts[coll]++;
      ops.push({ coll, rec: { id: r.id, deleted: 1 } });
    }
  }
  let customers = 0;
  for (const c of data.customers || []) {
    if (c.deleted || !(Number(c.balance) || 0)) continue;
    customers++;
    ops.push({ coll: 'customers', rec: { id: c.id, balance: 0 } });
  }
  // Proveedores: el saldo queda en la suma de sus saldos iniciales (0 si no tienen)
  const initial = {};
  for (const sp of data.supplier_payments || []) {
    if (sp && !sp.deleted && sp.kind === 'saldo_inicial') initial[sp.supplier_id] = (initial[sp.supplier_id] || 0) + Math.round(round2(sp.amount) * 100);
  }
  let suppliers = 0;
  for (const s of data.suppliers || []) {
    if (!s || s.deleted) continue;
    const want = round2((initial[s.id] || 0) / 100);
    if (round2(s.balance || 0) === want) continue;
    suppliers++;
    ops.push({ coll: 'suppliers', rec: { id: s.id, balance: want } });
  }
  let products = 0;
  if (zeroStock) {
    for (const p of data.products || []) {
      if (p.deleted) continue;
      const emptyStocks = p.stocks && typeof p.stocks === 'object' && !Array.isArray(p.stocks) && !Object.keys(p.stocks).length;
      if (!(Number(p.stock) || 0) && emptyStocks) continue;
      products++;
      ops.push({ coll: 'products', rec: { id: p.id, stock: 0, stocks: {} } });
    }
  }
  return { ops, counts, keptInvoices, customers, products, suppliers };
}

// ---------- Copias de seguridad ----------

export const BACKUP_KEEP = 30;
export const BACKUP_FILE_RE = /^jeano-gestion-(\d{4}-\d{2}-\d{2})\.json$/;

/** Nombre del archivo de la copia diaria: jeano-gestion-AAAA-MM-DD.json (fecha local) */
export function backupFileName(ms = Date.now()) { return `jeano-gestion-${toISODate(ms)}.json`; }

/** De los nombres de una carpeta, los de copias diarias que sobran (conserva las `keep` más nuevas) */
export function backupsToDelete(names, keep = BACKUP_KEEP) {
  const ours = [...new Set(names)].filter(n => BACKUP_FILE_RE.test(n)).sort().reverse();
  return ours.slice(keep);
}

/** ¿Toca hacer la copia diaria? lastDate: AAAA-MM-DD de la última copia automática */
export function dailyBackupDue(lastDate, now = Date.now()) {
  return !lastDate || String(lastDate) < toISODate(now);
}

/** Días enteros desde ms (Infinity si nunca) */
export function daysSince(ms, now = Date.now()) {
  if (!ms) return Infinity;
  return Math.floor((now - ms) / 86400000);
}

/**
 * ¿Mostrar el recordatorio de copia manual? Más de `days` días sin copia.
 * Si nunca se hizo, se cuenta desde que se empezó a usar la app en el equipo (since).
 */
export function backupReminderDue(lastBackup, since, now = Date.now(), days = 7) {
  const ref = lastBackup || since || now;
  return now - ref > days * 86400000;
}
