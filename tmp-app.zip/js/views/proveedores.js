// =====================================================================
// proveedores.js — Proveedores completos, cuenta corriente (pagos, saldo
// inicial de SGI, estado de cuenta), productos del proveedor y liquidación
// del período. Se muestra en Compras y proveedores (pestañas).
// =====================================================================
import * as db from '../db.js';
import { ctx, openSession, stockOf, userName } from '../ops.js';
import { html, $, ic, modal, toast, formData, fieldError, confirm, exportTable } from '../ui.js';
import { fmtMoney, fmtDate, fmtDateTime, norm, parseNum, round2, validCuit, toISODate, searchProducts, can, fmtQty, dayStart } from '../logic.js';
import {
  fromCents, toCents, supplierLedger, liquidacion, parseSgiBalance, SUPPLIER_METHODS, IVA_CONDITIONS, PROVINCES, isActive, methodLabel, purchaseDebt,
} from '../cuentas.js';
import { saveSupplier, paySupplier, takeSgiBalance, takeAllSgiBalances, pendingSgi, hasInitialBalance, supplierProducts, assignSupplier } from '../cuentas-ops.js';
import { mountStatement, printA4, printHead, rangeOf, periodText } from './ctacte.js';
import { walletPickerHTML, pickedCheques } from './cheque-ui.js';
import { photoThumb } from '../fotos.js';

const money = c => fmtMoney(fromCents(c));
const ivaLabel = v => (IVA_CONDITIONS.find(x => x[0] === v) || [, ''])[1];
const byName = (a, b) => String(a.name || '').localeCompare(String(b.name || ''), 'es');
const bal = s => round2((s && s.balance) || 0);
const view = { q: '', filter: 'activos' };

/** Texto del saldo: + le debemos, − a favor nuestro */
export function balanceText(v) {
  const b = round2(v);
  if (b > 0) return `Le debemos ${fmtMoney(b)}`;
  if (b < 0) return `A favor nuestro ${fmtMoney(-b)}`;
  return 'Sin saldo';
}

function ledgerOf(id) {
  return supplierLedger(id, { purchases: db.all('purchases'), payments: db.all('supplier_payments') });
}

// ---------- Lista ----------

export function mountSuppliers(box) {
  const paint = () => {
    const all = db.all('suppliers');
    const owed = all.filter(s => bal(s) > 0);
    const totalOwed = owed.reduce((a, s) => a + toCents(s.balance), 0);
    const favor = all.filter(s => bal(s) < 0).reduce((a, s) => a - toCents(s.balance), 0);
    const pend = pendingSgi();
    const q = norm(view.q);
    let list = all;
    if (view.filter === 'activos') list = list.filter(isActive);
    if (view.filter === 'inactivos') list = list.filter(s => s.active === 0);
    if (view.filter === 'saldo') list = list.filter(s => bal(s) !== 0);
    if (q) list = list.filter(s => norm([s.name, s.legal_name, s.cuit, s.city, s.contact, s.phone, s.email].filter(Boolean).join(' ')).includes(q));
    list.sort(view.filter === 'saldo' ? (a, b) => bal(b) - bal(a) || byName(a, b) : byName);
    const counts = new Map();
    for (const p of db.all('products')) if (p.supplier_id) counts.set(p.supplier_id, (counts.get(p.supplier_id) || 0) + 1);
    $('[data-pv-body]', box).innerHTML = String(html`
      <div class="stats">
        <div class="stat"><div class="k">Les debemos en total</div><div class="v money" id="pv-total" style="color:${totalOwed ? 'var(--danger)' : 'inherit'}">${money(totalOwed)}</div></div>
        <div class="stat"><div class="k">Proveedores con saldo</div><div class="v" id="pv-count">${owed.length}</div>${favor ? html`<div class="small muted">A favor nuestro: ${money(favor)}</div>` : ''}</div>
      </div>
      ${pend.length && can(ctx.user, 'compras') ? html`<div class="notice notice-info" id="pv-sgi"><p>${ic('download')} <b>${pend.length} ${pend.length === 1 ? 'proveedor tiene' : 'proveedores tienen'}</b> en las notas el saldo del sistema anterior (“Saldo en SGI al …”) y todavía no está cargado en su cuenta.</p>
        <p><button type="button" class="btn primary" data-pv="sgi-all">Tomar saldo de SGI de todos (${money(pend.reduce((a, x) => a + toCents(x.sgi.amount), 0))})</button></p></div>` : ''}
      <p class="muted small" aria-live="polite">${list.length} ${list.length === 1 ? 'proveedor' : 'proveedores'}</p>
      <div class="card"><ul class="list" id="pv-list">${list.slice(0, 400).map(s => html`<li><button type="button" class="row" data-pv-open="${s.id}">
        <span class="avatar" aria-hidden="true">${String(s.name || '?')[0].toUpperCase()}</span>
        <span class="grow"><span class="title">${s.name}${s.active === 0 ? html` <span class="badge">inactivo</span>` : ''}</span>
          <span class="sub" style="display:block">${[s.legal_name && s.legal_name !== s.name ? s.legal_name : '', s.cuit && 'CUIT ' + s.cuit, s.city, s.phone].filter(Boolean).join(' · ') || 'Sin datos'}${counts.get(s.id) ? ` · ${counts.get(s.id)} prod.` : ''}</span></span>
        ${bal(s) > 0 ? html`<span class="badge err money">Debemos ${fmtMoney(bal(s))}</span>` : bal(s) < 0 ? html`<span class="badge ok money">A favor ${fmtMoney(-bal(s))}</span>` : ''}
      </button></li>`)}${!list.length ? html`<li class="empty">No hay proveedores${q || view.filter !== 'todos' ? ' con ese filtro' : ''}.</li>` : ''}</ul></div>`);
  };
  box.innerHTML = String(html`
    <div class="btn-row" style="margin-bottom:1rem">
      <button type="button" class="btn primary" data-pv="new">${ic('plus')} Nuevo proveedor</button>
      <button type="button" class="btn ghost" data-pv="export">${ic('download')} Exportar Excel</button></div>
    <div class="field searchbox">${ic('search')}<label class="sr-only" for="pv-q">Buscar proveedor</label>
      <input id="pv-q" type="search" placeholder="Nombre, razón social, CUIT, localidad…" autocomplete="off" value="${view.q}"></div>
    <div class="chips" role="group" aria-label="Filtro de proveedores">
      ${[['activos', 'Activos'], ['saldo', 'Con saldo'], ['todos', 'Todos'], ['inactivos', 'Inactivos']].map(([k, l]) => html`<button type="button" class="chip" data-pv-f="${k}" aria-pressed="${view.filter === k}">${l}</button>`)}</div>
    <div data-pv-body></div>`);
  let t;
  $('#pv-q', box).addEventListener('input', e => { clearTimeout(t); t = setTimeout(() => { view.q = e.target.value; paint(); }, 120); });
  box.addEventListener('click', async e => {
    const f = e.target.closest('[data-pv-f]');
    if (f) { view.filter = f.dataset.pvF; box.querySelectorAll('[data-pv-f]').forEach(b => b.setAttribute('aria-pressed', String(b === f))); paint(); return; }
    const o = e.target.closest('[data-pv-open]');
    if (o) { await supplierDetail(o.dataset.pvOpen); paint(); return; }
    const a = e.target.closest('[data-pv]');
    if (!a) return;
    if (a.dataset.pv === 'new') { if (await supplierForm()) paint(); }
    if (a.dataset.pv === 'export') exportSuppliers();
    if (a.dataset.pv === 'sgi-all') { if (await sgiAllDialog()) paint(); }
  });
  paint();
}

async function sgiAllDialog() {
  const pend = pendingSgi().sort((a, b) => byName(a.supplier, b.supplier));
  const total = pend.reduce((a, x) => a + toCents(x.sgi.amount), 0);
  const ok = await modal({
    title: 'Tomar saldo de SGI',
    size: 'wide',
    body: html`<p class="lead">Se carga como <b>saldo inicial</b> de la cuenta corriente de <b>${pend.length}</b> proveedores lo que dice su nota “Saldo en SGI al …”. Total: <b class="money">${money(total)}</b>.</p>
      <p class="small muted">Positivo = les debemos. Negativo = saldo a favor nuestro. A los que ya tienen saldo inicial no se les vuelve a cargar.</p>
      <div class="table-wrap" style="max-height:40vh"><table><thead><tr><th>Proveedor</th><th class="r">Saldo SGI</th></tr></thead><tbody>
      ${pend.map(x => html`<tr><td style="white-space:normal">${x.supplier.name}</td><td class="r money">${fmtMoney(x.sgi.amount)}</td></tr>`)}</tbody></table></div>`,
    actions: [{ label: 'Cancelar', value: false }, { label: `Cargar ${pend.length} saldos`, kind: 'primary', value: true, id: 'sgi-go' }],
  });
  if (!ok) return false;
  try {
    const r = await takeAllSgiBalances();
    toast(`Listo: se cargó el saldo inicial de ${r.count} proveedores (${fmtMoney(r.total)}).`, 'ok', 4000);
    return true;
  } catch (e) { toast(e.message, 'error'); return false; }
}

async function exportSuppliers() {
  const rows = [['nombre', 'razon_social', 'cuit', 'condicion_iva', 'domicilio', 'localidad', 'provincia', 'telefono', 'email', 'contacto', 'cbu_alias', 'saldo', 'activo', 'productos', 'notas']];
  const counts = new Map();
  for (const p of db.all('products')) if (p.supplier_id) counts.set(p.supplier_id, (counts.get(p.supplier_id) || 0) + 1);
  for (const s of db.all('suppliers').sort(byName)) {
    rows.push([s.name, s.legal_name || '', s.cuit || '', ivaLabel(s.iva_condition), s.address || '', s.city || '', s.province || '', s.phone || '', s.email || '', s.contact || '', s.cbu || '', bal(s), s.active === 0 ? 'no' : 'si', counts.get(s.id) || 0, s.notes || '']);
  }
  await exportTable('proveedores-' + toISODate(Date.now()), 'Proveedores', rows);
}

// ---------- Alta / edición ----------

export async function supplierForm(s = {}) {
  const v = k => s[k] || '';
  return modal({
    title: s.id ? 'Editar proveedor' : 'Nuevo proveedor',
    size: 'wide',
    body: html`<form id="sf" novalidate>
      <div class="grid2">
        <div class="field"><label for="sf-n">Nombre de fantasía</label><input id="sf-n" name="name" value="${v('name')}" autocomplete="off"></div>
        <div class="field"><label for="sf-rs">Razón social</label><input id="sf-rs" name="legal_name" value="${v('legal_name')}" autocomplete="off"></div></div>
      <div class="grid2">
        <div class="field"><label for="sf-c">CUIT</label><input id="sf-c" name="cuit" inputmode="numeric" value="${v('cuit')}" placeholder="30-12345678-9" autocomplete="off"></div>
        <div class="field"><label for="sf-iva">Condición IVA</label><select id="sf-iva" name="iva_condition"><option value="">— Elegí —</option>
          ${IVA_CONDITIONS.map(([k, l]) => html`<option value="${k}" ${s.iva_condition === k ? 'selected' : ''}>${l}</option>`)}</select></div></div>
      <div class="field"><label for="sf-ad">Domicilio</label><input id="sf-ad" name="address" value="${v('address')}"></div>
      <div class="grid2">
        <div class="field"><label for="sf-ci">Localidad</label><input id="sf-ci" name="city" value="${v('city')}"></div>
        <div class="field"><label for="sf-pr">Provincia</label><input id="sf-pr" name="province" list="sf-provs" value="${s.id ? v('province') : (v('province') || 'Mendoza')}"><datalist id="sf-provs">${PROVINCES.map(p => html`<option value="${p}"></option>`)}</datalist></div></div>
      <div class="grid2">
        <div class="field"><label for="sf-p">Teléfono</label><input id="sf-p" name="phone" type="tel" value="${v('phone')}"></div>
        <div class="field"><label for="sf-e">Email</label><input id="sf-e" name="email" type="email" value="${v('email')}"></div></div>
      <div class="grid2">
        <div class="field"><label for="sf-ct">Contacto (vendedor / preventista)</label><input id="sf-ct" name="contact" value="${v('contact')}"></div>
        <div class="field"><label for="sf-cbu">CBU o alias</label><input id="sf-cbu" name="cbu" value="${v('cbu')}" autocomplete="off"></div></div>
      <div class="field"><label for="sf-o">Notas</label><textarea id="sf-o" name="notes" placeholder="Días de visita, condiciones de pago…">${v('notes')}</textarea></div>
      <label class="check"><input type="checkbox" name="active" ${s.active === 0 ? '' : 'checked'}> Activo</label>
      ${s.id ? html`<div class="btn-row" style="margin-top:.75rem"><button type="button" class="btn outline-danger" data-del>${ic('trash')} Borrar proveedor</button></div>` : ''}
    </form>`,
    onMount(m, close) {
      $('#sf', m).addEventListener('submit', e => e.preventDefault());
      const d = m.querySelector('[data-del]');
      if (d) d.onclick = async () => {
        if (bal(db.get('suppliers', s.id))) { toast('No se puede borrar un proveedor con saldo en la cuenta corriente. Desactivalo.', 'warn', 4000); return; }
        if (await confirm(`¿Borrar a ${s.name}? Sus compras y pagos quedan guardados.`, { danger: true, ok: 'Borrar' })) { await db.remove('suppliers', s.id); toast('Proveedor borrado.'); close({ deleted: true }); }
      };
    },
    actions: [{ label: 'Cancelar', value: null }, {
      label: 'Guardar', kind: 'primary', onClick: async (close, w) => {
        const f = formData($('#sf', w));
        if (!f.name.trim()) return fieldError($('#sf-n', w), 'Escribí el nombre.');
        if (f.cuit.trim() && !validCuit(f.cuit)) return fieldError($('#sf-c', w), 'El CUIT no es válido: revisá los 11 números.');
        if (f.email.trim() && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(f.email.trim())) return fieldError($('#sf-e', w), 'El email no es válido.');
        try {
          const rec = await saveSupplier({ ...f, id: s.id, active: f.active ? 1 : 0 });
          toast('Proveedor guardado.');
          close(rec);
        } catch (e) { fieldError(/CUIT/.test(e.message) ? $('#sf-c', w) : null, e.message); }
      },
    }],
  });
}

// ---------- Ficha: cuenta corriente y productos ----------

export async function supplierDetail(id) {
  let tab = 'cuenta';
  await modal({
    title: (db.get('suppliers', id) || {}).name || 'Proveedor',
    size: 'wide',
    body: html`<div id="sd"></div>`,
    onMount(m, close) {
      const paint = () => {
        const s = db.get('suppliers', id);
        const sgi = parseSgiBalance(s.notes);
        const showSgi = sgi && !hasInitialBalance(id) && can(ctx.user, 'compras');
        const prods = supplierProducts(id);
        $('#sd', m).innerHTML = String(html`
          <div class="stats">
            <div class="stat"><div class="k">Cuenta corriente</div><div class="v money" id="sd-bal" style="color:${bal(s) > 0 ? 'var(--danger)' : 'inherit'}">${fmtMoney(bal(s))}</div><div class="small muted">${balanceText(s.balance)}</div></div>
            <div class="stat"><div class="k">Productos</div><div class="v">${prods.length}</div></div></div>
          <p class="muted">${[s.legal_name, s.cuit && 'CUIT ' + s.cuit, ivaLabel(s.iva_condition), [s.address, s.city, s.province].filter(Boolean).join(', '), s.phone, s.email, s.contact && 'Contacto: ' + s.contact, s.cbu && 'CBU/alias: ' + s.cbu].filter(Boolean).join(' · ')}</p>
          ${showSgi ? html`<div class="notice notice-info" id="sd-sgi"><p>Las notas dicen <b>Saldo en SGI al ${sgi.date}: ${fmtMoney(sgi.amount)}</b>.</p>
            <p><button type="button" class="btn primary" data-sd="sgi">Tomar saldo de SGI</button></p></div>` : ''}
          <div class="btn-row" style="margin-bottom:1rem">
            <button type="button" class="btn primary big" data-sd="pay">${ic('cash')} Pagar</button>
            <button type="button" class="btn ghost" data-sd="edit">${ic('edit')} Editar datos</button></div>
          <div class="chips" role="tablist">
            <button type="button" class="chip" role="tab" data-sd-tab="cuenta" aria-pressed="${tab === 'cuenta'}" aria-selected="${tab === 'cuenta'}">Estado de cuenta</button>
            <button type="button" class="chip" role="tab" data-sd-tab="productos" aria-pressed="${tab === 'productos'}" aria-selected="${tab === 'productos'}">Productos (${prods.length})</button></div>
          <div id="sd-tab"></div>`);
        const box = $('#sd-tab', m);
        if (tab === 'cuenta') {
          mountStatement(box, {
            ledger: () => ledgerOf(id), balance: () => bal(db.get('suppliers', id)),
            title: `Estado de cuenta · ${s.name}`, subtitle: [[s.legal_name, s.cuit && 'CUIT ' + s.cuit].filter(Boolean).join(' · ')],
            fileBase: 'estado-cuenta-' + norm(s.name).replace(/[^a-z0-9]+/g, '-').slice(0, 40),
            debitLabel: 'Compras', creditLabel: 'Pagos', balanceHint: c => balanceText(fromCents(c)),
          });
        } else productsTab(box, id, paint);
      };
      m.addEventListener('click', async e => {
        const tb = e.target.closest('[data-sd-tab]');
        if (tb) { tab = tb.dataset.sdTab; paint(); return; }
        const a = e.target.closest('[data-sd]');
        if (!a) return;
        if (a.dataset.sd === 'edit') { const r = await supplierForm(db.get('suppliers', id)); if (r && r.deleted) { close(true); return; } if (r) { m.querySelector('.modal-head h2').textContent = r.name; paint(); } }
        if (a.dataset.sd === 'pay') { if (await payDialog(db.get('suppliers', id))) paint(); }
        if (a.dataset.sd === 'sgi') {
          const s = db.get('suppliers', id);
          const sgi = parseSgiBalance(s.notes);
          if (!(await confirm(`¿Cargar ${fmtMoney(sgi.amount)} como saldo inicial de ${s.name} (${sgi.amount >= 0 ? 'le debemos' : 'a favor nuestro'}), al ${sgi.date}?`, { ok: 'Cargar saldo' }))) return;
          try { await takeSgiBalance(id); toast('Saldo inicial cargado.'); paint(); } catch (err) { toast(err.message, 'error'); }
        }
      });
      paint();
    },
  });
}

function productsTab(box, id, repaint) {
  const edit = can(ctx.user, 'editar_productos');
  const showCost = can(ctx.user, 'ver_costos');
  let q = '';
  const paint = () => {
    const prods = supplierProducts(id).filter(p => !q || norm(`${p.name} ${p.barcode} ${p.sku}`).includes(norm(q)));
    $('[data-spt-list]', box).innerHTML = String(html`${prods.slice(0, 300).map(p => html`<li class="row">
      ${photoThumb(p, 'sm')}
      <span class="grow"><span class="title">${p.name}${p.active === 0 ? html` <span class="badge">inactivo</span>` : ''}</span>
        <span class="sub" style="display:block">${p.barcode || p.sku || p.category || ''}${showCost && p.cost ? ` · costo ${fmtMoney(p.cost)}` : ''} · Stock ${fmtQty(stockOf(p))}</span></span>
      <b class="money">${fmtMoney(p.price)}</b>
      ${edit ? html`<button type="button" class="icon-btn" data-spt-rm="${p.id}" aria-label="Sacar ${p.name} de este proveedor">${ic('x')}</button>` : ''}</li>`)}
      ${!prods.length ? html`<li class="empty">${q ? 'Ningún producto de este proveedor coincide.' : 'Este proveedor no tiene productos asignados.'}</li>` : ''}`);
  };
  box.innerHTML = String(html`
    <div class="field searchbox">${ic('search')}<label class="sr-only" for="spt-q">Filtrar productos del proveedor</label>
      <input id="spt-q" type="search" placeholder="Filtrar los productos de este proveedor" autocomplete="off"></div>
    ${edit ? html`<div class="field searchbox">${ic('plus')}<label class="sr-only" for="spt-add">Asignar un producto a este proveedor</label>
      <input id="spt-add" type="search" placeholder="Asignar un producto: buscá por nombre o código" autocomplete="off"></div>
      <div id="spt-res" class="results hidden"></div>` : ''}
    <ul class="list" data-spt-list></ul>`);
  $('#spt-q', box).addEventListener('input', e => { q = e.target.value; paint(); });
  const add = $('#spt-add', box);
  if (add) add.addEventListener('input', () => {
    const res = $('#spt-res', box);
    const list = add.value.trim() ? searchProducts(db.all('products').filter(p => p.supplier_id !== id), add.value, 12) : [];
    res.classList.toggle('hidden', !add.value.trim());
    res.innerHTML = String(html`${list.map(p => html`<button type="button" class="result" data-spt-add="${p.id}"><span class="grow"><span class="title">${p.name}</span>
      <span class="sub small muted" style="display:block">${(db.get('suppliers', p.supplier_id) || {}).name ? `Hoy: ${(db.get('suppliers', p.supplier_id) || {}).name}` : 'Sin proveedor'}</span></span>${ic('plus')}</button>`)}
      ${!list.length ? html`<div class="empty">Sin resultados.</div>` : ''}`);
  });
  box.addEventListener('click', async e => {
    const a = e.target.closest('[data-spt-add]');
    if (a) { await assignSupplier([a.dataset.sptAdd], id); add.value = ''; $('#spt-res', box).classList.add('hidden'); toast('Producto asignado.', 'ok', 1500); repaint(); return; }
    const r = e.target.closest('[data-spt-rm]');
    if (r) { await assignSupplier([r.dataset.sptRm], ''); toast('Producto sin proveedor.', 'ok', 1500); repaint(); }
  });
  paint();
}

// ---------- Pagar ----------

export async function payDialog(s) {
  const session = openSession();
  const purchases = db.all('purchases').filter(p => p.supplier_id === s.id && p.payment === 'cuenta_corriente').sort((a, b) => b.created_at - a.created_at).slice(0, 40);
  return modal({
    title: `Pagar a ${s.name}`,
    body: html`<p>${balanceText(s.balance)}</p>
      <form id="spf" novalidate>
        <div class="field"><label for="spf-a">Importe</label><input id="spf-a" class="money-input" inputmode="decimal" autocomplete="off" placeholder="${bal(s) > 0 ? fmtMoney(bal(s)) + ' (todo)' : '0,00'}">
          ${bal(s) > 0 ? html`<div class="hint">Vacío = paga todo lo que le debemos.</div>` : ''}</div>
        <div class="field"><label for="spf-m">Medio</label><select id="spf-m">${SUPPLIER_METHODS.map(x => html`<option value="${x.id}">${x.label}</option>`)}</select>
          <div class="hint" id="spf-cash" aria-live="polite"></div></div>
        <div id="spf-chq" class="hidden"><p class="small"><b>Cheques de la cartera que le entregás</b> (el importe es lo que suman)</p>${walletPickerHTML('spc')}</div>
        <div class="field"><label for="spf-r">Referencia <span class="muted">(N° de transferencia, cheque, recibo…)</span></label><input id="spf-r" autocomplete="off"></div>
        <div class="field"><label for="spf-n">Notas</label><input id="spf-n" autocomplete="off"></div>
        ${purchases.length ? html`<details><summary>Aplicar a compras (opcional)</summary><ul class="list">${purchases.map(p => html`<li><label class="check row" style="margin:0">
          <input type="checkbox" data-ap="${p.id}" data-amt="${purchaseDebt(p)}"> <span class="grow">${fmtDate(p.created_at)}${p.invoice_ref ? ` · Fact. ${p.invoice_ref}` : ''}${p.due_date ? ` · vence ${fmtDate(dayStart(p.due_date))}` : ''}</span><b class="money">${fmtMoney(purchaseDebt(p))}</b></label></li>`)}</ul></details>` : ''}
      </form>`,
    onMount(m) {
      const hint = () => {
        const met = $('#spf-m', m).value;
        $('#spf-chq', m).classList.toggle('hidden', met !== 'cheque');
        $('#spf-cash', m).textContent = met !== 'efectivo' ? '' : session ? 'Sale de la caja abierta como egreso (resta del efectivo esperado).' : 'No hay caja abierta en este equipo: el pago queda registrado pero no sale de ninguna caja.';
      };
      $('#spf-m', m).addEventListener('change', hint);
      m.addEventListener('change', e => {
        if (e.target.matches('[data-spc]')) { const pc = pickedCheques(m, 'spc'); $('#spf-a', m).value = pc.cents ? fmtMoney(fromCents(pc.cents)).replace('$ ', '') : ''; return; }
        if (!e.target.matches('[data-ap]')) return;
        const sum = [...m.querySelectorAll('[data-ap]:checked')].reduce((a, x) => a + toCents(Number(x.dataset.amt)), 0);
        if (sum) $('#spf-a', m).value = fmtMoney(fromCents(sum)).replace('$ ', '');
      });
      $('#spf', m).addEventListener('submit', e => { e.preventDefault(); m.querySelector('.modal-foot .primary').click(); });
      hint();
    },
    actions: [{ label: 'Cancelar', value: false }, {
      label: 'Registrar pago', kind: 'primary', id: 'spf-go', onClick: async (close, w) => {
        const inp = $('#spf-a', w);
        const v = inp.value.trim() === '' ? bal(s) : parseNum(inp.value);
        if (!isFinite(v) || v <= 0) return fieldError(inp, 'Escribí el importe que le pagás.');
        if (bal(s) >= 0 && round2(v) > bal(s) && !(await confirm(`Le debemos ${fmtMoney(bal(s))} y vas a pagar ${fmtMoney(v)}: la diferencia queda a favor nuestro. ¿Seguimos?`))) return;
        try {
          const p = await paySupplier({
            supplier_id: s.id, amount: v, method: $('#spf-m', w).value, reference: $('#spf-r', w).value, notes: $('#spf-n', w).value,
            applies_to: [...w.querySelectorAll('[data-ap]:checked')].map(x => x.dataset.ap),
            cheque_ids: $('#spf-m', w).value === 'cheque' ? pickedCheques(w, 'spc').ids : [],
          });
          toast(`Pago registrado: ${fmtMoney(p.amount)}${p.cash_movement_id ? ' (salió de la caja)' : ''}.`);
          close(p);
        } catch (e) { fieldError(inp, e.message); }
      },
    }],
  });
}

// ---------- Liquidación del período ----------

export function mountLiquidacion(box) {
  const now = new Date();
  const first = toISODate(new Date(now.getFullYear(), now.getMonth(), 1).getTime());
  box.innerHTML = String(html`<p class="muted">Resumen por proveedor del período: saldo al empezar, compras a cuenta corriente, pagos, ajustes y saldo al terminar.</p>
    <div class="stmt-filters">
      <div class="field"><label for="lq-f">Desde</label><input type="date" id="lq-f" value="${first}"></div>
      <div class="field"><label for="lq-t">Hasta</label><input type="date" id="lq-t" value="${toISODate(Date.now())}"></div>
      <div class="field"><label for="lq-s">Proveedor</label><select id="lq-s"><option value="">Todos</option>${db.all('suppliers').sort(byName).map(s => html`<option value="${s.id}">${s.name}</option>`)}</select></div>
      <div class="btn-row stmt-btns"><button type="button" class="btn ghost" data-lq="print">${ic('print')} Imprimir</button>
        <button type="button" class="btn ghost" data-lq="xls">${ic('download')} Excel</button></div></div>
    <div data-lq-body></div>`);
  const calc = () => {
    const r = rangeOf(box, '#lq-f', '#lq-t');
    const sid = $('#lq-s', box).value;
    const sups = db.all('suppliers', { includeDeleted: false }).filter(s => !sid || s.id === sid);
    return { r, l: liquidacion(sups, { purchases: db.all('purchases'), payments: db.all('supplier_payments'), from: r.from, to: r.to }) };
  };
  const paint = () => {
    const { l } = calc();
    $('[data-lq-body]', box).innerHTML = String(html`
      <div class="stats">
        <div class="stat"><div class="k">Compras a cuenta</div><div class="v money">${money(l.totals.compras)}</div></div>
        <div class="stat"><div class="k">Pagos</div><div class="v money" id="lq-pagos">${money(l.totals.pagos)}</div></div>
        <div class="stat"><div class="k">Saldo al empezar</div><div class="v money">${money(l.totals.opening)}</div></div>
        <div class="stat"><div class="k">Saldo al terminar</div><div class="v money" id="lq-closing">${money(l.totals.closing)}</div></div></div>
      <div class="card"><ul class="list">${l.rows.map(x => html`<li><button type="button" class="row" data-lq-open="${x.supplier.id}">
        <span class="grow"><span class="title">${x.supplier.name}</span>
          <span class="sub" style="display:block">Inicial ${money(x.opening)} · Compras ${money(x.compras)} · Pagos ${money(x.pagos)}${x.ajustes ? ` · Saldo inicial/ajustes ${money(x.ajustes)}` : ''}${x.contado ? ` · Contado ${money(x.contado)}` : ''}</span></span>
        <b class="money">${money(x.closing)}</b></button></li>`)}
        ${!l.rows.length ? html`<li class="empty">Sin movimientos ni saldos en ese período.</li>` : ''}</ul></div>`);
  };
  const printAll = async () => {
    const { r, l } = calc();
    await printA4(html`<div class="ticket doc-a4">${printHead('Liquidación de proveedores', [periodText(r)])}
      <table class="ptable"><thead><tr><th>Proveedor</th><th class="r">Saldo inicial</th><th class="r">Compras cta. cte.</th><th class="r">Pagos</th><th class="r">Saldo inicial / ajustes</th><th class="r">Saldo final</th><th class="r">Compras contado</th></tr></thead><tbody>
      ${l.rows.map(x => html`<tr><td>${x.supplier.name}</td><td class="r">${money(x.opening)}</td><td class="r">${money(x.compras)}</td><td class="r">${money(x.pagos)}</td><td class="r">${money(x.ajustes)}</td><td class="r"><b>${money(x.closing)}</b></td><td class="r">${money(x.contado)}</td></tr>`)}
      </tbody><tfoot><tr><td>Totales</td><td class="r">${money(l.totals.opening)}</td><td class="r">${money(l.totals.compras)}</td><td class="r">${money(l.totals.pagos)}</td><td class="r">${money(l.totals.ajustes)}</td><td class="r"><b>${money(l.totals.closing)}</b></td><td class="r">${money(l.totals.contado)}</td></tr></tfoot></table></div>`);
  };
  const printOne = async sid => {
    const { r, l } = calc();
    const x = l.rows.find(y => y.supplier.id === sid);
    if (!x) return;
    const s = x.supplier;
    await printA4(html`<div class="ticket doc-a4">${printHead(`Liquidación · ${s.name}`, [[s.legal_name, s.cuit && 'CUIT ' + s.cuit].filter(Boolean).join(' · '), periodText(r)])}
      <table class="ptable"><tbody>
        <tr><td>Saldo al empezar</td><td class="r">${money(x.opening)}</td></tr>
        <tr><td>+ Compras a cuenta corriente</td><td class="r">${money(x.compras)}</td></tr>
        <tr><td>− Pagos</td><td class="r">${money(x.pagos)}</td></tr>
        ${x.ajustes ? html`<tr><td>± Ajustes / saldo inicial</td><td class="r">${money(x.ajustes)}</td></tr>` : ''}
        <tr><td><b>Saldo al terminar</b></td><td class="r"><b>${money(x.closing)}</b></td></tr>
        ${x.contado ? html`<tr><td>(Compras de contado en el período)</td><td class="r">${money(x.contado)}</td></tr>` : ''}
      </tbody></table>
      <h3>Detalle</h3>
      <table class="ptable"><thead><tr><th>Fecha</th><th>Detalle</th><th class="r">Compras</th><th class="r">Pagos</th><th class="r">Saldo</th></tr></thead><tbody>
      ${x.rows.map(m => html`<tr><td>${fmtDate(m.at)}</td><td>${m.label}${m.cash ? ` (contado ${money(m.cash)})` : ''}</td><td class="r">${m.debit ? money(m.debit) : ''}</td><td class="r">${m.credit ? money(m.credit) : ''}</td><td class="r">${money(m.balance)}</td></tr>`)}</tbody></table>
      <p><b>${balanceText(fromCents(x.closing))}</b></p>
      <p style="margin-top:2.5rem">Firma y aclaración: ____________________________</p></div>`);
  };
  box.addEventListener('change', e => { if (e.target.matches('#lq-f, #lq-t, #lq-s')) paint(); });
  box.addEventListener('click', async e => {
    const o = e.target.closest('[data-lq-open]');
    if (o) {
      const go = await modal({
        title: (db.get('suppliers', o.dataset.lqOpen) || {}).name || 'Proveedor',
        body: html`<p>¿Qué querés ver?</p>`,
        actions: [{ label: 'Cerrar', value: null }, { label: 'Estado de cuenta', value: 'cuenta' }, { label: 'Imprimir liquidación', kind: 'primary', value: 'print' }],
      });
      if (go === 'print') printOne(o.dataset.lqOpen);
      if (go === 'cuenta') { await supplierDetail(o.dataset.lqOpen); paint(); }
      return;
    }
    const a = e.target.closest('[data-lq]');
    if (!a) return;
    if (a.dataset.lq === 'print') printAll();
    if (a.dataset.lq === 'xls') {
      const { r, l } = calc();
      const rows = [['proveedor', 'cuit', 'saldo_inicial', 'compras_cta_cte', 'pagos', 'ajustes', 'saldo_final', 'compras_contado', 'periodo']];
      for (const x of l.rows) rows.push([x.supplier.name, x.supplier.cuit || '', fromCents(x.opening), fromCents(x.compras), fromCents(x.pagos), fromCents(x.ajustes), fromCents(x.closing), fromCents(x.contado), periodText(r)]);
      rows.push(['TOTAL', '', fromCents(l.totals.opening), fromCents(l.totals.compras), fromCents(l.totals.pagos), fromCents(l.totals.ajustes), fromCents(l.totals.closing), fromCents(l.totals.contado), '']);
      await exportTable('liquidacion-proveedores-' + toISODate(Date.now()), 'Liquidación', rows);
    }
  });
  paint();
}

/** Línea de la compra para el detalle (pago y vencimiento) */
export function purchasePaymentText(p) {
  if (p.payment !== 'cuenta_corriente') return 'De contado';
  const debt = purchaseDebt(p);
  return `A cuenta corriente${p.paid ? ` · pagado al comprar ${fmtMoney(p.paid)}` : ''} · suma ${fmtMoney(debt)}${p.due_date ? ` · vence ${fmtDate(dayStart(p.due_date))}` : ''}`;
}


