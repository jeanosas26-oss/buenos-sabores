// =====================================================================
// productos-lote.js — Filtros de la lista de productos, eliminar /
// desactivar (con aviso si tiene ventas o stock), papelera (30 días) y
// cambios en lote con vista previa (precio por %, categoría, activar…).
// =====================================================================
import * as db from '../db.js';
import { branchName, multiBranch } from '../ops.js';
import { html, $, modal, toast, fieldError } from '../ui.js';
import { fmtMoney, fmtQty, fmtDateTime, parseNum } from '../logic.js';
import { PRODUCT_FILTERS, PRODUCT_SORTS, activeProductFilters, bulkPricePreview, trashList, TRASH_DAYS } from '../control.js';
import { usageOf, deleteProducts, setProductsActive, restoreProduct, setProductsCategory, bulkPrice } from '../seguridad.js';

// ---------- Filtros (se recuerdan en este equipo, menos el texto) ----------

const FKEY = 'jg-filtros-productos';
export function loadFilters() {
  const f = { ...PRODUCT_FILTERS };
  try { const sv = JSON.parse(localStorage.getItem(FKEY) || '{}'); for (const k of Object.keys(PRODUCT_FILTERS)) if (k !== 'q' && sv[k] !== undefined && typeof sv[k] === typeof PRODUCT_FILTERS[k]) f[k] = sv[k]; } catch (e) { /* sin almacenamiento */ }
  return f;
}
export function saveFilters(f) {
  try { const o = {}; for (const k of Object.keys(PRODUCT_FILTERS)) if (k !== 'q') o[k] = f[k]; localStorage.setItem(FKEY, JSON.stringify(o)); } catch (e) { /* nada */ }
}

/** Panel de filtros (dentro de un <details>) */
export function filtersHTML(f, { cats, suppliers, showPhoto, open = false, subcats = [] }) {
  const n = activeProductFilters(f);
  const opt = (v, l, cur) => html`<option value="${v}" ${cur === v ? 'selected' : ''}>${l}</option>`;
  return html`<details class="card filters-card" id="pf-filters" ${open ? 'open' : ''}><summary><b>Filtros</b>${n ? html` <span class="badge info" id="pf-nf">${n}</span>` : ''}</summary>
    <div class="filters" style="margin-top:.6rem">
      <div class="field"><label for="ff-cat">Rubro</label><select id="ff-cat" data-f="cat">${opt('', 'Todos', f.cat)}${cats.map(c => opt(c, c, f.cat))}</select></div>
      ${f.cat && subcats.length ? html`<div class="field"><label for="ff-sub">Subrubro</label><select id="ff-sub" data-f="subcat">${opt('', 'Todos', f.subcat)}${subcats.map(c => opt(c, c, f.subcat))}</select></div>` : ''}
      <div class="field"><label for="ff-sup">Proveedor</label><select id="ff-sup" data-f="supplier">${opt('', 'Todos', f.supplier)}${suppliers.map(s => opt(s.id, s.name, f.supplier))}${opt('-', 'Sin proveedor', f.supplier)}</select></div>
      <div class="field"><label for="ff-stock">Stock</label><select id="ff-stock" data-f="stock">${[['', 'Cualquiera'], ['con', 'Con stock'], ['sin', 'Sin stock (0)'], ['bajo', 'Stock bajo'], ['negativo', 'Stock negativo']].map(([v, l]) => opt(v, l, f.stock))}</select></div>
      <div class="field"><label for="ff-unit">Se vende por</label><select id="ff-unit" data-f="unit">${[['', 'Unidad y kilo'], ['u', 'Unidad'], ['kg', 'Kilo']].map(([v, l]) => opt(v, l, f.unit))}</select></div>
      <div class="field"><label for="ff-act">Estado</label><select id="ff-act" data-f="active">${[['activos', 'Activos'], ['inactivos', 'Inactivos'], ['todos', 'Activos e inactivos']].map(([v, l]) => opt(v, l, f.active))}</select></div>
      <div class="field"><label for="ff-sort">Ordenar por</label><select id="ff-sort" data-f="sort">${PRODUCT_SORTS.map(([v, l]) => opt(v, l, f.sort))}</select></div>
    </div>
    <div class="chips" role="group" aria-label="Más filtros">
      <label class="chip check-chip"><input type="checkbox" data-f="sinCodigo" ${f.sinCodigo ? 'checked' : ''}> Sin código</label>
      <label class="chip check-chip"><input type="checkbox" data-f="sinPrecio" ${f.sinPrecio ? 'checked' : ''}> Sin precio</label>
      ${showPhoto ? html`<label class="chip check-chip"><input type="checkbox" data-f="conFoto" ${f.conFoto ? 'checked' : ''}> Con foto</label>` : ''}
    </div>
    ${n ? html`<button type="button" class="btn ghost sm" data-act="clear-filters">Limpiar filtros</button>` : ''}
  </details>`;
}

/** Lee el panel de filtros a f */
export function readFilters(root, f) {
  for (const el of root.querySelectorAll('#pf-filters [data-f]')) f[el.dataset.f] = el.type === 'checkbox' ? el.checked : el.value;
}

// ---------- Eliminar / desactivar ----------

/**
 * Eliminar un producto (o varios) con confirmación. Si tienen ventas o stock, avisa y ofrece desactivarlos.
 * Devuelve 'deleted' | 'deactivated' | null.
 */
export async function deleteFlow(ids) {
  const us = usageOf(ids);
  if (!us.length) return null;
  const one = us.length === 1;
  const used = us.filter(u => u.hasSales || u.hasStock);
  const withStock = us.filter(u => u.hasStock);
  const name = one ? `“${us[0].p.name}”` : `${us.length} productos`;
  const r = await modal({
    title: one ? 'Eliminar producto' : `Eliminar ${us.length} productos`,
    body: html`${used.length ? html`<div class="notice notice-warn" id="del-warn">
        ${one ? html`<p><b>${us[0].p.name}</b> ${us[0].hasSales ? 'tiene ventas' : ''}${us[0].hasSales && us[0].hasStock ? ' y ' : ''}${us[0].hasStock ? html`tiene stock (${fmtQty(us[0].stock)}${us[0].p.unit === 'kg' ? ' kg' : ''}${multiBranch() ? ` en ${us[0].branches.map(b => branchName(b)).join(', ')}` : ''})` : ''}.</p>`
          : html`<p><b>${used.length}</b> de los ${us.length} tienen ventas o stock${withStock.length ? html` (${withStock.length} con stock)` : ''}.</p>`}
        <p>Te conviene <b>desactivarlo</b>: deja de aparecer para vender, pero sigue en los reportes y se puede volver a activar.</p></div>`
      : html`<p class="lead">¿Eliminar ${name}? Las ventas anteriores no cambian.</p>`}
      <p class="muted small">Lo eliminado queda ${TRASH_DAYS} días en la <b>papelera</b> de Productos y se puede restaurar. Queda registrado en la auditoría.</p>`,
    actions: [
      { label: 'Cancelar', value: null },
      ...(used.length ? [{ label: one ? 'Desactivar' : 'Desactivar todos', kind: 'primary', value: 'deactivate', id: 'del-deact' }, { label: 'Eliminar igual', kind: 'danger', value: 'delete', id: 'del-go' }]
        : [{ label: 'Eliminar', kind: 'danger', value: 'delete', id: 'del-go' }]),
    ],
  });
  if (!r) return null;
  try {
    if (r === 'deactivate') { const n = await setProductsActive(us.map(u => u.p.id), false); toast(n ? `${n === 1 ? 'Producto desactivado' : n + ' productos desactivados'}.` : 'Ya estaban desactivados.'); return 'deactivated'; }
    const n = await deleteProducts(us.map(u => u.p.id));
    toast(`${n === 1 ? 'Producto eliminado' : n + ' productos eliminados'}. Lo podés restaurar desde la papelera.`, 'ok', 4000);
    return 'deleted';
  } catch (e) { toast(e.message, 'error', 5000); return null; }
}

// ---------- Papelera ----------

export async function trashDialog() {
  let changed = false;
  const body = () => {
    const list = trashList(db.all('products', { includeDeleted: true }));
    return list.length ? html`<p class="muted small">Productos eliminados en los últimos ${TRASH_DAYS} días (${list.length}).</p>
      <ul class="list" id="trash-list">${list.slice(0, 300).map(p => html`<li class="row"><span class="grow"><span class="title">${p.name}</span>
        <span class="sub" style="display:block">${p.barcode || p.sku || 'Sin código'} · ${fmtMoney(p.price)} · eliminado el ${fmtDateTime(p.updated_at)}</span></span>
        <button type="button" class="btn sm ghost" data-restore="${p.id}">Restaurar</button></li>`)}</ul>`
      : html`<p class="empty" id="trash-empty">La papelera está vacía.</p>`;
  };
  await modal({
    title: 'Papelera de productos',
    size: 'wide',
    body: html`<div id="trash">${body()}</div>`,
    onMount(m) {
      m.addEventListener('click', async e => {
        const b = e.target.closest('[data-restore]');
        if (!b) return;
        b.disabled = true;
        try {
          const r = await restoreProduct(b.dataset.restore);
          changed = true;
          toast(r.barcodeCleared ? `Restaurado sin código de barras: ese código ahora lo usa “${r.barcodeCleared}”.` : `“${r.product.name}” restaurado.`, r.barcodeCleared ? 'warn' : 'ok', 5000);
          $('#trash', m).innerHTML = String(body());
        } catch (err) { toast(err.message, 'error'); b.disabled = false; }
      });
    },
    actions: [{ label: 'Cerrar', kind: 'primary', value: true }],
  });
  return changed;
}

// ---------- Cambios en lote ----------

/** Barra de acciones para los seleccionados */
export function bulkBarHTML(n, total) {
  return html`<div class="bulk-bar" id="bulk-bar" role="region" aria-label="Acciones con los seleccionados">
    <div class="bulk-info"><b id="bulk-n">${n}</b> ${n === 1 ? 'seleccionado' : 'seleccionados'}
      <button type="button" class="btn ghost sm" data-act="sel-all">Seleccionar los ${total} filtrados</button>
      ${n ? html`<button type="button" class="btn ghost sm" data-act="sel-none">Ninguno</button>` : ''}</div>
    <div class="btn-row">
      <button type="button" class="btn sm ghost" data-bulk="price" ${n ? '' : 'disabled'}>Precio %</button>
      <button type="button" class="btn sm ghost" data-bulk="category" ${n ? '' : 'disabled'}>Categoría</button>
      <button type="button" class="btn sm ghost" data-bulk="activate" ${n ? '' : 'disabled'}>Activar</button>
      <button type="button" class="btn sm ghost" data-bulk="deactivate" ${n ? '' : 'disabled'}>Desactivar</button>
      <button type="button" class="btn sm outline-danger" data-bulk="delete" ${n ? '' : 'disabled'}>Eliminar</button>
      <button type="button" class="btn sm ghost" data-act="sel-exit">Listo</button>
    </div></div>`;
}

const STEPS = [[0, 'Sin redondear (centavos)'], [1, 'A $ 1'], [10, 'A $ 10'], [50, 'A $ 50'], [100, 'A $ 100']];

/** Ejecuta una acción en lote. Devuelve true si cambió algo. */
export async function bulkAction(kind, ids, { cats = [] } = {}) {
  if (!ids.length) return false;
  if (kind === 'delete') return !!(await deleteFlow(ids));
  if (kind === 'activate' || kind === 'deactivate') {
    const on = kind === 'activate';
    const ok = await modal({ title: on ? 'Activar productos' : 'Desactivar productos', body: html`<p class="lead">¿${on ? 'Activar' : 'Desactivar'} ${ids.length} ${ids.length === 1 ? 'producto' : 'productos'}?${on ? '' : ' Dejan de aparecer para vender.'}</p>`, actions: [{ label: 'Cancelar', value: false }, { label: on ? 'Activar' : 'Desactivar', kind: 'primary', value: true, id: 'bk-go' }] });
    if (!ok) return false;
    const n = await setProductsActive(ids, on);
    toast(n ? `${n} ${n === 1 ? 'producto' : 'productos'} ${on ? 'activados' : 'desactivados'}.` : 'No había nada para cambiar.');
    return n > 0;
  }
  if (kind === 'category') {
    const cat = await modal({
      title: `Cambiar categoría (${ids.length})`,
      body: html`<form id="bc" novalidate><div class="field"><label for="bc-c">Nueva categoría</label><input id="bc-c" list="bc-cats" autocomplete="off"><datalist id="bc-cats">${cats.map(c => html`<option value="${c}"></option>`)}</datalist></div></form>`,
      onMount(m) { $('#bc', m).addEventListener('submit', e => { e.preventDefault(); m.parentElement.querySelector('#bk-go').click(); }); },
      actions: [{ label: 'Cancelar', value: null }, { label: 'Cambiar', kind: 'primary', id: 'bk-go', onClick: (close, w) => { const v = $('#bc-c', w).value.trim(); if (!v) return fieldError($('#bc-c', w), 'Escribí la categoría.'); close(v); } }],
    });
    if (!cat) return false;
    const n = await setProductsCategory(ids, cat);
    toast(`${n} ${n === 1 ? 'producto pasó' : 'productos pasaron'} a “${cat}”.`);
    return n > 0;
  }
  if (kind === 'price') {
    const prods = ids.map(id => db.get('products', id)).filter(Boolean);
    let pv = null;
    const go = await modal({
      title: `Cambiar precios (${prods.length})`,
      size: 'wide',
      body: html`<form id="bp" novalidate><div class="grid2">
          <div class="field"><label for="bp-pct">Porcentaje</label><input id="bp-pct" class="money-input" inputmode="decimal" placeholder="Ej: 10 o -5" autocomplete="off"></div>
          <div class="field"><label for="bp-step">Redondear</label><select id="bp-step">${STEPS.map(([v, l]) => html`<option value="${v}">${l}</option>`)}</select></div></div>
        <p class="hint muted">10 = sube 10 %. -5 = baja 5 %. Primero mirá la vista previa.</p></form>
        <div id="bp-prev" aria-live="polite"><p class="muted">Escribí el porcentaje para ver cómo quedan los precios.</p></div>
        <p id="bp-err" class="field-err" role="alert"></p>`,
      onMount(m) {
        const upd = () => {
          const pct = parseNum($('#bp-pct', m).value);
          const step = Number($('#bp-step', m).value);
          pv = $('#bp-pct', m).value.trim() ? bulkPricePreview(prods, pct, step) : null;
          const box = $('#bp-prev', m);
          $('#bp-err', m).textContent = pv && pv.error ? pv.error : '';
          const go = m.parentElement.querySelector('#bk-go');
          if (go) go.disabled = !pv || !!pv.error;
          if (!pv || pv.error) { box.innerHTML = String(html`<p class="muted">Escribí el porcentaje para ver cómo quedan los precios.</p>`); return; }
          box.innerHTML = String(html`<p><b>${pv.up}</b> suben · <b>${pv.down}</b> bajan${pv.same ? html` · <b>${pv.same}</b> quedan igual` : ''}</p>
            <div class="table-wrap" style="max-height:40vh;overflow:auto"><table id="bp-table"><thead><tr><th>Producto</th><th class="r">Antes</th><th class="r">Después</th></tr></thead><tbody>
            ${pv.rows.slice(0, 200).map(r => html`<tr><td style="white-space:normal">${r.name}</td><td class="r">${fmtMoney(r.old)}</td><td class="r"><b>${fmtMoney(r.price)}</b></td></tr>`)}
            </tbody></table></div>${pv.rows.length > 200 ? html`<p class="small muted">Se muestran 200 de ${pv.rows.length}.</p>` : ''}`);
        };
        m.addEventListener('input', upd); m.addEventListener('change', upd);
        $('#bp', m).addEventListener('submit', e => e.preventDefault());
        setTimeout(() => { const g = m.parentElement.querySelector('#bk-go'); if (g) g.disabled = true; }, 0);
      },
      actions: [{ label: 'Cancelar', value: null }, { label: 'Aplicar precios', kind: 'primary', id: 'bk-go', onClick: (close, w) => {
        if (!pv || pv.error) return;
        close({ pct: parseNum($('#bp-pct', w).value), step: Number($('#bp-step', w).value) });
      } }],
    });
    if (!go) return false;
    const pct = go.pct;
    const sure = await modal({ title: 'Confirmar precios', body: html`<p class="lead">Se van a cambiar los precios de <b>${pv.rows.filter(r => r.price !== r.old).length}</b> productos (${pct > 0 ? '+' : ''}${String(pct).replace('.', ',')} %). Queda registrado en la auditoría.</p>${Math.abs(pct) > 50 ? html`<div class="notice notice-warn"><p>Es un cambio de más del 50 %. Revisá que el porcentaje esté bien.</p></div>` : ''}`,
      actions: [{ label: 'Cancelar', value: false }, { label: 'Sí, cambiar', kind: 'primary', value: true, id: 'bk-sure' }] });
    if (!sure) return false;
    const n = await bulkPrice(ids, pct, go.step);
    toast(`Precios actualizados: ${n} ${n === 1 ? 'producto' : 'productos'}.`);
    return n > 0;
  }
  return false;
}
