// =====================================================================
// productos.js — Lista, alta/edición, ajuste de stock, importar/exportar.
// =====================================================================
import * as db from '../db.js';
import { ctx, saveProduct, adjustStock, importProducts, readProductFile, importLegacySetup, stockOf, stockByBranch, multiBranch, currentBranch, branches } from '../ops.js';
import { html, $, on, ic, modal, toast, formData, fieldError, confirm, pickFile, loadXlsx, exportTable } from '../ui.js';
import { fmtMoney, fmtQty, fmtNum2, parseNum, margin, IVA_RATES, can, searchProducts, round2, uuid } from '../logic.js';
import { openScanner, canScan, scanButton, codeVariants, playError } from '../scanner.js';
import { filterProducts, checkProduct, isManager, PRODUCT_FILTERS, activeProductFilters } from '../control.js';
import { authorize, confirmWarnings } from '../autoriza.js';
import { auditOps, adjustStockAudited } from '../seguridad.js';
import { photoThumb, photoField, mountPhotoField, savePhoto } from '../fotos.js';
import { subcategoriesOf } from '../comercial-ops.js';
import { minOf } from '../comercial.js';
import { loadFilters, saveFilters, filtersHTML, readFilters, deleteFlow, trashDialog, bulkBarHTML, bulkAction } from './productos-lote.js';

const PAGE = 60;
let main;
// Filtros de la lista (se recuerdan en este equipo, menos el texto). sel: selección múltiple
const view = { ...loadFilters(), shown: PAGE };
const sel = { on: false, ids: new Set() };
let filtersOpen = null; // el panel de filtros queda abierto o cerrado como lo dejó el usuario

export function render(m) {
  main = m;
  const edit = can(ctx.user, 'editar_productos');
  main.innerHTML = String(html`
    <div class="page-head"><h1>Productos</h1>
      ${edit ? html`<div class="btn-row">
        <button type="button" class="btn primary" data-act="new">${ic('plus')} Nuevo</button>
        ${can(ctx.user, 'ajustar_stock') ? html`<a class="btn soft big" href="#/conteo" id="p-conteo">${ic('scale')} Contar stock</a>` : ''}
        <button type="button" class="btn ghost" data-act="import">${ic('upload')} Importar productos</button>
        ${can(ctx.user, 'fotos') ? html`<button type="button" class="btn ghost" data-act="import-photos" id="p-import-photos">${ic('camera')} Importar fotos</button>
        <a class="btn ghost" href="#/fotos" id="p-fotos">${ic('camera')} Fotos faltantes</a>` : ''}
        <button type="button" class="btn ghost" data-act="export">${ic('download')} Exportar Excel</button>
        <button type="button" class="btn ghost" data-act="select" id="p-select">${ic('check')} Seleccionar</button>
        <button type="button" class="btn ghost" data-act="trash" id="p-trash">${ic('trash')} Papelera</button>
        <a class="btn ghost" href="#/rubros" id="p-rubros">${ic('box')} Rubros</a>
        <a class="btn ghost" href="#/etiquetas" id="p-etiquetas">${ic('tag')} Etiquetas</a></div>`
        : can(ctx.user, 'ajustar_stock') ? html`<div class="btn-row"><a class="btn soft big" href="#/conteo" id="p-conteo">${ic('scale')} Contar stock</a></div>` : ''}
    </div>
    <div id="low-alert"></div>
    <div id="p-bulk"></div>
    <div class="field searchbox${canScan() ? ' has-scan' : ''}">${ic('search')}<label class="sr-only" for="p-q">Buscar producto</label>
      <input id="p-q" type="search" placeholder="Nombre, código o categoría" value="${view.q}" autocomplete="off">
      ${scanButton('data-act="scan" id="p-scan"', 'Buscar con la cámara')}</div>
    <div class="chips" role="group" aria-label="Filtros rápidos">
      ${[['bajo', 'Stock bajo'], ['sin', 'Sin stock'], ['negativo', 'Stock negativo']].map(([k, l]) => html`<button type="button" class="chip" data-quick="${k}" aria-pressed="${view.stock === k}">${k === 'bajo' ? ic('alert') : ''} ${l}</button>`)}
      <button type="button" class="chip" data-quick="inactivos" aria-pressed="${view.active === 'inactivos'}">Inactivos</button></div>
    <div id="p-filters"></div>
    <div class="card"><p class="muted small" id="p-count" aria-live="polite"></p>
      ${multiBranch() ? html`<p class="small" id="p-branch">${ic('store')} Stock de <b>${(currentBranch() || {}).name || ''}</b>. Tocá un producto para ver el de cada sucursal.</p>` : ''}
      <ul class="list" id="p-list"></ul>
      <button type="button" class="btn ghost block hidden" id="p-more" data-act="more">Mostrar más</button></div>`);
  paintCats();
  paint();
  let t;
  $('#p-q', main).addEventListener('input', e => { clearTimeout(t); t = setTimeout(() => { view.q = e.target.value; view.shown = PAGE; paint(); }, 150); });
  main.addEventListener('change', e => {
    if (!e.target.closest('#pf-filters')) return;
    readFilters(main, view); view.shown = PAGE; saveFilters(view); paintCats(); paint();
  });
  return on(main, 'click', '[data-act], [data-open], [data-quick], [data-bulk]', (e, el) => {
    if (el.dataset.open) {
      if (sel.on) { if (sel.ids.has(el.dataset.open)) sel.ids.delete(el.dataset.open); else sel.ids.add(el.dataset.open); paint(); return; }
      return productDetail(db.get('products', el.dataset.open));
    }
    if (el.dataset.quick) {
      const k = el.dataset.quick;
      if (k === 'inactivos') view.active = view.active === 'inactivos' ? 'activos' : 'inactivos';
      else view.stock = view.stock === k ? '' : k;
      view.shown = PAGE; saveFilters(view); paintCats(); paint(); return;
    }
    if (el.dataset.bulk) return runBulk(el.dataset.bulk);
    act(el.dataset.act, el);
  });
}

async function runBulk(kind) {
  const cats = [...new Set(db.all('products').map(p => p.category || 'General'))].sort((a, b) => a.localeCompare(b, 'es'));
  if (await bulkAction(kind, [...sel.ids].filter(id => db.get('products', id) && !db.get('products', id).deleted), { cats })) {
    for (const id of [...sel.ids]) { const p = db.get('products', id); if (!p || p.deleted) sel.ids.delete(id); }
    paintCats(); paint();
  }
}

// Todo lo que se ve en la lista (stock y "stock bajo") es de la sucursal de este equipo
// Punto de pedido de la sucursal de este equipo (stock_mins) o el general (stock_min)
const isLow = p => { const m = minOf(p, ctx.branchId); return m > 0 && stockOf(p) <= m; };
const unitTxt = p => (p.unit === 'kg' ? ' kg' : '');

/** Tabla con el stock de cada sucursal y el total */
function branchStockTable(p) {
  const rows = stockByBranch(p);
  const cur = ctx.branchId;
  return html`<div class="table-wrap"><table aria-label="Stock por sucursal"><thead><tr><th>Sucursal</th><th class="r">Stock</th></tr></thead><tbody>
    ${rows.map(r => html`<tr><td style="white-space:normal">${r.branch.name}${r.branch.id === cur ? html` <span class="branch-tag">este equipo</span>` : ''}${r.branch.active === 0 ? html` <span class="badge">inactiva</span>` : ''}</td>
      <td class="r" data-branch-stock="${r.branch.id}">${fmtQty(r.qty)}${unitTxt(p)}</td></tr>`)}
    </tbody><tfoot><tr><td>Total</td><td class="r" data-stock-total>${fmtQty(p.stock)}${unitTxt(p)}</td></tr></tfoot></table></div>`;
}

/** Panel de filtros y botones rápidos (se repinta al cambiar) */
function paintCats() {
  const prods = db.all('products');
  const cats = [...new Set(prods.map(p => p.category || 'General'))].sort((a, b) => a.localeCompare(b, 'es'));
  const suppliers = db.all('suppliers').sort((a, b) => String(a.name || '').localeCompare(String(b.name || ''), 'es'));
  const box = $('#p-filters', main);
  if (!box) return;
  const cur = box.querySelector('details');
  if (cur) filtersOpen = cur.open; // el evento "toggle" llega tarde: manda lo que se ve ahora
  if (filtersOpen === null) filtersOpen = activeProductFilters(view) > 0;
  if (!view.cat) view.subcat = '';
  const subcats = view.cat ? [...new Set([...subcategoriesOf(view.cat).map(s => s.name), ...prods.filter(p => (p.category || 'General') === view.cat && p.subcategory).map(p => p.subcategory)])].sort((a, b) => a.localeCompare(b, 'es')) : [];
  box.innerHTML = String(filtersHTML(view, { cats, suppliers, subcats, open: filtersOpen, showPhoto: db.COLLECTIONS.includes('product_photos') ? db.count('product_photos') > 0 : prods.some(p => p.photo) }));
  box.querySelector('details').addEventListener('toggle', e => { filtersOpen = e.target.open; });
  main.querySelectorAll('[data-quick]').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.quick === 'inactivos' ? view.active === 'inactivos' : view.stock === b.dataset.quick)));
}

// Fotos de productos: van en su propia colección (product_photos, id = id del producto)
const hasPhoto = p => !!p.photo || (db.COLLECTIONS.includes('product_photos') && !!db.get('product_photos', p.id) && !db.get('product_photos', p.id).deleted);

function filtered() {
  return filterProducts(db.all('products'), view, { stockOf, hasPhoto });
}

function paint() {
  const showCost = can(ctx.user, 'ver_costos');
  const lows = db.all('products').filter(p => p.active !== 0 && isLow(p));
  $('#low-alert', main).innerHTML = lows.length && view.stock !== 'bajo' ? String(html`<div class="notice notice-warn"><p>${ic('alert')} <b>${lows.length} ${lows.length === 1 ? 'producto tiene' : 'productos tienen'} stock bajo.</b> <button type="button" class="btn sm ghost" data-quick="bajo">Ver</button></p></div>`) : '';
  const list = filtered();
  $('#p-count', main).textContent = `${list.length} ${list.length === 1 ? 'producto' : 'productos'}`;
  const total = db.count('products');
  for (const id of [...sel.ids]) if (!db.get('products', id) || db.get('products', id).deleted) sel.ids.delete(id);
  $('#p-bulk', main).innerHTML = sel.on ? String(bulkBarHTML(sel.ids.size, list.length)) : '';
  const sb = $('#p-select', main);
  if (sb) { sb.setAttribute('aria-pressed', String(sel.on)); sb.lastChild.textContent = sel.on ? ' Salir de selección' : ' Seleccionar'; }
  $('#p-list', main).classList.toggle('selecting', sel.on);
  $('#p-list', main).innerHTML = list.length ? String(html`${list.slice(0, view.shown).map(p => html`<li>
    <button type="button" class="row" data-open="${p.id}" ${sel.on ? html`role="checkbox" aria-checked="${sel.ids.has(p.id)}"` : ''}>
      ${sel.on ? html`<span class="sel-box ${sel.ids.has(p.id) ? 'on' : ''}" aria-hidden="true">${sel.ids.has(p.id) ? ic('check') : ''}</span>` : ''}
      ${photoThumb(p, 'sm')}<span class="grow"><span class="title">${p.name}${p.active === 0 ? html` <span class="badge">inactivo</span>` : ''}</span>
        <span class="sub" style="display:block">${p.category || 'General'}${p.barcode ? ` · ${p.barcode}` : p.sku ? ` · ${p.sku}` : ''}${showCost && p.cost ? ` · costo ${fmtMoney(p.cost)}` : ''}</span></span>
      <span style="text-align:right"><b class="money" style="display:block;font-size:1.1rem">${fmtMoney(p.price)}${p.unit === 'kg' ? '/kg' : ''}</b>
        <span class="badge ${isLow(p) ? 'err' : stockOf(p) <= 0 ? 'warn' : ''}">Stock ${fmtQty(stockOf(p))}${unitTxt(p)}</span></span>
    </button></li>`)}`)
    : String(html`<li class="empty">${total ? 'No hay productos con ese filtro.' : html`Todavía no cargaste productos.${can(ctx.user, 'editar_productos') ? html`<br>Tocá <b>Nuevo</b> o <b>Importar productos</b>.` : ''}`}</li>`);
  $('#p-more', main).classList.toggle('hidden', list.length <= view.shown);
}

async function act(name, el) {
  if (name === 'more') { view.shown += PAGE; paint(); return; }
  if (name === 'clear-filters') { Object.assign(view, { ...PRODUCT_FILTERS, q: view.q }); view.shown = PAGE; saveFilters(view); paintCats(); paint(); return; }
  if (name === 'select') {
    sel.on = !sel.on; if (!sel.on) sel.ids.clear(); paint();
    const b = $('#bulk-bar', main); if (b) b.scrollIntoView({ block: 'nearest' });
    return;
  }
  if (name === 'sel-exit') { sel.on = false; sel.ids.clear(); paint(); return; }
  if (name === 'sel-none') { sel.ids.clear(); paint(); return; }
  if (name === 'sel-all') { for (const p of filtered()) sel.ids.add(p.id); paint(); return; }
  if (name === 'trash') { if (await trashDialog()) { paintCats(); paint(); } return; }
  if (name === 'new') { if (await productForm()) { paintCats(); paint(); } return; }
  if (name === 'import') return importDialog();
  if (name === 'import-photos') { const m = await import('./fotos.js'); await m.importPhotosDialog(() => { paintCats(); paint(); }); return; }
  if (name === 'export') return exportProducts();
  if (name === 'scan') return scanSearch();
}

/** Producto (activo o no) con ese código de barras o interno */
export function productByCode(code) {
  const list = db.all('products');
  for (const c of codeVariants(code)) {
    const p = list.find(x => x.barcode === c) || list.find(x => x.sku && String(x.sku).trim().toLowerCase() === c.toLowerCase());
    if (p) return p;
  }
  return null;
}

/** Buscar con la cámara: muestra el producto en la lista y lo abre */
async function scanSearch() {
  const code = await openScanner({ title: 'Buscar producto por código' });
  if (!code || !main.isConnected) return;
  const p = productByCode(code);
  const inp = $('#p-q', main);
  view.q = p ? (p.barcode || p.sku || code) : code;
  view.shown = PAGE;
  if (inp) inp.value = view.q;
  paint();
  if (p) { await productDetail(p); return; }
  playError();
  if (!can(ctx.user, 'editar_productos')) { toast(`No encontramos el código ${code}.`, 'warn', 4000); return; }
  const go = await modal({
    title: 'Código no encontrado',
    body: html`<p class="lead">No encontramos el código <b>${code}</b>.</p>`,
    actions: [{ label: 'Cerrar', value: false }, { label: 'Crear producto con este código', kind: 'primary', value: true }],
  });
  if (go && await productForm({ barcode: code })) { view.q = code; if (inp) inp.value = code; paintCats(); paint(); }
}

/** Ficha del producto con acciones según el rol */
async function productDetail(p) {
  const edit = can(ctx.user, 'editar_productos');
  if (edit) { if (await productForm(p)) { paintCats(); paint(); } return; }
  await modal({
    title: p.name,
    body: html`${photoThumb(p, 'lg', p.name)}<div class="stats" style="grid-template-columns:1fr 1fr">
      <div class="stat"><div class="k">Precio</div><div class="v money">${fmtMoney(p.price)}</div></div>
      <div class="stat"><div class="k">Stock${multiBranch() ? ' acá' : ''}</div><div class="v">${fmtQty(stockOf(p))} ${p.unit}</div></div></div>
      ${multiBranch() ? branchStockTable(p) : ''}
      <p class="muted">${p.category} ${p.barcode ? `· Código ${p.barcode}` : ''}</p>`,
    actions: [{ label: html`${ic('lock')} Ajustar stock`, id: 'pd-adjust', onClick: async close => {
      const a = await authorize(`ajustar el stock de “${p.name}”`, { action: 'ajuste_stock', entity: 'products', entityId: p.id, perm: 'ajustar_stock' });
      if (!a) return;
      close(true);
      if (await stockDialog(db.get('products', p.id), a)) paint();
    } }, { label: 'Cerrar', kind: 'primary', value: true }],
  });
}

/** Alta / edición de producto. Devuelve el producto guardado o null. */
export async function productForm(p = {}) {
  const suppliers = db.all('suppliers').sort((a, b) => String(a.name || '').localeCompare(String(b.name || ''), 'es'));
  const cats = [...new Set(db.all('products').map(x => x.category || 'General'))].sort();
  const isNew = !p.id;
  // Cajero y vendedor: solo crean un producto nuevo desde una compra (el stock y el costo los pone la compra)
  const limited = !can(ctx.user, 'editar_productos');
  if (limited && !isNew) { toast('Solo el dueño o el encargado pueden cambiar un producto.', 'warn'); return null; }
  const multi = multiBranch();
  const branchLabel = (currentBranch() || {}).name || '';
  const hide = limited ? ' hidden' : '';
  const r = await modal({
    title: isNew ? 'Nuevo producto' : 'Editar producto',
    size: 'wide',
    body: html`<form id="pf" novalidate>
      ${limited ? html`<div class="notice notice-info" id="pf-limited"><p>El <b>stock</b> y el <b>costo</b> los pone la compra al guardarla. Revisá bien el nombre, el código y el precio de venta: después solo el dueño o el encargado pueden cambiar el producto.</p></div>` : ''}
      <div class="field"><label for="pf-name">Nombre</label><input id="pf-name" name="name" value="${p.name || ''}" autocomplete="off"></div>
      <div class="grid2">
        <div class="field"><label for="pf-price">Precio de venta (con IVA)</label><input id="pf-price" name="price" class="money-input" inputmode="decimal" value="${p.price ? fmtNum2(p.price) : ''}" placeholder="0,00"></div>
        <div class="field${hide}"><label for="pf-cost">Costo</label><input id="pf-cost" name="cost" class="money-input" inputmode="decimal" value="${p.cost ? fmtNum2(p.cost) : ''}" placeholder="0,00"></div>
      </div>
      <div class="field${hide}"><div class="notice notice-info" id="pf-margin" aria-live="polite" style="margin:0"></div></div>
      <div class="grid3">
        <div class="field"><label for="pf-iva">IVA</label><select id="pf-iva" name="iva_rate">${IVA_RATES.map(x => html`<option value="${x}" ${Number(p.iva_rate ?? 21) === x ? 'selected' : ''}>${String(x).replace('.', ',')}%</option>`)}</select></div>
        <div class="field"><label for="pf-unit">Se vende por</label><select id="pf-unit" name="unit"><option value="u" ${p.unit !== 'kg' ? 'selected' : ''}>Unidad</option><option value="kg" ${p.unit === 'kg' ? 'selected' : ''}>Kilo</option></select></div>
        <div class="field"><label for="pf-cat">Categoría</label><input id="pf-cat" name="category" list="pf-cats" value="${p.category || ''}" placeholder="General"><datalist id="pf-cats">${cats.map(c => html`<option value="${c}"></option>`)}</datalist></div>
      </div>
      <div class="grid2">
        <div class="field${hide}"><label for="pf-stock">${multi ? html`Stock en ${branchLabel}` : 'Stock'} ${isNew ? '' : html`<span class="muted">(cambialo con “Ajustar”)</span>`}</label><input id="pf-stock" name="stock" inputmode="decimal" value="${fmtQty(isNew ? (p.stock || 0) : stockOf(p))}" ${isNew ? '' : 'readonly'}>
          ${multi && isNew ? html`<div class="hint">En las otras sucursales arranca en 0.</div>` : ''}</div>
        <div class="field"><label for="pf-min">Stock mínimo / punto de pedido${multi ? ' (todas)' : ''}</label><input id="pf-min" name="stock_min" inputmode="decimal" value="${fmtQty(p.stock_min || 0)}"></div>
      </div>
      <div class="grid3">
        <div class="field"><label for="pf-sub">Subrubro</label><input id="pf-sub" name="subcategory" list="pf-subs" value="${p.subcategory || ''}" autocomplete="off"><datalist id="pf-subs">${subcategoriesOf(p.category || '').map(s => html`<option value="${s.name}"></option>`)}</datalist></div>
        ${multi ? html`<div class="field"><label for="pf-minb">Punto de pedido en ${branchLabel}</label><input id="pf-minb" name="stock_min_branch" inputmode="decimal" value="${p.stock_mins && p.stock_mins[ctx.branchId] !== undefined ? fmtQty(p.stock_mins[ctx.branchId]) : ''}" placeholder="igual que todas"></div>` : ''}
        <div class="field"><label for="pf-rq">Cantidad a pedir</label><input id="pf-rq" name="reorder_qty" inputmode="decimal" value="${p.reorder_qty ? fmtQty(p.reorder_qty) : ''}" placeholder="automática"></div>
        <div class="field"><label for="pf-exp">Vencimiento</label><input id="pf-exp" name="expires_at" type="date" value="${p.expires_at || ''}"></div>
      </div>
      <div class="grid2">
        <div class="field"><label for="pf-bar">Código de barras</label>
          <div class="field-scan"><input id="pf-bar" name="barcode" inputmode="numeric" value="${p.barcode || ''}" autocomplete="off">${scanButton('data-scan-bar', 'Escanear el código con la cámara')}</div>
          <div class="hint">Podés escanearlo con el lector${canScan() ? ' o con la cámara' : ''}.</div></div>
        <div class="field"><label for="pf-sku">Código interno</label><input id="pf-sku" name="sku" value="${p.sku || ''}" autocomplete="off"></div>
      </div>
      ${multi && !isNew ? html`<div class="field" id="pf-branches"><span class="label">Stock por sucursal</span>${branchStockTable(p)}</div>` : ''}
      ${limited ? '' : photoField(p.id)}
      <div class="field"><label for="pf-sup">Proveedor</label><select id="pf-sup" name="supplier_id"><option value="">— Sin proveedor —</option>${suppliers.map(s => html`<option value="${s.id}" ${s.id === p.supplier_id ? 'selected' : ''}>${s.name}</option>`)}</select></div>
      <label class="check${hide}"><input type="checkbox" name="active" ${p.active === 0 && !limited ? '' : 'checked'}> Activo (aparece para vender)</label>
      <label class="check${hide}"><input type="checkbox" name="quick" ${p.quick ? 'checked' : ''}> A mano en Vender (botón fijo al lado de “Monto libre”)</label>
      <label class="check${hide}"><input type="checkbox" name="open_price" ${p.open_price ? 'checked' : ''}> Precio libre: al venderlo pide el importe (ej: “Varios panadería”)</label>
      ${isNew ? '' : html`<div class="btn-row" style="margin-top:.75rem">
        <button type="button" class="btn ghost" data-adjust>${ic('scale')} Ajustar stock</button>
        <button type="button" class="btn outline-danger" data-delete id="pf-delete">${ic('trash')} Eliminar</button></div>`}
    </form>`,
    onMount(m, close) {
      // La barra de código no debe enviar el formulario (los lectores mandan Enter)
      $('#pf', m).addEventListener('submit', e => e.preventDefault());
      const upd = () => {
        const pr = parseNum($('#pf-price', m).value), co = parseNum($('#pf-cost', m).value);
        const box = $('#pf-margin', m);
        if (!isFinite(pr) || !isFinite(co) || co <= 0) { box.textContent = 'Cargá el costo para ver la ganancia.'; return; }
        const g = margin(pr, co);
        box.textContent = `Ganás ${fmtMoney(g.gain)} por ${$('#pf-unit', m).value === 'kg' ? 'kilo' : 'unidad'} (${String(g.pct).replace('.', ',')}% sobre el costo).`;
      };
      ['#pf-price', '#pf-cost', '#pf-unit'].forEach(s => $(s, m).addEventListener('input', upd));
      const sb = m.querySelector('[data-scan-bar]');
      if (sb) sb.onclick = async () => {
        const code = await openScanner({ title: 'Escanear código de barras' });
        if (!code) return;
        const inp = $('#pf-bar', m);
        inp.value = code;
        inp.dispatchEvent(new Event('input', { bubbles: true }));
        toast(`Código ${code} cargado.`, 'ok', 1800);
      };
      upd();
      m._photo = mountPhotoField(m);
      const adj = m.querySelector('[data-adjust]');
      if (adj) adj.onclick = async () => {
        const np = await stockDialog(db.get('products', p.id));
        if (!np) return;
        $('#pf-stock', m).value = fmtQty(stockOf(np));
        const box = $('#pf-branches', m);
        if (box) box.innerHTML = String(html`<span class="label">Stock por sucursal</span>${branchStockTable(np)}`);
      };
      const del = m.querySelector('[data-delete]');
      if (del) del.onclick = async () => {
        const r = await deleteFlow([p.id]);
        if (r) close({ deleted: r === 'deleted', deactivated: r === 'deactivated' });
      };
    },
    actions: [{ label: 'Cancelar', value: null }, {
      label: 'Guardar', kind: 'primary', onClick: async (close, w) => {
        const f = formData($('#pf', w));
        const price = f.price.trim() ? parseNum(f.price) : NaN;
        const cost = !limited && f.cost.trim() ? parseNum(f.cost) : 0;
        const stock = limited ? 0 : parseNum(f.stock || '0'), smin = parseNum(f.stock_min || '0');
        const prev = isNew ? null : db.get('products', p.id);
        // Validaciones anti-error de tipeo: lo grave bloquea; lo raro (precio que cambia más del 50 %, costo mayor
        // que el precio, nombre repetido, código interno repetido) pide confirmación
        const chk = checkProduct({ id: p.id, name: f.name, price, cost, stock: isNew ? stock : undefined, stock_min: smin, barcode: f.barcode, sku: f.sku }, prev, db.all('products'));
        const fieldOf = { name: '#pf-name', price: '#pf-price', cost: '#pf-cost', stock: '#pf-stock', stock_min: '#pf-min', barcode: '#pf-bar', sku: '#pf-sku' };
        if (chk.errors.length) return fieldError($(fieldOf[chk.errors[0].field], w), chk.errors[0].msg);
        if (chk.warnings.length && !(await confirmWarnings(chk.warnings))) return;
        try {
          const rec = { ...p, name: f.name, price, cost, iva_rate: Number(f.iva_rate), unit: f.unit, category: f.category, stock_min: smin, barcode: f.barcode, sku: f.sku, supplier_id: f.supplier_id, active: f.active ? 1 : 0 };
          // Subrubro, punto de pedido por sucursal, cantidad a pedir y vencimiento (esquema 0006)
          // Botón “a mano” en Vender y precio libre (esquema 0009); un usuario limitado no los cambia
          if (!limited) { rec.quick = f.quick ? 1 : 0; rec.open_price = f.open_price ? 1 : 0; }
          rec.subcategory = String(f.subcategory || '').trim();
          rec.expires_at = f.expires_at || null;
          const rq = parseNum(f.reorder_qty || ''); rec.reorder_qty = Number.isFinite(rq) && rq > 0 ? rq : null;
          if (f.stock_min_branch !== undefined && ctx.branchId) {
            const mb = parseNum(f.stock_min_branch); const mins = { ...((db.get('products', p.id) || p).stock_mins || {}) };
            if (String(f.stock_min_branch).trim() !== '' && Number.isFinite(mb) && mb >= 0) mins[ctx.branchId] = mb; else delete mins[ctx.branchId];
            rec.stock_mins = mins;
          }
          // El stock se carga solo al crear (en la sucursal de este equipo); después se cambia con “Ajustar”
          if (isNew) rec.stock = stock;
          else { const cur = db.get('products', p.id); rec.stock = cur.stock; if (cur.stocks) rec.stocks = cur.stocks; }
          const priceChanged = prev && round2(prev.price) !== round2(price);
          const extra = priceChanged ? auditOps('producto_precio', 'products', p.id, { name: f.name.trim(), old: round2(prev.price), price: round2(price), cost: round2(cost) }) : [];
          if (limited) rec.id = uuid();
          if (limited) extra.push(...auditOps('producto_nuevo', 'products', rec.id, { name: f.name.trim(), barcode: f.barcode, price: round2(price), desde: 'compra' }));
          const saved = await saveProduct(rec, extra);
          const ph = $('.modal', w)._photo;
          if (ph && ph.changed() && saved && saved.id) await savePhoto(saved.id, ph.value());
          toast('Producto guardado.');
          close(saved);
        } catch (e) { fieldError(e.message.includes('código') ? $('#pf-bar', w) : null, e.message); }
      },
    }],
  });
  return r;
}

async function stockDialog(p, auth = null) {
  return modal({
    title: 'Ajustar stock',
    body: html`<p><b>${p.name}</b><br><span class="muted">Stock actual${multiBranch() ? ` en ${(currentBranch() || {}).name || ''}` : ''}: ${fmtQty(stockOf(p))} ${p.unit}</span></p>
      <form id="sa" novalidate>
        <fieldset class="seg"><legend>¿Qué querés hacer?</legend>
          <label><input type="radio" name="mode" value="set" checked><span>Contado: hay…</span></label>
          <label><input type="radio" name="mode" value="add"><span>Sumar / restar</span></label></fieldset>
        <div class="field"><label for="sa-q">Cantidad</label><input id="sa-q" class="money-input" inputmode="decimal" autocomplete="off" placeholder="Ej: 12 o -3"></div>
        <div class="field"><label for="sa-r">Motivo</label><input id="sa-r" list="sa-sug" placeholder="Ej: recuento, rotura, vencido"><datalist id="sa-sug"><option value="Recuento"></option><option value="Rotura"></option><option value="Vencido"></option><option value="Consumo interno"></option></datalist></div>
      </form>`,
    onMount(m) { $('#sa', m).addEventListener('submit', e => { e.preventDefault(); m.querySelector('.modal-foot .primary').click(); }); },
    actions: [{ label: 'Cancelar', value: null }, {
      label: 'Guardar ajuste', kind: 'primary', onClick: async (close, w) => {
        const inp = $('#sa-q', w);
        const q = parseNum(inp.value);
        if (!isFinite(q)) return fieldError(inp, 'Escribí una cantidad.');
        if (Number.isInteger(q) && Math.abs(q) >= 100000) return fieldError(inp, 'Eso parece un código de barras, no una cantidad.');
        const reason = $('#sa-r', w).value.trim();
        if (!reason) return fieldError($('#sa-r', w), 'Escribí el motivo (queda registrado).');
        const mode = w.querySelector('[name=mode]:checked').value;
        const target = mode === 'set' ? q : stockOf(p) + q;
        const warn = [];
        if (target < 0) warn.push(`El stock quedaría negativo (${fmtQty(target)}).`);
        if (Math.abs(target - stockOf(p)) > (p.unit === 'kg' ? 50 : 999)) warn.push(`El stock cambia de ${fmtQty(stockOf(p))} a ${fmtQty(target)}.`);
        if (warn.length && !(await confirmWarnings(warn))) return;
        try {
          const np = await adjustStockAudited(p.id, target, reason, auth);
          toast('Stock actualizado.');
          close(np);
        } catch (e) { toast(e.message, 'error'); }
      },
    }],
  });
}

async function importDialog() {
  const go = await modal({
    title: 'Importar productos',
    body: html`<p>Elegí un archivo con tus productos:</p>
      <ul class="stack">
        <li><b>Excel (.xlsx) o CSV</b> con columnas <i>nombre, precio, stock, codigo</i> (también se leen <i>costo, categoria, minimo, iva</i>).</li>
        <li><b>JSON del sistema anterior</b> (productos.json).</li>
      </ul>
      <div class="notice notice-info"><p>Si un producto ya existe (mismo código, o mismo nombre si no tiene código) se actualizan su precio, costo y stock. No se borra nada.</p>
        ${multiBranch() ? html`<p>El stock del archivo se carga en <b>${(currentBranch() || {}).name || ''}</b>. Los precios son los mismos en todas las sucursales; en las otras, el stock de los productos nuevos arranca en 0.</p>` : ''}</div>`,
    actions: [{ label: 'Cancelar', value: false }, { label: 'Elegir archivo', kind: 'primary', value: true }],
  });
  if (!go) return;
  const file = await pickFile('.json,.csv,.txt,.xlsx,.xls,.ods,application/json,text/csv');
  if (!file) return;
  // Archivos de fiambrería/verdulería "por kilo": se ofrece cargar todo por kg
  let preRows = null;
  if (/kg|kilo/i.test(file.name)) {
    try { preRows = await readProductFile(file, loadXlsx); } catch (e) { preRows = null; }
    if (preRows && preRows.some(r => !r.unit)) {
      const allKg = await modal({
        title: '¿Se venden por kilo?',
        body: html`<p>El archivo <b>${file.name}</b> parece de productos por kilo.</p><p>¿Cargamos <b>todos</b> sus productos como "por kg"? (en Vender te va a pedir el peso)</p>`,
        actions: [{ label: 'No, según el nombre', value: false }, { label: 'Sí, todos por kilo', kind: 'primary', value: true }],
      });
      if (allKg) preRows.forEach(r => { if (!r.unit) r.unit = 'kg'; });
    }
  }
  let progress = null;
  const prog = modal({
    title: 'Importando…', dismissable: false,
    body: html`<p id="imp-msg" aria-live="polite">Leyendo ${file.name}…</p>`,
    onMount(m, close) { progress = { m, close }; },
  });
  try {
    const rows = preRows || await readProductFile(file, loadXlsx);
    if (!rows.length) throw new Error('El archivo no tiene filas con productos.');
    const r = await importProducts(rows, (n, t) => { const el = $('#imp-msg', progress.m); if (el) el.textContent = `Guardando ${n} de ${t}…`; });
    const lg = rows.legacy && ctx.user.role === 'dueno' ? await importLegacySetup(rows.legacy) : null;
    progress.close(true);
    await prog;
    await modal({
      title: 'Importación terminada',
      body: html`<div class="notice notice-ok"><p><b>${r.created}</b> productos nuevos · <b>${r.updated}</b> actualizados${r.skipped ? html` · <b>${r.skipped}</b> filas salteadas (sin nombre)` : ''}.</p></div>
        ${lg ? html`<div class="notice notice-info"><p>Copia del sistema anterior: ${lg.settingsUpdated.length ? html`se completaron los datos del comercio (${lg.settingsUpdated.length} campos)` : 'los datos del comercio ya estaban cargados'}${lg.usersCreated ? html` y se crearon <b>${lg.usersCreated}</b> usuarios (cada uno crea su PIN la primera vez que entra)` : ''}.${lg.branchesSet ? html` Se configuraron <b>${lg.branchesSet}</b> sucursales con su punto de venta.` : ''} Revisá Ajustes → Facturación: el punto de venta para ARCA tiene que ser uno dado de alta para "Web services".</p></div>` : ''}
        ${r.errors.length ? html`<details><summary>Ver avisos (${r.errors.length})</summary><ul>${r.errors.slice(0, 50).map(e => html`<li>${e}</li>`)}</ul></details>` : ''}`,
      actions: [{ label: 'Listo', kind: 'primary', value: true }],
    });
    paintCats(); paint();
  } catch (e) {
    if (progress) progress.close(false);
    await prog;
    toast('No se pudo importar: ' + e.message, 'error', 6000);
  }
}

async function exportProducts() {
  const sup = id => (db.get('suppliers', id) || {}).name || '';
  // "stock" es el de la sucursal de este equipo (así el archivo se puede volver a importar acá);
  // con varias sucursales se agregan columnas con el stock de cada una y el total.
  const multi = multiBranch();
  const brs = multi ? branches({ includeInactive: true }) : [];
  const rows = [['nombre', 'precio', 'costo', 'stock', 'minimo', 'codigo', 'categoria', 'iva', 'unidad', 'proveedor', 'activo', ...brs.map(b => 'stock ' + b.name), ...(multi ? ['stock total'] : [])]];
  for (const p of db.all('products').sort((a, b) => String(a.name || '').localeCompare(String(b.name || ''), 'es'))) {
    rows.push([p.name, round2(p.price), round2(p.cost), stockOf(p), Number(p.stock_min), p.barcode || p.sku || '', p.category || '', p.iva_rate, p.unit, sup(p.supplier_id), p.active === 0 ? 'no' : 'si',
      ...brs.map(b => stockOf(p, b.id)), ...(multi ? [Number(p.stock) || 0] : [])]);
  }
  await exportTable('productos-' + new Date().toISOString().slice(0, 10), 'Productos', rows);
}

