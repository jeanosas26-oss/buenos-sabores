// =====================================================================
// clientes-cuenta.js — Ficha del cliente: cuenta corriente con estado de
// cuenta (fechas, saldo acumulado, imprimir, Excel), cobros total/parcial
// con medio y referencia, y límite de crédito.
// =====================================================================
import * as db from '../db.js';
import { ctx, openSession, userName } from '../ops.js';
import { html, $, ic, modal, toast, fieldError, confirm } from '../ui.js';
import { fmtMoney, norm, parseNum, round2, can } from '../logic.js';
import { customerLedger, CUSTOMER_METHODS, creditCheck, fromCents } from '../cuentas.js';
import { collectCustomer } from '../cuentas-ops.js';
import { chequeFieldsHTML, readCheque } from './cheque-ui.js';
import { mountStatement } from './ctacte.js';
import { customerForm } from './clientes.js';
import { ivaName } from '../print.js';

const bal = c => round2((c && c.balance) || 0);

function ledgerOf(c) {
  return customerLedger(c, { sales: db.all('sales'), returns: db.all('returns'), payments: db.all('customer_payments'), movements: db.all('cash_movements') });
}

/** Texto del saldo de un cliente */
export function customerBalanceText(v) {
  const b = round2(v);
  return b > 0 ? `Debe ${fmtMoney(b)}` : b < 0 ? `Saldo a favor ${fmtMoney(-b)}` : 'Sin deuda';
}

/** Ficha del cliente */
export async function customerDetail(id) {
  await modal({
    title: (db.get('customers', id) || {}).name || 'Cliente',
    size: 'wide',
    body: html`<div id="cd"></div>`,
    onMount(m, close) {
      const paint = () => {
        const c = db.get('customers', id);
        const lim = creditCheck(c, 0);
        const okSales = db.all('sales').filter(s => s.customer_id === id && s.status === 'ok' && !s.test).length;
        $('#cd', m).innerHTML = String(html`
          <div class="stats">
            <div class="stat"><div class="k">Saldo cuenta corriente</div><div class="v money" id="cd-bal" style="color:${bal(c) > 0 ? 'var(--danger)' : 'inherit'}">${fmtMoney(bal(c))}</div><div class="small muted">${customerBalanceText(c.balance)}</div></div>
            <div class="stat"><div class="k">Límite de crédito</div><div class="v money">${lim.limit ? fmtMoney(fromCents(lim.limit)) : 'Sin límite'}</div>
              ${lim.limit ? html`<div class="small ${lim.available < 0 ? 'field-err' : 'muted'}">${lim.available < 0 ? `Pasado por ${fmtMoney(fromCents(-lim.available))}` : `Disponible ${fmtMoney(fromCents(lim.available))}`}</div>` : ''}</div>
          </div>
          <p class="muted">${c.doc_number ? `${c.doc_type} ${c.doc_number} · ` : ''}${ivaName(c.iva_condition)}${c.phone ? ` · ${c.phone}` : ''}${c.address ? ` · ${c.address}` : ''} · ${okSales} ${okSales === 1 ? 'compra' : 'compras'}${c.seller_id ? ` · Vendedor: ${userName(c.seller_id)}` : ''}${c.active === 0 ? ' · INACTIVO' : ''}</p>
          ${c.notes ? html`<p class="small">${c.notes}</p>` : ''}
          <div class="btn-row" style="margin-bottom:1rem">
            ${can(ctx.user, 'cobrar_cc') ? html`<button type="button" class="btn primary big" data-cd="pay" ${bal(c) > 0 ? '' : 'disabled'}>${ic('cash')} Registrar cobro</button>` : ''}
            <button type="button" class="btn ghost" data-cd="edit">${ic('edit')} Editar</button>
            ${can(ctx.user, 'anular') ? html`<button type="button" class="btn outline-danger" data-cd="del">${ic('trash')} Borrar</button>` : ''}
          </div>
          <h3>Estado de cuenta</h3>
          <div id="cd-st"></div>`);
        mountStatement($('#cd-st', m), {
          ledger: () => ledgerOf(db.get('customers', id)), balance: () => bal(db.get('customers', id)),
          title: `Estado de cuenta · ${c.name}`, subtitle: [[c.doc_number ? `${c.doc_type} ${c.doc_number}` : '', ivaName(c.iva_condition)].filter(Boolean).join(' · ')],
          fileBase: 'estado-cuenta-' + norm(c.name).replace(/[^a-z0-9]+/g, '-').slice(0, 40),
          debitLabel: 'Compras', creditLabel: 'Pagos', balanceHint: x => customerBalanceText(fromCents(x)),
        });
      };
      m.addEventListener('click', async e => {
        const a = e.target.closest('[data-cd]');
        if (!a) return;
        const c = db.get('customers', id);
        if (a.dataset.cd === 'edit') { const r = await customerForm(c); if (r) { m.querySelector('.modal-head h2').textContent = r.name; paint(); } }
        if (a.dataset.cd === 'pay') { if (await payDialog(c)) paint(); }
        if (a.dataset.cd === 'del') {
          if (bal(c) !== 0) { toast('No se puede borrar un cliente con saldo en la cuenta. Podés desactivarlo (Editar).', 'warn', 4000); return; }
          if (await confirm(`¿Borrar a ${c.name}? Sus ventas quedan guardadas.`, { danger: true, ok: 'Borrar' })) {
            await db.remove('customers', id);
            toast('Cliente borrado.');
            close(true);
          }
        }
      });
      paint();
    },
  });
}

/** Cobro de cuenta corriente: total (vacío) o parcial, medio y referencia */
export async function payDialog(c) {
  const session = openSession();
  return modal({
    title: `Cobro a ${c.name}`,
    body: html`<p>${customerBalanceText(c.balance)}</p>
      <form id="pf" novalidate>
        <div class="field"><label for="pf-a">Importe que paga</label><input id="pf-a" class="money-input" inputmode="decimal" value="" placeholder="${fmtMoney(c.balance)} (todo)" autocomplete="off">
          <div class="hint">Vacío = paga todo. Puede pagar una parte.</div></div>
        <div class="field"><label for="pf-m">Medio</label><select id="pf-m">${CUSTOMER_METHODS.map(x => html`<option value="${x.id}" ${!session && x.id === 'transferencia' ? 'selected' : ''}>${x.label}</option>`)}</select>
          <div class="hint" id="pf-h" aria-live="polite"></div></div>
        <div id="pf-chq" class="hidden"><p class="small"><b>Datos del cheque</b> (entra a la cartera por el importe del cobro)</p>${chequeFieldsHTML('pfc', { withAmount: false })}</div>
        <div class="field"><label for="pf-r">Referencia <span class="muted">(N° de operación, cheque, recibo…)</span></label><input id="pf-r" autocomplete="off"></div>
        <div class="field"><label for="pf-n">Notas</label><input id="pf-n" autocomplete="off"></div>
      </form>`,
    onMount(m) {
      const hint = () => {
        const met = $('#pf-m', m).value;
        $('#pf-chq', m).classList.toggle('hidden', met !== 'cheque');
        $('#pf-h', m).textContent = met === 'efectivo' ? (session ? 'Entra a la caja abierta (suma al efectivo esperado).' : 'La caja está cerrada: para cobrar en efectivo abrila primero.') : 'No entra a la caja en efectivo: queda registrado como cobro.';
      };
      $('#pf-m', m).addEventListener('change', hint);
      $('#pf', m).addEventListener('submit', e => { e.preventDefault(); m.querySelector('.modal-foot .primary').click(); });
      hint();
    },
    actions: [{ label: 'Cancelar', value: false }, {
      label: 'Registrar cobro', kind: 'primary', id: 'pf-go', onClick: async (close, w) => {
        const inp = $('#pf-a', w);
        const v = inp.value.trim() === '' ? bal(c) : parseNum(inp.value);
        if (!isFinite(v) || v <= 0) return fieldError(inp, 'Importe inválido.');
        if (round2(v) > bal(c) && !(await confirm(`Debe ${fmtMoney(bal(c))} y paga ${fmtMoney(v)}: la diferencia queda como saldo a favor del cliente. ¿Seguimos?`))) return;
        try {
          const met = $('#pf-m', w).value;
          const cheques = met === 'cheque' ? [readCheque(w, 'pfc', round2(v))] : [];
          const p = await collectCustomer({ customer_id: c.id, amount: v, method: met, reference: $('#pf-r', w).value || (cheques[0] ? 'Cheque ' + cheques[0].number : ''), notes: $('#pf-n', w).value, cheques });
          toast(`Cobro registrado: ${fmtMoney(p.amount)}.`);
          close(p);
        } catch (e) { fieldError(inp, e.message); }
      },
    }],
  });
}
