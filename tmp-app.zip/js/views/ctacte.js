// =====================================================================
// ctacte.js — Estado de cuenta (proveedores y clientes): filtro por fechas,
// saldo acumulado, imprimir (A4) y exportar a Excel. Lo usan proveedores.js
// y clientes.js.
// =====================================================================
import { html, $, raw, esc, ic, exportTable } from '../ui.js';
import { fmtMoney, fmtDate, fmtDateTime, toISODate, dayStart, dayEnd } from '../logic.js';
import { statement, fromCents } from '../cuentas.js';
import { settings } from '../ops.js';

const money = c => fmtMoney(fromCents(c));

/** Imprime en hoja A4 (el ancho de ticket de Ajustes no se usa para esto) */
export async function printA4(content) {
  const area = document.querySelector('#print-area');
  area.className = 'a4';
  area.innerHTML = String(content);
  await new Promise(r => setTimeout(r, 100));
  window.print();
}

/** Encabezado de los impresos: comercio y fecha */
export function printHead(title, lines = []) {
  const st = settings();
  return html`<div class="ph"><div><b>${st.business_name || st.legal_name || ''}</b>${st.cuit ? html`<br>CUIT ${st.cuit}` : ''}</div>
    <div style="text-align:right">Impreso ${fmtDateTime(Date.now())}</div></div>
    <h2 style="margin:.5rem 0 .2rem">${title}</h2>${lines.map(l => html`<div>${l}</div>`)}`;
}

/** Rango de fechas de los campos desde/hasta (vacío = sin límite) */
export function rangeOf(root, fromSel, toSel) {
  const f = $(fromSel, root).value, t = $(toSel, root).value;
  return { from: f ? dayStart(f) : -Infinity, to: t ? dayEnd(t) : Infinity, fromIso: f, toIso: t };
}

export function periodText({ fromIso, toIso }) {
  if (!fromIso && !toIso) return 'Todos los movimientos';
  if (!fromIso) return `Hasta el ${fmtDate(dayStart(toIso))}`;
  if (!toIso) return `Desde el ${fmtDate(dayStart(fromIso))}`;
  return `Del ${fmtDate(dayStart(fromIso))} al ${fmtDate(dayStart(toIso))}`;
}

/**
 * Bloque de estado de cuenta montado en `box`.
 * opts: {ledger: () => movimientos, balance: () => saldo actual (pesos), title, subtitle: [líneas], fileBase,
 *        debitLabel, creditLabel, balanceHint: c => texto del saldo}
 */
export function mountStatement(box, opts) {
  const id = 'st' + Math.random().toString(36).slice(2, 7);
  const today = toISODate(Date.now());
  box.innerHTML = String(html`<div class="stmt-filters">
      <div class="field"><label for="${id}-f">Desde</label><input type="date" id="${id}-f" max="${today}"></div>
      <div class="field"><label for="${id}-t">Hasta</label><input type="date" id="${id}-t" value=""></div>
      <div class="btn-row stmt-btns">
        <button type="button" class="btn ghost" data-st-print>${ic('print')} Imprimir</button>
        <button type="button" class="btn ghost" data-st-xls>${ic('download')} Excel</button></div>
    </div>
    <div data-st-body></div>`);
  const calc = () => {
    const r = rangeOf(box, `#${id}-f`, `#${id}-t`);
    return { r, st: statement(opts.ledger(), { balance: opts.balance(), from: r.from, to: r.to }) };
  };
  const paint = () => {
    const { r, st } = calc();
    $('[data-st-body]', box).innerHTML = String(html`
      <ul class="stmt" aria-label="Movimientos">
        <li class="stmt-row stmt-open"><span class="grow">Saldo anterior${r.fromIso ? ` al ${fmtDate(dayStart(r.fromIso))}` : ''}</span><b class="money">${money(st.opening)}</b></li>
        ${[...st.rows].reverse().map(m => html`<li class="stmt-row" data-kind="${m.kind}">
          <span class="grow"><span class="d">${fmtDateTime(m.at)}</span> <span class="t">${m.label}</span>${m.due ? html` <span class="badge warn">vence ${fmtDate(dayStart(m.due))}</span>` : ''}</span>
          <span class="nums"><span class="money ${m.debit ? 'deb' : m.credit ? 'cre' : 'muted'}">${m.debit ? '+' + money(m.debit) : m.credit ? '−' + money(m.credit) : m.cash ? html`(contado ${money(m.cash)})` : '—'}</span>
          <span class="bal money">Saldo ${money(m.balance)}</span></span></li>`)}
        ${!st.rows.length ? html`<li class="empty">No hay movimientos en esas fechas.</li>` : ''}
      </ul>
      <div class="stmt-tot"><span>${opts.debitLabel || 'Debe'}: <b class="money">${money(st.debit)}</b></span>
        <span>${opts.creditLabel || 'Haber'}: <b class="money">${money(st.credit)}</b></span>
        <span>Saldo final: <b class="money" data-st-closing>${money(st.closing)}</b></span></div>`);
  };
  box.addEventListener('change', e => { if (e.target.matches('input[type=date]')) paint(); });
  box.addEventListener('click', async e => {
    if (e.target.closest('[data-st-print]')) {
      const { r, st } = calc();
      await printA4(html`<div class="ticket doc-a4">${printHead(opts.title, [...(opts.subtitle || []), periodText(r)])}
        <table class="ptable"><thead><tr><th>Fecha</th><th>Detalle</th><th class="r">${opts.debitLabel || 'Debe'}</th><th class="r">${opts.creditLabel || 'Haber'}</th><th class="r">Saldo</th></tr></thead><tbody>
        <tr><td></td><td>Saldo anterior</td><td></td><td></td><td class="r">${money(st.opening)}</td></tr>
        ${st.rows.map(m => html`<tr><td>${fmtDate(m.at)}</td><td>${m.label}${m.cash ? html` (contado ${money(m.cash)})` : ''}</td><td class="r">${m.debit ? money(m.debit) : ''}</td><td class="r">${m.credit ? money(m.credit) : ''}</td><td class="r">${money(m.balance)}</td></tr>`)}
        </tbody><tfoot><tr><td></td><td>Totales</td><td class="r">${money(st.debit)}</td><td class="r">${money(st.credit)}</td><td class="r"><b>${money(st.closing)}</b></td></tr></tfoot></table>
        ${opts.balanceHint ? html`<p><b>${opts.balanceHint(st.closing)}</b></p>` : ''}</div>`);
    }
    if (e.target.closest('[data-st-xls]')) {
      const { r, st } = calc();
      const rows = [['fecha', 'detalle', (opts.debitLabel || 'debe').toLowerCase(), (opts.creditLabel || 'haber').toLowerCase(), 'saldo']];
      rows.push([r.fromIso ? fmtDate(dayStart(r.fromIso)) : '', 'Saldo anterior', '', '', fromCents(st.opening)]);
      for (const m of st.rows) rows.push([fmtDateTime(m.at), m.label, m.debit ? fromCents(m.debit) : '', m.credit ? fromCents(m.credit) : '', fromCents(m.balance)]);
      rows.push(['', 'Totales', fromCents(st.debit), fromCents(st.credit), fromCents(st.closing)]);
      await exportTable(`${opts.fileBase || 'estado-de-cuenta'}-${toISODate(Date.now())}`, 'Estado de cuenta', rows);
    }
  });
  paint();
  return { refresh: paint };
}

/** Texto seguro para atributos sueltos */
export const attr = v => raw(esc(v));
