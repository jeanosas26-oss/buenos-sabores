// =====================================================================
// pedidos-prov.js — Pedidos a proveedores y faltantes (punto de pedido), como SGI: se arman desde el stock bajo,
// se imprimen o se mandan por WhatsApp al proveedor y, cuando llega la mercadería, se convierten en compra
// (con lote y vencimiento opcionales).
// =====================================================================
import * as db from '../db.js';
import { ctx, settings, stockOf, currentBranch, multiBranch } from '../ops.js';
import { html, $, on, ic, modal, toast, confirm, raw, icon, exportTable } from '../ui.js';
import { fmtMoney, fmtQty, fmtNum2, fmtDate, parseNum, round2, round3, searchProducts, waLink, norm } from '../logic.js';
import { reorderList, SUPPLIER_ORDER_STATUS, docText } from '../comercial.js';
import { saveSupplierOrder, receiveSupplierOrder } from '../comercial-ops.js';
import { printA4, printHead } from './ctacte.js';

let tab = 'faltantes', fSup = '', fStatus = 'abiertos';
const supName = id => (id && (db.get('suppliers', id) || {}).name) || 'Sin proveedor';
const suppliers = () => db.all('suppliers').filter(s => s.active !== 0).sort((a, b) => String(a.name).localeCompare(String(b.name), 'es'));
const branchTxt = () => (multiBranch() ? ` · ${(currentBranch() || {}).name || ''}` : '');

export function render(main) {
  const paint = () => {
    const sups = suppliers();
    let body;
    if (tab === 'faltantes') {
      const rows = reorderList(db.all('products'), { stockOf: (p, b) => stockOf(p, b), branchId: ctx.branchId, supplierId: fSup === '-' ? '' : fSup }).filter(r => fSup !== '-' || !r.product.supplier_id);
      const bySup = new Map();
      for (const r of rows) { const k = r.product.supplier_id || ''; if (!bySup.has(k)) bySup.set(k, []); bySup.get(k).push(r); }
      body = html`<p class="muted">Productos con stock en el punto de pedido o por debajo${branchTxt()}. El punto de pedido es el “stock mínimo” del producto (o el de cada sucursal).</p>
        <div class="rep-tools"><button type="button" class="btn ghost" data-act="f-print">${ic('print')} Imprimir</button><button type="button" class="btn ghost" data-act="f-xls">${ic('download')} Excel</button></div>
        <p id="f-count"><b>${rows.length}</b> productos para reponer</p>
        ${[...bySup.entries()].map(([sid, list]) => html`<section class="card" data-supgroup="${sid}"><div class="card-head"><h2 style="font-size:1.05rem">${supName(sid)} <span class="badge">${list.length}</span></h2>
          <button type="button" class="btn primary sm" data-mk="${sid}">${ic('truck')} Armar pedido</button></div>
          <div class="table-wrap"><table><thead><tr><th>Producto</th><th class="r">Stock</th><th class="r">Mínimo</th><th class="r">Pedir</th></tr></thead><tbody>
          ${list.map(r => html`<tr><td style="white-space:normal">${r.product.name}</td><td class="r ${r.stock <= 0 ? 'neg' : ''}">${fmtQty(r.stock)}</td><td class="r">${fmtQty(r.min)}</td><td class="r"><b>${fmtQty(r.suggested)}</b></td></tr>`)}</tbody></table></div></section>`)}
        ${!rows.length ? html`<div class="card"><p class="empty">No hay faltantes. Cargá el stock mínimo en los productos para que aparezcan acá.</p></div>` : ''}`;
    } else {
      const list = db.all('supplier_orders').filter(o => (!fSup || (fSup === '-' ? !o.supplier_id : o.supplier_id === fSup)) && (fStatus === 'todos' || (fStatus === 'abiertos' ? ['borrador', 'enviado'].includes(o.status || 'borrador') : o.status === fStatus))).sort((a, b) => b.created_at - a.created_at);
      body = html`<div class="rep-tools"><button type="button" class="btn primary" data-act="new" id="so-new">${ic('plus')} Nuevo pedido</button>
          <div class="field" style="margin:0"><label for="so-st" class="sr-only">Estado</label><select id="so-st"><option value="abiertos" ${fStatus === 'abiertos' ? 'selected' : ''}>Borradores y enviados</option>${Object.entries(SUPPLIER_ORDER_STATUS).map(([k, v]) => html`<option value="${k}" ${fStatus === k ? 'selected' : ''}>${v}</option>`)}<option value="todos" ${fStatus === 'todos' ? 'selected' : ''}>Todos</option></select></div></div>
        <ul class="list" id="so-list">${list.map(o => html`<li><button type="button" class="row" data-so="${o.id}"><span class="grow"><span class="title">Pedido N° ${o.number} · ${supName(o.supplier_id)}</span>
          <span class="sub" style="display:block">${fmtDate(o.created_at)} · ${(o.items || []).length} productos${o.expected_date ? ` · llega ${String(o.expected_date).split('-').reverse().join('/')}` : ''}</span></span>
          <span style="text-align:right"><b class="money">${fmtMoney(o.total)}</b><br><span class="badge ${o.status === 'recibido' ? 'ok' : o.status === 'enviado' ? 'info' : ''}">${SUPPLIER_ORDER_STATUS[o.status || 'borrador']}</span></span></button></li>`)}
          ${!list.length ? html`<li class="empty">No hay pedidos con ese filtro.</li>` : ''}</ul>`;
    }
    main.innerHTML = String(html`<div class="page-head"><h1>Pedidos a proveedores</h1></div>
      <div class="chips" role="group" aria-label="Sección"><button type="button" class="chip" data-tab="faltantes" aria-pressed="${tab === 'faltantes'}">Faltantes (punto de pedido)</button><button type="button" class="chip" data-tab="pedidos" aria-pressed="${tab === 'pedidos'}">Pedidos</button></div>
      <div class="field"><label for="so-sup">Proveedor</label><select id="so-sup"><option value="">Todos</option>${sups.map(s => html`<option value="${s.id}" ${fSup === s.id ? 'selected' : ''}>${s.name}</option>`)}<option value="-" ${fSup === '-' ? 'selected' : ''}>Sin proveedor</option></select></div>
      ${body}`);
    $('#so-sup', main).onchange = e => { fSup = e.target.value; paint(); };
    const st = $('#so-st', main); if (st) st.onchange = e => { fStatus = e.target.value; paint(); };
  };
  paint();
  const faltRows = () => reorderList(db.all('products'), { stockOf: (p, b) => stockOf(p, b), branchId: ctx.branchId, supplierId: fSup === '-' ? '' : fSup }).filter(r => fSup !== '-' || !r.product.supplier_id);
  const offs = [
    on(main, 'click', '[data-tab]', (e, el) => { tab = el.dataset.tab; paint(); }),
    on(main, 'click', '[data-mk]', async (e, el) => {
      const sid = el.dataset.mk;
      const items = faltRows().filter(r => (r.product.supplier_id || '') === sid).map(r => ({ product_id: r.product.id, name: r.product.name, code: r.product.barcode || r.product.sku || '', qty: r.suggested, unit_cost: r.product.cost || 0 }));
      if (await orderForm({ supplier_id: sid || null, items })) { tab = 'pedidos'; paint(); }
    }),
    on(main, 'click', '[data-act]', async (e, el) => {
      const a = el.dataset.act;
      if (a === 'new') { if (await orderForm({ items: [] })) paint(); }
      if (a === 'f-xls') exportTable('faltantes', 'Faltantes', [['Producto', 'Código', 'Proveedor', 'Stock', 'Mínimo', 'Falta', 'Pedir'], ...faltRows().map(r => [r.product.name, r.product.barcode || r.product.sku || '', supName(r.product.supplier_id), r.stock, r.min, r.missing, r.suggested])]);
      if (a === 'f-print') printA4(html`<div class="ticket rep">${printHead('Faltantes · punto de pedido' + branchTxt())}<table class="ptable"><thead><tr><th>Producto</th><th>Proveedor</th><th class="r">Stock</th><th class="r">Mínimo</th><th class="r">Pedir</th></tr></thead><tbody>${faltRows().map(r => html`<tr><td>${r.product.name}</td><td>${supName(r.product.supplier_id)}</td><td class="r">${fmtQty(r.stock)}</td><td class="r">${fmtQty(r.min)}</td><td class="r">${fmtQty(r.suggested)}</td></tr>`)}</tbody></table></div>`);
    }),
    on(main, 'click', '[data-so]', async (e, el) => { await orderDetail(db.get('supplier_orders', el.dataset.so)); paint(); }),
  ];
  return () => offs.forEach(f => f());
}

function orderHTML(o) {
  const s = o.supplier_id ? db.get('suppliers', o.supplier_id) : null;
  return html`<div class="ticket rep">${printHead(`PEDIDO A PROVEEDOR N° ${o.number}`, [`Fecha: ${fmtDate(o.created_at)}`, `Proveedor: ${supName(o.supplier_id)}${s && s.cuit ? ` · CUIT ${s.cuit}` : ''}`, ...(o.expected_date ? [`Entrega: ${String(o.expected_date).split('-').reverse().join('/')}`] : []), ...(settings().address ? [`Entregar en: ${(currentBranch() || {}).address || settings().address}`] : [])])}
    <table class="ptable"><thead><tr><th class="r">Cant.</th><th>Producto</th><th>Código</th></tr></thead><tbody>${(o.items || []).map(it => html`<tr><td class="r">${fmtQty(it.qty)}</td><td>${it.name}</td><td>${it.code || ''}</td></tr>`)}</tbody></table>
    ${o.notes ? html`<p>${o.notes}</p>` : ''}</div>`;
}

async function orderDetail(o) {
  if (!o) return;
  const s = o.supplier_id ? db.get('suppliers', o.supplier_id) : null;
  const open = o.status !== 'recibido' && o.status !== 'anulado';
  const a = await modal({
    title: `Pedido N° ${o.number} · ${supName(o.supplier_id)}`, size: 'wide',
    body: html`<p><span class="badge">${SUPPLIER_ORDER_STATUS[o.status || 'borrador']}</span> · ${fmtDate(o.created_at)}${o.purchase_id ? ' · compra cargada' : ''}</p>
      <div class="table-wrap"><table><thead><tr><th>Producto</th><th class="r">Cant.</th><th class="r">Costo</th></tr></thead><tbody>${(o.items || []).map(it => html`<tr><td style="white-space:normal">${it.name}</td><td class="r">${fmtQty(it.qty)}</td><td class="r">${fmtMoney(it.unit_cost)}</td></tr>`)}</tbody></table></div>
      <p>Total estimado <b class="money">${fmtMoney(o.total)}</b></p>${o.notes ? html`<p class="muted">${o.notes}</p>` : ''}`,
    actions: [
      { label: raw(icon('print') + ' Imprimir'), onClick: () => printA4(orderHTML(o)) },
      { label: raw(icon('whatsapp') + ' WhatsApp'), onClick: () => { window.open(waLink(docText('supplier_order', o, settings(), supName(o.supplier_id)), s ? s.phone : ''), '_blank', 'noopener'); if (o.status === 'borrador' || !o.status) db.put('supplier_orders', { id: o.id, status: 'enviado' }); } },
      ...(open ? [{ label: 'Editar', value: 'edit' }, { label: 'Anular', value: 'void' }, { label: 'Llegó: cargar compra', kind: 'primary', value: 'recv', id: 'so-recv' }] : [{ label: 'Cerrar', kind: 'primary', value: null }]),
    ],
  });
  if (a === 'edit') await orderForm(o);
  if (a === 'void' && await confirm(`¿Anulás el pedido N° ${o.number}?`, { danger: true, ok: 'Anular' })) await db.put('supplier_orders', { id: o.id, status: 'anulado' });
  if (a === 'recv') await receiveForm(db.get('supplier_orders', o.id));
}

/** Armar / editar un pedido */
async function orderForm(o) {
  const items = (o.items || []).map(x => ({ ...x }));
  let sup = o.supplier_id || '';
  return modal({
    title: o.id ? `Pedido N° ${o.number}` : 'Nuevo pedido a proveedor', size: 'wide',
    body: html`<div class="grid2"><div class="field"><label for="of-s">Proveedor</label><select id="of-s"><option value="">— Sin proveedor —</option>${suppliers().map(s => html`<option value="${s.id}" ${s.id === sup ? 'selected' : ''}>${s.name}</option>`)}</select></div>
      <div class="field"><label for="of-d">Fecha de entrega</label><input type="date" id="of-d" value="${o.expected_date || ''}"></div></div>
      <button type="button" class="btn ghost sm" id="of-falt">${ic('alert')} Agregar los faltantes de este proveedor</button>
      <div class="field searchbox" style="margin-top:.6rem">${ic('search')}<label class="sr-only" for="of-q">Buscar producto</label><input id="of-q" type="search" placeholder="Agregar producto" autocomplete="off"></div><div id="of-res" class="results"></div>
      <div id="of-items"></div>
      <div class="field"><label for="of-n">Notas</label><textarea id="of-n" rows="2">${o.notes || ''}</textarea></div>`,
    onMount(m) {
      const paint = () => {
        $('#of-items', m).innerHTML = String(html`<ul class="list">${items.map((it, i) => html`<li class="row"><span class="grow">${it.name}<span class="sub small muted" style="display:block">costo ${fmtMoney(it.unit_cost)}</span></span>
          <input data-oq="${i}" inputmode="decimal" value="${fmtQty(it.qty)}" aria-label="Cantidad de ${it.name}" style="width:5.5rem;text-align:right"><button type="button" class="icon-btn" data-orm="${i}" aria-label="Quitar">${ic('x')}</button></li>`)}
          ${!items.length ? html`<li class="empty">Sin productos todavía.</li>` : ''}</ul><p class="small">${items.length} productos · total estimado <b>${fmtMoney(items.reduce((a, x) => a + round2(x.qty * x.unit_cost), 0))}</b></p>`);
      };
      paint();
      const add = p => { const ex = items.find(x => x.product_id === p.id); if (ex) ex.qty = round3(ex.qty + 1); else items.push({ product_id: p.id, name: p.name, code: p.barcode || p.sku || '', qty: 1, unit_cost: p.cost || 0 }); paint(); };
      $('#of-s', m).onchange = e => { sup = e.target.value; };
      $('#of-falt', m).onclick = () => {
        const rows = reorderList(db.all('products'), { stockOf: (p, b) => stockOf(p, b), branchId: ctx.branchId, supplierId: sup }).filter(r => sup || !r.product.supplier_id);
        let n = 0;
        for (const r of rows) if (!items.some(x => x.product_id === r.product.id)) { items.push({ product_id: r.product.id, name: r.product.name, code: r.product.barcode || r.product.sku || '', qty: r.suggested, unit_cost: r.product.cost || 0 }); n++; }
        paint(); toast(n ? `Se agregaron ${n} faltantes.` : 'No hay faltantes nuevos de ese proveedor.', n ? 'ok' : 'warn');
      };
      $('#of-q', m).oninput = e => {
        const v = e.target.value;
        $('#of-res', m).innerHTML = v.trim() ? String(html`${searchProducts(db.all('products'), v, 8).map(p => html`<button type="button" class="result" data-oadd="${p.id}"><span class="grow">${p.name}</span><span class="small muted">stock ${fmtQty(stockOf(p))}</span></button>`)}`) : '';
      };
      m.addEventListener('click', e => {
        const a = e.target.closest('[data-oadd]'); if (a) { add(db.get('products', a.dataset.oadd)); $('#of-q', m).value = ''; $('#of-res', m).innerHTML = ''; $('#of-q', m).focus(); }
        const r = e.target.closest('[data-orm]'); if (r) { items.splice(Number(r.dataset.orm), 1); paint(); }
      });
      m.addEventListener('input', e => { if (e.target.dataset.oq !== undefined) { const v = parseNum(e.target.value); items[Number(e.target.dataset.oq)].qty = Number.isFinite(v) ? v : 0; } });
    },
    actions: [{ label: 'Cancelar', value: null }, { label: 'Guardar pedido', kind: 'primary', id: 'of-go', onClick: async (close, w) => {
      try { const r = await saveSupplierOrder({ id: o.id, supplier_id: $('#of-s', w).value || null, items, notes: $('#of-n', w).value, expected_date: $('#of-d', w).value }); toast(`Pedido N° ${r.number} guardado.`); close(r); } catch (e) { toast(e.message, 'error'); }
    } }],
  });
}

/** Llegó la mercadería: cantidades y costos reales, lote y vencimiento → compra */
async function receiveForm(o) {
  const rows = (o.items || []).filter(it => it.product_id).map(it => ({ ...it, lot: '', expires_at: '' }));
  return modal({
    title: `Cargar compra del pedido N° ${o.number}`, size: 'wide',
    body: html`<p class="muted">Corregí lo que llegó de verdad. El stock se suma a ${(currentBranch() || {}).name || 'esta sucursal'} y el costo se actualiza. El vencimiento es opcional.</p>
      <ul class="list">${rows.map((it, i) => html`<li style="padding:.5rem 0;border-bottom:1px solid var(--line)"><b>${it.name}</b>
        <div class="grid2" style="grid-template-columns:repeat(auto-fit,minmax(130px,1fr))">
          <div class="field"><label for="rv-q${i}">Llegó</label><input id="rv-q${i}" data-rq="${i}" inputmode="decimal" value="${fmtQty(it.qty)}"></div>
          <div class="field"><label for="rv-c${i}">Costo unit.</label><input id="rv-c${i}" data-rc="${i}" inputmode="decimal" value="${fmtNum2(it.unit_cost)}"></div>
          <div class="field"><label for="rv-l${i}">Lote</label><input id="rv-l${i}" data-rl="${i}"></div>
          <div class="field"><label for="rv-e${i}">Vence</label><input id="rv-e${i}" data-re="${i}" type="date"></div></div></li>`)}</ul>
      <fieldset class="seg"><legend>Pago</legend><label><input type="radio" name="pay" value="contado" checked><span>Contado</span></label><label><input type="radio" name="pay" value="cuenta_corriente" ${o.supplier_id ? '' : 'disabled'}><span>Cuenta corriente</span></label></fieldset>
      <div class="field"><label for="rv-ref">N° de factura / remito</label><input id="rv-ref" autocomplete="off"></div>`,
    onMount(m) {
      m.addEventListener('input', e => {
        const t = e.target, d = t.dataset;
        if (d.rq !== undefined) rows[d.rq].qty = parseNum(t.value) || 0;
        if (d.rc !== undefined) rows[d.rc].unit_cost = parseNum(t.value) || 0;
        if (d.rl !== undefined) rows[d.rl].lot = t.value;
        if (d.re !== undefined) rows[d.re].expires_at = t.value;
      });
      m.addEventListener('change', e => { if (e.target.dataset.re !== undefined) rows[e.target.dataset.re].expires_at = e.target.value; });
    },
    actions: [{ label: 'Cancelar', value: null }, { label: 'Cargar compra', kind: 'primary', id: 'rv-go', onClick: async (close, w) => {
      try {
        const p = await receiveSupplierOrder(o.id, { items: rows, payment: w.querySelector('[name=pay]:checked').value, invoice_ref: $('#rv-ref', w).value });
        toast(`Compra cargada por ${fmtMoney(p.total)}.`); close(p);
      } catch (e) { toast(e.message, 'error', 5000); }
    } }],
  });
}
