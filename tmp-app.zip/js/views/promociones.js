// =====================================================================
// promociones.js — Promociones como SGI: 2x1 / 3x2 (lleva N paga M), % de descuento por producto o rubro,
// precio por cantidad (3 por $ X), combos; con vigencia desde/hasta y sucursales. Se aplican solas en Vender.
// =====================================================================
import * as db from '../db.js';
import { branches, multiBranch } from '../ops.js';
import { html, $, on, ic, modal, toast, confirm } from '../ui.js';
import { fmtMoney, fmtQty, parseNum, searchProducts, toISODate, norm } from '../logic.js';
import { PROMO_KINDS, promoLabel, promoActive, promoError } from '../comercial.js';
import { savePromotion, livePromotions, categoryList, subcategoriesOf } from '../comercial-ops.js';

const stateOf = p => {
  if (p.active === 0) return ['Pausada', ''];
  if (promoActive(p)) return ['Vigente', 'ok'];
  if (p.from && String(p.from) > toISODate(Date.now())) return ['Programada', 'info'];
  return ['Vencida', 'warn'];
};
const scopeText = p => {
  if (p.kind === 'combo') return ((p.params && p.params.items) || []).map(i => `${fmtQty(i.qty)} × ${(db.get('products', i.product_id) || {}).name || '?'}`).join(' + ');
  if ((p.product_ids || []).length) return p.product_ids.map(id => (db.get('products', id) || {}).name || '?').slice(0, 4).join(', ') + (p.product_ids.length > 4 ? ` y ${p.product_ids.length - 4} más` : '');
  return `Rubro ${p.category}${p.subcategory ? ' / ' + p.subcategory : ''}`;
};

export function render(main) {
  const paint = () => {
    const list = livePromotions().sort((a, b) => (stateOf(a)[0] === 'Vigente' ? -1 : 0) - (stateOf(b)[0] === 'Vigente' ? -1 : 0) || String(a.name).localeCompare(String(b.name), 'es'));
    main.innerHTML = String(html`
      <div class="page-head"><h1>Promociones</h1><button type="button" class="btn primary" data-promo="" id="pr-add">${ic('plus')} Nueva promoción</button></div>
      <p class="muted">Se aplican solas al vender (y se ven en el ticket). Cada producto recibe una sola promoción: si entra en dos, gana la que más descuenta.</p>
      <ul class="list" id="promo-list">${list.map(p => { const [s, cls] = stateOf(p); return html`<li><button type="button" class="row" data-promo="${p.id}">
        <span class="grow"><span class="title">${(p.params && p.params.code) ? html`<strong>${p.params.code}</strong> · ` : ''}${p.name} <span class="badge info">${promoLabel(p)}</span></span>
        <span class="sub" style="display:block">${scopeText(p)}${p.from || p.to ? ` · ${p.from ? 'desde ' + p.from.split('-').reverse().join('/') : ''} ${p.to ? 'hasta ' + p.to.split('-').reverse().join('/') : ''}` : ''}${(p.branch_ids || []).length ? ` · ${p.branch_ids.map(id => (db.get('branches', id) || {}).name || '?').join(', ')}` : ''}</span></span>
        <span class="badge ${cls}">${s}</span></button></li>`; })}
        ${!list.length ? html`<li class="empty">Todavía no hay promociones. Tocá “Nueva promoción”.</li>` : ''}</ul>`);
  };
  paint();
  const off = on(main, 'click', '[data-promo]', async (e, el) => { if (await promoForm(el.dataset.promo ? db.get('promotions', el.dataset.promo) : null)) paint(); });
  return off;
}

async function promoForm(p0) {
  const p = p0 ? JSON.parse(JSON.stringify(p0)) : { name: '', kind: 'nxm', product_ids: [], category: '', subcategory: '', params: { n: 2, m: 1 }, from: toISODate(Date.now()), to: '', active: 1, branch_ids: [] };
  let scope = p.category && !(p.product_ids || []).length ? 'rubro' : 'productos';
  const cats = categoryList();
  const catNames = cats.length ? cats.map(c => c.name) : [...new Set(db.all('products').map(x => x.category).filter(Boolean))].sort((a, b) => a.localeCompare(b, 'es'));
  return modal({
    title: p0 ? 'Editar promoción' : 'Nueva promoción',
    size: 'wide',
    body: html`<form id="pf" novalidate>
      <div class="field"><label for="pf-cod">Código (como en SGI, ej. PF)</label><input id="pf-cod" value="${(p.params && p.params.code) || ''}" placeholder="Ej: PF" autocomplete="off" style="text-transform:uppercase"></div>
      <div class="field"><label for="pf-n">Nombre (sale en el ticket)</label><input id="pf-n" value="${p.name}" placeholder="Ej: 2x1 en gaseosas" autocomplete="off"></div>
      <div class="field"><label for="pf-k">Tipo</label><select id="pf-k">${Object.entries(PROMO_KINDS).map(([k, l]) => html`<option value="${k}" ${p.kind === k ? 'selected' : ''}>${l}</option>`)}</select></div>
      <div id="pf-params"></div>
      <div id="pf-scope"></div>
      <div class="grid2"><div class="field"><label for="pf-f">Desde</label><input type="date" id="pf-f" value="${p.from || ''}"></div>
        <div class="field"><label for="pf-t">Hasta</label><input type="date" id="pf-t" value="${p.to || ''}"></div></div>
      ${multiBranch() ? html`<div class="field"><span class="label">Sucursales (ninguna marcada = todas)</span><div class="btn-row">${branches().map(b => html`<label class="check-chip"><input type="checkbox" data-br="${b.id}" ${(p.branch_ids || []).includes(b.id) ? 'checked' : ''}> ${b.name}</label>`)}</div></div>` : ''}
      <label class="check"><input type="checkbox" id="pf-a" ${p.active === 0 ? '' : 'checked'}> Activa</label>
      <p class="field-err" id="pf-err" role="alert"></p></form>`,
    onMount(m) {
      const q = p.params || (p.params = {});
      const paintParams = () => {
        const k = $('#pf-k', m).value;
        p.kind = k;
        const num = (id, label, val, hint = '') => html`<div class="field"><label for="${id}">${label}</label><input id="${id}" inputmode="decimal" value="${val ?? ''}" autocomplete="off">${hint ? html`<p class="hint muted small">${hint}</p>` : ''}</div>`;
        $('#pf-params', m).innerHTML = String(k === 'nxm' ? html`<div class="grid2">${num('pp-n', 'Lleva (N)', q.n ?? 2)}${num('pp-m', 'Paga (M)', q.m ?? 1)}</div>
            <label class="check"><input type="checkbox" id="pp-mix" ${q.mix ? 'checked' : ''}> Se pueden mezclar productos (sale sin cargo el más barato)</label>`
          : k === 'pct' ? html`<div class="grid2">${num('pp-pct', 'Descuento %', q.pct ?? 10)}${num('pp-min', 'Llevando al menos (opcional)', q.min_qty ?? '')}</div>`
            : k === 'precio_cantidad' ? html`<div class="grid2">${num('pp-q', 'Cantidad', q.qty ?? 3)}${num('pp-p', 'Precio por esa cantidad $', q.price ?? '')}</div>
              <label class="check"><input type="checkbox" id="pp-mix" ${q.mix ? 'checked' : ''}> Se pueden mezclar productos</label>`
              : html`${num('pp-p', 'Precio del combo $', q.price ?? '')}`);
        paintScope();
      };
      const paintScope = () => {
        const k = p.kind;
        const box = $('#pf-scope', m);
        if (k === 'combo') {
          const its = q.items || (q.items = []);
          const normal = its.reduce((a, i) => a + (Number((db.get('products', i.product_id) || {}).price) || 0) * Number(i.qty || 0), 0);
          box.innerHTML = String(html`<div class="label">Productos del combo</div>
            <ul class="list">${its.map((i, x) => html`<li class="row"><span class="grow">${(db.get('products', i.product_id) || {}).name || '?'}</span>
              <input data-cq="${x}" inputmode="decimal" value="${fmtQty(i.qty)}" style="width:5rem;text-align:right" aria-label="Cantidad"><button type="button" class="icon-btn" data-crm="${x}" aria-label="Quitar">${ic('x')}</button></li>`)}</ul>
            ${its.length ? html`<p class="small muted">Precio normal ${fmtMoney(normal)}</p>` : ''}${searchBox()}`);
          return;
        }
        box.innerHTML = String(html`<fieldset class="seg"><legend>¿A qué se aplica?</legend>
          <label><input type="radio" name="sc" value="productos" ${scope === 'productos' ? 'checked' : ''}><span>Productos</span></label>
          <label><input type="radio" name="sc" value="rubro" ${scope === 'rubro' ? 'checked' : ''}><span>Rubro / subrubro</span></label></fieldset>
          ${scope === 'rubro' ? html`<div class="grid2"><div class="field"><label for="pf-c">Rubro</label><select id="pf-c"><option value="">Elegí…</option>${catNames.map(c => html`<option ${norm(c) === norm(p.category) ? 'selected' : ''}>${c}</option>`)}</select></div>
            <div class="field"><label for="pf-sc">Subrubro</label><select id="pf-sc"><option value="">Todos</option>${subcategoriesOf(p.category).map(s => html`<option ${norm(s.name) === norm(p.subcategory) ? 'selected' : ''}>${s.name}</option>`)}</select></div></div>`
            : html`<div class="chips" style="flex-wrap:wrap">${(p.product_ids || []).map(id => html`<button type="button" class="chip" data-prm="${id}" aria-label="Quitar ${(db.get('products', id) || {}).name}">${(db.get('products', id) || {}).name || '?'} ✕</button>`)}</div>${searchBox()}`}`);
      };
      const searchBox = () => html`<div class="field searchbox">${ic('search')}<label class="sr-only" for="pf-s">Buscar producto</label><input id="pf-s" type="search" placeholder="Buscar producto para agregar" autocomplete="off"></div><div id="pf-res" class="results"></div>`;
      const readParams = () => {
        const v = id => { const el = $('#' + id, m); return el ? parseNum(el.value) : undefined; };
        if (p.kind === 'nxm') Object.assign(q, { n: v('pp-n'), m: v('pp-m'), mix: !!($('#pp-mix', m) || {}).checked });
        if (p.kind === 'pct') { q.pct = v('pp-pct'); const mn = v('pp-min'); if (Number.isFinite(mn) && mn > 0) q.min_qty = mn; else delete q.min_qty; }
        if (p.kind === 'precio_cantidad') Object.assign(q, { qty: v('pp-q'), price: v('pp-p'), mix: !!($('#pp-mix', m) || {}).checked });
        if (p.kind === 'combo') q.price = v('pp-p');
      };
      m.addEventListener('change', e => {
        if (e.target.id === 'pf-k') { readParams(); paintParams(); }
        if (e.target.name === 'sc') { scope = e.target.value; if (scope === 'rubro') p.product_ids = []; else { p.category = ''; p.subcategory = ''; } paintScope(); }
        if (e.target.id === 'pf-c') { p.category = e.target.value; p.subcategory = ''; paintScope(); }
        if (e.target.id === 'pf-sc') p.subcategory = e.target.value;
      });
      m.addEventListener('input', e => {
        if (e.target.id === 'pf-s') {
          const list = searchProducts(db.all('products'), e.target.value, 8);
          $('#pf-res', m).innerHTML = e.target.value.trim() ? String(html`${list.map(x => html`<button type="button" class="result" data-padd="${x.id}"><span class="grow">${x.name}</span><span class="money">${fmtMoney(x.price)}</span></button>`)}`) : '';
        }
        if (e.target.dataset.cq !== undefined) q.items[Number(e.target.dataset.cq)].qty = parseNum(e.target.value) || 0;
      });
      m.addEventListener('click', e => {
        const a = e.target.closest('[data-padd]');
        if (a) {
          readParams();
          if (p.kind === 'combo') { const ex = q.items.find(i => i.product_id === a.dataset.padd); if (ex) ex.qty += 1; else q.items.push({ product_id: a.dataset.padd, qty: 1 }); }
          else if (!p.product_ids.includes(a.dataset.padd)) p.product_ids.push(a.dataset.padd);
          paintScope(); const s = $('#pf-s', m); if (s) s.focus();
        }
        const r = e.target.closest('[data-prm]'); if (r) { p.product_ids = p.product_ids.filter(id => id !== r.dataset.prm); paintScope(); }
        const c = e.target.closest('[data-crm]'); if (c) { q.items.splice(Number(c.dataset.crm), 1); paintScope(); }
      });
      m.readParams = readParams;
      paintParams();
    },
    actions: [
      ...(p0 ? [{ label: 'Borrar', onClick: async close => { if (await confirm(`¿Borrás la promoción “${p0.name}”?`, { danger: true, ok: 'Borrar' })) { await db.put('promotions', { id: p0.id, deleted: 1 }); toast('Promoción borrada.'); close(true); } } }] : []),
      { label: 'Cancelar', value: null },
      { label: 'Guardar', kind: 'primary', id: 'pf-go', onClick: async (close, w) => {
        const m = $('.modal', w);
        m.readParams();
        p.name = $('#pf-n', w).value; { const c = ($('#pf-cod', w).value || '').trim().toUpperCase(); p.params = p.params || {}; if (c) p.params.code = c; else delete p.params.code; } p.from = $('#pf-f', w).value || null; p.to = $('#pf-t', w).value || null; p.active = $('#pf-a', w).checked ? 1 : 0;
        p.branch_ids = [...w.querySelectorAll('[data-br]')].filter(x => x.checked).map(x => x.dataset.br);
        if (p.kind === 'combo') { p.product_ids = []; p.category = ''; }
        const err = promoError(p);
        if (err) { $('#pf-err', w).textContent = err; return; }
        try { const r = await savePromotion(p); toast('Promoción guardada.'); close(r); } catch (e) { $('#pf-err', w).textContent = e.message; }
      } },
    ],
  });
}
