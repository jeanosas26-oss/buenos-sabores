// =====================================================================
// medios.js — Ajustes → Tarjetas y medios de pago (solo el dueño), como SGI:
// tarjetas de crédito/débito con % de recargo, cuotas máximas y planes por cuotas; medios propios ("Coca Cola").
// =====================================================================
import * as db from '../db.js';
import { html, $, on, ic, modal, toast, fieldError } from '../ui.js';
import { fmtQty, parseNum } from '../logic.js';
import { BASE_METHODS, cardCharge } from '../comercial.js';
import { allCards, saveCard, savePaymentMethod, seedCatalogs } from '../comercial-ops.js';

export async function render(main) {
  await seedCatalogs().catch(e => toast(e.message, 'error'));
  const paint = () => {
    const cards = allCards();
    const pms = db.all('payment_methods');
    const ov = code => pms.find(p => p.code === code);
    const custom = pms.filter(p => !BASE_METHODS.some(b => b.code === p.code)).sort((a, b) => String(a.name).localeCompare(String(b.name), 'es'));
    main.innerHTML = String(html`
      <div class="page-head"><h1>Tarjetas y medios de pago</h1><a class="btn ghost" href="#/ajustes">${ic('back')} Ajustes</a></div>
      <section class="card"><div class="card-head"><h2>Tarjetas</h2><button type="button" class="btn primary sm" data-card="">${ic('plus')} Nueva tarjeta</button></div>
        <p class="muted small">El recargo se suma al total de la venta (y al IVA) cuando se cobra con esa tarjeta. Con “planes” ponés un % distinto según las cuotas (ej. 1 pago 0 %, 3 cuotas 15 %, 6 cuotas 30 %).</p>
        <div class="table-wrap"><table id="cards-t"><thead><tr><th>Tarjeta</th><th>Tipo</th><th class="r">Recargo</th><th class="r">Cuotas</th><th>Estado</th><th></th></tr></thead><tbody>
        ${cards.map(c => html`<tr><td><b>${c.name}</b>${(c.plans || []).length ? html`<div class="small muted">${c.plans.map(p => `${p.installments}c ${fmtQty(p.surcharge_pct)}%`).join(' · ')}</div>` : ''}</td>
          <td>${c.kind === 'debito' ? 'Débito' : 'Crédito'}</td><td class="r">${fmtQty(c.surcharge_pct || 0)} %</td><td class="r">${c.kind === 'debito' ? 1 : c.max_installments || 1}</td>
          <td>${c.active === 0 ? html`<span class="badge">Inactiva</span>` : html`<span class="badge ok">Activa</span>`}</td>
          <td><button type="button" class="btn ghost sm" data-card="${c.id}" aria-label="Editar ${c.name}">${ic('edit')}</button></td></tr>`)}
        </tbody></table></div></section>
      <section class="card"><div class="card-head"><h2>Medios de pago</h2><button type="button" class="btn primary sm" data-pm="">${ic('plus')} Nuevo medio</button></div>
        <p class="muted small">Los fijos se pueden renombrar o desactivar (el efectivo siempre queda). Los propios (como “Coca Cola”, un convenio) aparecen al cobrar y en los informes con su nombre.</p>
        <ul class="list">${BASE_METHODS.map(b => { const o = ov(b.code); return html`<li><button type="button" class="row" data-pmb="${b.code}"><span class="grow"><span class="title">${(o && o.name) || b.name}</span><span class="sub" style="display:block">Fijo${b.affects_cash ? ' · suma a la caja' : ''}</span></span>${o && o.active === 0 ? html`<span class="badge">Inactivo</span>` : html`<span class="badge ok">Activo</span>`}</button></li>`; })}
        ${custom.map(p => html`<li><button type="button" class="row" data-pm="${p.id}"><span class="grow"><span class="title">${p.name}</span><span class="sub" style="display:block">Propio · código ${p.code}${p.affects_cash ? ' · suma a la caja' : ''}</span></span>${p.active === 0 ? html`<span class="badge">Inactivo</span>` : html`<span class="badge ok">Activo</span>`}</button></li>`)}</ul></section>`);
  };
  paint();
  const offs = [
    on(main, 'click', '[data-card]', async (e, el) => { if (await cardForm(el.dataset.card ? db.get('card_types', el.dataset.card) : {})) paint(); }),
    on(main, 'click', '[data-pm]', async (e, el) => { if (await pmForm(el.dataset.pm ? db.get('payment_methods', el.dataset.pm) : {})) paint(); }),
    on(main, 'click', '[data-pmb]', async (e, el) => { const b = BASE_METHODS.find(x => x.code === el.dataset.pmb); const o = db.all('payment_methods').find(p => p.code === b.code); if (await pmForm({ ...b, ...(o || {}), builtin: true })) paint(); }),
  ];
  return () => offs.forEach(f => f());
}

async function cardForm(c) {
  let plans = (c.plans || []).map(p => ({ ...p }));
  return modal({
    title: c.id ? `Tarjeta ${c.name}` : 'Nueva tarjeta',
    body: html`<form id="cf" novalidate>
      <div class="field"><label for="cf-n">Nombre</label><input id="cf-n" value="${c.name || ''}" autocomplete="off"></div>
      <fieldset class="seg"><legend>Tipo</legend>
        <label><input type="radio" name="k" value="credito" ${c.kind !== 'debito' ? 'checked' : ''}><span>Crédito</span></label>
        <label><input type="radio" name="k" value="debito" ${c.kind === 'debito' ? 'checked' : ''}><span>Débito</span></label></fieldset>
      <div class="grid2"><div class="field"><label for="cf-p">Recargo %</label><input id="cf-p" inputmode="decimal" value="${fmtQty(c.surcharge_pct || 0)}"></div>
        <div class="field" id="cf-mf"><label for="cf-m">Cuotas máximas</label><input id="cf-m" inputmode="numeric" value="${c.max_installments || 12}"></div></div>
      <div id="cf-plans"></div>
      <label class="check"><input type="checkbox" id="cf-a" ${c.active === 0 ? '' : 'checked'}> Activa</label>
      <p class="small muted" id="cf-ej" aria-live="polite"></p></form>`,
    onMount(m) {
      const paintPlans = () => {
        const deb = m.querySelector('[name=k]:checked').value === 'debito';
        $('#cf-mf', m).classList.toggle('hidden', deb);
        $('#cf-plans', m).innerHTML = deb ? '' : String(html`<div class="label">Planes por cuotas (opcional)</div>
          ${plans.map((p, i) => html`<div class="pay-line"><input data-pi="${i}" inputmode="numeric" value="${p.installments}" aria-label="Cuotas del plan ${i + 1}" style="text-align:right"><span>cuotas con</span><input data-pp="${i}" inputmode="decimal" value="${fmtQty(p.surcharge_pct)}" aria-label="Recargo del plan ${i + 1}" style="text-align:right"><span>%</span><button type="button" class="icon-btn" data-prm="${i}" aria-label="Quitar plan">${ic('x')}</button></div>`)}
          <button type="button" class="btn ghost sm" id="cf-add">${ic('plus')} Agregar plan</button>`);
        ej();
      };
      const ej = () => { const pct = parseNum($('#cf-p', m).value) || 0; const r = cardCharge(10000, pct, 3); $('#cf-ej', m).textContent = `Ejemplo: $ 10.000 con ${fmtQty(pct)} % → total $ ${r.amount.toLocaleString('es-AR', { minimumFractionDigits: 2 })} (3 cuotas de $ ${r.installment_amount.toLocaleString('es-AR', { minimumFractionDigits: 2 })}).`; };
      m.addEventListener('change', e => { if (e.target.name === 'k') paintPlans(); });
      m.addEventListener('input', e => {
        if (e.target.dataset.pi) plans[e.target.dataset.pi].installments = e.target.value;
        if (e.target.dataset.pp) plans[e.target.dataset.pp].surcharge_pct = e.target.value;
        if (e.target.id === 'cf-p') ej();
      });
      m.addEventListener('click', e => {
        if (e.target.closest('#cf-add')) { plans.push({ installments: plans.length ? Number(plans[plans.length - 1].installments) + 3 : 3, surcharge_pct: 0 }); paintPlans(); }
        const r = e.target.closest('[data-prm]'); if (r) { plans.splice(Number(r.dataset.prm), 1); paintPlans(); }
      });
      paintPlans();
    },
    actions: [{ label: 'Cancelar', value: null }, { label: 'Guardar', kind: 'primary', id: 'cf-go', onClick: async (close, w) => {
      const pct = parseNum($('#cf-p', w).value);
      if (!Number.isFinite(pct) || pct < 0) return fieldError($('#cf-p', w), 'Poné un porcentaje (0 si no tiene recargo).');
      try {
        const r = await saveCard({ id: c.id, name: $('#cf-n', w).value, kind: w.querySelector('[name=k]:checked').value, surcharge_pct: pct, max_installments: parseNum($('#cf-m', w).value),
          plans: plans.map(p => ({ installments: parseNum(p.installments), surcharge_pct: parseNum(p.surcharge_pct) })), active: $('#cf-a', w).checked });
        toast('Tarjeta guardada.'); close(r);
      } catch (e) { toast(e.message, 'error'); }
    } }],
  });
}

async function pmForm(p) {
  return modal({
    title: p.id || p.builtin ? `Medio: ${p.name}` : 'Nuevo medio de pago',
    body: html`<form id="pf" novalidate>
      <div class="field"><label for="pf-n">Nombre</label><input id="pf-n" value="${p.name || ''}" autocomplete="off" placeholder="Ej: Coca Cola"></div>
      ${p.builtin ? '' : html`<div class="field"><label for="pf-k">Tipo</label><select id="pf-k">${[['otro', 'Otro / convenio'], ['transferencia', 'Transferencia'], ['qr', 'QR'], ['mercadopago', 'Billetera virtual'], ['efectivo', 'Efectivo (suma a la caja)']].map(([k, l]) => html`<option value="${k}" ${p.kind === k ? 'selected' : ''}>${l}</option>`)}</select></div>`}
      ${p.code === 'efectivo' ? '' : html`<label class="check"><input type="checkbox" id="pf-a" ${p.active === 0 ? '' : 'checked'}> Activo (aparece al cobrar)</label>`}</form>`,
    actions: [{ label: 'Cancelar', value: null }, { label: 'Guardar', kind: 'primary', id: 'pf-go', onClick: async (close, w) => {
      try {
        const kind = p.builtin ? p.kind : $('#pf-k', w).value;
        const r = await savePaymentMethod({ id: p.builtin ? null : p.id, code: p.builtin ? p.code : null, name: $('#pf-n', w).value, kind, active: $('#pf-a', w) ? $('#pf-a', w).checked : 1, affects_cash: kind === 'efectivo' ? 1 : 0 });
        toast('Medio de pago guardado.'); close(r);
      } catch (e) { toast(e.message, 'error'); }
    } }],
  });
}
