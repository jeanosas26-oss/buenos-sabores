// =====================================================================
// auditoria.js — Pantalla "Auditoría" (solo el dueño): registro de las
// acciones sensibles con filtros, y "Faltantes por cajero" con la marca
// de descontado / justificado.
// =====================================================================
import * as db from '../db.js';
import { userName, multiBranch, branches, branchName } from '../ops.js';
import { html, $, on, ic, modal, toast, exportTable } from '../ui.js';
import { fmtMoney, fmtDateTime, fmtQty, toISODate, dayStart, dayEnd, payLabel } from '../logic.js';
import { filterAudit, auditLabel, AUDIT_ACTIONS, shortagesByCashier } from '../control.js';
import { auditEntries, auditAvailable, markShortage } from '../seguridad.js';

let main;
let tab = 'registro';
const FKEY = 'jg-filtros-auditoria';
const f = { from: toISODate(Date.now() - 7 * 86400000), to: toISODate(Date.now()), user: '', action: '', branch: '', q: '' };
try { const sv = JSON.parse(localStorage.getItem(FKEY) || '{}'); for (const k of ['user', 'action', 'branch']) if (typeof sv[k] === 'string') f[k] = sv[k]; } catch (e) { /* nada */ }
const saveF = () => { try { localStorage.setItem(FKEY, JSON.stringify({ user: f.user, action: f.action, branch: f.branch })); } catch (e) { /* nada */ } };

export async function render(m) {
  main = m;
  await paint();
  const off = on(main, 'click', '[data-tab], [data-aud], [data-act], [data-mark]', async (e, el) => {
    if (el.dataset.tab) { tab = el.dataset.tab; await paint(); return; }
    if (el.dataset.aud) { await detail(el.dataset.aud); return; }
    if (el.dataset.mark) { await mark(el.dataset.mark, el.dataset.status); return; }
    if (el.dataset.act === 'export') await exportAudit();
  });
  const onCh = e => { if (e.target.closest('#au-f')) readF(); };
  let t;
  const onIn = e => { if (e.target.id === 'af-q') { clearTimeout(t); t = setTimeout(readF, 200); } };
  main.addEventListener('change', onCh);
  main.addEventListener('input', onIn);
  return () => { off(); main.removeEventListener('change', onCh); main.removeEventListener('input', onIn); };
}

function readF() {
  if (!$('#au-f', main)) return; // se cambió de pestaña antes de que llegara la búsqueda
  f.from = $('#af-from', main).value || f.from; f.to = $('#af-to', main).value || f.to;
  f.user = $('#af-user', main).value; f.action = $('#af-act', main).value; f.q = $('#af-q', main).value.trim();
  const b = $('#af-br', main); f.branch = b ? b.value : '';
  saveF();
  paintList();
}

let entries = [];

async function paint() {
  entries = await auditEntries();
  const users = db.all('users', { includeDeleted: true }).filter(u => u.name).sort((a, b) => String(a.name).localeCompare(String(b.name), 'es'));
  main.innerHTML = String(html`
    <div class="page-head"><h1>Auditoría</h1>
      ${tab === 'registro' ? html`<button type="button" class="btn ghost" data-act="export">${ic('download')} Exportar Excel</button>` : ''}</div>
    ${auditAvailable() ? '' : html`<div class="notice notice-warn"><p>Esta versión de la base todavía no tiene el registro de auditoría en la nube: lo de este equipo queda guardado acá y se sube cuando se actualice.</p></div>`}
    <div class="chips" role="tablist">
      <button type="button" class="chip" role="tab" data-tab="registro" aria-pressed="${tab === 'registro'}" aria-selected="${tab === 'registro'}">Registro</button>
      <button type="button" class="chip" role="tab" data-tab="faltantes" aria-pressed="${tab === 'faltantes'}" aria-selected="${tab === 'faltantes'}" id="au-tab-f">Faltantes por cajero</button>
    </div>
    ${tab === 'registro' ? html`<form class="card" id="au-f" aria-label="Filtros">
        <div class="grid2">
          <div class="field"><label for="af-from">Desde</label><input id="af-from" type="date" value="${f.from}"></div>
          <div class="field"><label for="af-to">Hasta</label><input id="af-to" type="date" value="${f.to}"></div>
          <div class="field"><label for="af-user">Usuario</label><select id="af-user"><option value="">Todos</option>${users.map(u => html`<option value="${u.id}" ${f.user === u.id ? 'selected' : ''}>${u.name}</option>`)}</select></div>
          <div class="field"><label for="af-act">Acción</label><select id="af-act"><option value="">Todas</option>
            <option value="caja" ${f.action === 'caja' ? 'selected' : ''}>Caja (todo)</option><option value="lote" ${f.action === 'lote' ? 'selected' : ''}>Cambios en lote (todo)</option>
            ${Object.entries(AUDIT_ACTIONS).map(([k, l]) => html`<option value="${k}" ${f.action === k ? 'selected' : ''}>${l}</option>`)}</select></div>
          ${multiBranch() ? html`<div class="field"><label for="af-br">Sucursal</label><select id="af-br"><option value="">Todas</option>${branches({ includeInactive: true }).map(b => html`<option value="${b.id}" ${f.branch === b.id ? 'selected' : ''}>${b.name}</option>`)}</select></div>` : ''}
          <div class="field"><label for="af-q">Buscar</label><input id="af-q" type="search" value="${f.q}" placeholder="Producto, motivo, N° de venta…" autocomplete="off"></div>
        </div></form>
      <p class="muted small" id="au-count" aria-live="polite"></p>
      <div class="card"><ul class="list" id="au-list"></ul></div>` : html`<div id="au-short"></div>`}`);
  const form = $('#au-f', main);
  if (form) form.addEventListener('submit', e => e.preventDefault());
  if (tab === 'registro') paintList(); else paintShortages();
}

function filtered() {
  return filterAudit(entries, { from: dayStart(f.from), to: dayEnd(f.to), user: f.user, action: f.action, branch: f.branch, q: f.q });
}

/** Resumen de una línea del detalle */
export function describe(a) {
  const d = a.detail || {};
  const p = [];
  if (d.name) p.push(d.name);
  if (d.number || d.sale_number) p.push(`Venta N° ${d.number || d.sale_number}`);
  if (d.return_number) p.push(`Devolución N° ${d.return_number}`);
  if (d.old !== undefined && d.price !== undefined) p.push(`${fmtMoney(d.old)} → ${fmtMoney(d.price)}`);
  if (d.before !== undefined && d.after !== undefined) p.push(`stock ${fmtQty(d.before)} → ${fmtQty(d.after)}`);
  if (d.pct !== undefined) p.push(`${d.pct > 0 ? '+' : ''}${String(d.pct).replace('.', ',')} %`);
  if (d.category) p.push(`categoría “${d.category}”`);
  if (d.count) p.push(`${d.count} productos`);
  if (d.amount !== undefined) p.push(fmtMoney(d.amount));
  else if (d.total !== undefined) p.push(fmtMoney(d.total));
  if (d.difference !== undefined && d.difference !== null) p.push(`${d.difference < 0 ? 'faltan' : d.difference > 0 ? 'sobran' : 'justo'} ${d.difference ? fmtMoney(Math.abs(d.difference)) : ''}`.trim());
  if (d.shortage_user_id) p.push(`a cargo de ${userName(d.shortage_user_id)}`);
  if (d.minutes) p.push(`${d.minutes} minutos atrasado`);
  if (d.reason) p.push(`“${d.reason}”`);
  if (d.note) p.push(`“${d.note}”`);
  if (d.what) p.push(d.what);
  return p.join(' · ');
}

function paintList() {
  const list = filtered();
  const box = $('#au-list', main);
  if (!box) return;
  $('#au-count', main).textContent = `${list.length} ${list.length === 1 ? 'registro' : 'registros'}${list.length > 300 ? ' (se muestran los 300 más recientes)' : ''}`;
  box.innerHTML = list.length ? String(html`${list.slice(0, 300).map(a => html`<li><button type="button" class="row" data-aud="${a.id}">
      <span class="grow"><span class="title">${auditLabel(a.action)}</span>
        <span class="sub" style="display:block">${fmtDateTime(a.created_at)} · ${userName(a.user_id)}${a.detail && a.detail.authorized_by ? html` · <b>autorizó ${userName(a.detail.authorized_by)}</b>` : ''}${multiBranch() && a.branch_id ? html` · <span class="branch-tag">${branchName(a.branch_id)}</span>` : ''}</span>
        <span class="sub" style="display:block">${describe(a)}</span></span>
      ${/fallida|faltante|anulada|eliminad|reabierta|reloj/.test(a.action) ? html`<span class="badge ${a.action === 'faltante_justificado' || a.action === 'faltante_descontado' ? 'ok' : 'warn'}">${a.action === 'autorizacion_fallida' ? 'PIN mal' : '!'}</span>` : ''}
    </button></li>`)}`) : String(html`<li class="empty">No hay registros con esos filtros.</li>`);
}

async function detail(id) {
  const a = entries.find(x => x.id === id);
  if (!a) return;
  const d = a.detail || {};
  const fmtV = (k, v) => {
    if (v === null || v === undefined || v === '') return '—';
    if (/(^|_)(at|time)$/.test(k) && typeof v === 'number') return fmtDateTime(v);
    if (/user|_by$/.test(k) && typeof v === 'string') return userName(v);
    if (k === 'payments' || k === 'refunds') return (v || []).map(p => `${payLabel(p.method)} ${fmtMoney(p.amount)}`).join(' + ');
    if (typeof v === 'object') return JSON.stringify(v);
    return String(v);
  };
  await modal({
    title: auditLabel(a.action),
    size: 'wide',
    body: html`<p class="muted">${fmtDateTime(a.created_at)} · ${userName(a.user_id)}${a.branch_id && multiBranch() ? ` · ${branchName(a.branch_id)}` : ''}</p>
      <div class="table-wrap"><table><tbody>
      ${Object.entries(d).filter(([k]) => !['user_name', 'authorized_name'].includes(k)).map(([k, v]) => html`<tr><th style="text-align:left">${k}</th><td style="white-space:normal">${fmtV(k, v)}</td></tr>`)}
      </tbody></table></div>`,
    actions: [{ label: 'Cerrar', kind: 'primary', value: true }],
  });
}

function paintShortages() {
  const box = $('#au-short', main);
  const groups = shortagesByCashier(db.all('cash_sessions'), entries);
  const badge = st => html`<span class="badge ${st === 'pendiente' ? 'err' : 'ok'}">${st === 'pendiente' ? 'Pendiente' : st === 'descontado' ? 'Descontado' : 'Justificado'}</span>`;
  box.innerHTML = groups.length ? String(html`${groups.map(g => html`<div class="card shortage-card" data-cashier="${g.user_id}">
      <div class="card-head"><h2>${userName(g.user_id)}</h2>
        <span class="money"><b>${fmtMoney(g.pending)}</b> pendiente${g.pendingCount !== 1 ? 's' : ''} · ${g.count} ${g.count === 1 ? 'faltante' : 'faltantes'} (${fmtMoney(g.total)} en total)</span></div>
      <ul class="list">${g.items.map(it => html`<li class="row"><span class="grow"><span class="title money">${fmtMoney(it.amount)}</span>
          <span class="sub" style="display:block">Caja del ${fmtDateTime(it.session.opened_at)}${multiBranch() ? ` · ${branchName(it.session.branch_id)}` : ''} · cerró ${userName(it.session.closed_by)}${it.session.blind ? ' (a ciegas)' : ''}</span></span>
          ${badge(it.status)}
          <span class="btn-row" style="flex:none">${it.status === 'pendiente' ? html`
            <button type="button" class="btn sm ghost" data-mark="${it.session.id}" data-status="descontado">Descontado</button>
            <button type="button" class="btn sm ghost" data-mark="${it.session.id}" data-status="justificado">Justificado</button>`
            : html`<button type="button" class="btn sm ghost" data-mark="${it.session.id}" data-status="pendiente">Volver a pendiente</button>`}</span></li>`)}</ul></div>`)}`)
    : String(html`<div class="card"><p class="empty">No hay cajas cerradas con faltante. ${ic('check')}</p></div>`);
}

async function mark(sessionId, status) {
  const s = db.get('cash_sessions', sessionId);
  const note = await modal({
    title: status === 'descontado' ? 'Marcar como descontado' : status === 'justificado' ? 'Marcar como justificado' : 'Volver a pendiente',
    body: html`<p>Faltante de <b class="money">${fmtMoney(Number(s.shortage_amount) || -(Number(s.difference) || 0))}</b> de la caja del ${fmtDateTime(s.opened_at)}.</p>
      <div class="field"><label for="mk-n">${status === 'justificado' ? 'Justificación' : 'Nota'}</label><input id="mk-n" placeholder="${status === 'descontado' ? 'Ej: descontado del sueldo de noviembre' : status === 'justificado' ? 'Ej: error en un vuelto, apareció en otra caja' : 'Motivo'}"></div>
      <p id="mk-err" class="field-err" role="alert"></p>`,
    actions: [{ label: 'Cancelar', value: null }, { label: 'Guardar', kind: 'primary', id: 'mk-go', onClick: (close, w) => {
      const v = $('#mk-n', w).value.trim();
      if (status === 'justificado' && !v) { $('#mk-err', w).textContent = 'Escribí la justificación.'; return; }
      close({ v });
    } }],
  });
  if (!note) return;
  try { await markShortage(sessionId, status, note.v); toast('Guardado en la auditoría.'); } catch (e) { toast(e.message, 'error'); }
  entries = await auditEntries();
  paintShortages();
}

async function exportAudit() {
  const rows = [['fecha', 'accion', 'usuario', 'autorizo', 'sucursal', 'detalle']];
  for (const a of filtered().reverse()) rows.push([fmtDateTime(a.created_at), auditLabel(a.action), userName(a.user_id), a.detail && a.detail.authorized_by ? userName(a.detail.authorized_by) : '', a.branch_id ? branchName(a.branch_id) : '', describe(a)]);
  await exportTable(`auditoria-${f.from}_a_${f.to}`, 'Auditoría', rows);
}
