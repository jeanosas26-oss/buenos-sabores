// =====================================================================
// views/ia.js — Asistente IA (botón "IA" de la barra de arriba): preguntas sobre el comercio.
// A la nube va solo un RESUMEN armado en el equipo (ia-context.js: ventas por día y semana, más vendidos, stock bajo,
// por vencer, caja de hoy y compras recientes; pocos KB y sin datos de clientes), nunca la base entera.
// =====================================================================
import * as db from '../db.js';
import { ctx, settings, stockOf, currentBranch, multiBranch } from '../ops.js';
import { html, $, modal, ic, esc } from '../ui.js';
import { can } from '../logic.js';
import { assistantContext } from '../ia-context.js';
import * as ia from '../ia.js';

export const SUGGESTIONS = ['¿Qué vendí más esta semana?', '¿Qué tengo que pedir?', '¿Qué está por vencer?', '¿Cómo vengo hoy comparado con ayer?'];
const history = []; // [{role, content}] de esta sesión (no se guarda)

/** Resumen de datos para el asistente (de la sucursal del equipo) */
export function buildContext() {
  const b = currentBranch();
  return assistantContext({
    sales: db.all('sales'), returns: db.all('returns'), products: db.all('products'),
    lots: db.COLLECTIONS.includes('product_lots') ? db.all('product_lots') : [],
    sessions: db.all('cash_sessions'), movements: db.all('cash_movements'), purchases: db.all('purchases'), suppliers: db.all('suppliers'),
  }, { now: Date.now(), branchId: ctx.branchId || null, stockOf: (p, br) => stockOf(p, br || ctx.branchId), business: settings().business_name || '', branchName: multiBranch() && b ? b.name : '' });
}

function stateChip(s) {
  if (!s) return html`<span class="ia-state off" id="ia-state">${ia.statusLabel(s, 'text')}</span>`;
  return html`<span class="ia-state ${s.engine === 'claude' ? 'claude' : s.engine === 'off' ? 'off' : ''}" id="ia-state">${ia.statusLabel(s, 'text')}</span>`;
}

const msgHtml = m => html`<div class="ia-msg ${m.role === 'user' ? 'q' : m.err ? 'err' : 'a'}">${m.content}</div>`;

/** Abre el panel del asistente */
export async function openAssistant() {
  if (!ctx.user || !can(ctx.user, 'reportes')) return;
  let st = await ia.aiStatus();
  const shown = history.slice();
  return modal({
    title: 'Asistente IA',
    size: 'wide',
    body: html`<div id="ia-panel">
      <p class="muted small" style="display:flex;flex-wrap:wrap;gap:.5rem;align-items:center">${stateChip(st)}
        <span>Responde con un resumen de los datos de ${multiBranch() && currentBranch() ? esc(currentBranch().name) : 'tu comercio'} (ventas, stock, vencimientos, caja y compras). Revisá los números importantes.</span></p>
      <div class="ia-chat" id="ia-chat" aria-live="polite">${shown.map(msgHtml)}</div>
      <div class="ia-sugs" id="ia-sugs">${SUGGESTIONS.map(t => html`<button type="button" class="chip" data-sug>${t}</button>`)}</div>
      <form class="ia-ask" id="ia-form"><label class="sr-only" for="ia-q">Tu pregunta</label>
        <input id="ia-q" maxlength="500" autocomplete="off" placeholder="Preguntá algo sobre tu comercio">
        <button type="submit" class="btn primary" id="ia-send">${ic('check')} Preguntar</button></form>
      <div id="ia-offer"></div>
    </div>`,
    onMount(m, close) {
      const chat = $('#ia-chat', m), q = $('#ia-q', m), send = $('#ia-send', m);
      const scroll = () => { chat.scrollTop = chat.scrollHeight; };
      const push = msg => { shown.push(msg); chat.insertAdjacentHTML('beforeend', String(msgHtml(msg))); scroll(); };
      const refreshState = async () => { st = await ia.aiStatus({ fresh: true }); const el = $('#ia-state', m); if (el) el.outerHTML = String(stateChip(st)); };
      const askNow = async text => {
        const question = String(text || '').trim();
        if (!question || send.disabled) return;
        q.value = '';
        push({ role: 'user', content: question });
        send.disabled = true; send.textContent = 'Pensando…';
        try {
          const r = await ia.ask(question, buildContext(), history.slice(-6), settings().business_name || '');
          history.push({ role: 'user', content: question }, { role: 'assistant', content: r.answer });
          push({ role: 'assistant', content: r.answer });
        } catch (e) {
          if (e.code === 'AI_LIMIT') {
            push({ role: 'assistant', content: e.message, err: true });
            const owner = can(ctx.user, 'comercio');
            $('#ia-offer', m).innerHTML = String(html`<div class="notice notice-warn" id="ia-limit-offer"><p><b>Llegaste al límite gratis de hoy.</b> Con Claude no hay límite diario (Anthropic le cobra al comercio lo que use).</p>
              ${owner ? html`<p><a class="btn primary" href="#/ajustes" id="ia-go-ajustes" data-close-ia>${ic('gear')} Activar Claude en Ajustes → IA</a></p>` : html`<p>Pedile al dueño que active Claude en Ajustes → IA.</p>`}</div>`);
          } else {
            push({ role: 'assistant', content: e.message || 'No se pudo responder.', err: true });
          }
        } finally {
          send.disabled = false; send.innerHTML = String(html`${ic('check')} Preguntar`);
          refreshState();
          q.focus();
        }
      };
      $('#ia-form', m).addEventListener('submit', e => { e.preventDefault(); askNow(q.value); });
      m.addEventListener('click', e => {
        const s = e.target.closest('[data-sug]');
        if (s) askNow(s.textContent);
        if (e.target.closest('[data-close-ia]')) { e.preventDefault(); close(null); ia.goToAiSettings(); }
      });
      scroll();
      if (st && st.engine === 'off') $('#ia-offer', m).innerHTML = String(html`<div class="notice notice-warn"><p>${st.off_message || 'La IA no está activada en la nube.'}</p></div>`);
    },
    actions: [{ label: 'Cerrar', value: null }],
  });
}
