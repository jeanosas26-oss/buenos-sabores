// =====================================================================
// cheque-ui.js — Piezas de pantalla para usar cheques como medio: datos de un cheque nuevo (recibido)
// y lista de cheques en cartera para elegir (entregar). Las usan caja, gastos, compras, cobros y pagos.
// =====================================================================
import { html, $ } from '../ui.js';
import { fmtMoney, fmtDate, parseNum, dayStart, toISODate } from '../logic.js';
import { banks, chequesInWallet, bankName } from '../tesoreria-ops.js';
import { daysToDue } from '../tesoreria-calc.js';

/** Campos de un cheque recibido. p = prefijo de los ids. withAmount: pide el importe (si no, usa el del movimiento) */
export function chequeFieldsHTML(p, { withAmount = true } = {}) {
  const in30 = toISODate(Date.now() + 30 * 86400000);
  return html`<div class="grid2 cheque-fields">
    <div class="field"><label for="${p}-bank">Banco</label><select id="${p}-bank"><option value="">— Elegí —</option>${banks().map(b => html`<option value="${b.id}">${b.name}</option>`)}</select></div>
    <div class="field"><label for="${p}-num">N° de cheque</label><input id="${p}-num" inputmode="numeric" autocomplete="off"></div>
    ${withAmount ? html`<div class="field"><label for="${p}-amt">Importe del cheque</label><input id="${p}-amt" class="money-input" inputmode="decimal" autocomplete="off" placeholder="0,00"></div>` : ''}
    <div class="field"><label for="${p}-due">Fecha de cobro</label><input id="${p}-due" type="date" value="${in30}"></div>
    <div class="field"><label for="${p}-holder">Librador (titular)</label><input id="${p}-holder" autocomplete="off"></div>
    <div class="field"><label for="${p}-cuit">CUIT del librador <span class="muted">(opcional)</span></label><input id="${p}-cuit" inputmode="numeric" autocomplete="off"></div>
  </div>`;
}

/** Lee los campos de un cheque nuevo */
export function readCheque(root, p, amount = null) {
  const v = id => ($(`#${p}-${id}`, root) || { value: '' }).value;
  return {
    bank_id: v('bank') || null, number: v('num').trim(), amount: amount ?? parseNum(v('amt')), due_date: v('due'),
    holder: v('holder').trim(), cuit: v('cuit').trim(), issue_date: toISODate(Date.now()),
  };
}

/** Lista para elegir cheques de la cartera (checkbox data-wc con el importe en data-amt) */
export function walletPickerHTML(name = 'wc') {
  const list = chequesInWallet();
  if (!list.length) return html`<p class="muted small">No hay cheques en cartera.</p>`;
  return html`<ul class="list wallet">${list.map(c => {
    const d = daysToDue(c.due_date);
    return html`<li><label class="check row" style="margin:0"><input type="checkbox" data-${name}="${c.id}" data-amt="${c.amount}">
      <span class="grow"><span class="title">${bankName(c.bank_id) || 'Cheque'} N° ${c.number}</span>
      <span class="sub" style="display:block">Cobro ${fmtDate(dayStart(c.due_date))}${d !== null && d < 0 ? ' · vencido' : d !== null && d <= 7 ? ` · vence en ${d} días` : ''}${c.holder ? ` · ${c.holder}` : ''}</span></span>
      <b class="money">${fmtMoney(c.amount)}</b></label></li>`;
  })}</ul>`;
}

/** Ids y suma (centavos) de los cheques tildados */
export function pickedCheques(root, name = 'wc') {
  const els = [...root.querySelectorAll(`[data-${name}]:checked`)];
  return { ids: els.map(e => e.getAttribute('data-' + name)), cents: els.reduce((a, e) => a + Math.round(Number(e.dataset.amt) * 100), 0) };
}
