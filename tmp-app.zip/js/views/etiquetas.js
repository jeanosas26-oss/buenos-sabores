// =====================================================================
// etiquetas.js — Etiquetas y carteles de precio para góndola (hoja A4 con varias): nombre, precio grande, código
// de barras EAN-13 dibujado en SVG propio, precio por kilo / litro (ley de góndola) y fecha.
// Se eligen por rubro, proveedor, los que cambiaron de precio desde una fecha, o uno por uno.
// =====================================================================
import * as db from '../db.js';
import { settings } from '../ops.js';
import { html, raw, $, on, ic, toast } from '../ui.js';
import { fmtMoney, fmtDate, searchProducts, toISODate, dayStart, norm } from '../logic.js';
import { eanSvg, unitPriceInfo, LABEL_SIZES, labelPages, promoActive, promoLabel, promoCovers } from '../comercial.js';
import { priceChangedIds, livePromotions } from '../comercial-ops.js';

const opts = { size: 'mediana', barcode: true, date: true, unit: true, oferta: false, by: 'cambios', cat: '', sup: '', since: toISODate(Date.now() - 7 * 86400000), q: '' };
const picked = new Set();

function candidates() {
  const all = db.all('products').filter(p => p.active !== 0);
  if (opts.by === 'rubro') return opts.cat ? all.filter(p => norm(p.category) === norm(opts.cat)) : [];
  if (opts.by === 'proveedor') return opts.sup ? all.filter(p => p.supplier_id === opts.sup) : [];
  if (opts.by === 'cambios') { const ids = priceChangedIds(dayStart(opts.since)); return all.filter(p => ids.has(p.id)); }
  if (opts.by === 'promos') { const pr = livePromotions().filter(x => promoActive(x)); return all.filter(p => pr.some(x => promoCovers(x, p) || ((x.params || {}).items || []).some(i => i.product_id === p.id))); }
  return opts.q.trim() ? searchProducts(all, opts.q, 40) : [];
}

/** HTML de una etiqueta */
function labelHTML(p) {
  const up = opts.unit ? unitPriceInfo(p) : null;
  const pr = opts.oferta ? livePromotions().find(x => promoActive(x) && promoCovers(x, p)) : null;
  const [ent, dec] = Number(p.price).toFixed(2).split('.');
  const priceTxt = `$ ${Number(ent).toLocaleString('es-AR')}`;
  return html`<div class="lbl lbl-${opts.size}">
    ${opts.oferta ? html`<div class="lo">${pr ? promoLabel(pr).toUpperCase() : 'OFERTA'}</div>` : ''}
    <div class="ln">${p.name}</div>
    <div class="lp">${priceTxt}<small>,${dec}</small>${p.unit === 'kg' ? html`<small> /kg</small>` : ''}</div>
    ${up && p.unit !== 'kg' ? html`<div class="lu">Precio por ${up.unit === 'kg' ? 'kilo' : 'litro'}: ${fmtMoney(up.price)}</div>` : ''}
    ${opts.barcode && p.barcode && opts.size !== 'oferta' ? html`<div class="lb">${raw(eanSvg(p.barcode, { height: 40 }) || `<span class="lu">${p.barcode}</span>`)}</div>` : ''}
    ${opts.date ? html`<div class="ld">${settings().business_name || ''} · ${fmtDate(Date.now())}</div>` : ''}
  </div>`;
}

function sheetsHTML(list) {
  const S = LABEL_SIZES[opts.size];
  return html`${labelPages(list, opts.size).map(pg => html`<div class="lbl-page" style="grid-template-columns:repeat(${S.cols},1fr)">${pg.map(labelHTML)}</div>`)}`;
}

export function render(main) {
  const cats = [...new Set(db.all('products').map(p => p.category).filter(Boolean))].sort((a, b) => a.localeCompare(b, 'es'));
  const sups = db.all('suppliers').sort((a, b) => String(a.name).localeCompare(String(b.name), 'es'));
  main.innerHTML = String(html`
    <div class="page-head"><h1>Etiquetas de góndola</h1><a class="btn ghost" href="#/productos">${ic('back')} Productos</a></div>
    <div class="card">
      <div class="filters">
        <div class="field"><label for="et-by">Elegir productos</label><select id="et-by">${[['cambios', 'Cambiaron de precio desde…'], ['rubro', 'Por rubro'], ['proveedor', 'Por proveedor'], ['promos', 'Con promoción vigente'], ['buscar', 'Buscar uno por uno']].map(([k, l]) => html`<option value="${k}" ${opts.by === k ? 'selected' : ''}>${l}</option>`)}</select></div>
        <div class="field" data-by="cambios"><label for="et-since">Desde</label><input type="date" id="et-since" value="${opts.since}"></div>
        <div class="field" data-by="rubro"><label for="et-cat">Rubro</label><select id="et-cat"><option value="">Elegí…</option>${cats.map(c => html`<option ${c === opts.cat ? 'selected' : ''}>${c}</option>`)}</select></div>
        <div class="field" data-by="proveedor"><label for="et-sup">Proveedor</label><select id="et-sup"><option value="">Elegí…</option>${sups.map(s => html`<option value="${s.id}" ${s.id === opts.sup ? 'selected' : ''}>${s.name}</option>`)}</select></div>
        <div class="field" data-by="buscar"><label for="et-q">Buscar</label><input id="et-q" type="search" value="${opts.q}" autocomplete="off" placeholder="Nombre o código"></div>
        <div class="field"><label for="et-size">Tamaño</label><select id="et-size">${Object.entries(LABEL_SIZES).map(([k, v]) => html`<option value="${k}" ${opts.size === k ? 'selected' : ''}>${v.name}</option>`)}</select></div>
      </div>
      <div class="chips" style="flex-wrap:wrap">
        <label class="chip check-chip"><input type="checkbox" id="et-bc" ${opts.barcode ? 'checked' : ''}> Código de barras</label>
        <label class="chip check-chip"><input type="checkbox" id="et-un" ${opts.unit ? 'checked' : ''}> Precio por kilo / litro</label>
        <label class="chip check-chip"><input type="checkbox" id="et-dt" ${opts.date ? 'checked' : ''}> Fecha</label>
        <label class="chip check-chip"><input type="checkbox" id="et-of" ${opts.oferta ? 'checked' : ''}> Cartel de OFERTA</label></div>
    </div>
    <div class="rep-tools"><button type="button" class="btn ghost sm" data-act="all">Marcar todos</button><button type="button" class="btn ghost sm" data-act="none">Ninguno</button>
      <button type="button" class="btn primary" data-act="print" id="et-print">${ic('print')} Imprimir <span id="et-n"></span></button></div>
    <div class="grid2" style="grid-template-columns:repeat(auto-fit,minmax(min(100%,320px),1fr));gap:1rem">
      <div><div class="pick-list" id="et-list"></div></div>
      <div><p class="small muted">Vista previa (primera hoja)</p><div class="labels-prev" id="et-prev"></div></div></div>`);
  const sel = () => candidates().filter(p => picked.has(p.id));
  const paint = () => {
    main.querySelectorAll('[data-by]').forEach(el => el.classList.toggle('hidden', el.dataset.by !== opts.by));
    const list = candidates();
    $('#et-list', main).innerHTML = list.length ? String(html`${list.slice(0, 500).map(p => html`<label><input type="checkbox" data-pk="${p.id}" ${picked.has(p.id) ? 'checked' : ''}> <span class="grow">${p.name}</span> <b class="money">${fmtMoney(p.price)}</b></label>`)}`)
      : String(html`<p class="empty">${opts.by === 'cambios' ? 'No hay cambios de precio registrados desde esa fecha.' : 'Elegí un rubro, un proveedor o buscá productos.'}</p>`);
    const s = sel();
    $('#et-n', main).textContent = s.length ? `(${s.length})` : '';
    $('#et-print', main).disabled = !s.length;
    const per = LABEL_SIZES[opts.size].cols * LABEL_SIZES[opts.size].rows;
    const box = $('#et-prev', main);
    box.innerHTML = s.length ? String(html`<div class="prev-scale"><div class="prev-a4">${sheetsHTML(s.slice(0, per))}</div></div><p class="small muted">${labelPages(s, opts.size).length} hoja(s) A4</p>`) : '<p class="empty">Marcá los productos.</p>';
    // La vista previa es la hoja A4 real (200 mm ≈ 756 px) achicada al ancho de la pantalla
    const a4 = box.querySelector('.prev-a4');
    if (a4) { const k = Math.min(1, (box.clientWidth - 16) / 756); a4.style.transform = `scale(${k})`; a4.parentElement.style.height = Math.ceil(a4.offsetHeight * k) + 'px'; }
  };
  const autoPick = () => { picked.clear(); if (opts.by !== 'buscar') for (const p of candidates()) picked.add(p.id); };
  autoPick(); paint();
  const read = () => {
    opts.by = $('#et-by', main).value; opts.since = $('#et-since', main).value || opts.since; opts.cat = $('#et-cat', main).value; opts.sup = $('#et-sup', main).value;
    opts.size = $('#et-size', main).value; opts.barcode = $('#et-bc', main).checked; opts.unit = $('#et-un', main).checked; opts.date = $('#et-dt', main).checked; opts.oferta = $('#et-of', main).checked;
  };
  const onChange = e => {
    if (e.target.dataset.pk) { if (e.target.checked) picked.add(e.target.dataset.pk); else picked.delete(e.target.dataset.pk); paint(); return; }
    const before = `${opts.by}|${opts.cat}|${opts.sup}|${opts.since}`;
    read();
    if (before !== `${opts.by}|${opts.cat}|${opts.sup}|${opts.since}`) autoPick();
    paint();
  };
  main.addEventListener('change', onChange);
  let t;
  const onInput = e => { if (e.target.id === 'et-q') { clearTimeout(t); t = setTimeout(() => { opts.q = e.target.value; paint(); }, 150); } };
  main.addEventListener('input', onInput);
  const off = on(main, 'click', '[data-act]', (e, el) => {
    const a = el.dataset.act;
    if (a === 'all') { for (const p of candidates()) picked.add(p.id); paint(); }
    if (a === 'none') { picked.clear(); paint(); }
    if (a === 'print') {
      const s = sel();
      if (!s.length) return toast('Marcá al menos un producto.', 'warn');
      const area = document.querySelector('#print-area');
      area.className = 'labels';
      area.innerHTML = String(sheetsHTML(s));
      setTimeout(() => window.print(), 120);
    }
  });
  return () => { off(); main.removeEventListener('change', onChange); main.removeEventListener('input', onInput); };
}
