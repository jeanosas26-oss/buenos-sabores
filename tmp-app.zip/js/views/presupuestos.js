// =====================================================================
// presupuestos.js — Presupuestos y Pedidos de clientes (como SGI): se arman desde el carrito de Vender, se imprimen
// (A4) o se mandan por WhatsApp, y se convierten en venta en un toque (vuelven al carrito y se cobran).
// =====================================================================
import * as db from '../db.js';
import { ctx, settings } from '../ops.js';
import { html, $, on, ic, modal, toast, confirm, raw, icon } from '../ui.js';
import { fmtMoney, fmtQty, fmtDate, toISODate, norm, waLink } from '../logic.js';
import { QUOTE_STATUS, ORDER_STATUS, quoteStatus, cartFromDoc, docText } from '../comercial.js';
import { saveCustomerDoc, setDocStatus, DOC_COLLS } from '../comercial-ops.js';
import { printA4, printHead } from './ctacte.js';
import { pickCustomer } from './clientes.js';

const KINDS = { quote: { title: 'Presupuestos', one: 'Presupuesto', status: QUOTE_STATUS }, order: { title: 'Pedidos de clientes', one: 'Pedido', status: ORDER_STATUS } };
let tab = 'quote', fStatus = 'abiertos', q = '';
const custName = d => (d.customer_id && (db.get('customers', d.customer_id) || {}).name) || d.customer_name || 'Consumidor final';
const statusOf = (kind, d) => (kind === 'quote' ? quoteStatus(d) : d.status || 'pendiente');
const dateTxt = iso => (iso ? fmtDate(new Date(String(iso).slice(0, 10) + 'T12:00').getTime()) : '');

export function render(main, app) {
  try { const t = sessionStorage.getItem('jg_pres_tab'); if (t && KINDS[t]) tab = t; } catch (e) { /* nada */ }
  const paint = () => {
    const K = KINDS[tab];
    const coll = DOC_COLLS[tab];
    const all = db.COLLECTIONS.includes(coll) ? db.all(coll) : [];
    const list = all.filter(d => {
      const s = statusOf(tab, d);
      if (fStatus === 'abiertos' && !['abierto', 'pendiente', 'preparado'].includes(s)) return false;
      if (fStatus !== 'abiertos' && fStatus !== 'todos' && s !== fStatus) return false;
      if (q && !norm(`${d.number} ${custName(d)} ${(d.items || []).map(i => i.name).join(' ')} ${d.notes || ''}`).includes(norm(q))) return false;
      return true;
    }).sort((a, b) => b.created_at - a.created_at);
    const open = all.filter(d => ['abierto', 'pendiente', 'preparado'].includes(statusOf(tab, d)));
    main.innerHTML = String(html`
      <div class="page-head"><h1>Presupuestos y pedidos</h1>
        <a class="btn primary" href="#/vender" id="pr-new">${ic('plus')} Nuevo desde Vender</a></div>
      <div class="chips" role="group" aria-label="Tipo">${Object.entries(KINDS).map(([k, v]) => html`<button type="button" class="chip" data-tab="${k}" aria-pressed="${k === tab}">${v.title}</button>`)}</div>
      <p class="muted small">Cargá los productos en <b>Vender</b> y tocá <b>“Presupuesto / pedido”</b>. Desde acá se imprimen, se mandan por WhatsApp y se venden en un toque.</p>
      <div class="stats"><div class="stat"><div class="k">${tab === 'quote' ? 'Vigentes' : 'Por entregar'}</div><div class="v" id="pr-open">${open.length}</div></div>
        <div class="stat"><div class="k">Total ${tab === 'quote' ? 'presupuestado' : 'pedido'}</div><div class="v money">${fmtMoney(open.reduce((a, d) => a + (Number(d.total) || 0), 0))}</div></div></div>
      <div class="filters">
        <div class="field"><label for="pr-q">Buscar</label><input id="pr-q" type="search" value="${q}" placeholder="N°, cliente o producto"></div>
        <div class="field"><label for="pr-s">Estado</label><select id="pr-s">
          <option value="abiertos" ${fStatus === 'abiertos' ? 'selected' : ''}>${tab === 'quote' ? 'Vigentes' : 'Pendientes y preparados'}</option>
          ${Object.entries(K.status).map(([k, v]) => html`<option value="${k}" ${fStatus === k ? 'selected' : ''}>${v}</option>`)}
          <option value="todos" ${fStatus === 'todos' ? 'selected' : ''}>Todos</option></select></div>
      </div>
      <ul class="list" id="pr-list">${list.slice(0, 300).map(d => html`<li><button type="button" class="row" data-doc="${d.id}">
        <span class="grow"><span class="title">${K.one} N° ${d.number} · ${custName(d)}</span>
          <span class="sub" style="display:block">${fmtDate(d.created_at)} · ${(d.items || []).length} productos${d.valid_until ? ` · vence ${dateTxt(d.valid_until)}` : ''}${d.delivery_date ? ` · entrega ${dateTxt(d.delivery_date)}` : ''}</span></span>
        <span class="nums" style="text-align:right"><b class="money">${fmtMoney(d.total)}</b><br><span class="badge ${badgeCls(statusOf(tab, d))}">${K.status[statusOf(tab, d)] || statusOf(tab, d)}</span></span>
      </button></li>`)}${!list.length ? html`<li class="empty">No hay ${K.title.toLowerCase()} ${fStatus === 'todos' ? '' : 'con ese filtro'}.</li>` : ''}</ul>`);
    const qi = $('#pr-q', main);
    qi.oninput = () => { q = qi.value; const pos = qi.selectionStart; paint(); const n = $('#pr-q', main); n.focus(); n.setSelectionRange(pos, pos); };
    $('#pr-s', main).onchange = e => { fStatus = e.target.value; paint(); };
  };
  paint();
  const offs = [
    on(main, 'click', '[data-tab]', (e, el) => { tab = el.dataset.tab; fStatus = 'abiertos'; try { sessionStorage.setItem('jg_pres_tab', tab); } catch (x) { /* nada */ } paint(); }),
    on(main, 'click', '[data-doc]', async (e, el) => { await docDetail(tab, db.get(DOC_COLLS[tab], el.dataset.doc), app); if (main.isConnected) paint(); }),
  ];
  return () => offs.forEach(f => f());
}
const badgeCls = s => ({ convertido: 'ok', anulado: '', vencido: 'warn', preparado: 'ok' })[s] || '';

/** HTML A4 de presupuesto / pedido */
export function docHTML(kind, d) {
  const st = settings();
  const c = d.customer_id ? db.get('customers', d.customer_id) : null;
  const K = KINDS[kind];
  return html`<div class="ticket">${printHead(`${K.one.toUpperCase()} N° ${d.number}`, [
    `Fecha: ${fmtDate(d.created_at)}`, `Cliente: ${custName(d)}${c && c.doc_number ? ` · ${c.doc_type} ${c.doc_number}` : ''}${c && c.phone ? ` · Tel. ${c.phone}` : ''}`,
    ...(d.valid_until ? [`Válido hasta: ${dateTxt(d.valid_until)}`] : []), ...(d.delivery_date ? [`Entrega: ${dateTxt(d.delivery_date)}`] : []),
    ...(st.address ? [st.address] : []), ...(st.phone ? [`Tel. ${st.phone}`] : []),
  ])}
    <table class="ptable"><thead><tr><th>Cant.</th><th>Producto</th><th class="r">Precio</th><th class="r">Importe</th></tr></thead>
    <tbody>${(d.items || []).map(it => html`<tr><td>${fmtQty(it.qty)}${it.unit === 'kg' ? ' kg' : ''}</td><td>${it.name}</td><td class="r">${fmtMoney(it.unit_price)}</td><td class="r">${fmtMoney((it.subtotal || 0) + (it.discount || 0))}</td></tr>`)}</tbody>
    <tfoot>${Number(d.discount) > 0 ? html`<tr><td colspan="3">Descuento</td><td class="r">-${fmtMoney(d.discount)}</td></tr>` : ''}<tr><td colspan="3">TOTAL</td><td class="r">${fmtMoney(d.total)}</td></tr></tfoot></table>
    ${d.notes ? html`<p>${d.notes}</p>` : ''}
    <p class="small">${kind === 'quote' ? 'Presupuesto sin valor fiscal. Precios sujetos a cambio después de la fecha de validez.' : 'Pedido sin valor fiscal.'}</p></div>`;
}

function shareDoc(kind, d) {
  const c = d.customer_id ? db.get('customers', d.customer_id) : null;
  window.open(waLink(docText(kind, d, settings(), custName(d)), c ? c.phone : ''), '_blank', 'noopener');
}

/** Ficha de un presupuesto / pedido con sus acciones */
async function docDetail(kind, d, app) {
  if (!d) return;
  const K = KINDS[kind];
  const s = statusOf(kind, d);
  const done = s === 'convertido' || s === 'anulado';
  const sale = d.converted_sale_id ? db.get('sales', d.converted_sale_id) : null;
  const act = await modal({
    title: `${K.one} N° ${d.number}`,
    size: 'wide',
    body: html`<p><span class="badge ${badgeCls(s)}">${K.status[s] || s}</span> · ${fmtDate(d.created_at)} · ${custName(d)}${sale ? html` · Venta N° ${sale.number}` : ''}</p>
      <div class="table-wrap"><table><thead><tr><th>Producto</th><th class="r">Cant.</th><th class="r">Precio</th><th class="r">Importe</th></tr></thead>
      <tbody>${(d.items || []).map(it => html`<tr><td style="white-space:normal">${it.name}</td><td class="r">${fmtQty(it.qty)}</td><td class="r">${fmtMoney(it.unit_price)}</td><td class="r">${fmtMoney(it.subtotal)}</td></tr>`)}</tbody></table></div>
      ${Number(d.discount) > 0 ? html`<p class="muted">Descuento: -${fmtMoney(d.discount)}</p>` : ''}
      <p class="lead">Total <b class="money" id="pd-total">${fmtMoney(d.total)}</b></p>
      ${d.notes ? html`<p class="muted">${d.notes}</p>` : ''}
      ${s === 'vencido' ? html`<div class="notice notice-warn"><p>Venció el ${dateTxt(d.valid_until)}. Al venderlo podés usar los precios de hoy.</p></div>` : ''}`,
    actions: [
      { label: raw(icon('print') + ' Imprimir'), onClick: () => printA4(docHTML(kind, d)) },
      { label: raw(icon('whatsapp') + ' WhatsApp'), onClick: () => shareDoc(kind, d) },
      ...(!done ? [{ label: 'Anular', value: 'anular' }] : []),
      ...(kind === 'order' && s === 'pendiente' ? [{ label: 'Preparado', value: 'preparado' }] : []),
      ...(!done ? [{ label: raw(icon('cart') + ' Vender'), kind: 'primary', value: 'vender', id: 'pd-sell' }] : [{ label: 'Cerrar', kind: 'primary', value: null }]),
    ],
  });
  if (act === 'anular') { if (await confirm(`¿Anulás el ${K.one.toLowerCase()} N° ${d.number}?`, { danger: true, ok: 'Anular' })) { await setDocStatus(kind, d.id, 'anulado'); toast('Anulado.'); } }
  if (act === 'preparado') { await setDocStatus(kind, d.id, 'preparado'); toast('Marcado como preparado.'); }
  if (act === 'vender') await sellDoc(kind, d, app);
}

/** Pasa el presupuesto / pedido al carrito de Vender (al cobrarlo queda "convertido") */
export async function sellDoc(kind, d, app) {
  let current = false;
  if (kind === 'quote' && quoteStatus(d) === 'vencido') {
    current = await confirm('El presupuesto está vencido. ¿Lo vendés con los precios de hoy?', { title: 'Presupuesto vencido', ok: 'Precios de hoy', cancel: 'Precios del presupuesto' });
  }
  const r = cartFromDoc(d, id => db.get('products', id), { current });
  if (!r.cart.length) { toast('Ninguno de los productos sigue a la venta.', 'warn'); return; }
  if (r.missing.length) toast(`Quedaron afuera (ya no están a la venta): ${r.missing.join(', ')}`, 'warn', 6000);
  const { loadIntoCart } = await import('./vender.js');
  loadIntoCart({ cart: r.cart, customer_id: d.customer_id || null, discount: current ? 0 : Number(d.discount) || 0, source: { kind, id: d.id, number: d.number }, observations: d.notes || '' });
  if (app) app.navigate('vender'); else location.hash = '#/vender';
  toast(`${KINDS[kind].one} N° ${d.number} en el carrito: revisalo y cobrá.`, 'ok', 3500);
}

/** Desde Vender: guardar el carrito como presupuesto o pedido */
export async function saveAsDocModal({ cart, customer_id = null, discount = 0, notes = '', source = null }) {
  let cust = customer_id;
  const plus = n => toISODate(Date.now() + n * 86400000);
  const r = await modal({
    title: 'Guardar como presupuesto o pedido',
    body: html`<form id="sd" novalidate>
      <fieldset class="seg"><legend>¿Qué es?</legend>
        <label><input type="radio" name="k" value="quote" ${!source || source.kind === 'quote' ? 'checked' : ''}><span>Presupuesto</span></label>
        <label><input type="radio" name="k" value="order" ${source && source.kind === 'order' ? 'checked' : ''}><span>Pedido de cliente</span></label></fieldset>
      <div class="field"><span class="label">Cliente</span><button type="button" class="btn ghost block" id="sd-cust">${ic('user')} <span id="sd-cn">${cust ? (db.get('customers', cust) || {}).name : 'Consumidor final'}</span></button></div>
      <div class="field" id="sd-vf"><label for="sd-v">Válido hasta</label><input type="date" id="sd-v" value="${plus(15)}"></div>
      <div class="field hidden" id="sd-df"><label for="sd-d">Fecha de entrega</label><input type="date" id="sd-d" value="${plus(1)}"></div>
      <div class="field"><label for="sd-n">Notas</label><textarea id="sd-n" rows="2" maxlength="500">${notes}</textarea></div>
      <p class="muted small">${cart.length} productos${discount > 0 ? ` · descuento ${fmtMoney(discount)}` : ''}. Las promociones se aplican al vender.</p></form>`,
    onMount(m) {
      const sync = () => { const k = m.querySelector('[name=k]:checked').value; $('#sd-vf', m).classList.toggle('hidden', k !== 'quote'); $('#sd-df', m).classList.toggle('hidden', k !== 'order'); };
      m.addEventListener('change', sync); sync();
      $('#sd-cust', m).onclick = async () => { const id = await pickCustomer(cust); if (id !== undefined) { cust = id; $('#sd-cn', m).textContent = id ? db.get('customers', id).name : 'Consumidor final'; } };
    },
    actions: [{ label: 'Cancelar', value: null }, { label: 'Guardar', kind: 'primary', id: 'sd-go', onClick: async (close, w) => {
      const kind = w.querySelector('[name=k]:checked').value;
      try {
        const rec = await saveCustomerDoc(kind, { customer_id: cust, items: cart, discount, notes: $('#sd-n', w).value, valid_until: $('#sd-v', w).value, delivery_date: $('#sd-d', w).value });
        close({ kind, rec });
      } catch (e) { toast(e.message, 'error'); }
    } }],
  });
  if (!r) return null;
  await modal({
    title: `${KINDS[r.kind].one} N° ${r.rec.number} guardado`,
    body: html`<p class="lead">Total <b class="money">${fmtMoney(r.rec.total)}</b> · ${custName(r.rec)}</p><p class="muted">Lo encontrás en el menú <b>Presupuestos</b>.</p>`,
    actions: [
      { label: raw(icon('print') + ' Imprimir'), onClick: () => printA4(docHTML(r.kind, r.rec)) },
      { label: raw(icon('whatsapp') + ' WhatsApp'), onClick: () => shareDoc(r.kind, r.rec) },
      { label: 'Listo', kind: 'primary', value: true },
    ],
  });
  return r.rec;
}
