// =====================================================================
// views/fotos.js — "Fotos faltantes" (ruta #/fotos) e "Importar fotos".
//
// Fotos faltantes: lista de productos activos sin foto (rubro, proveedor, buscar, solo con stock). Tocás uno → se
// abre la cámara → se guarda → abajo queda listo el siguiente (un toque más y sigue). "Escanear código y sacar
// foto": se lee el código con la cámara, se confirma el producto y se saca la foto. Pensado para la góndola.
// (El navegador no deja abrir la cámara sin un toque del usuario: por eso el "siguiente" es un botón grande.)
//
// Importar fotos: varias imágenes, una carpeta o un .zip. Cada archivo va al producto por su nombre (código de
// barras, código interno o nombre; ver fotos-match.js). Se procesan de a dos, se guardan en tandas y la pantalla
// sigue respondiendo; se puede cancelar (lo ya guardado queda).
// Solo dueño o encargado (can 'fotos'): la nube rechaza las fotos de otros roles.
// =====================================================================
import * as db from '../db.js';
import { ctx, stockOf } from '../ops.js';
import { html, $, on, ic, modal, toast, download } from '../ui.js';
import { fmtQty, can } from '../logic.js';
import { openScanner, canScan, playError } from '../scanner.js';
import { filterProducts } from '../control.js';
import { photoOf, hasPhoto, photoThumb, compressPhoto, savePhoto, pickPhotoFile } from '../fotos.js';
import { planPhotoImport, fileStem, REASONS } from '../fotos-match.js';
import { readZip, imageType } from '../zip.js';
import { audit } from '../seguridad.js';
import { productForm, productByCode } from './productos.js';

const PAGE = 60;
const FKEY = 'jg-filtros-fotos';
const nf = n => Number(n || 0).toLocaleString('es-AR');

let main = null;
const view = { q: '', cat: '', supplier: '', conStock: false, shown: PAGE, ...loadF() };
// Estado de la tanda en esta sesión (sobrevive a que la pantalla se vuelva a dibujar)
const run = { nextId: null, last: null, mode: 'list', skipped: new Set(), busy: false };

function loadF() {
  try { const o = JSON.parse(localStorage.getItem(FKEY) || '{}'); return { cat: String(o.cat || ''), supplier: String(o.supplier || ''), conStock: !!o.conStock }; } catch (e) { return {}; }
}
function saveF() {
  try { localStorage.setItem(FKEY, JSON.stringify({ cat: view.cat, supplier: view.supplier, conStock: view.conStock })); } catch (e) { /* sin almacenamiento */ }
}

/** Productos activos sin foto que pasan los filtros (orden por nombre) */
function missing() {
  const list = filterProducts(db.all('products'), { q: view.q, cat: view.cat, supplier: view.supplier, stock: view.conStock ? 'con' : '', active: 'activos' }, { stockOf });
  return list.filter(p => !hasPhoto(p.id));
}
function totals() {
  let act = 0, sin = 0;
  for (const p of db.all('products')) { if (p.active === 0) continue; act++; if (!hasPhoto(p.id)) sin++; }
  return { act, sin };
}
const filtersOn = () => !!(view.q || view.cat || view.supplier || view.conStock);

/** El siguiente para sacarle foto: el elegido si sigue faltando, si no el primero que no se salteó */
function nextOf(list) {
  if (run.nextId) { const p = list.find(x => x.id === run.nextId); if (p) return p; }
  return list.find(p => !run.skipped.has(p.id)) || null;
}

export async function render(m) {
  main = m;
  await db.whenLoaded(); // las fotos se leen en segundo plano: sin esto, todos parecerían "sin foto"
  if (!main.isConnected) return;
  const cats = [...new Set(db.all('products').map(p => p.category || 'General'))].sort((a, b) => a.localeCompare(b, 'es'));
  const sups = db.all('suppliers').filter(s => s.active !== 0).sort((a, b) => String(a.name || '').localeCompare(String(b.name || ''), 'es'));
  if (view.cat && !cats.includes(view.cat)) view.cat = '';
  if (view.supplier && !sups.some(s => s.id === view.supplier)) view.supplier = '';
  const opt = (v, l, cur) => html`<option value="${v}" ${cur === v ? 'selected' : ''}>${l}</option>`;
  main.innerHTML = String(html`
    <div class="page-head"><h1>Fotos faltantes</h1>
      <div class="btn-row"><a class="btn ghost sm" href="#/productos">${ic('back')} Productos</a>
        <button type="button" class="btn ghost sm" data-act="import" id="ph-import">${ic('upload')} Importar fotos</button></div></div>
    <section class="card ph-top">
      <div class="ph-count" id="ph-count" aria-live="polite"></div>
      ${canScan() ? html`<button type="button" class="btn primary big block" data-act="scan" id="ph-scan">${ic('camera')} Escanear código y sacar foto</button>` : ''}
    </section>
    <div class="field searchbox">${ic('search')}<label class="sr-only" for="ph-q">Buscar producto sin foto</label>
      <input id="ph-q" type="search" placeholder="Buscar por nombre o código" value="${view.q}" autocomplete="off" enterkeyhint="search"></div>
    <div class="ph-filters" id="ph-filters">
      <div class="field"><label for="ph-cat">Rubro</label><select id="ph-cat" data-f="cat">${opt('', 'Todos', view.cat)}${cats.map(c => opt(c, c, view.cat))}</select></div>
      <div class="field"><label for="ph-sup">Proveedor</label><select id="ph-sup" data-f="supplier">${opt('', 'Todos', view.supplier)}${sups.map(s => opt(s.id, s.name, view.supplier))}${opt('-', 'Sin proveedor', view.supplier)}</select></div>
      <label class="chip check-chip ph-stock"><input type="checkbox" id="ph-constock" data-f="conStock" ${view.conStock ? 'checked' : ''}> Solo con stock</label>
    </div>
    <div class="card"><ul class="list ph-list" id="ph-list"></ul>
      <button type="button" class="btn ghost block hidden" id="ph-more" data-act="more">Mostrar más</button></div>
    <div class="ph-next" id="ph-next" aria-live="polite"></div>`);
  paint();
  let t;
  $('#ph-q', main).addEventListener('input', e => { clearTimeout(t); t = setTimeout(() => { view.q = e.target.value; view.shown = PAGE; paint(); }, 150); });
  main.addEventListener('change', e => {
    const el = e.target.closest('[data-f]');
    if (!el) return;
    view[el.dataset.f] = el.type === 'checkbox' ? el.checked : el.value;
    view.shown = PAGE; run.nextId = null; saveF(); paint();
  });
  return on(main, 'click', '[data-act], [data-shoot]', (e, el) => {
    if (el.dataset.shoot) { run.mode = 'list'; return shoot(db.get('products', el.dataset.shoot)); }
    const a = el.dataset.act;
    if (a === 'more') { view.shown += PAGE; paint(); return; }
    if (a === 'scan') return scanFlow();
    if (a === 'import') return importPhotosDialog(() => paint());
    if (a === 'skip') { skip(); return; }
    if (a === 'next-shoot') { const p = nextOf(missing()); if (p) { run.mode = 'list'; shoot(p); } return; }
    if (a === 'to-list') { run.mode = 'list'; paint(); return; }
    if (a === 'undo') return undo();
  });
}

function paint() {
  if (!main || !main.isConnected) return;
  const list = missing();
  const tot = totals();
  const count = $('#ph-count', main);
  const shown = filtersOn() ? list.length : tot.sin;
  count.innerHTML = String(tot.sin
    ? html`<span class="ph-big" id="ph-faltan">${shown === 1 ? 'Falta' : 'Faltan'} ${nf(shown)}</span>
      <span class="ph-sub">${filtersOn() ? html`con estos filtros · ${nf(tot.sin)} en total` : html`${shown === 1 ? 'foto de producto activo' : 'fotos de productos activos'} · ${nf(tot.act - tot.sin)} ya ${tot.act - tot.sin === 1 ? 'tiene' : 'tienen'}`}</span>
      <span class="ph-bar" role="progressbar" aria-label="Productos con foto" aria-valuemin="0" aria-valuemax="${tot.act}" aria-valuenow="${tot.act - tot.sin}"><span style="width:${tot.act ? Math.round((tot.act - tot.sin) * 100 / tot.act) : 0}%"></span></span>`
    : html`<span class="ph-big" id="ph-faltan">${ic('check')} No falta ninguna foto</span><span class="ph-sub">${nf(tot.act)} productos activos con foto.</span>`);
  const next = nextOf(list);
  $('#ph-list', main).innerHTML = String(list.length
    ? html`${list.slice(0, view.shown).map(p => html`<li>
      <button type="button" class="row ${next && next.id === p.id ? 'is-next' : ''}" data-shoot="${p.id}" aria-label="Sacar foto a ${p.name}">
        ${photoThumb(p, 'sm')}<span class="grow"><span class="title">${p.name}</span>
          <span class="sub" style="display:block">${p.category || 'General'}${p.barcode ? ` · ${p.barcode}` : p.sku ? ` · ${p.sku}` : ''} · Stock ${fmtQty(stockOf(p))}${p.unit === 'kg' ? ' kg' : ''}</span></span>
        <span class="ph-cam" aria-hidden="true">${ic('camera')}</span>
      </button></li>`)}`
    : html`<li class="empty">${filtersOn() ? 'Ningún producto sin foto con esos filtros.' : 'Todos los productos activos tienen foto.'}</li>`);
  $('#ph-more', main).classList.toggle('hidden', list.length <= view.shown);
  paintNext(next);
}

function paintNext(next) {
  const box = $('#ph-next', main);
  if (!box) return;
  const last = run.last && db.get('products', run.last.id);
  if (!next && !last) { box.innerHTML = ''; box.classList.add('hidden'); return; }
  box.classList.remove('hidden');
  const scanMode = run.mode === 'scan' && canScan();
  // Compacta (queda fija abajo mientras se recorre la lista): lo último guardado en una línea, el siguiente y un botón grande
  box.innerHTML = String(html`
    ${last ? html`<p class="ph-saved" id="ph-saved"><span class="grow">${ic('check')} Guardada: <b>${last.name}</b></span>
      <button type="button" class="ph-link" data-act="undo" id="ph-undo">Deshacer</button></p>` : ''}
    ${run.busy ? html`<p class="ph-busy" id="ph-busy">Guardando la foto…</p>`
      : scanMode ? html`<div class="ph-next-btns"><button type="button" class="btn primary" data-act="scan" id="ph-scan-next">${ic('camera')} Escanear otro</button>
          ${next ? html`<button type="button" class="btn ghost" data-act="to-list" id="ph-to-list">Seguir con la lista</button>` : ''}</div>`
      : next ? html`<div class="ph-next-row">${photoThumb(next, 'sm')}<span class="grow"><span class="ph-k">${last ? 'Siguiente' : 'Empezá por'}</span>
            <b class="ph-n" id="ph-next-name">${next.name}</b></span>
            <button type="button" class="btn ghost sm" data-act="skip" id="ph-skip">Saltar</button></div>
          <button type="button" class="btn primary block" data-act="next-shoot" id="ph-next-shoot">${ic('camera')} Sacar foto</button>`
      : html`<p class="ph-k">${ic('check')} No quedan productos sin foto en esta lista.</p>`}`);
}

/**
 * Saca (o elige) la foto de un producto y la guarda. Se llama durante el toque (abre la cámara ya).
 * file: si ya se eligió (flujo de escanear), no se vuelve a pedir.
 */
async function shoot(p, filePromise = null) {
  if (!p || run.busy) return;
  const fp = filePromise || pickPhotoFile({ capture: true });
  const f = await fp;
  if (!f) return;
  run.busy = true; paint();
  try {
    await db.whenLoaded();
    const before = missing();
    const idx = before.findIndex(x => x.id === p.id);
    const photo = await compressPhoto(f, { fit: 'auto' });
    await savePhoto(p.id, photo);
    run.last = { id: p.id };
    run.skipped.delete(p.id);
    // El siguiente: el que venía después en la lista (sin los salteados)
    const after = idx >= 0 ? before.slice(idx + 1).find(x => !run.skipped.has(x.id) && !hasPhoto(x.id)) : null;
    run.nextId = after ? after.id : null;
    toast(`Foto guardada: ${p.name}`, 'ok', 1800);
  } catch (e) {
    toast(e.message || 'No se pudo guardar la foto.', 'error', 4000);
  } finally {
    run.busy = false;
    paint();
    const btn = main && main.isConnected && ($('#ph-scan-next', main) || $('#ph-next-shoot', main));
    if (btn) btn.focus({ preventScroll: true });
  }
}

/** Saltear el siguiente (queda en la lista) y pasar al que sigue; al llegar al final vuelve a empezar */
function skip() {
  const l = missing();
  const p = nextOf(l);
  if (!p) return;
  run.skipped.add(p.id);
  const i = l.findIndex(x => x.id === p.id);
  const n = l.slice(i + 1).find(x => !run.skipped.has(x.id)) || l.find(x => !run.skipped.has(x.id));
  if (!n) run.skipped.clear(); // se saltearon todos: se empieza de nuevo
  run.nextId = n ? n.id : (l[0] || {}).id || null;
  paint();
}

async function undo() {
  const id = run.last && run.last.id;
  if (!id) return;
  await savePhoto(id, '');
  run.nextId = id; run.last = null;
  toast('Se quitó la foto.', 'ok', 1600);
  paint();
}

/** Escanear el código, confirmar el producto y sacar la foto */
async function scanFlow() {
  const code = await openScanner({ title: 'Escaneá el producto para sacarle la foto' });
  if (!code || !main || !main.isConnected) return;
  let p = productByCode(code);
  if (!p) {
    playError();
    if (!can(ctx.user, 'editar_productos')) { toast(`No encontramos el código ${code}.`, 'warn', 4000); return; }
    const go = await modal({
      title: 'Código no encontrado',
      body: html`<p class="lead">No hay ningún producto con el código <b>${code}</b>.</p>`,
      actions: [{ label: 'Cerrar', value: false }, { label: 'Crear producto con este código', kind: 'primary', value: true, id: 'ph-create' }],
    });
    if (!go) return;
    p = await productForm({ barcode: code });
    if (!p || p.deleted || hasPhoto(p.id)) { paint(); return; } // ya le cargó la foto en el formulario
  }
  const had = !!photoOf(p.id);
  // El toque en "Sacar foto" abre la cámara (el navegador no la abre sin un toque)
  const file = await modal({
    title: had ? 'Este producto ya tiene foto' : 'Sacar foto',
    body: html`<div class="ph-confirm">${photoThumb(p, 'lg', p.name)}
      <p class="lead"><b id="ph-c-name">${p.name}</b><br><span class="muted">${p.category || 'General'}${p.barcode ? ` · ${p.barcode}` : ''}</span></p>
      ${had ? html`<div class="notice notice-warn"><p>Si sacás otra, reemplaza a la que tiene.</p></div>` : ''}</div>`,
    actions: [{ label: 'Cancelar', value: null },
      { label: html`${ic('upload')} Elegir archivo`, id: 'ph-c-file', onClick: close => close(pickPhotoFile({ capture: false })) },
      { label: html`${ic('camera')} ${had ? 'Reemplazar foto' : 'Sacar foto'}`, kind: 'primary', id: 'ph-c-cam', onClick: close => close(pickPhotoFile({ capture: true })) }],
  });
  if (!file) return;
  run.mode = 'scan';
  await shoot(p, file);
}

// =====================================================================
// Importar fotos
// =====================================================================

const SKIP_NAME = /(^|\/)(__MACOSX|\.)[^/]*|(^|\/)(thumbs\.db|desktop\.ini)$/i;

/** Lee lo elegido como lista de {name, size, blob()} con solo las imágenes; devuelve también cuántos se ignoraron */
async function sourcesOf(kind, files) {
  const out = [];
  let ignored = 0;
  for (const f of files) {
    const rel = f.webkitRelativePath || f.name;
    if (kind === 'zip' || /\.zip$/i.test(f.name)) {
      const entries = await readZip(f);
      for (const e of entries) {
        if (e.dir) continue;
        if (SKIP_NAME.test(e.name) || !imageType(e.name)) { ignored++; continue; }
        out.push({ name: e.name, size: e.size, blob: e.blob });
      }
      continue;
    }
    if (SKIP_NAME.test(rel) || !(/^image\//.test(f.type) || imageType(f.name))) { ignored++; continue; }
    const file = f.type ? f : new Blob([f], { type: imageType(f.name) });
    out.push({ name: rel, size: f.size, blob: async () => file });
  }
  return { items: out, ignored };
}

/** Abre el selector durante el toque. kind: 'files' | 'dir' | 'zip'. Devuelve Promise<File[]> */
function pickMany(kind) {
  return new Promise(resolve => {
    const i = document.createElement('input');
    i.type = 'file';
    i.style.display = 'none';
    i.dataset.photoImport = kind;
    if (kind === 'zip') i.accept = '.zip,application/zip,application/x-zip-compressed';
    else { i.multiple = true; if (kind === 'dir') i.webkitdirectory = true; else i.accept = 'image/*'; }
    let done = false;
    const end = list => { if (done) return; done = true; i.remove(); resolve(list); };
    i.addEventListener('change', () => end([...(i.files || [])]));
    i.addEventListener('cancel', () => end([]));
    document.body.appendChild(i);
    i.click();
  });
}

const canDir = () => { try { return 'webkitdirectory' in document.createElement('input'); } catch (e) { return false; } };

/** Ventana "Importar fotos" (desde Productos o Fotos faltantes). onDone() se llama si se guardó algo. */
export async function importPhotosDialog(onDone = () => {}) {
  if (!can(ctx.user, 'fotos')) { toast('Tu usuario no puede cargar fotos.', 'warn'); return; }
  let replace = false;
  const picked = await modal({
    title: 'Importar fotos',
    size: 'wide',
    body: html`<p>Elegí varias fotos, una carpeta entera o un archivo .zip.</p>
      <label class="check"><input type="checkbox" id="pi-replace"> Reemplazar las que ya tienen foto</label>
      <div class="ph-pick">
        <button type="button" class="btn soft" data-pick="files" id="pi-files">${ic('upload')} Elegir fotos</button>
        ${canDir() ? html`<button type="button" class="btn soft" data-pick="dir" id="pi-dir">${ic('box')} Elegir carpeta</button>` : ''}
        <button type="button" class="btn soft" data-pick="zip" id="pi-zip">${ic('download')} Elegir .zip</button>
      </div>
      <h3 class="ph-h">¿A qué producto va cada foto?</h3>
      <p class="small">Al que tenga en el <b>nombre del archivo</b>:</p>
      <ul class="ph-rules small">
        <li>su <b>código de barras</b>: <code>7790070318046.jpg</code>, <code>7790070318046_1.jpg</code>, <code>7790070318046-frente.png</code></li>
        <li>o su <b>código interno</b>: <code>A123.jpg</code></li>
        <li>o su <b>nombre</b>: <code>Yerba Playadito 1 kg.jpg</code> (sin importar acentos ni mayúsculas)</li>
      </ul>
      <p class="muted small">Quedan cuadradas de 400 px, con el producto entero y centrado sobre fondo blanco. Antes de cargar te mostramos cuántas coinciden.</p>`,
    onMount(m, close) {
      m.addEventListener('click', e => {
        const b = e.target.closest('[data-pick]');
        if (!b) return;
        replace = $('#pi-replace', m).checked;
        const kind = b.dataset.pick;
        close({ kind, files: pickMany(kind) }); // el selector se abre ya, durante el toque
      });
    },
    actions: [{ label: 'Cancelar', value: null }],
  });
  if (!picked) return;
  const files = await picked.files;
  if (!files.length) return;
  // Leer la lista (y el índice del .zip) y armar el plan
  let read;
  const wait = waitBox('Leyendo los archivos…');
  try {
    read = await sourcesOf(picked.kind, files);
    await db.whenLoaded();
  } catch (e) { wait.close(); toast('No se pudo leer: ' + e.message, 'error', 6000); return; }
  wait.close();
  if (!read.items.length) { toast(read.ignored ? 'No encontramos imágenes (JPG, PNG o WEBP) en lo que elegiste.' : 'No elegiste ninguna imagen.', 'warn', 5000); return; }
  const plan = planPhotoImport(read.items, db.all('products'), { hasPhoto, replace });
  const go = await modal({
    title: 'Importar fotos',
    body: html`<p class="lead"><b>${nf(read.items.length)}</b> ${read.items.length === 1 ? 'imagen' : 'imágenes'}${read.ignored ? html` <span class="muted">(${nf(read.ignored)} ${read.ignored === 1 ? 'archivo que no es foto se ignora' : 'archivos que no son fotos se ignoran'})</span>` : ''}.</p>
      <ul class="ph-plan" id="pi-plan">
        <li><b id="pi-todo">${nf(plan.todo.length)}</b> se van a cargar</li>
        ${plan.skipped.length ? html`<li><b id="pi-skip">${nf(plan.skipped.length)}</b> son de productos que ya tienen foto (no se tocan)</li>` : ''}
        ${plan.unmatched.length ? html`<li><b id="pi-unm">${nf(plan.unmatched.length)}</b> sin coincidencia${plan.unmatched.length ? html` <span class="muted small">(ej.: ${plan.unmatched.slice(0, 3).map(u => fileStem(u.file.name)).join(', ')})</span>` : ''}</li>` : ''}
        ${plan.dupes.length ? html`<li><b>${nf(plan.dupes.length)}</b> ${plan.dupes.length === 1 ? 'repetida' : 'repetidas'} (otra imagen del mismo producto)</li>` : ''}
      </ul>`,
    actions: [{ label: 'Cancelar', value: false },
      ...(plan.todo.length ? [{ label: `Cargar ${nf(plan.todo.length)} ${plan.todo.length === 1 ? 'foto' : 'fotos'}`, kind: 'primary', value: true, id: 'pi-go' }]
        : [{ label: 'Ver detalle', kind: 'primary', value: 'detail', id: 'pi-go' }])],
  });
  if (!go) return;
  const result = go === true ? await processImport(plan.todo) : { saved: [], errors: [], cancelled: false };
  if (result.saved.length) {
    audit('fotos_importadas', 'product_photos', '', { saved: result.saved.length, unmatched: plan.unmatched.length, errors: result.errors.length, replace }).catch(() => {});
    onDone();
  }
  await summary(plan, result, read.ignored);
}

function waitBox(msg) {
  let c = null;
  const p = modal({ title: 'Importar fotos', dismissable: false, body: html`<p aria-live="polite">${msg}</p>`, onMount(m, close) { c = close; } });
  return { close: () => { if (c) c(true); return p; } };
}

/** Procesa y guarda de a tandas. Devuelve {saved: [{file, product}], errors: [{file, product, msg}], cancelled} */
async function processImport(todo) {
  const saved = [], errors = [];
  let cancelled = false, done = 0, ui = null;
  const t0 = performance.now();
  const prog = modal({
    title: 'Cargando fotos…', dismissable: false,
    body: html`<p id="pi-msg" aria-live="polite">Preparando…</p>
      <progress id="pi-prog" max="${todo.length}" value="0" style="width:100%"></progress>
      <p class="muted small" id="pi-eta"></p>
      <p class="muted small">Podés seguir usando el equipo, pero no cierres la app. Si cancelás, lo ya cargado queda.</p>`,
    actions: [{ label: 'Cancelar', id: 'pi-cancel', onClick: () => { cancelled = true; const b = $('#pi-cancel'); if (b) { b.disabled = true; b.textContent = 'Cancelando…'; } } }],
    onMount(m, close) { ui = { m, close }; },
  });
  let wake = null;
  try { if (navigator.wakeLock) wake = await navigator.wakeLock.request('screen'); } catch (e) { /* sin bloqueo de pantalla */ }
  let pending = [];
  let lastPaint = 0;
  const flush = async () => {
    if (!pending.length) return;
    const ops = pending; pending = [];
    await db.putBatch(ops.map(x => ({ coll: 'product_photos', rec: { id: x.product.id, product_id: x.product.id, photo: x.photo, deleted: 0 } })));
    for (const x of ops) saved.push({ file: x.file, product: x.product });
  };
  const paintProg = force => {
    const now = performance.now();
    if (!force && now - lastPaint < 120) return;
    lastPaint = now;
    const el = $('#pi-msg', ui.m), pr = $('#pi-prog', ui.m), eta = $('#pi-eta', ui.m);
    if (!el) return;
    el.textContent = `Foto ${nf(done)} de ${nf(todo.length)}${errors.length ? ` · ${nf(errors.length)} con error` : ''}`;
    pr.value = done;
    if (done >= 8 && done < todo.length) {
      const left = (now - t0) / done * (todo.length - done) / 1000;
      eta.textContent = left < 60 ? `Faltan unos ${Math.max(1, Math.round(left))} segundos.` : `Faltan unos ${Math.round(left / 60)} minutos.`;
    } else eta.textContent = '';
  };
  let i = 0;
  const worker = async () => {
    while (!cancelled && i < todo.length) {
      const it = todo[i++];
      try {
        const blob = await it.file.blob();
        const photo = await compressPhoto(blob, { fit: 'contain' });
        pending.push({ file: it.file, product: it.product, photo });
      } catch (e) {
        errors.push({ file: it.file, product: it.product, msg: e.message || String(e) });
      }
      done++;
      if (pending.length >= 20) await flush();
      paintProg(false);
      await new Promise(r => setTimeout(r, 0)); // deja respirar a la pantalla
    }
  };
  try {
    await Promise.all([worker(), worker()]); // de a dos: mientras una se decodifica, la otra se comprime
    await flush();
  } catch (e) {
    cancelled = true; // la base no guardó: se frena todo (lo ya guardado queda)
    errors.push({ file: { name: '—' }, product: null, msg: 'No se pudo guardar: ' + e.message });
  } finally {
    try { if (wake) await wake.release(); } catch (e) { /* nada */ }
    paintProg(true);
    ui.close(true);
    await prog;
  }
  return { saved, errors, cancelled };
}

async function summary(plan, result, ignored) {
  const notDone = result.cancelled ? plan.todo.filter(x => !result.saved.some(s => s.product.id === x.product.id) && !result.errors.some(e => e.product && e.product.id === x.product.id)) : [];
  const rows = [['archivo', 'resultado', 'producto', 'detalle']];
  const pname = p => (p ? `${p.name}${p.barcode ? ' (' + p.barcode + ')' : ''}` : '');
  for (const u of plan.unmatched) rows.push([u.file.name, 'sin coincidencia', '', u.reason === 'ambiguo' ? `${REASONS.ambiguo} (${u.n})` : REASONS.sin_coincidencia]);
  for (const e of result.errors) rows.push([e.file.name, 'error', pname(e.product), e.msg]);
  for (const d of plan.dupes) rows.push([d.file.name, 'repetida', pname(d.product), `${REASONS.repetida}: ${d.kept.name}`]);
  for (const s of plan.skipped) rows.push([s.file.name, 'ya tenía foto', pname(s.product), REASONS.ya_tiene]);
  for (const x of notDone) rows.push([x.file.name, 'cancelada', pname(x.product), 'Se canceló antes de cargarla']);
  const dl = () => {
    const csv = rows.map(r => r.map(v => { const s = String(v ?? ''); return /[";\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s; }).join(';')).join('\r\n');
    download(`fotos-sin-asignar-${new Date().toISOString().slice(0, 10)}.csv`, '﻿' + csv, 'text/csv;charset=utf-8');
  };
  await modal({
    title: result.cancelled ? 'Importación cancelada' : 'Importación terminada',
    size: 'wide',
    body: html`<div class="ph-sum" id="pi-sum">
        <div class="stat ok"><div class="k">Asignadas</div><div class="v" id="pi-n-ok">${nf(result.saved.length)}</div></div>
        <div class="stat ${plan.unmatched.length ? 'warn' : ''}"><div class="k">Sin coincidencia</div><div class="v" id="pi-n-unm">${nf(plan.unmatched.length)}</div></div>
        <div class="stat ${result.errors.length ? 'err' : ''}"><div class="k">Con error</div><div class="v" id="pi-n-err">${nf(result.errors.length)}</div></div>
        ${plan.skipped.length ? html`<div class="stat"><div class="k">Ya tenían foto</div><div class="v" id="pi-n-skip">${nf(plan.skipped.length)}</div></div>` : ''}
      </div>
      ${plan.dupes.length || ignored || notDone.length ? html`<p class="muted small">${[plan.dupes.length ? `${nf(plan.dupes.length)} ${plan.dupes.length === 1 ? 'repetida' : 'repetidas'} (se usó una por producto)` : '', ignored ? `${nf(ignored)} ${ignored === 1 ? 'archivo que no es foto' : 'archivos que no son fotos'}` : '', notDone.length ? `${nf(notDone.length)} sin cargar por cancelar` : ''].filter(Boolean).join(' · ')}.</p>` : ''}
      ${plan.unmatched.length ? html`<details><summary>Ver las que no coinciden (${nf(plan.unmatched.length)})</summary><ul class="ph-unm" id="pi-unm-list">${plan.unmatched.slice(0, 100).map(u => html`<li>${u.file.name}${u.reason === 'ambiguo' ? html` <span class="muted small">(el nombre coincide con ${u.n} productos)</span>` : ''}</li>`)}${plan.unmatched.length > 100 ? html`<li class="muted">… y ${nf(plan.unmatched.length - 100)} más (en la lista descargable)</li>` : ''}</ul></details>` : ''}
      ${result.errors.length ? html`<details><summary>Ver errores (${nf(result.errors.length)})</summary><ul class="ph-unm" id="pi-err-list">${result.errors.slice(0, 100).map(e => html`<li>${e.file.name}: ${e.msg}</li>`)}</ul></details>` : ''}
      ${rows.length > 1 ? html`<p class="muted small">Renombrá las que no coinciden con el código de barras del producto y volvé a importarlas.</p>` : ''}`,
    actions: [...(rows.length > 1 ? [{ label: html`${ic('download')} Descargar lista`, id: 'pi-dl', onClick: () => dl() }] : []), { label: 'Listo', kind: 'primary', value: true, id: 'pi-done' }],
  });
}

