// =====================================================================
// comisiones.js — Reporte de comisiones de vendedores por período:
// por venta (ventas netas de devoluciones y anuladas) o por cobranza (lo
// efectivamente cobrado). Detalle exportable a Excel e imprimible.
// =====================================================================
import * as db from '../db.js';
import { html, $, ic, exportTable } from '../ui.js';
import { fmtMoney, fmtDate, fmtDateTime, toISODate } from '../logic.js';
import { commissionReport, fromCents, COMMISSION_BASES } from '../cuentas.js';
import { printA4, printHead, rangeOf, periodText } from './ctacte.js';

const money = c => fmtMoney(fromCents(c));
const KIND = { venta: 'Venta', devolucion: 'Devolución', cobro: 'Cobro cta. cte.' };
const custName = id => (id && (db.get('customers', id) || {}).name) || 'Consumidor final';
const pctTxt = p => `${String(p.pct || 0).replace('.', ',')}%`;

export function render(main) {
  const now = new Date();
  const first = toISODate(new Date(now.getFullYear(), now.getMonth(), 1).getTime());
  main.innerHTML = String(html`
    <div class="page-head"><h1>Comisiones de vendedores</h1></div>
    <p class="muted">Por venta: sobre lo vendido menos devoluciones y notas de crédito (las anuladas no cuentan). Por cobranza: sobre lo cobrado de contado de sus ventas, menos lo devuelto en plata, más los cobros de cuenta corriente de sus clientes. El % y la base se configuran en Ajustes → Usuarios.</p>
    <div class="card"><div class="stmt-filters">
      <div class="field"><label for="cm-f">Desde</label><input type="date" id="cm-f" value="${first}"></div>
      <div class="field"><label for="cm-t">Hasta</label><input type="date" id="cm-t" value="${toISODate(Date.now())}"></div>
      <div class="field"><label for="cm-s">Vendedor</label><select id="cm-s"><option value="">Todos</option></select></div>
      <div class="btn-row stmt-btns"><button type="button" class="btn ghost" data-cm="print">${ic('print')} Imprimir</button>
        <button type="button" class="btn ghost" data-cm="xls">${ic('download')} Excel con el detalle</button></div>
    </div></div>
    <div id="cm-body"></div>`);
  const calc = () => {
    const r = rangeOf(main, '#cm-f', '#cm-t');
    const rep = commissionReport({
      sales: db.all('sales'), returns: db.all('returns'), customerPayments: db.all('customer_payments'),
      users: db.all('users', { includeDeleted: true }), from: r.from, to: r.to, sellerId: $('#cm-s', main).value || null,
    });
    return { r, rep };
  };
  const fillSellers = () => {
    const { rep } = calc();
    const sel = $('#cm-s', main);
    const cur = sel.value;
    sel.innerHTML = String(html`<option value="">Todos</option>${rep.sellers.map(p => html`<option value="${p.user_id}" ${p.user_id === cur ? 'selected' : ''}>${p.name}</option>`)}`);
  };
  const paint = () => {
    const { rep } = calc();
    $('#cm-body', main).innerHTML = String(html`
      <div class="stats"><div class="stat"><div class="k">Total de comisiones</div><div class="v money" id="cm-total">${money(rep.totals.commission)}</div></div>
        <div class="stat"><div class="k">Base total</div><div class="v money">${money(rep.totals.base)}</div></div></div>
      ${rep.sellers.map(p => html`<section class="card" data-seller="${p.user_id}">
        <div class="card-head"><h2>${p.name}</h2><b class="money" data-cm-com>${money(p.commission)}</b></div>
        <p class="small muted">${p.base_kind ? `${COMMISSION_BASES[p.base_kind]} · ${pctTxt(p)}` : 'Sin comisión'} · ${p.salesCount} ${p.salesCount === 1 ? 'venta' : 'ventas'}</p>
        <div class="stmt-tot"><span>Vendido <b class="money">${money(p.ventas)}</b></span><span>Devoluciones <b class="money">${money(p.devoluciones)}</b></span>
          <span>Cobrado <b class="money">${money(p.cobrado_contado - p.devuelto_contado + p.cobros_cc)}</b></span><span>Base <b class="money" data-cm-base>${money(p.base)}</b></span></div>
        <details><summary>Ver detalle (${p.lines.length})</summary><ul class="stmt">${p.lines.map(l => html`<li class="stmt-row">
          <span class="grow"><span class="d">${fmtDateTime(l.at)}</span> <span class="t">${l.ref} · ${custName(l.customer_id)}</span></span>
          <span class="nums">${l.kind !== 'cobro' ? html`<span class="money ${l.total < 0 ? 'cre' : ''}">${money(l.total)}</span>` : ''}<span class="bal money">cobrado ${money(l.cobrado)}</span></span></li>`)}
          ${!p.lines.length ? html`<li class="empty">Sin movimientos en el período.</li>` : ''}</ul></details>
      </section>`)}
      ${!rep.sellers.length ? html`<div class="card"><p class="empty">No hay vendedores. Creá uno en Ajustes → Usuarios (rol Vendedor) y elegilo al vender.</p></div>` : ''}`);
  };
  main.addEventListener('change', e => { if (e.target.matches('#cm-f, #cm-t')) { fillSellers(); paint(); } if (e.target.matches('#cm-s')) paint(); });
  main.addEventListener('click', async e => {
    const a = e.target.closest('[data-cm]');
    if (!a) return;
    const { r, rep } = calc();
    if (a.dataset.cm === 'xls') {
      const rows = [['vendedor', 'base_comision', 'porcentaje', 'fecha', 'tipo', 'comprobante', 'cliente', 'importe', 'a_cuenta_corriente', 'cobrado']];
      for (const p of rep.sellers) {
        for (const l of p.lines) rows.push([p.name, p.base_kind ? COMMISSION_BASES[p.base_kind] : 'Sin comisión', p.pct, fmtDateTime(l.at), KIND[l.kind], l.ref, custName(l.customer_id), fromCents(l.total), fromCents(l.cc), fromCents(l.cobrado)]);
        rows.push([p.name, 'TOTAL', p.pct, '', '', `Base ${fromCents(p.base)}`, '', fromCents(p.ventas - p.devoluciones), '', `Comisión ${fromCents(p.commission)}`]);
      }
      await exportTable('comisiones-' + toISODate(Date.now()), 'Comisiones', rows);
    }
    if (a.dataset.cm === 'print') {
      await printA4(html`<div class="ticket doc-a4">${printHead('Comisiones de vendedores', [periodText(r)])}
        <table class="ptable"><thead><tr><th>Vendedor</th><th>Base</th><th class="r">%</th><th class="r">Vendido</th><th class="r">Devoluciones</th><th class="r">Cobrado</th><th class="r">Base</th><th class="r">Comisión</th></tr></thead><tbody>
        ${rep.sellers.map(p => html`<tr><td>${p.name}</td><td>${p.base_kind ? COMMISSION_BASES[p.base_kind] : 'Sin comisión'}</td><td class="r">${pctTxt(p)}</td><td class="r">${money(p.ventas)}</td><td class="r">${money(p.devoluciones)}</td><td class="r">${money(p.cobrado_contado - p.devuelto_contado + p.cobros_cc)}</td><td class="r">${money(p.base)}</td><td class="r"><b>${money(p.commission)}</b></td></tr>`)}
        </tbody><tfoot><tr><td colspan="6">Total</td><td class="r">${money(rep.totals.base)}</td><td class="r"><b>${money(rep.totals.commission)}</b></td></tr></tfoot></table>
        <p class="small">Fecha de cada venta, devolución o cobro. Comisión redondeada al centavo sobre la base total de cada vendedor.</p></div>`);
    }
  });
  fillSellers();
  paint();
}


