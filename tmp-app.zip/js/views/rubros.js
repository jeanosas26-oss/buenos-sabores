// =====================================================================
// rubros.js — Rubros y subrubros (ABM, como SGI). La primera vez crea los rubros a partir de las categorías que
// ya tienen los productos (no se pierde ninguna: el producto sigue con su categoría de texto).
// =====================================================================
import * as db from '../db.js';
import { html, $, on, ic, modal, toast, confirm } from '../ui.js';
import { norm } from '../logic.js';
import { migrateCategories, categoryList, saveCategory, deleteCategory, saveSubcategory, deleteSubcategory } from '../comercial-ops.js';

let q = '';
export async function render(main) {
  const n = await migrateCategories().catch(e => { toast(e.message, 'error'); return 0; });
  if (n) toast(`Se crearon ${n} rubros a partir de las categorías de los productos.`, 'ok', 4000);
  const paint = () => {
    const list = categoryList().filter(c => !q || norm(c.name + ' ' + c.subs.map(s => s.name).join(' ')).includes(norm(q)));
    const sinRubro = db.all('products').filter(p => !String(p.category || '').trim()).length;
    main.innerHTML = String(html`
      <div class="page-head"><h1>Rubros y subrubros</h1>
        <div class="btn-row"><a class="btn ghost" href="#/productos">${ic('back')} Productos</a><button type="button" class="btn primary" data-cat="" id="rb-add">${ic('plus')} Nuevo rubro</button></div></div>
      <p class="muted">El rubro es la categoría del producto. Al cambiarle el nombre a un rubro, cambia en todos sus productos. ${sinRubro ? `Hay ${sinRubro} productos sin rubro.` : ''}</p>
      <div class="field searchbox">${ic('search')}<label class="sr-only" for="rb-q">Buscar rubro</label><input id="rb-q" type="search" value="${q}" placeholder="Buscar rubro o subrubro"></div>
      <p class="small muted" id="rb-count">${list.length} rubros</p>
      <div class="listgrid" id="rb-list">${list.map(c => html`<section class="card" data-catcard="${c.id}">
        <div class="card-head"><h2 style="font-size:1.05rem">${c.name}</h2><button type="button" class="btn ghost sm" data-cat="${c.id}" aria-label="Editar rubro ${c.name}">${ic('edit')}</button></div>
        <p class="small muted"><a href="#/productos" data-goprod="${c.name}">${c.products} productos</a>${c.active === 0 ? ' · inactivo' : ''}</p>
        <div class="chips" style="flex-wrap:wrap">${c.subs.map(s => html`<button type="button" class="chip" data-sub="${s.id}">${s.name}</button>`)}
          <button type="button" class="chip" data-newsub="${c.id}" aria-label="Nuevo subrubro en ${c.name}">${ic('plus')} Subrubro</button></div></section>`)}</div>`);
    const qi = $('#rb-q', main);
    qi.oninput = () => { q = qi.value; const pos = qi.selectionStart; paint(); const x = $('#rb-q', main); x.focus(); x.setSelectionRange(pos, pos); };
  };
  paint();
  const offs = [
    on(main, 'click', '[data-cat]', async (e, el) => { if (await catForm(el.dataset.cat ? db.get('categories', el.dataset.cat) : null)) paint(); }),
    on(main, 'click', '[data-newsub]', async (e, el) => { if (await subForm({ category_id: el.dataset.newsub })) paint(); }),
    on(main, 'click', '[data-sub]', async (e, el) => { if (await subForm(db.get('subcategories', el.dataset.sub))) paint(); }),
    on(main, 'click', '[data-goprod]', (e, el) => { try { const k = 'jg-filtros-productos'; const f = JSON.parse(localStorage.getItem(k) || '{}'); f.cat = el.dataset.goprod; f.subcat = ''; localStorage.setItem(k, JSON.stringify(f)); } catch (x) { /* nada */ } }),
  ];
  return () => offs.forEach(f => f());
}

async function catForm(c) {
  const others = categoryList().filter(x => !c || x.id !== c.id);
  return modal({
    title: c ? `Rubro ${c.name}` : 'Nuevo rubro',
    body: html`<div class="field"><label for="cf-n">Nombre</label><input id="cf-n" value="${c ? c.name : ''}" autocomplete="off"></div>
      ${c ? html`<label class="check"><input type="checkbox" id="cf-a" ${c.active === 0 ? '' : 'checked'}> Activo</label>
        <details><summary>Borrar el rubro</summary><div class="field"><label for="cf-mv">Pasar sus productos a</label><select id="cf-mv"><option value="">Elegí…</option>${others.map(o => html`<option>${o.name}</option>`)}</select></div>
        <button type="button" class="btn danger sm" id="cf-del">${ic('trash')} Borrar rubro</button></details>` : ''}`,
    onMount(m, close) {
      const d = $('#cf-del', m);
      if (d) d.onclick = async () => {
        if (!(await confirm(`¿Borrás el rubro “${c.name}”?`, { danger: true, ok: 'Borrar' }))) return;
        try { await deleteCategory(c.id, $('#cf-mv', m).value); toast('Rubro borrado.'); close(true); } catch (e) { toast(e.message, 'error', 5000); }
      };
    },
    actions: [{ label: 'Cancelar', value: null }, { label: 'Guardar', kind: 'primary', id: 'cf-go', onClick: async (close, w) => {
      try { const r = await saveCategory({ id: c && c.id, name: $('#cf-n', w).value, active: $('#cf-a', w) ? $('#cf-a', w).checked : 1 }); toast('Rubro guardado.'); close(r); } catch (e) { toast(e.message, 'error'); }
    } }],
  });
}

async function subForm(s) {
  const cat = db.get('categories', s.category_id);
  return modal({
    title: s.id ? `Subrubro ${s.name}` : `Nuevo subrubro en ${cat ? cat.name : ''}`,
    body: html`<div class="field"><label for="sf-n">Nombre</label><input id="sf-n" value="${s.name || ''}" autocomplete="off"></div>`,
    actions: [
      ...(s.id ? [{ label: 'Borrar', onClick: async close => { if (await confirm(`¿Borrás el subrubro “${s.name}”? Sus productos quedan sin subrubro.`, { danger: true, ok: 'Borrar' })) { await deleteSubcategory(s.id); close(true); } } }] : []),
      { label: 'Cancelar', value: null },
      { label: 'Guardar', kind: 'primary', id: 'sf-go', onClick: async (close, w) => {
        try { const r = await saveSubcategory({ id: s.id, name: $('#sf-n', w).value, category_id: s.category_id }); toast('Subrubro guardado.'); close(r); } catch (e) { toast(e.message, 'error'); }
      } },
    ],
  });
}
