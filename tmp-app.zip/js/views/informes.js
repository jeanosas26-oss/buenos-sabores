// =====================================================================
// informes.js (pantalla) — Informes como SGI: Caja diaria, Stock de artículos (valorizado a costo y venta),
// Ventas por período, Ventas por cliente, Artículos por cliente, Ventas por artículo, Compras por artículo,
// Ventas promedio (día / hora / día de semana), Novedades (cambios de precio) y accesos a Comisiones, Faltantes y
// Vencimientos. Todos con filtros, imprimibles (A4) y a Excel.
// =====================================================================
import * as db from '../db.js';
import { multiBranch, branches, inBranch, stockOf, branchName, userName, ctx } from '../ops.js';
import { html, $, on, ic, exportTable } from '../ui.js';
import { fmtMoney, fmtQty, fmtDate, fmtDateTime, toISODate, payLabel } from '../logic.js';
import {
  salesByPeriod, salesByCustomer, itemsByCustomer, salesByArticle, purchasesByArticle, salesAverages, stockValued,
  priceNovelties, cashDaily, toTable,
} from '../informes.js';
import { printA4, printHead } from './ctacte.js';

const REPORTS = [
  ['caja', 'Caja diaria'], ['stock', 'Stock valorizado'], ['periodo', 'Ventas por período'], ['cliente', 'Ventas por cliente'],
  ['artcliente', 'Artículos por cliente'], ['articulo', 'Ventas por artículo'], ['compras', 'Compras por artículo'],
  ['promedio', 'Ventas promedio'], ['novedades', 'Novedades de precios'],
];
const today = () => toISODate(Date.now());
const monthStart = () => { const d = new Date(); return toISODate(new Date(d.getFullYear(), d.getMonth(), 1).getTime()); };
const F = { rep: 'periodo', from: null, to: null, branch: 'all', cat: '', sup: '', cust: '', group: 'day' };
const M = v => fmtMoney(v);
const range = () => ({ from: new Date(F.from + 'T00:00').getTime(), to: new Date(F.to + 'T23:59:59.999').getTime() });
const inB = list => (!multiBranch() || F.branch === 'all' ? list : list.filter(x => inBranch(x, F.branch)));

/** Datos del informe elegido → {title, cols, rows, totals (fila), extra (html), note} */
function build() {
  const { from, to } = range();
  const sales = inB(db.all('sales')), returns = inB(db.all('returns'));
  const productOf = id => db.get('products', id), customerOf = id => db.get('customers', id);
  const period = `Del ${fmtDate(from)} al ${fmtDate(to)}${multiBranch() ? ` · ${F.branch === 'all' ? 'Todas las sucursales' : branchName(F.branch)}` : ''}`;
  switch (F.rep) {
    case 'caja': {
      const r = cashDaily({ sessions: inB(db.all('cash_sessions')), sales: db.all('sales'), movements: db.all('cash_movements'), returns: db.all('returns') }, { from, to });
      const rows = r.rows.map(x => ({ ...x.arqueo, opened: x.session.opened_at, closed: x.session.closed_at, user: userName(x.session.opened_by), branch: branchName(x.session.branch_id) }));
      return {
        title: 'Caja diaria', period,
        cols: [{ h: 'Apertura', k: 'opened', f: r => fmtDateTime(r.opened) }, { h: 'Cierre', k: 'closed', f: r => (r.closed ? fmtDateTime(r.closed) : 'abierta') }, ...(multiBranch() ? [{ h: 'Sucursal', k: 'branch' }] : []), { h: 'Abrió', k: 'user' },
          { h: 'Ventas', k: 'count', n: 1 }, { h: 'Vendido', k: 'salesTotal', m: 1 }, { h: 'Inicial', k: 'opening', m: 1 }, { h: '+ Efectivo', k: 'cashSales', m: 1 }, { h: '+ Ingresos', k: 'ingresos', m: 1 }, { h: '− Egresos', k: 'egresos', m: 1 },
          { h: '− Devol.', k: 'devoluciones', m: 1 }, { h: 'Esperado', k: 'expected', m: 1 }, { h: 'Contado', k: 'counted', m: 1 }, { h: 'Diferencia', k: 'difference', m: 1 }],
        rows, totals: { opened: 'TOTAL', ...r.totals },
        extra: html`<div class="card"><h2>Por medio de pago</h2><div class="rep-sum">${Object.entries(r.byMethod).map(([k, v]) => html`<span>${payLabel(k)} <b class="money">${M(v)}</b></span>`)}${!Object.keys(r.byMethod).length ? 'Sin ventas.' : ''}</div></div>`,
      };
    }
    case 'stock': {
      const br = multiBranch() && F.branch !== 'all' ? F.branch : null;
      const r = stockValued(db.all('products'), { stockOf: p => (br ? stockOf(p, br) : multiBranch() ? Number(p.stock) || 0 : stockOf(p)), category: F.cat, supplierId: F.sup });
      return {
        title: 'Stock de artículos valorizado', period: `Al ${fmtDateTime(Date.now())}${multiBranch() ? ` · ${br ? branchName(br) : 'Todas las sucursales'}` : ''}`,
        cols: [{ h: 'Rubro', k: 'category' }, { h: 'Producto', k: 'name' }, { h: 'Código', k: 'code' }, { h: 'Stock', k: 'stock', n: 1 }, { h: 'Costo', k: 'cost', m: 1 }, { h: 'Precio', k: 'price', m: 1 }, { h: 'Valor a costo', k: 'cost_value', m: 1 }, { h: 'Valor a venta', k: 'sale_value', m: 1 }],
        rows: r.rows, totals: { category: 'TOTAL', cost_value: r.totals.cost_value, sale_value: r.totals.sale_value },
        note: `${r.totals.count} productos · ganancia potencial ${M(r.totals.profit)}${r.totals.negatives ? ` · ${r.totals.negatives} con stock negativo (no suman)` : ''}`,
      };
    }
    case 'periodo': {
      const r = salesByPeriod(sales, returns, { from, to, group: F.group });
      return {
        title: 'Informe de ventas por período', period,
        cols: [{ h: F.group === 'month' ? 'Mes' : F.group === 'week' ? 'Semana' : 'Día', k: 'label' }, { h: 'Ventas', k: 'count', n: 1 }, { h: 'Vendido', k: 'gross', m: 1 }, { h: 'Devoluciones', k: 'returns', m: 1 }, { h: 'Neto', k: 'total', m: 1 }, { h: 'IVA', k: 'iva', m: 1 }, { h: 'Intereses tarjeta', k: 'surcharge', m: 1 }, { h: 'Ticket prom.', k: 'avg', m: 1 }],
        rows: r.rows, totals: { label: 'TOTAL', ...r.totals },
      };
    }
    case 'cliente': {
      const r = salesByCustomer(sales, returns, { from, to, customerOf });
      return {
        title: 'Ventas por cliente', period,
        cols: [{ h: 'Cliente', k: 'name' }, { h: 'Compras', k: 'count', n: 1 }, { h: 'Vendido', k: 'gross', m: 1 }, { h: 'Devoluciones', k: 'returns', m: 1 }, { h: 'Neto', k: 'total', m: 1 }, { h: 'Promedio', k: 'avg', m: 1 }, { h: 'Última', k: 'last', f: r => fmtDate(r.last) }, { h: 'Saldo cta. cte.', k: 'balance', m: 1 }],
        rows: r.rows, totals: { name: 'TOTAL', ...r.totals },
      };
    }
    case 'artcliente': {
      const r = itemsByCustomer(sales, returns, { from, to, customerId: F.cust || null, customerOf });
      return {
        title: 'Artículos por cliente', period: period + (F.cust ? ` · ${(customerOf(F.cust) || {}).name || ''}` : ''),
        cols: [{ h: 'Cliente', k: 'customer' }, { h: 'Producto', k: 'name' }, { h: 'Cantidad', k: 'qty', n: 1 }, { h: 'Veces', k: 'times', n: 1 }, { h: 'Total', k: 'total', m: 1 }],
        rows: r.rows, totals: { customer: 'TOTAL', total: r.totals.total },
      };
    }
    case 'articulo': {
      const r = salesByArticle(sales, returns, { from, to, productOf, category: F.cat, supplierId: F.sup });
      return {
        title: 'Ventas por artículo', period,
        cols: [{ h: 'Producto', k: 'name' }, { h: 'Rubro', k: 'category' }, { h: 'Cantidad', k: 'qty', n: 1 }, { h: 'Total', k: 'total', m: 1 }, { h: 'Precio prom.', k: 'avg_price', m: 1 }, { h: 'Costo', k: 'cost', m: 1 }, { h: 'Ganancia', k: 'profit', m: 1 }, { h: 'Margen %', k: 'margin', n: 1 }],
        rows: r.rows, totals: { name: 'TOTAL', total: r.totals.total, cost: r.totals.cost, profit: r.totals.profit },
        note: 'La ganancia usa el costo actual del producto.',
      };
    }
    case 'compras': {
      const r = purchasesByArticle(inB(db.all('purchases')), { from, to, productOf, supplierOf: id => db.get('suppliers', id), supplierId: F.sup });
      return {
        title: 'Compras por artículo', period,
        cols: [{ h: 'Producto', k: 'name' }, { h: 'Cantidad', k: 'qty', n: 1 }, { h: 'Total', k: 'total', m: 1 }, { h: 'Costo prom.', k: 'avg_cost', m: 1 }, { h: 'Último costo', k: 'last_cost', m: 1 }, { h: 'Última compra', k: 'last', f: r => fmtDate(r.last) }, { h: 'Proveedor', k: 'supplier' }],
        rows: r.rows, totals: { name: 'TOTAL', total: r.totals.total },
      };
    }
    case 'promedio': {
      const r = salesAverages(sales, returns, { from, to });
      const t1 = { cols: [{ h: 'Día', k: 'label' }, { h: 'Ventas', k: 'count', n: 1 }, { h: 'Total', k: 'total', m: 1 }, { h: 'Días', k: 'days', n: 1 }, { h: 'Promedio por día', k: 'per_day', m: 1 }, { h: 'Ticket prom.', k: 'avg_ticket', m: 1 }], rows: r.byWeekday };
      const t2 = { cols: [{ h: 'Hora', k: 'label' }, { h: 'Ventas', k: 'count', n: 1 }, { h: 'Total', k: 'total', m: 1 }, { h: 'Promedio por día', k: 'per_day', m: 1 }, { h: 'Ticket prom.', k: 'avg_ticket', m: 1 }], rows: r.byHour };
      const max = Math.max(1, ...r.byHour.map(h => h.total));
      return {
        title: 'Ventas promedio', period, ...t1,
        note: `${r.days} días · ${r.count} ventas · total ${M(r.total)} · promedio por día ${M(r.per_day)} · ticket promedio ${M(r.avg_ticket)}`,
        extra: html`<div class="card"><h2>Por hora</h2><ul class="bars">${r.byHour.map(h => html`<li><div class="lbl"><span>${h.label}</span><span class="money">${M(h.per_day)} por día</span></div><div class="sub-lbl">${h.count} ventas · ${M(h.total)}</div><div class="track" aria-hidden="true"><div class="fill" style="width:${Math.max(2, (h.total / max) * 100)}%"></div></div></li>`)}</ul></div>`,
        second: t2,
      };
    }
    case 'novedades': {
      const r = priceNovelties(db.all('audit_log'), { from, to, productOf });
      return {
        title: 'Novedades: cambios de precio', period,
        cols: [{ h: 'Fecha', k: 'at', f: r => fmtDateTime(r.at) }, { h: 'Producto', k: 'name' }, { h: 'Antes', k: 'old', m: 1 }, { h: 'Ahora', k: 'price', m: 1 }, { h: 'Cambio %', k: 'pct', n: 1 }, { h: 'Precio actual', k: 'current', m: 1 }, { h: 'Usuario', k: 'user_id', f: r => (r.user_id ? userName(r.user_id) : '') }],
        rows: r, note: 'Salen los cambios hechos en el producto y en lote (los de lote, hasta 40 productos por cambio). Para imprimir los carteles, Productos → Etiquetas → “Cambiaron de precio desde…”.',
      };
    }
    default: return { title: '', cols: [], rows: [] };
  }
}

const cell = (c, r) => {
  const v = c.f ? c.f(r) : r[c.k];
  if (v === null || v === undefined || v === '') return '';
  if (c.m) return M(v);
  if (c.n) return typeof v === 'number' ? fmtQty(v) : v;
  return v;
};
function tableHTML(t, totals) {
  return html`<div class="table-wrap"><table class="ptable"><thead><tr>${t.cols.map(c => html`<th class="${c.m || c.n ? 'r' : ''}">${c.h}</th>`)}</tr></thead>
    <tbody>${t.rows.slice(0, 2000).map(r => html`<tr>${t.cols.map(c => html`<td class="${c.m || c.n ? 'r' : ''} ${c.m && Number(r[c.k]) < 0 ? 'neg' : ''}" style="${c.m || c.n ? '' : 'white-space:normal'}">${cell(c, r)}</td>`)}</tr>`)}</tbody>
    ${totals ? html`<tfoot><tr>${t.cols.map(c => html`<td class="${c.m || c.n ? 'r' : ''}">${totals[c.k] !== undefined ? (c.m ? M(totals[c.k]) : c.n ? fmtQty(totals[c.k]) : totals[c.k]) : ''}</td>`)}</tr></tfoot>` : ''}</table></div>
    ${t.rows.length > 2000 ? html`<p class="small muted">Se muestran 2.000 de ${t.rows.length} filas (el Excel tiene todas).</p>` : ''}`;
}

export function render(main) {
  if (!F.from) { F.from = monthStart(); F.to = today(); }
  try { const r = sessionStorage.getItem('jg_informe'); if (r && REPORTS.some(x => x[0] === r)) F.rep = r; } catch (e) { /* nada */ }
  const cats = [...new Set(db.all('products').map(p => p.category).filter(Boolean))].sort((a, b) => a.localeCompare(b, 'es'));
  const sups = db.all('suppliers').sort((a, b) => String(a.name).localeCompare(String(b.name), 'es'));
  const custs = db.all('customers').sort((a, b) => String(a.name).localeCompare(String(b.name), 'es'));
  const paint = () => {
    const R = build();
    const usesDates = !['stock'].includes(F.rep);
    main.innerHTML = String(html`
      <div class="page-head"><h1>Informes</h1></div>
      <div class="chips" role="group" aria-label="Informe" style="flex-wrap:wrap">${REPORTS.map(([k, l]) => html`<button type="button" class="chip" data-rep="${k}" aria-pressed="${F.rep === k}">${l}</button>`)}
        <a class="chip" href="#/comisiones">Comisiones</a><a class="chip" href="#/pedidos_prov">Faltantes</a><a class="chip" href="#/vencimientos">Por vencer</a></div>
      <div class="card"><div class="filters">
        ${usesDates ? html`<div class="field"><label for="in-f">Desde</label><input type="date" id="in-f" value="${F.from}"></div><div class="field"><label for="in-t">Hasta</label><input type="date" id="in-t" value="${F.to}"></div>` : ''}
        ${multiBranch() ? html`<div class="field"><label for="in-b">Sucursal</label><select id="in-b"><option value="all">Todas</option>${branches().map(b => html`<option value="${b.id}" ${F.branch === b.id ? 'selected' : ''}>${b.name}</option>`)}</select></div>` : ''}
        ${F.rep === 'periodo' ? html`<div class="field"><label for="in-g">Agrupar por</label><select id="in-g">${[['day', 'Día'], ['week', 'Semana'], ['month', 'Mes']].map(([k, l]) => html`<option value="${k}" ${F.group === k ? 'selected' : ''}>${l}</option>`)}</select></div>` : ''}
        ${['stock', 'articulo'].includes(F.rep) ? html`<div class="field"><label for="in-c">Rubro</label><select id="in-c"><option value="">Todos</option>${cats.map(c => html`<option ${c === F.cat ? 'selected' : ''}>${c}</option>`)}</select></div>` : ''}
        ${['stock', 'articulo', 'compras'].includes(F.rep) ? html`<div class="field"><label for="in-s">Proveedor</label><select id="in-s"><option value="">Todos</option>${sups.map(s => html`<option value="${s.id}" ${s.id === F.sup ? 'selected' : ''}>${s.name}</option>`)}</select></div>` : ''}
        ${F.rep === 'artcliente' ? html`<div class="field"><label for="in-cu">Cliente</label><select id="in-cu"><option value="">Todos</option>${custs.map(c => html`<option value="${c.id}" ${c.id === F.cust ? 'selected' : ''}>${c.name}</option>`)}</select></div>` : ''}
      </div>
      <div class="rep-tools"><button type="button" class="btn ghost" data-act="print" id="in-print">${ic('print')} Imprimir</button><button type="button" class="btn ghost" data-act="xls" id="in-xls">${ic('download')} Excel</button>
        ${usesDates ? html`<button type="button" class="btn ghost sm" data-quick="hoy">Hoy</button><button type="button" class="btn ghost sm" data-quick="mes">Este mes</button><button type="button" class="btn ghost sm" data-quick="ant">Mes anterior</button>` : ''}</div></div>
      <h2 id="in-title">${R.title}</h2><p class="muted small">${R.period}${R.note ? html`<br>${R.note}` : ''}</p>
      <div class="card" id="in-table">${tableHTML(R, R.totals)}</div>
      ${R.second ? html`<div class="card">${tableHTML(R.second)}</div>` : ''}
      ${R.extra || ''}`);
  };
  paint();
  const onChange = e => {
    const id = e.target.id;
    if (id === 'in-f') F.from = e.target.value || F.from;
    if (id === 'in-t') F.to = e.target.value || F.to;
    if (id === 'in-b') F.branch = e.target.value;
    if (id === 'in-g') F.group = e.target.value;
    if (id === 'in-c') F.cat = e.target.value;
    if (id === 'in-s') F.sup = e.target.value;
    if (id === 'in-cu') F.cust = e.target.value;
    paint();
  };
  main.addEventListener('change', onChange);
  const offs = [
    on(main, 'click', '[data-rep]', (e, el) => { F.rep = el.dataset.rep; try { sessionStorage.setItem('jg_informe', F.rep); } catch (x) { /* nada */ } paint(); }),
    on(main, 'click', '[data-quick]', (e, el) => {
      const d = new Date();
      if (el.dataset.quick === 'hoy') { F.from = F.to = today(); }
      if (el.dataset.quick === 'mes') { F.from = monthStart(); F.to = today(); }
      if (el.dataset.quick === 'ant') { F.from = toISODate(new Date(d.getFullYear(), d.getMonth() - 1, 1).getTime()); F.to = toISODate(new Date(d.getFullYear(), d.getMonth(), 0).getTime()); }
      paint();
    }),
    on(main, 'click', '[data-act]', (e, el) => {
      const R = build();
      if (el.dataset.act === 'xls') {
        const xcols = R.cols.map(c => ({ h: c.h, f: r => { const v = c.f ? c.f(r) : r[c.k]; return v === null || v === undefined ? '' : v; } }));
        const rows = toTable(R.rows, xcols);
        if (R.totals) rows.push(R.cols.map(c => R.totals[c.k] ?? ''));
        exportTable(R.title.toLowerCase().replace(/[^a-z0-9áéíóúñ]+/gi, '-'), R.title.slice(0, 31), rows);
      }
      if (el.dataset.act === 'print') printA4(html`<div class="ticket rep">${printHead(R.title, [R.period, ...(R.note ? [R.note] : [])])}${tableHTML(R, R.totals)}${R.second ? tableHTML(R.second) : ''}</div>`);
    }),
  ];
  return () => { offs.forEach(f => f()); main.removeEventListener('change', onChange); };
}
