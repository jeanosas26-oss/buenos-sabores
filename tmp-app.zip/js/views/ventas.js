// =====================================================================
// ventas.js — Historial de ventas con filtros, reimpresión, anulación y
// devoluciones / notas de crédito (totales o parciales).
// =====================================================================
import * as db from '../db.js';
import {
  ctx, settings, userName, voidSale, requestInvoice, multiBranch, branches, inBranch, branchName,
  saleReturns, returnBlockReason, createReturn, requestCreditNote, openSession,
} from '../ops.js';
import { html, raw, $, on, ic, icon, modal, toast, exportTable } from '../ui.js';
import {
  fmtMoney, fmtDateTime, fmtTime, fmtQty, toISODate, dayStart, dayEnd, payLabel, PAY_METHODS, can,
  cbteNombre, cbteLetra, ncTipo, fmtCbteNro, saleText, waLink, round2, round3, parseNum, discriminaIva, hasCae,
} from '../logic.js';
import { returnableLines, buildReturn, allLeftPicks, refundSplit, REFUND_METHODS } from '../negocio.js';
import { ticketHTML, printSale, drawQRs, returnTicketHTML, printReturn } from '../print.js';
import { saleExtraMatch, methodTotal, isManager } from '../control.js';
import { authorize } from '../autoriza.js';
import { auditOps } from '../seguridad.js';
import { facturaParaMandar } from '../factura-pdf.js';

let main;
// branch: '' = la sucursal de este equipo, 'all' = todas, o el id de una sucursal
const f = { from: toISODate(Date.now()), to: toISODate(Date.now()), method: '', user: '', status: '', branch: '', seller: '', doc: '', min: '', max: '', q: '' };
// Los filtros (menos las fechas, que arrancan en hoy) se recuerdan en este equipo
const FKEY = 'jg-filtros-ventas';
try { const sv = JSON.parse(localStorage.getItem(FKEY) || '{}'); for (const k of ['method', 'user', 'status', 'branch', 'seller', 'doc', 'min', 'max']) if (typeof sv[k] === 'string') f[k] = sv[k]; } catch (e) { /* sin almacenamiento */ }
const saveF = () => { try { const { from, to, q, ...rest } = f; localStorage.setItem(FKEY, JSON.stringify(rest)); } catch (e) { /* nada */ } };
const branchSel = () => f.branch || ctx.branchId;
const manager = () => !!ctx.user && can(ctx.user, 'reportes');
const canND = () => !!ctx.user && can(ctx.user, 'devolver');
const custName = id => (id && (db.get('customers', id) || {}).name) || '';

/** Para entrar con un filtro puesto (desde el tablero "Hoy"): status y días hacia atrás */
export function presetFilter({ status = '', days = 0 } = {}) {
  f.status = status;
  f.from = toISODate(Date.now() - days * 86400000);
  f.to = toISODate(Date.now());
  f.method = ''; f.user = ''; f.seller = ''; f.doc = ''; f.min = ''; f.max = ''; f.q = '';
  f.branch = multiBranch() ? 'all' : '';
}

export function render(m) {
  main = m;
  const users = db.all('users', { includeDeleted: true }).filter(u => u.name);
  const sellers = users.filter(u => u.role === 'vendedor' || db.all('sales').some(s => s.seller_id === u.id));
  const extra = ['seller', 'doc', 'min', 'max', 'q'].filter(k => f[k]).length;
  main.innerHTML = String(html`
    <div class="page-head"><h1>Ventas</h1>
      ${manager() || canND() ? html`<div class="btn-row">${canND() ? html`<button type="button" class="btn ghost" data-act="nd" id="v-nd">${raw(icon('plus'))} Nota de débito</button>` : ''}${manager() ? html`<button type="button" class="btn ghost" data-act="export">${raw(icon('download'))} Exportar Excel</button>` : ''}</div>` : ''}</div>
    <form class="card" id="vf" aria-label="Filtros">
      ${multiBranch() ? html`<div class="field"><label for="vf-b">Sucursal</label><select id="vf-b">
        ${branches({ includeInactive: true }).map(b => html`<option value="${b.id}" ${branchSel() === b.id ? 'selected' : ''}>${b.name}</option>`)}
        <option value="all" ${branchSel() === 'all' ? 'selected' : ''}>Todas las sucursales</option></select></div>` : ''}
      <div class="grid2">
        <div class="field"><label for="vf-from">Desde</label><input id="vf-from" type="date" value="${f.from}"></div>
        <div class="field"><label for="vf-to">Hasta</label><input id="vf-to" type="date" value="${f.to}"></div>
      </div>
      <div class="grid3">
        <div class="field"><label for="vf-m">Medio de pago</label><select id="vf-m"><option value="">Todos</option>${PAY_METHODS.map(p => html`<option value="${p.id}" ${f.method === p.id ? 'selected' : ''}>${p.label}</option>`)}</select></div>
        <div class="field"><label for="vf-u">Usuario</label><select id="vf-u"><option value="">Todos</option>${users.map(u => html`<option value="${u.id}" ${f.user === u.id ? 'selected' : ''}>${u.name}</option>`)}</select></div>
        <div class="field"><label for="vf-s">Estado</label><select id="vf-s"><option value="">Todas</option><option value="ok" ${f.status === 'ok' ? 'selected' : ''}>Válidas</option><option value="anulada" ${f.status === 'anulada' ? 'selected' : ''}>Anuladas</option><option value="pendiente" ${f.status === 'pendiente' ? 'selected' : ''}>Factura o NC pendiente</option><option value="devoluciones" ${f.status === 'devoluciones' ? 'selected' : ''}>Devoluciones / notas de crédito</option><option value="mandar" ${f.status === 'mandar' ? 'selected' : ''}>Facturas para mandar al cliente</option></select></div>
      </div>
      <details id="vf-more" ${extra ? 'open' : ''}><summary>Más filtros${extra ? ` (${extra})` : ''}</summary>
        <div class="field" style="margin-top:.6rem"><label for="vf-q">N° de venta, cliente o producto</label><input id="vf-q" type="search" value="${f.q}" autocomplete="off" placeholder="Ej: 1234, Gómez, yerba"></div>
        <div class="grid2">
          <div class="field"><label for="vf-d">Comprobante</label><select id="vf-d">${[['', 'Todos'], ['factura', 'Con factura (CAE)'], ['no_fiscal', 'No fiscal']].map(([v, l]) => html`<option value="${v}" ${f.doc === v ? 'selected' : ''}>${l}</option>`)}</select></div>
          ${sellers.length ? html`<div class="field"><label for="vf-v">Vendedor</label><select id="vf-v"><option value="">Todos</option>${sellers.map(u => html`<option value="${u.id}" ${f.seller === u.id ? 'selected' : ''}>${u.name}</option>`)}<option value="-" ${f.seller === '-' ? 'selected' : ''}>Sin vendedor</option></select></div>` : html`<span></span>`}
          <div class="field"><label for="vf-min">Monto desde</label><input id="vf-min" inputmode="decimal" value="${f.min}" placeholder="$ 0"></div>
          <div class="field"><label for="vf-max">Monto hasta</label><input id="vf-max" inputmode="decimal" value="${f.max}" placeholder="Sin tope"></div>
        </div>
        <button type="button" class="btn ghost sm" data-act="clear">Limpiar filtros</button>
      </details>
    </form>
    <div class="stats" id="v-sum"></div>
    <div class="card"><ul class="list" id="v-list"></ul></div>`);
  const sync = () => {
    f.from = $('#vf-from', main).value || f.from; f.to = $('#vf-to', main).value || f.to;
    f.method = $('#vf-m', main).value; f.user = $('#vf-u', main).value; f.status = $('#vf-s', main).value;
    const b = $('#vf-b', main);
    if (b) f.branch = b.value === ctx.branchId ? '' : b.value;
    f.doc = $('#vf-d', main).value; f.q = $('#vf-q', main).value.trim();
    const v = $('#vf-v', main); f.seller = v ? v.value : '';
    const num = el => { const x = parseNum(el.value); return el.value.trim() && isFinite(x) ? String(x) : ''; };
    f.min = num($('#vf-min', main)); f.max = num($('#vf-max', main));
    saveF();
    paint();
  };
  $('#vf', main).addEventListener('change', sync);
  let qt;
  $('#vf-q', main).addEventListener('input', () => { clearTimeout(qt); qt = setTimeout(sync, 200); });
  $('#vf', main).addEventListener('submit', e => e.preventDefault());
  paint();
  return on(main, 'click', '[data-sale], [data-ret], [data-act]', (e, el) => {
    if (el.dataset.sale) saleDetail(el.dataset.sale);
    else if (el.dataset.ret) returnDetail(el.dataset.ret);
    else if (el.dataset.act === 'export') exportSales();
    else if (el.dataset.act === 'nd') import('./nota-debito.js').then(m => m.debitNoteDialog(null)).then(r => { if (r) paint(); });
    else if (el.dataset.act === 'clear') { Object.assign(f, { method: '', user: '', status: '', seller: '', doc: '', min: '', max: '', q: '' }); saveF(); render(main); }
  });
}

/** Devoluciones del rango (por la fecha de la devolución) */
function filteredReturns() {
  const from = dayStart(f.from), to = dayEnd(f.to);
  const br = multiBranch() ? branchSel() : 'all';
  if (f.status && !['devoluciones', 'pendiente'].includes(f.status)) return [];
  return db.all('returns').filter(r => r.created_at >= from && r.created_at <= to
    && (br === 'all' || inBranch(r, br))
    && (!f.method || (r.refunds || []).some(p => p.method === f.method))
    && (!f.user || r.user_id === f.user)
    && (!f.q || saleExtraMatch({ ...r, number: r.number }, { q: f.q }, { custName }))
    && (!f.min || Number(r.total) >= Number(f.min)) && (!f.max || Number(r.total) <= Number(f.max))
    && (f.doc !== 'factura' || (r.doc && r.doc.kind === 'nota_credito' && r.doc.status === 'autorizado'))
    && (f.doc !== 'no_fiscal' || !(r.doc && r.doc.kind === 'nota_credito'))
    && (!f.seller || f.seller === '-')
    && (f.status !== 'pendiente' || (r.doc && r.doc.kind === 'nota_credito' && r.doc.status !== 'autorizado')))
    .sort((a, b) => b.created_at - a.created_at);
}

function filtered() {
  const from = dayStart(f.from), to = dayEnd(f.to);
  const br = multiBranch() ? branchSel() : 'all';
  if (f.status === 'devoluciones') return [];
  return db.all('sales').filter(s => s.created_at >= from && s.created_at <= to
    && (br === 'all' || inBranch(s, br))
    && (!f.method || (s.payments || []).some(p => p.method === f.method))
    && (!f.user || s.user_id === f.user)
    && (!f.status || (f.status === 'pendiente' ? s.doc && s.doc.kind === 'factura' && s.doc.status !== 'autorizado' : f.status === 'mandar' ? facturaParaMandar(s) : s.status === f.status))
    && saleExtraMatch(s, f, { custName }))
    .sort((a, b) => b.created_at - a.created_at);
}

function docBadge(s) {
  const d = s.doc || {};
  if (s.test) return html`<span class="badge warn" title="Factura de la etapa de prueba: no suma en los totales">De prueba</span>`;
  if (s.status === 'anulada') return html`<span class="badge err">Anulada</span>`;
  const dev = db.all('returns').some(r => r.sale_id === s.id) ? html` <span class="badge info">Con devolución</span>` : '';
  if (d.kind === 'factura') {
    if (d.status === 'autorizado') return html`<span class="badge ok">${cbteNombre(d.cbte_tipo)}</span>${dev}`;
    return html`<span class="badge warn">Factura ${d.status === 'rechazado' ? 'rechazada' : 'pendiente'}</span>${dev}`;
  }
  return html`<span class="badge">Ticket</span>${dev}`;
}

function returnBadge(r) {
  const d = r.doc || {};
  if (r.test) return html`<span class="badge warn">De prueba</span>`;
  if (d.kind === 'nota_credito') {
    if (d.status === 'autorizado') return html`<span class="badge ok">NC ${cbteLetra(d.cbte_tipo)}</span>`;
    return html`<span class="badge warn">NC ${d.status === 'rechazado' ? 'rechazada' : 'pendiente'}</span>`;
  }
  return html`<span class="badge info">Devolución</span>`;
}

function paint() {
  const list = filtered();
  const rets = filteredReturns();
  const ok = list.filter(s => s.status === 'ok' && !s.test); // las ventas "de prueba" (con CAE, de antes de empezar de cero) no suman
  const total = round2(ok.reduce((a, s) => a + s.total, 0));
  const devs = round2(rets.filter(r => !r.test).reduce((a, r) => a + r.total, 0));
  // El cajero / vendedor no ve los totales (si no, filtrando "Efectivo" sabría lo que tiene que haber en la caja)
  if (!manager()) $('#v-sum', main).innerHTML = String(html`<div class="stat"><div class="k">Ventas</div><div class="v">${ok.length}</div></div>`);
  else if (f.method) {
    const devM = round2(rets.filter(r => !r.test).reduce((a, r) => a + (r.refunds || []).filter(p => p.method === f.method).reduce((x, p) => x + p.amount, 0), 0));
    $('#v-sum', main).innerHTML = String(html`
    <div class="stat"><div class="k">Cobrado con ${payLabel(f.method)}</div><div class="v money" id="v-total">${fmtMoney(methodTotal(ok, f.method))}</div></div>
    <div class="stat"><div class="k">Ventas</div><div class="v">${ok.length}</div></div>
    ${devM ? html`<div class="stat"><div class="k">Devuelto con ${payLabel(f.method)}</div><div class="v money" id="v-devs">-${fmtMoney(devM)}</div></div>` : ''}
    <div class="stat"><div class="k">Total de esas ventas</div><div class="v money">${fmtMoney(total)}</div></div>`);
  } else $('#v-sum', main).innerHTML = String(html`
    <div class="stat"><div class="k">${devs ? 'Vendido' : 'Total'}</div><div class="v money" id="v-total">${fmtMoney(total)}</div></div>
    <div class="stat"><div class="k">Ventas</div><div class="v">${ok.length}</div></div>
    ${devs ? html`<div class="stat"><div class="k">Devoluciones (NC)</div><div class="v money" id="v-devs">-${fmtMoney(devs)}</div></div>
      <div class="stat"><div class="k">Neto</div><div class="v money" id="v-neto">${fmtMoney(total - devs)}</div></div>` : ''}`);
  const multiDay = f.from !== f.to;
  const showBranch = multiBranch() && branchSel() === 'all';
  // Ventas y devoluciones juntas, de la más nueva a la más vieja
  const rows = [...list.map(s => ({ t: s.created_at, s })), ...rets.map(r => ({ t: r.created_at, r }))].sort((a, b) => b.t - a.t);
  const retRow = r => html`<li>
    <button type="button" class="row" data-ret="${r.id}">
      <span class="grow"><span class="title">Devolución N° ${r.number} · ${multiDay ? fmtDateTime(r.created_at) : fmtTime(r.created_at)}</span>
        <span class="sub" style="display:block">${showBranch ? html`<span class="branch-tag">${branchName(r.branch_id)}</span> ` : ''}De la venta N° ${(db.get('sales', r.sale_id) || {}).number || '—'} · ${(r.refunds || []).map(p => payLabel(p.method)).join(' + ')} · ${userName(r.user_id)}</span></span>
      <span style="text-align:right"><b class="money" style="display:block;color:var(--danger)">-${fmtMoney(r.total)}</b>${returnBadge(r)}</span>
    </button></li>`;
  $('#v-list', main).innerHTML = rows.length ? String(html`${rows.slice(0, 300).map(({ s, r }) => r ? retRow(r) : html`<li>
    <button type="button" class="row" data-sale="${s.id}">
      <span class="grow"><span class="title">${s.doc_type === 'ND' ? 'Nota de débito ' : ''}N° ${s.number} · ${multiDay ? fmtDateTime(s.created_at) : fmtTime(s.created_at)}</span>
        <span class="sub" style="display:block">${showBranch ? html`<span class="branch-tag">${branchName(s.branch_id)}</span> ` : ''}${(s.payments || []).map(p => payLabel(p.method)).join(' + ')} · ${userName(s.user_id)}${s.customer_id ? ' · ' + ((db.get('customers', s.customer_id) || {}).name || '') : ''}</span></span>
      <span style="text-align:right"><b class="money" style="display:block;${s.status === 'anulada' ? 'text-decoration:line-through;color:var(--muted)' : ''}">${fmtMoney(s.total)}</b>${docBadge(s)}</span>
    </button></li>`)}${rows.length > 300 ? html`<li class="empty">Se muestran las 300 más recientes. Achicá el rango de fechas para ver otras.</li>` : ''}`)
    : String(html`<li class="empty">No hay ${f.status === 'devoluciones' ? 'devoluciones' : 'ventas'} ${f.method || f.user || f.status || f.doc || f.seller || f.min || f.max || f.q ? 'con esos filtros' : 'en esas fechas'}${multiBranch() && branchSel() !== 'all' ? ' en esta sucursal' : ''}.</li>`);
}

async function saleDetail(id) {
  const s = db.get('sales', id);
  const st = settings();
  const cust = s.customer_id ? db.get('customers', s.customer_id) : null;
  const d = s.doc || {};
  const rets = saleReturns(id);
  const canVoid = s.status === 'ok' && !rets.length && !s.test;
  const canReturn = s.status === 'ok' && !s.test;
  const retBlock = canReturn ? returnBlockReason(s) : '';
  const retry = s.status === 'ok' && d.kind === 'factura' && d.status !== 'autorizado';
  await modal({
    title: `Venta N° ${s.number}`,
    body: html`
      ${s.status === 'anulada' ? html`<div class="notice notice-error"><p><b>Venta anulada</b> ${s.voided_at ? `el ${fmtDateTime(s.voided_at)}` : ''} ${s.voided_by ? `por ${userName(s.voided_by)}` : ''}${s.void_reason ? ` — ${s.void_reason}` : ''}</p>
        ${d.credit_note ? html`<p>${cbteNombre(d.credit_note.cbte_tipo)} N° ${fmtCbteNro(d.credit_note.pto_vta, d.credit_note.cbte_nro)} · CAE ${d.credit_note.cae}</p>` : ''}</div>` : ''}
      ${retry ? html`<div class="notice notice-warn"><p><b>La factura está pendiente.</b> ${d.error || ''}</p></div>` : ''}
      ${facturaParaMandar(s) ? html`<div class="notice notice-info"><p><b>Esta factura se autorizó después de la venta:</b> mandásela al cliente${s.doc_contact ? html` (${s.doc_contact})` : ''}.</p></div>` : ''}
      ${rets.length ? html`<div class="card" id="sd-returns" style="padding:.6rem .8rem"><div class="card-head"><h2>Devoluciones de esta venta</h2></div>
        <ul class="list">${rets.map(r => html`<li><button type="button" class="row" data-open-ret="${r.id}">
          <span class="grow"><span class="title">N° ${r.number} · ${fmtDateTime(r.created_at)}</span>
          <span class="sub" style="display:block">${r.items.map(it => `${fmtQty(it.qty)} ${it.name}`).join(', ')}</span></span>
          <span style="text-align:right"><b class="money" style="display:block">-${fmtMoney(r.total)}</b>${returnBadge(r)}</span></button></li>`)}</ul>
        ${retBlock ? html`<p class="small muted">${retBlock}</p>` : ''}</div>` : ''}
      <div id="sd-ticket">${ticketHTML(s)}</div>`,
    onMount(m, close) {
      drawQRs(m);
      m.addEventListener('click', e => { const b = e.target.closest('[data-open-ret]'); if (b) { close(true); returnDetail(b.dataset.openRet); } });
    },
    actions: [
      ...(canReturn && !retBlock ? [{ label: raw(icon('back') + ' Nota de crédito / devolución'), kind: 'primary', id: 'sd-return', onClick: async close => {
        const auth = await authorize(`hacer una devolución de la venta N° ${s.number}`, { action: 'devolucion', entity: 'sales', entityId: id, perm: 'devolver' });
        if (!auth) return;
        close(true);
        const r = await returnDialog(db.get('sales', id), auth);
        paint();
        if (r) await afterReturn(r);
      } }] : []),
      ...(d.kind === 'factura' && d.status === 'autorizado' && s.status === 'ok' ? [{ label: raw(icon('whatsapp') + ' Mandar factura PDF'), kind: facturaParaMandar(s) ? 'primary' : '', id: 'sd-mandar', onClick: async close => {
        close(true);
        const { mandarFacturaDialog } = await import('./mandar-factura.js');
        await mandarFacturaDialog(id);
        paint();
      } }] : []),
      { label: raw(icon('print') + ' Imprimir'), onClick: () => printSale(db.get('sales', id)) },
      { label: raw(icon('whatsapp') + ' WhatsApp'), onClick: () => window.open(waLink(saleText(db.get('sales', id), st, cust ? cust.name : ''), cust ? cust.phone : ''), '_blank', 'noopener') },
      ...(canND() && s.status === 'ok' && !s.test && s.customer_id ? [{ label: 'Nota de débito', id: 'sd-nd', onClick: async close => {
        close(true);
        const { debitNoteDialog } = await import('./nota-debito.js');
        if (await debitNoteDialog(db.get('sales', id))) paint();
      } }] : []),
      ...(retry ? [{ label: 'Reintentar factura', kind: 'primary', onClick: async (close, w) => {
        const b = w.querySelector('.modal-foot .primary'); b.disabled = true; b.textContent = 'Pidiendo CAE…';
        const r = await requestInvoice(id);
        if (r.ok) { toast(`Factura autorizada. CAE ${r.doc.cae}`); close(true); paint(); }
        else { toast('No se pudo facturar: ' + r.error, 'error', 6000); b.disabled = false; b.textContent = 'Reintentar factura'; }
      } }] : []),
      ...(canVoid ? [{ label: 'Anular', kind: 'danger', id: 'sd-void', onClick: async close => {
        const auth = await authorize(`anular la venta N° ${s.number}`, { action: 'venta_anulada', entity: 'sales', entityId: s.id, perm: 'anular' });
        if (auth && await askVoid(s, auth)) { close(true); paint(); }
      } }] : []),
    ],
  });
}

async function askVoid(s, auth = null) {
  const facturada = s.doc && s.doc.kind === 'factura' && s.doc.status === 'autorizado';
  const r = await modal({
    title: `Anular venta N° ${s.number}`,
    body: html`<p class="lead">Se devuelve el stock${multiBranch() ? ` a ${branchName(s.branch_id)}` : ''}${(s.payments || []).some(p => p.method === 'cuenta_corriente') ? ', se descuenta de la cuenta corriente del cliente' : ''} y la venta deja de contar en la caja y en los reportes.</p>
      ${facturada ? html`<div class="notice notice-info"><p>Como tiene factura, se va a emitir una <b>nota de crédito</b> en ARCA.</p></div>` : ''}
      <div class="field"><label for="av-r">Motivo</label><input id="av-r" placeholder="Ej: error de carga, devolución"></div>
      <p id="av-err" class="field-err" role="alert"></p>`,
    actions: [{ label: 'No anular', value: false }, {
      label: 'Sí, anular', kind: 'danger', onClick: async (close, w) => {
        const reason = $('#av-r', w).value.trim();
        if (!reason) { $('#av-err', w).textContent = 'Escribí el motivo (queda registrado).'; $('#av-r', w).focus(); return; }
        const b = w.querySelector('.modal-foot .danger'); b.disabled = true; b.textContent = 'Anulando…';
        try {
          await voidSale(s.id, reason, { authorizedBy: auth && auth.by, extraOps: auditOps('venta_anulada', 'sales', s.id, { number: s.number, total: s.total, reason, payments: s.payments }, auth) });
          toast('Venta anulada.'); close(true);
        }
        catch (e) { $('#av-err', w).textContent = e.message; b.disabled = false; b.textContent = 'Sí, anular'; }
      },
    }],
  });
  return !!r;
}

async function exportSales() {
  const rows = [['numero', 'fecha', 'sucursal', 'usuario', 'cliente', 'comprobante', 'estado', 'medios', 'neto', 'iva', 'descuento', 'total']];
  for (const s of filtered().reverse()) {
    const d = s.doc || {};
    rows.push([s.number, fmtDateTime(s.created_at), branchName(s.branch_id), userName(s.user_id), (db.get('customers', s.customer_id) || {}).name || 'Consumidor final',
      d.kind === 'factura' && d.status === 'autorizado' ? `${cbteNombre(d.cbte_tipo)} ${fmtCbteNro(d.pto_vta, d.cbte_nro)}` : d.kind === 'factura' ? 'Factura pendiente' : 'No fiscal',
      s.status, (s.payments || []).map(p => `${payLabel(p.method)} ${p.amount}`).join(' + '), s.net, s.iva, s.discount, s.total]);
  }
  await exportTable(`ventas-${f.from}_a_${f.to}`, 'Ventas', rows);
}


// ---------- Devoluciones / notas de crédito ----------

/** Ventana para elegir qué se devuelve, el motivo y cómo se devuelve la plata. Devuelve la devolución guardada o null. */
export async function returnDialog(sale, auth = null) {
  const st = settings();
  const prev = saleReturns(sale.id);
  const lines = returnableLines(sale, prev).filter(l => l.left > 0.0005);
  const cust = sale.customer_id ? db.get('customers', sale.customer_id) : null;
  const fiscal = hasCae(sale);
  const letra = fiscal ? cbteLetra(ncTipo(sale.doc.cbte_tipo)) : '';
  const picks = {};
  let method = 'efectivo';
  const step = l => (Number.isInteger(l.sold) && Number.isInteger(l.left) ? 1 : 0.1);
  return modal({
    title: `Devolución · Venta N° ${sale.number}`,
    size: 'wide',
    body: html`
      ${fiscal ? html`<div class="notice notice-info"><p>Esta venta tiene <b>${cbteNombre(sale.doc.cbte_tipo)} ${fmtCbteNro(sale.doc.pto_vta, sale.doc.cbte_nro)}</b>: se va a emitir una <b>Nota de crédito ${letra}</b> en ARCA por lo que devuelvas, en el mismo punto de venta.</p></div>`
        : html`<p class="muted">Venta con ticket no fiscal: se hace un <b>comprobante de devolución</b> (no fiscal).</p>`}
      <p class="muted small">La mercadería vuelve al stock de <b>${branchName(sale.branch_id)}</b>${prev.length ? ` · ya tiene ${prev.length} ${prev.length === 1 ? 'devolución' : 'devoluciones'}` : ''}.</p>
      <div class="btn-row" style="margin-bottom:.6rem"><button type="button" class="btn ghost" data-all>${ic('check')} Devolver todo</button>
        <button type="button" class="btn ghost" data-none>Nada</button></div>
      <ul class="list ret-lines">${lines.map(l => html`<li class="ret-line" data-line="${l.line}">
        <div class="top"><span class="name">${l.name}</span><span class="money" data-amt="${l.line}">$ 0,00</span></div>
        <div class="sub muted small">Vendidos ${fmtQty(l.sold)}${l.returned ? ` · ya devueltos ${fmtQty(l.returned)}` : ''} · ${fmtMoney(l.unit_price)} c/u</div>
        <div class="ctrl">
          <button type="button" class="qty-btn" data-rdec="${l.line}" aria-label="Devolver uno menos de ${l.name}">${ic('minus')}</button>
          <label class="sr-only" for="rq-${l.line}">Cantidad a devolver de ${l.name}</label>
          <input id="rq-${l.line}" class="qty-val ret-qty" data-rq="${l.line}" data-step="${step(l)}" inputmode="decimal" autocomplete="off" value="0">
          <button type="button" class="qty-btn" data-rinc="${l.line}" aria-label="Devolver uno más de ${l.name}">${ic('plus')}</button>
          <span class="small muted">de ${fmtQty(l.left)}</span>
        </div></li>`)}</ul>
      <div class="field"><label for="rt-reason">Motivo</label><input id="rt-reason" list="rt-sug" placeholder="Ej: producto vencido">
        <datalist id="rt-sug">${['Producto vencido', 'Producto fallado', 'Error al cobrar', 'El cliente se arrepintió', 'Cambio por otro producto'].map(x => html`<option value="${x}"></option>`)}</datalist></div>
      <fieldset class="seg" id="rt-methods"><legend>¿Cómo se devuelve la plata?</legend>
        ${REFUND_METHODS.map(m => html`<label><input type="radio" name="rt-m" value="${m.id}" ${m.id === method ? 'checked' : ''} ${m.id === 'cuenta_corriente' && !cust ? 'disabled' : ''}><span>${m.label}</span></label>`)}
      </fieldset>
      <p class="small muted" id="rt-mhint"></p>
      <div class="change-box" id="rt-total" aria-live="polite"><div class="k">Total a devolver</div><div class="v" id="rt-tv">$ 0,00</div></div>
      <p id="rt-err" class="field-err" role="alert"></p>`,
    onMount(m) {
      const recalc = () => {
        let calc = null, err = '';
        try { calc = buildReturn(sale, prev, picks, discriminaIva(st.iva_condition)); } catch (e) { err = Object.values(picks).some(v => v > 0) ? e.message : ''; }
        for (const l of lines) {
          const el = m.querySelector(`[data-amt="${l.line}"]`);
          const it = calc && calc.items.find(x => x.line === l.line);
          el.textContent = fmtMoney(it ? it.subtotal : 0);
          m.querySelector(`[data-line="${l.line}"]`).classList.toggle('on', !!it);
        }
        $('#rt-tv', m).textContent = fmtMoney(calc ? calc.total : 0);
        $('#rt-total', m).className = 'change-box' + (calc ? ' ok' : '');
        const hint = { efectivo: openSession() ? 'Sale de la caja abierta y se descuenta del efectivo esperado.' : 'Hay que abrir la caja para devolver en efectivo.',
          cuenta_corriente: cust ? `Baja el saldo de ${cust.name}.` : '', mismo_medio: calc ? refundSplit(sale, calc.total, 'mismo_medio').map(p => `${payLabel(p.method)} ${fmtMoney(p.amount)}`).join(' + ') + ' (lo que no es efectivo devolvelo en el posnet, Mercado Pago o transferencia).' : 'Como se pagó la venta.' };
        $('#rt-mhint', m).textContent = hint[method] || '';
        $('#rt-err', m).textContent = err;
        const go = $('#rt-go', m.parentElement);
        if (go) go.disabled = !calc;
        return calc;
      };
      const setQty = (line, v) => {
        const l = lines.find(x => x.line === Number(line));
        if (!l) return;
        const q = Math.max(0, Math.min(l.left, round3(v)));
        picks[l.line] = q;
        const inp = m.querySelector(`[data-rq="${l.line}"]`);
        if (document.activeElement !== inp) inp.value = fmtQty(q);
      };
      m.addEventListener('click', e => {
        const inc = e.target.closest('[data-rinc]'), dec = e.target.closest('[data-rdec]');
        if (inc || dec) {
          const line = (inc || dec).dataset[inc ? 'rinc' : 'rdec'];
          const st = Number(m.querySelector(`[data-rq="${line}"]`).dataset.step);
          setQty(line, (picks[line] || 0) + (inc ? st : -st));
          recalc();
        }
        if (e.target.closest('[data-all]')) { for (const [k, v] of Object.entries(allLeftPicks(sale, prev))) setQty(k, v); recalc(); }
        if (e.target.closest('[data-none]')) { for (const l of lines) setQty(l.line, 0); recalc(); }
      });
      m.addEventListener('input', e => {
        const q = e.target.closest('[data-rq]');
        if (q) { const v = parseNum(q.value); picks[q.dataset.rq] = isFinite(v) && v > 0 ? round3(v) : 0; recalc(); }
      });
      m.addEventListener('change', e => {
        if (e.target.name === 'rt-m') { method = e.target.value; recalc(); }
        const q = e.target.closest('[data-rq]');
        if (q) { setQty(q.dataset.rq, picks[q.dataset.rq] || 0); q.value = fmtQty(picks[q.dataset.rq] || 0); recalc(); }
      });
      m.recalc = recalc;
      setTimeout(recalc, 0);
    },
    actions: [{ label: 'Cancelar', value: null }, {
      label: 'Confirmar devolución', kind: 'primary', id: 'rt-go', onClick: async (close, w) => {
        const b = $('#rt-go', w);
        b.disabled = true; b.textContent = 'Guardando…';
        try {
          const reason = $('#rt-reason', w).value.trim();
          const r = await createReturn({ sale_id: sale.id, picks, reason, refund_method: method, authorizedBy: auth && auth.by,
            extraOps: auditOps('devolucion', 'returns', '', { sale_id: sale.id, sale_number: sale.number, reason, refund_method: method }, auth) });
          close(r);
        } catch (e) {
          $('#rt-err', w).textContent = e.message;
          b.disabled = false; b.textContent = 'Confirmar devolución';
        }
      },
    }],
  });
}

/** Después de guardar: si lleva NC de ARCA la pide; muestra el comprobante para imprimir */
async function afterReturn(ret) {
  const fiscal = ret.doc && ret.doc.kind === 'nota_credito';
  let current = ret;
  await modal({
    title: `Devolución N° ${ret.number} guardada`,
    body: html`
      ${ret.refunds.some(p => p.method === 'efectivo') ? html`<div class="change-box ok"><div class="k">Devolver en efectivo</div><div class="v" id="rt-cash">${fmtMoney(ret.refunds.filter(p => p.method === 'efectivo').reduce((a, p) => a + p.amount, 0))}</div></div>` : ''}
      <div id="rt-status">${fiscal ? html`<div class="notice notice-info"><p><b>Pidiendo la nota de crédito a ARCA…</b></p></div>`
        : html`<div class="notice notice-ok"><p>${ic('check')} Devolución registrada. El stock volvió a ${branchName(ret.branch_id)}.</p></div>`}</div>
      <div id="rt-ticket">${returnTicketHTML(ret)}</div>`,
    onMount(m) {
      drawQRs(m);
      if (!fiscal) return;
      requestCreditNote(ret.id).then(r => {
        current = db.get('returns', ret.id);
        const box = $('#rt-status', m);
        if (!box) return;
        box.innerHTML = r.ok
          ? String(html`<div class="notice notice-ok"><p><b>${cbteNombre(r.doc.cbte_tipo)} autorizada.</b> N° ${fmtCbteNro(r.doc.pto_vta, r.doc.cbte_nro)} · CAE ${r.doc.cae}</p></div>`)
          : String(html`<div class="notice notice-warn"><p><b>La devolución se guardó, pero la nota de crédito quedó PENDIENTE.</b></p><p>${r.error}</p><p class="small">Se reintenta sola cuando vuelva internet, o desde Ventas.</p></div>`);
        $('#rt-ticket', m).innerHTML = String(returnTicketHTML(current));
        drawQRs(m);
        paint();
      });
    },
    actions: [
      { label: raw(icon('print') + ' Imprimir'), onClick: () => printReturn(current) },
      { label: 'Listo', kind: 'primary', value: true },
    ],
  });
}

async function returnDetail(id) {
  const r = db.get('returns', id);
  if (!r) return;
  const d = r.doc || {};
  const retry = d.kind === 'nota_credito' && d.status !== 'autorizado';
  await modal({
    title: `Devolución N° ${r.number}`,
    body: html`${retry ? html`<div class="notice notice-warn"><p><b>La nota de crédito está ${d.status === 'rechazado' ? 'rechazada' : 'pendiente'}.</b> ${d.error || ''}</p></div>` : ''}
      <div id="rd-ticket">${returnTicketHTML(r)}</div>`,
    onMount(m) { drawQRs(m); },
    actions: [
      { label: raw(icon('print') + ' Imprimir'), onClick: () => printReturn(db.get('returns', id)) },
      { label: 'Ver la venta', onClick: close => { close(true); saleDetail(r.sale_id); } },
      ...(retry ? [{ label: 'Reintentar nota de crédito', kind: 'primary', id: 'rd-retry', onClick: async (close, w) => {
        const b = $('#rd-retry', w); b.disabled = true; b.textContent = 'Pidiendo CAE…';
        const x = await requestCreditNote(id);
        if (x.ok) { toast(`Nota de crédito autorizada. CAE ${x.doc.cae}`); close(true); paint(); }
        else { toast('No se pudo: ' + x.error, 'error', 6000); b.disabled = false; b.textContent = 'Reintentar nota de crédito'; }
      } }] : []),
    ],
  });
}
