// =====================================================================
// login.js — Primer uso (asistente), elegir usuario + PIN y conectar nube.
// =====================================================================
import * as db from '../db.js';
import * as sync from '../sync.js';
import { saveSettings, saveUser, settings } from '../ops.js';
import { checkLocalPin, hasLocalPin, localVerifier } from '../pin.js';
import { html, $, on, ic, modal, toast, formData, fieldError } from '../ui.js';
import { validPin, validCuit, ROLES, pinMin, isSensitive } from '../logic.js';

let root, opts;
let offUser = null;

export function render(r, o) {
  root = r; opts = o;
  if (!db.count('users')) wizardStart();
  else chooseUser();
}

function shell(content) {
  root.innerHTML = String(html`<div class="login"><div class="login-box">
    <div class="login-logo"><img src="icons/icon-192.png" alt=""><div><b>JEANO Gestión</b><span class="muted">${settings().business_name || 'Tu comercio, ordenado'}</span></div></div>
    ${content}
  </div></div>`);
}

// ---------- Asistente de primer uso ----------

function wizardStart() {
  shell(html`<div class="card">
    <h1>¡Bienvenido!</h1>
    <p class="lead">Vamos a dejar todo listo en 2 pasos: los datos del comercio y tu usuario de dueño.</p>
    <div class="stack">
      <button type="button" class="btn primary big block" id="w-start">Empezar</button>
      <button type="button" class="btn ghost block" id="w-cloud">${ic('cloud')} Ya uso JEANO en otro equipo</button>
      <button type="button" class="btn ghost block hidden" data-install>${ic('install')} Instalar app</button>
    </div>
  </div>`);
  $('#w-start').onclick = () => wizardBusiness({});
  $('#w-cloud').onclick = () => cloudDialog();
  const ib = root.querySelector('[data-install]');
  if (!opts.app.isStandalone() && (opts.app.canInstall() || opts.app.isIOS)) ib.classList.remove('hidden');
  ib.onclick = () => opts.app.install();
}

function steps(n) { return html`<div class="steps" aria-label="Paso ${n} de 2"><i class="on"></i><i class="${n > 1 ? 'on' : ''}"></i></div>`; }

function wizardBusiness(data) {
  shell(html`<form class="card" id="wf" novalidate>
    ${steps(1)}
    <h1>Datos del comercio</h1>
    <div class="field"><label for="w-name">Nombre del comercio</label>
      <input id="w-name" name="business_name" autocomplete="organization" required value="${data.business_name || ''}" placeholder="Ej: Buenos Sabores"></div>
    <fieldset class="seg"><legend>Condición frente al IVA</legend>
      ${[['MT', 'Monotributo'], ['RI', 'Resp. Inscripto'], ['EX', 'Exento']].map(([v, l]) => html`
        <label><input type="radio" name="iva_condition" value="${v}" ${(data.iva_condition || 'MT') === v ? 'checked' : ''}><span>${l}</span></label>`)}
    </fieldset>
    <div class="field"><label for="w-cuit">CUIT <span class="muted">(opcional)</span></label>
      <input id="w-cuit" name="cuit" inputmode="numeric" value="${data.cuit || ''}" placeholder="20-12345678-9"></div>
    <div class="field"><label for="w-addr">Dirección <span class="muted">(opcional)</span></label>
      <input id="w-addr" name="address" autocomplete="street-address" value="${data.address || ''}"></div>
    <div class="field"><label for="w-phone">Teléfono <span class="muted">(opcional)</span></label>
      <input id="w-phone" name="phone" type="tel" autocomplete="tel" value="${data.phone || ''}"></div>
    <div class="btn-row"><button type="button" class="btn ghost" id="w-back">Volver</button><button class="btn primary big">Siguiente</button></div>
  </form>`);
  $('#w-back').onclick = wizardStart;
  $('#wf').onsubmit = e => {
    e.preventDefault();
    const f = formData(e.target);
    if (!f.business_name.trim()) return fieldError($('#w-name'), 'Escribí el nombre del comercio.');
    if (f.cuit.trim() && !validCuit(f.cuit)) return fieldError($('#w-cuit'), 'El CUIT no es válido. Revisalo o dejalo vacío.');
    wizardOwner({ ...data, ...f });
  };
}

function wizardOwner(data) {
  shell(html`<form class="card" id="wf" novalidate>
    ${steps(2)}
    <h1>Tu usuario (dueño)</h1>
    <p class="muted">Con tu nombre y un PIN de 6 a 8 números vas a entrar a la app. El dueño ve todo: costos, reportes y ajustes.</p>
    <div class="field"><label for="w-oname">Tu nombre</label><input id="w-oname" name="name" autocomplete="name" required value="${data.owner_name || ''}"></div>
    <div class="grid2">
      <div class="field"><label for="w-pin">PIN (6 a 8 números)</label><input id="w-pin" name="pin" type="password" inputmode="numeric" maxlength="8" autocomplete="new-password"></div>
      <div class="field"><label for="w-pin2">Repetí el PIN</label><input id="w-pin2" name="pin2" type="password" inputmode="numeric" maxlength="8" autocomplete="new-password"></div>
    </div>
    <div class="btn-row"><button type="button" class="btn ghost" id="w-back">Volver</button><button class="btn primary big" id="w-finish">Terminar</button></div>
  </form>`);
  $('#w-back').onclick = () => wizardBusiness(data);
  $('#wf').onsubmit = async e => {
    e.preventDefault();
    const f = formData(e.target);
    if (!f.name.trim()) return fieldError($('#w-oname'), 'Escribí tu nombre.');
    if (!validPin(f.pin) || f.pin.length < 6) return fieldError($('#w-pin'), 'El PIN del dueño tiene que tener de 6 a 8 números.');
    if (f.pin !== f.pin2) return fieldError($('#w-pin2'), 'Los PIN no coinciden.');
    $('#w-finish').disabled = true;
    await saveSettings({
      business_name: data.business_name.trim(), iva_condition: data.iva_condition, cuit: data.cuit.trim(),
      address: data.address.trim(), phone: data.phone.trim(), legal_name: data.business_name.trim(),
    });
    const u = await saveUser({ name: f.name, role: 'dueno', pin: f.pin });
    sync.rememberPin(u.id, f.pin);
    toast('¡Listo! Ya podés usar la app.');
    opts.onLogin(u);
  };
}

// ---------- Elegir sucursal (equipo nuevo en un comercio con varias sucursales) ----------

export function chooseBranch(r, list, onPick) {
  root = r;
  shell(html`<div class="card">
    <h1>¿En qué sucursal está este equipo?</h1>
    <p class="muted">Se elige una sola vez. Las ventas, la caja y el stock de este equipo van a ser de esa sucursal.</p>
    <div class="stack">
      ${list.map(b => html`<button type="button" class="btn ghost big block branch-pick" data-branch="${b.id}">
        ${ic('store')}<span class="grow" style="text-align:left"><b>${b.name}</b><small class="muted" style="display:block;font-weight:400">${b.address ? b.address + ' · ' : ''}Punto de venta ${b.pos_number}</small></span></button>`)}
    </div>
  </div>`);
  const off = on(root, 'click', '[data-branch]', async (e, el) => {
    off();
    root.querySelectorAll('[data-branch]').forEach(b => { b.disabled = true; });
    await onPick(el.dataset.branch);
  });
}

// ---------- Elegir usuario y PIN ----------

// PIN incorrecto 5 veces seguidas en este equipo: 5 minutos sin poder probar ese usuario (la nube, además, bloquea
// 15 minutos el pedido de sesión después de 5 intentos fallidos por usuario y equipo).
const LOCAL_MAX = 5;
const LOCAL_LOCK_MS = 5 * 60 * 1000;
function lockKey(uid) { return 'jg_pinlock_' + uid; }
function readLock(uid) { try { return JSON.parse(localStorage.getItem(lockKey(uid)) || 'null') || { n: 0, until: 0 }; } catch (e) { return { n: 0, until: 0 }; } }
function writeLock(uid, v) { try { if (v) localStorage.setItem(lockKey(uid), JSON.stringify(v)); else localStorage.removeItem(lockKey(uid)); } catch (e) { /* sin almacenamiento */ } }
function minutes(ms) { const m = Math.max(1, Math.ceil(ms / 60000)); return m === 1 ? '1 minuto' : `${m} minutos`; }

function chooseUser() {
  const users = db.all('users').filter(u => u.active).sort((a, b) => String(a.name || '').localeCompare(String(b.name || ''), 'es'));
  shell(html`<div class="card">
    <h1>¿Quién sos?</h1>
    <div class="users-grid" id="users-grid">
      ${users.map(u => html`<button type="button" class="user-btn" data-user="${u.id}">
        <span class="avatar" aria-hidden="true">${u.name[0].toUpperCase()}</span><b>${u.name}</b><small>${ROLES[u.role]}</small></button>`)}
    </div>
    <div id="l-waiting" aria-live="polite"></div>
  </div>
  <div class="btn-row">
    ${sync.isConfigured() ? '' : html`<button type="button" class="btn ghost" id="l-cloud">${ic('cloud')} Conectar a la nube</button>`}
    <button type="button" class="btn ghost hidden" data-install>${ic('install')} Instalar app</button>
  </div>`);
  // Un solo escuchador aunque se cambie de usuario varias veces (si no, el PIN se abría repetido)
  if (offUser) offUser();
  offUser = on(root, 'click', '[data-user]', (e, el) => {
    if (document.querySelector('.modal-wrap')) return;
    const u = db.get('users', el.dataset.user);
    if (u) askPin(u);
    else if (el.dataset.remote) remoteLogin({ id: el.dataset.user, name: el.dataset.name, role: el.dataset.role });
  });
  const c = $('#l-cloud');
  if (c) c.onclick = () => cloudDialog();
  const ib = root.querySelector('[data-install]');
  if (!opts.app.isStandalone() && (opts.app.canInstall() || opts.app.isIOS)) ib.classList.remove('hidden');
  ib.onclick = () => opts.app.install();
  extrasForLogin();
}

/**
 * Equipo autorizado: usuarios que el dueño dio de alta en otro equipo y todavía no bajaron a este (los trae la nube,
 * sin ningún secreto), y aviso de cambios de otros usuarios que esperan para subir.
 */
async function extrasForLogin() {
  if (!sync.isDevice()) return;
  const waiting = (await sync.waitingByAuthor()).filter(w => w.count);
  const box = $('#l-waiting');
  if (box && waiting.length) {
    const named = waiting.filter(w => w.name);
    const anon = waiting.filter(w => !w.name).reduce((a, w) => a + w.count, 0);
    box.innerHTML = String(html`<div class="notice notice-warn" id="l-wait-notice" style="margin-top:1rem"><p><b>Hay cambios guardados en este equipo que todavía no subieron a la nube.</b></p>
      <ul style="margin:.25rem 0 .5rem;padding-left:1.2rem">${named.map(w => html`<li>${w.count} ${w.count === 1 ? 'cambio' : 'cambios'} de ${w.name}</li>`)}${anon ? html`<li>${anon} ${anon === 1 ? 'cambio' : 'cambios'} sin usuario (los sube el dueño o el encargado)</li>` : ''}</ul>
      <p class="small">No se pierden: se suben cuando ${named.length ? 'esa persona,' : ''} el dueño o el encargado entren con su PIN en este equipo con internet.</p></div>`);
  }
  const remote = (await sync.cloudUsers()).filter(u => !db.get('users', u.id));
  const grid = $('#users-grid');
  if (!grid || !remote.length) return;
  for (const u of remote) {
    const b = document.createElement('button');
    b.type = 'button'; b.className = 'user-btn'; b.dataset.user = u.id; b.dataset.remote = '1'; b.dataset.name = u.name || ''; b.dataset.role = u.role || '';
    b.innerHTML = String(html`<span class="avatar" aria-hidden="true">${(u.name || '?')[0].toUpperCase()}</span><b>${u.name}</b><small>${ROLES[u.role] || ''}</small>`);
    grid.appendChild(b);
  }
}

/**
 * Teclado de PIN (4 a 8 números). Entra solo al completar `len` números (el largo del PIN de ese usuario) o con ✓.
 * verify(pin) devuelve true si entra, o el texto del error. Con lockUid cuenta los intentos fallidos de ese usuario en
 * este equipo (5 → 5 minutos).
 */
function pinModal({ title, hint = 'Ingresá tu PIN', verify, lockUid = null, len = 4 }) {
  let pin = '';
  let busy = false;
  const want = Math.min(8, Math.max(4, Number(len) || 4));
  return modal({
    title,
    body: html`<p class="muted" style="text-align:center">${hint}</p>
      <label class="sr-only" for="pin-in">PIN</label>
      <input id="pin-in" class="sr-only" type="password" inputmode="numeric" maxlength="8" autocomplete="off">
      <div class="pin-dots" aria-hidden="true">${Array.from({ length: want }, () => html`<i></i>`)}</div>
      <p id="pin-msg" class="field-err" role="alert" style="text-align:center;min-height:1.4em"></p>
      <div class="pinpad">${[1, 2, 3, 4, 5, 6, 7, 8, 9].map(n => html`<button type="button" data-k="${n}">${n}</button>`)}
        <button type="button" data-k="del" aria-label="Borrar">⌫</button><button type="button" data-k="0">0</button><button type="button" data-k="ok" aria-label="Entrar">✓</button></div>`,
    onMount(m, close) {
      const input = $('#pin-in', m);
      const msg = $('#pin-msg', m);
      const dotsBox = m.querySelector('.pin-dots');
      const paint = () => {
        const n = Math.max(want, pin.length);
        if (dotsBox.children.length !== n) dotsBox.innerHTML = '<i></i>'.repeat(n);
        [...dotsBox.children].forEach((d, i) => d.classList.toggle('on', i < pin.length));
      };
      const locked = () => {
        if (!lockUid) return false;
        const l = readLock(lockUid);
        if (l.until > Date.now()) { msg.textContent = `PIN incorrecto ${LOCAL_MAX} veces. Esperá ${minutes(l.until - Date.now())} para volver a probar (o pedile al dueño que te cambie el PIN).`; return true; }
        return false;
      };
      locked();
      const check = async (force = false) => {
        if (busy || pin.length < 4 || (!force && pin.length !== want && pin.length < 8)) return;
        if (locked()) { pin = ''; input.value = ''; paint(); return; }
        busy = true;
        const typed = pin;
        msg.textContent = '';
        let r;
        try { r = await verify(typed); } catch (e) { r = e.message; }
        busy = false;
        if (r === true) { if (lockUid) writeLock(lockUid, null); close(true); return; }
        if (lockUid && r && r.countFail !== false) {
          const l = readLock(lockUid);
          const n = (l.until && l.until <= Date.now() ? 0 : l.n) + 1;
          writeLock(lockUid, n >= LOCAL_MAX ? { n: 0, until: Date.now() + LOCAL_LOCK_MS } : { n, until: 0 });
          if (!locked()) msg.textContent = typeof r === 'string' ? r : r.msg;
        } else msg.textContent = typeof r === 'string' ? r : (r && r.msg) || 'PIN incorrecto.';
        pin = ''; input.value = ''; paint();
      };
      m.addEventListener('click', e => {
        const b = e.target.closest('[data-k]');
        if (!b || busy) return;
        if (b.dataset.k === 'ok') { check(true); return; }
        if (b.dataset.k === 'del') pin = pin.slice(0, -1);
        else if (pin.length < 8) pin += b.dataset.k;
        input.value = pin; paint(); check();
      });
      input.addEventListener('input', () => { pin = input.value.replace(/\D/g, '').slice(0, 8); input.value = pin; paint(); check(); });
      input.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); check(true); } });
      setTimeout(() => input.focus(), 50);
    },
  });
}

/** ¿Este usuario entra validando el PIN en la nube? (con nube: dueño, encargado y quien tenga permisos sensibles) */
function cloudOnly(user) { return sync.isConfigured() && isSensitive(user); }

const OFFLINE_SENSITIVE = 'Sin internet, el dueño y el encargado (y quien tenga permisos de supervisor) no pueden entrar: su PIN se valida en la nube. Cajeros y vendedores sí pueden entrar y vender.';

/** Aviso al entrar: dueño o encargado con un PIN de 4 números */
function shortPinWarning(user) {
  if (pinMin(user.role) > 4 && (Number(user.pin_len) || 4) < pinMin(user.role)) {
    toast(user.role === 'dueno' ? 'Tu PIN tiene 4 números: cambialo por uno de 6 a 8 en Ajustes → Usuarios.' : 'Tu PIN tiene 4 números: pedile al dueño que te lo cambie por uno de 6 a 8.', 'warn', 7000);
  }
}

async function askPin(user) {
  if (cloudOnly(user)) {
    // El dueño que recién autorizó el equipo y todavía no tiene PIN en la nube: lo crea ahora
    if (sync.isDevice() && navigator.onLine !== false && sync.sessionInfo() && sync.sessionInfo().uid === user.id) {
      const cu = (await sync.cloudUsers()).find(x => x.id === user.id);
      if (cu && !cu.has_pin) return createPin(user);
    }
    return cloudLogin(user);
  }
  if (!hasLocalPin(user)) {
    // Con nube y sin verificador en este equipo (todavía no bajó, o se lo cambiaron): se valida en la nube
    if (sync.isDevice() && navigator.onLine !== false) {
      const cu = (await sync.cloudUsers()).find(x => x.id === user.id);
      if (cu && cu.has_pin) return cloudLogin(user);
    }
    return createPin(user);
  }
  let tries = 0;
  const ok = await pinModal({
    title: `Hola, ${user.name}`,
    lockUid: user.id,
    len: user.pin_len,
    verify: async pin => {
      // El PIN se valida en el equipo (sin internet también se puede vender). La nube lo vuelve a verificar al
      // pedir la sesión de este usuario para subir sus cambios.
      const fresh = db.get('users', user.id) || user;
      const r = await checkLocalPin(fresh, pin);
      if (r.ok) {
        sync.rememberPin(user.id, pin);
        // Verificador viejo (sha256): se cambia por el nuevo en este equipo (la nube manda el suyo al entrar con internet)
        if (r.legacy) await db.put('users', { ...fresh, pin_local: await localVerifier(pin), pin_hash: null, pin_len: pin.length }, { fromSync: true });
        return true;
      }
      tries++;
      return tries >= 3 ? 'PIN incorrecto. Si lo olvidaste, pedile al dueño que lo cambie.' : 'PIN incorrecto, probá de nuevo.';
    },
  });
  if (ok) { const u = db.get('users', user.id); opts.onLogin(u); shortPinWarning(u); }
}

/**
 * Ingreso con el PIN validado en la nube (hace falta internet): dueño, encargado y permisos sensibles siempre;
 * cualquiera que todavía no tenga verificador en este equipo. Con el acceso viejo (sin equipo autorizado) se valida
 * con /api/device/verify-pin y el equipo se convierte en la primera sincronización.
 */
async function cloudLogin(user) {
  if (navigator.onLine === false) {
    await modal({ title: `Hola, ${user.name}`, body: html`<div class="notice notice-warn" id="pin-offline"><p>${isSensitive(user) && sync.isConfigured() ? OFFLINE_SENSITIVE : 'Para entrar por primera vez en este equipo hace falta internet.'}</p></div>`, actions: [{ label: 'Entendido', kind: 'primary', value: true }] });
    return;
  }
  const ok = await pinModal({
    title: `Hola, ${user.name}`,
    hint: 'Ingresá tu PIN (se verifica en la nube)',
    lockUid: user.id,
    len: user.pin_len,
    verify: async pin => {
      try {
        if (sync.isDevice()) await sync.openSession(user, pin);
        else { await sync.verifySupervisor(user, pin); sync.rememberPin(user.id, pin); }
      } catch (e) {
        if (e.offline || e.network) return { msg: 'No hay conexión con la nube. ' + OFFLINE_SENSITIVE, countFail: false };
        return e.code === 'BAD_PIN' ? { msg: e.message } : { msg: e.message, countFail: false };
      }
      if (!db.get('users', user.id)) await sync.syncNow(); // usuario nuevo en este equipo: bajan sus datos
      return true;
    },
  });
  if (!ok) return;
  const u = db.get('users', user.id);
  if (u) { opts.onLogin(u); shortPinWarning(u); }
  else toast('Todavía no bajaron los datos de tu usuario. Probá de nuevo en un momento.', 'warn', 5000);
}

/** Usuario que la nube conoce y este equipo todavía no bajó */
function remoteLogin(cu) { return cloudLogin(cu); }

/**
 * "Ingresá tu PIN para sincronizar": la sesión de la nube venció (12 h) o se recargó la app. Se pide el PIN del
 * usuario que ya está adentro (se valida en el equipo, si tiene verificador, y en la nube).
 */
export async function cloudPin(user) {
  if (!user) return false;
  const local = db.get('users', user.id) || user;
  const ok = await pinModal({
    title: 'Sincronizar con la nube',
    hint: `${local.name}, ingresá tu PIN para subir tus cambios`,
    lockUid: user.id,
    len: local.pin_len,
    verify: async pin => {
      if (hasLocalPin(local) && !(await checkLocalPin(local, pin)).ok) return 'PIN incorrecto, probá de nuevo.';
      try { await sync.openSession(local, pin); } catch (e) { return { msg: e.message, countFail: e.code === 'BAD_PIN' }; }
      return true;
    },
  });
  if (ok) {
    const done = await sync.syncNow();
    toast(done ? 'Sincronizado.' : (sync.status.error || 'No se pudo sincronizar.'), done ? 'ok' : 'warn');
  }
  return !!ok;
}

/** Formulario "elegí tu PIN" (dos campos): devuelve el PIN o null */
function pinForm({ title, intro, role, id = 'cp', dismissable = true, onSave }) {
  const min = pinMin(role);
  return modal({
    title,
    dismissable,
    body: html`<p>${intro}</p>
      <form id="${id}" novalidate><div class="grid2">
      <div class="field"><label for="${id}1">PIN (${min} a 8 números)</label><input id="${id}1" type="password" inputmode="numeric" maxlength="8" autocomplete="new-password"></div>
      <div class="field"><label for="${id}2">Repetir</label><input id="${id}2" type="password" inputmode="numeric" maxlength="8" autocomplete="new-password"></div></div></form>
      <p id="${id}-err" class="field-err" role="alert"></p>`,
    actions: [...(dismissable ? [{ label: 'Cancelar', value: null }] : []), {
      label: 'Guardar PIN', kind: 'primary', id: `${id}-go`, onClick: async (close, w) => {
        const a = $(`#${id}1`, w), b = $(`#${id}2`, w);
        if (!validPin(a.value) || a.value.length < min) return fieldError(a, `Tienen que ser de ${min} a 8 números.`);
        if (a.value !== b.value) return fieldError(b, 'No coinciden.');
        const btn = $(`#${id}-go`, w); btn.disabled = true;
        try { close(await onSave(a.value)); } catch (e) { $(`#${id}-err`, w).textContent = e.message; btn.disabled = false; }
      },
    }],
  });
}

async function createPin(user) {
  // Con nube: el PIN lo carga el dueño (Ajustes → Usuarios). Acá solo lo crea el dueño que acaba de conectar el equipo
  // con su contraseña (tiene la sesión de la nube): así nadie se "inventa" un PIN para otro.
  if (sync.isConfigured()) {
    const s = sync.sessionInfo();
    if (!sync.isDevice() || !s || s.uid !== user.id) {
      await modal({
        title: `Hola, ${user.name}`,
        body: html`<div class="notice notice-warn" id="cp-none"><p>Tu usuario todavía no tiene PIN${navigator.onLine === false ? ' en este equipo' : ''}.</p>
          <p>${navigator.onLine === false ? 'Entrá una vez con internet (o pedile al dueño que te cargue el PIN en Ajustes → Usuarios).' : html`Pedile al dueño que te lo cargue en <b>Ajustes → Usuarios</b>.`}</p></div>`,
        actions: [{ label: 'Entendido', kind: 'primary', value: true }],
      });
      return;
    }
  }
  const u = await pinForm({
    title: `Hola, ${user.name}`, role: user.role,
    intro: 'Este usuario todavía no tiene PIN: creá uno para entrar.',
    onSave: async pin => { const r = await saveUser({ ...user, pin }); sync.rememberPin(r.id, pin); return r; },
  });
  if (u) opts.onLogin(db.get('users', u.id) || u);
}

// ---------- Nube ----------

/**
 * Enlaza el usuario de la nube con el local: si el dueño ya existía en este
 * equipo con otro id, se pasa su PIN al usuario de la nube y el local queda dado de baja.
 */
export async function linkCloudUser(cloudUser, localUser) {
  if (!cloudUser || !cloudUser.id) return localUser;
  const existing = db.get('users', cloudUser.id);
  const match = localUser || db.all('users').find(u => u.email && cloudUser.email && u.email.toLowerCase() === cloudUser.email.toLowerCase());
  if (match && match.id !== cloudUser.id) {
    // El hash del PIN depende del id del usuario: no se puede copiar. Si el dueño entró recién con su PIN (está en
    // memoria), se calcula para el usuario de la nube; si no, el PIN se vuelve a crear una vez.
    const pin = sync.pinFor(match.id);
    const rec = { id: cloudUser.id, name: match.name || cloudUser.name, role: cloudUser.role || match.role, email: cloudUser.email || match.email, active: 1, pin_hash: null, pin_local: null };
    if (pin) sync.rememberPin(cloudUser.id, pin);
    const saved = await db.put('users', rec);
    await db.put('users', { id: match.id, active: 0, deleted: 1 });
    return saved;
  }
  if (!existing) return db.put('users', { id: cloudUser.id, name: cloudUser.name || cloudUser.email, role: cloudUser.role || 'dueno', email: cloudUser.email || '', active: 1, pin_hash: null });
  return existing;
}

/** El dueño recién conectado sin PIN en la nube: lo elige ahora (queda en la nube, para entrar con PIN en los equipos) */
async function ownerPin(user) {
  return pinForm({
    title: 'Tu PIN para la nube', role: user.role, id: 'op', dismissable: false,
    intro: 'Listo, este equipo quedó autorizado. Elegí tu PIN: con él vas a entrar en este equipo y en los otros (celu, otra PC). Se valida en la nube.',
    onSave: async pin => { await sync.setUserPin(user.id, pin); return db.get('users', user.id) || user; },
  });
}

/** Ventana para conectar con la nube (login o crear cuenta) */
export async function cloudDialog({ currentUser = null, onDone = null } = {}) {
  const cfg = sync.config();
  const st = settings();
  const defUrl = sync.cleanUrl((globalThis.JG_CONFIG && globalThis.JG_CONFIG.cloudUrl) || '');
  return modal({
    title: 'Conectar a la nube',
    body: html`<p class="muted">Con la nube tus datos se guardan en internet y podés usar la app en varios equipos. Te la configura JEANO DIGITAL.</p>
      <form id="cf" novalidate>
        <fieldset class="seg"><legend class="sr-only">Tipo</legend>
          <label><input type="radio" name="mode" value="login" checked><span>Ya tengo cuenta</span></label>
          <label><input type="radio" name="mode" value="register"><span>Crear cuenta</span></label>
        </fieldset>
        ${defUrl && !cfg.url
          ? html`<details class="small"><summary>Servidor: ${defUrl.replace(/^https?:\/\//, '')}</summary>
              <div class="field"><label for="c-url">Dirección del servidor</label><input id="c-url" name="url" inputmode="url" autocomplete="url" value="${defUrl}"></div></details>`
          : html`<div class="field"><label for="c-url">Dirección del servidor</label><input id="c-url" name="url" inputmode="url" autocomplete="url" value="${cfg.url || defUrl}" placeholder="https://gestion.ejemplo.workers.dev"></div>`}
        <div class="field"><label for="c-mail">Email</label><input id="c-mail" name="email" type="email" autocomplete="email" value="${(currentUser && currentUser.email) || ''}"></div>
        <div class="field"><label for="c-pass">Contraseña</label><input id="c-pass" name="password" type="password" autocomplete="current-password" autocapitalize="off" autocorrect="off" spellcheck="false"></div>
        <label class="check"><input type="checkbox" id="c-show"> Mostrar contraseña</label>
        <div class="field"><label for="c-dev">Nombre de este equipo</label><input id="c-dev" name="device_name" value="${(cfg.device && cfg.device.name) || sync.defaultDeviceName()}" placeholder="Ej: PC de caja, Celu de Carla" maxlength="80">
          <div class="hint">El equipo queda autorizado: después cada uno entra con su PIN. La contraseña no se guarda en el equipo y el acceso se le puede quitar desde Ajustes → Equipos.</div></div>
        <div id="reg-extra" class="hidden">
          <div class="field"><label for="c-name">Tu nombre</label><input id="c-name" name="name" value="${(currentUser && currentUser.name) || ''}"></div>
          <div class="field"><label for="c-biz">Nombre del comercio</label><input id="c-biz" name="business_name" value="${st.business_name || ''}"></div>
        </div>
        <p id="c-msg" role="alert" class="field-err"></p>
      </form>`,
    onMount(m) {
      m.querySelectorAll('[name=mode]').forEach(r => r.addEventListener('change', () => {
        $('#reg-extra', m).classList.toggle('hidden', formData($('#cf', m)).mode !== 'register');
      }));
      $('#cf', m).addEventListener('submit', e => e.preventDefault());
      $('#c-show', m).addEventListener('change', e => { $('#c-pass', m).type = e.target.checked ? 'text' : 'password'; });
    },
    actions: [{ label: 'Cancelar', value: false }, {
      label: 'Conectar', kind: 'primary', id: 'c-go', onClick: async (close, w) => {
        const f = formData($('#cf', w));
        const msg = $('#c-msg', w);
        if (!f.url.trim()) return fieldError($('#c-url', w), 'Escribí la dirección del servidor.');
        if (!f.email.trim()) return fieldError($('#c-mail', w), 'Escribí tu email.');
        if (f.password.length < 6) return fieldError($('#c-pass', w), 'La contraseña tiene que tener al menos 6 caracteres.');
        if (f.mode === 'register' && !f.name.trim()) return fieldError($('#c-name', w), 'Escribí tu nombre.');
        const btn = $('#c-go', w);
        btn.disabled = true; btn.textContent = 'Conectando…'; msg.textContent = '';
        try {
          const res = await sync.connect({ url: f.url, email: f.email.trim(), password: f.password, mode: f.mode, name: f.name.trim(), business_name: (f.business_name || '').trim() || st.business_name, device_name: (f.device_name || '').trim() });
          await sync.syncNow();
          let u = await linkCloudUser(res.user, currentUser);
          // Si el dueño ya estaba adentro, sigue adentro con su usuario de la nube (y su sesión)
          if (currentUser && u) sync.setUser(u);
          close(true);
          // Su usuario de la nube necesita PIN (para entrar con PIN en este y en los otros equipos)
          if (currentUser && u && sync.isDevice()) {
            const cu = (await sync.cloudUsers()).find(x => x.id === u.id);
            if (!cu || !cu.has_pin) {
              // El PIN con el que entró recién (en memoria) pasa a la nube; si no sirve (4 números) o no está, lo elige
              const pin = sync.pinFor(u.id);
              let ok = false;
              if (pin && pin.length >= 6) { try { await sync.setUserPin(u.id, pin); ok = true; } catch (e) { console.warn(e); } }
              if (!ok) await ownerPin(u);
              u = db.get('users', u.id) || u;
            }
          }
          toast('Conectado a la nube.');
          if (onDone) onDone(u);
          else render(root, opts); // ahora hay usuarios: se elige usuario y PIN
        } catch (err) {
          msg.textContent = err.message + (/contraseña incorrect/i.test(err.message)
            ? ' Tocá "Mostrar contraseña" para revisarla (mayúsculas y espacios cuentan). Si no la recordás, cambiala desde la PC: Ajustes → Nube → Cambiar contraseña de la nube.' : '');
          btn.disabled = false; btn.textContent = 'Conectar';
        }
      },
    }],
  });
}

