// =====================================================================
// remitos.js — Remitos internos entre sucursales: mandar mercadería a otra
// sucursal (descuenta en origen), recibirla controlando lo que llegó (suma en
// destino y registra faltantes/sobrantes), anular e imprimir.
// =====================================================================
import * as db from '../db.js';
import {
  ctx, branches, branchName, currentBranch, multiBranch, stockOf, userName,
  createTransfer, receiveTransfer, voidTransfer, transfersToReceive,
} from '../ops.js';
import { html, raw, $, on, ic, icon, modal, toast, confirm } from '../ui.js';
import { fmtDateTime, fmtQty, parseNum, round3, searchProducts, findByCode, can } from '../logic.js';
import { transferDifferences } from '../negocio.js';
import { transferHTML, printTransfer } from '../print.js';
import { openScanner, canScan, scanButton, codeVariants, playError } from '../scanner.js';

let main;
const nro = t => String(t.number || 0).padStart(6, '0');
const STATUS = { enviado: ['warn', 'En camino'], recibido: ['ok', 'Recibido'], anulado: ['err', 'Anulado'] };
const badge = t => { const [k, l] = STATUS[t.status] || ['', t.status]; return html`<span class="badge ${k}">${l}</span>`; };

function products() { return db.all('products').filter(p => p.active !== 0); }
function findCode(code) {
  const list = products();
  for (const c of codeVariants(code)) { const p = findByCode(list, c); if (p) return p; }
  return null;
}

export function render(m) {
  main = m;
  paint();
  return on(main, 'click', '[data-act], [data-tr]', async (e, el) => {
    if (el.dataset.tr) return openTransfer(el.dataset.tr);
    if (el.dataset.act === 'new') { const t = await newTransfer(); paint(); if (t) await showTransfer(t, true); }
  });
}

function row(t, here) {
  const other = t.from_branch === here ? `Para ${branchName(t.to_branch)}` : `Desde ${branchName(t.from_branch)}`;
  const n = (t.items || []).length;
  const faltan = (t.differences || []).filter(d => d.diff < 0).length;
  return html`<li><button type="button" class="row" data-tr="${t.id}">
    <span class="grow"><span class="title">Remito N° ${nro(t)} · ${other}</span>
      <span class="sub" style="display:block">${fmtDateTime(t.created_at)} · ${n} ${n === 1 ? 'producto' : 'productos'} · envió ${userName(t.created_by)}${faltan ? html` · <b style="color:var(--danger)">${faltan} con faltante</b>` : ''}</span></span>
    ${badge(t)}</button></li>`;
}

function paint() {
  const here = ctx.branchId;
  const cur = currentBranch();
  const all = db.all('transfers').sort((a, b) => b.created_at - a.created_at);
  const toReceive = transfersToReceive(here);
  const sent = all.filter(t => t.status === 'enviado' && t.from_branch === here);
  const mine = all.filter(t => t.status !== 'enviado' && (t.from_branch === here || t.to_branch === here || can(ctx.user, 'remitos'))).slice(0, 50);
  const canSend = can(ctx.user, 'remitos') && branches().length > 1;
  main.innerHTML = String(html`
    <div class="page-head"><h1>Remitos${cur ? html` <span class="branch-tag" style="font-size:.9rem;vertical-align:middle">${cur.name}</span>` : ''}</h1>
      ${canSend ? html`<button type="button" class="btn primary" data-act="new">${ic('truck')} Mandar a otra sucursal</button>` : ''}</div>
    ${!multiBranch() ? html`<div class="notice notice-info"><p>Los remitos son para pasar mercadería entre sucursales. Creá la segunda sucursal en Ajustes → Sucursales.</p></div>` : ''}
    <section class="card" id="tr-in" aria-labelledby="h-tri"><div class="card-head"><h2 id="h-tri">Por recibir en ${cur ? cur.name : 'esta sucursal'}</h2>
      ${toReceive.length ? html`<span class="badge warn">${toReceive.length}</span>` : ''}</div>
      ${toReceive.length ? html`<ul class="list">${toReceive.map(t => row(t, here))}</ul>`
        : html`<p class="muted">No hay mercadería en camino para esta sucursal.</p>`}</section>
    <section class="card" id="tr-out" aria-labelledby="h-tro"><h2 id="h-tro">Enviados que todavía no recibieron</h2>
      ${sent.length ? html`<ul class="list">${sent.map(t => row(t, here))}</ul>` : html`<p class="muted">Nada en camino desde esta sucursal.</p>`}</section>
    <section class="card" aria-labelledby="h-trh"><h2 id="h-trh">Historial</h2>
      ${mine.length ? html`<ul class="list">${mine.map(t => row(t, here))}</ul>` : html`<p class="muted">Todavía no hay remitos recibidos ni anulados.</p>`}</section>`);
}

// ---------- Nuevo remito ----------

async function newTransfer() {
  const from = ctx.branchId;
  const dests = branches().filter(b => b.id !== from);
  const lines = []; // {product_id, name, qty}
  let to = dests.length === 1 ? dests[0].id : '';
  return modal({
    title: `Mandar mercadería desde ${branchName(from)}`,
    size: 'wide',
    body: html`
      <div class="field"><label for="tr-to">¿A qué sucursal va?</label><select id="tr-to">
        ${dests.length > 1 ? html`<option value="">Elegí la sucursal…</option>` : ''}
        ${dests.map(b => html`<option value="${b.id}" ${b.id === to ? 'selected' : ''}>${b.name}</option>`)}</select></div>
      <form class="searchbox${canScan() ? ' has-scan' : ''}" id="tr-sf" role="search" style="margin-bottom:.5rem">
        ${ic('search')}<label for="tr-q" class="sr-only">Buscar producto por nombre o código</label>
        <input id="tr-q" type="search" autocomplete="off" enterkeyhint="go" placeholder="Buscar o escanear producto…">
        ${scanButton('data-trscan id="tr-scan"', 'Escanear con la cámara')}
      </form>
      <div id="tr-res" class="results hidden" role="listbox" aria-label="Resultados"></div>
      <ul class="list" id="tr-lines"></ul>
      <div class="field"><label for="tr-notes">Notas <span class="muted">(opcional)</span></label><input id="tr-notes" placeholder="Ej: lleva Juan en la camioneta"></div>
      <p id="tr-err" class="field-err" role="alert"></p>`,
    onMount(m) {
      const paintLines = () => {
        $('#tr-lines', m).innerHTML = lines.length ? String(html`${lines.map((l, i) => {
          const p = db.get('products', l.product_id);
          const st = p ? stockOf(p, from) : 0;
          return html`<li class="ret-line on"><div class="top"><span class="name">${l.name}</span>
            <button type="button" class="icon-btn" data-trdel="${i}" aria-label="Quitar ${l.name}">${ic('trash')}</button></div>
            <div class="sub small ${st < l.qty ? '' : 'muted'}" ${st < l.qty ? raw('style="color:var(--danger)"') : ''}>Stock en ${branchName(from)}: ${fmtQty(st)}${st < l.qty ? ' (queda negativo)' : ''}</div>
            <div class="ctrl"><button type="button" class="qty-btn" data-trdec="${i}" aria-label="Uno menos de ${l.name}">${ic('minus')}</button>
              <label class="sr-only" for="tq-${i}">Cantidad de ${l.name}</label>
              <input id="tq-${i}" class="qty-val" data-trq="${i}" inputmode="decimal" autocomplete="off" value="${fmtQty(l.qty)}">
              <button type="button" class="qty-btn" data-trinc="${i}" aria-label="Uno más de ${l.name}">${ic('plus')}</button></div></li>`;
        })}`) : String(html`<li class="empty">Buscá o escaneá los productos que mandás.</li>`);
        const go = $('#tr-go', m.parentElement);
        if (go) go.disabled = !lines.length;
      };
      const add = (p, qty = 1) => {
        if (!p) return;
        const ex = lines.find(l => l.product_id === p.id);
        if (ex) ex.qty = round3(ex.qty + qty); else lines.push({ product_id: p.id, name: p.name, qty });
        paintLines();
      };
      const q = $('#tr-q', m);
      const res = $('#tr-res', m);
      const showRes = () => {
        const list = q.value.trim() ? searchProducts(products(), q.value, 20) : [];
        res.classList.toggle('hidden', !q.value.trim());
        res.innerHTML = list.length ? String(html`${list.map(p => html`<button type="button" class="result" data-tradd="${p.id}"><span class="grow"><span class="title">${p.name}</span>
          <span class="sub muted small" style="display:block">${p.barcode || p.sku || p.category} · Stock ${fmtQty(stockOf(p, from))}</span></span></button>`)}`)
          : String(html`<div class="empty">No encontramos “${q.value}”.</div>`);
      };
      q.addEventListener('input', showRes);
      $('#tr-sf', m).addEventListener('submit', e => {
        e.preventDefault();
        const p = findCode(q.value) || (searchProducts(products(), q.value, 2).length === 1 ? searchProducts(products(), q.value, 2)[0] : null);
        if (p) { add(p); q.value = ''; showRes(); q.focus(); } else if (/^\d{6,14}$/.test(q.value.trim())) toast(`No hay ningún producto con el código ${q.value.trim()}.`, 'warn');
      });
      m.addEventListener('click', async e => {
        const a = e.target.closest('[data-tradd]');
        if (a) { add(db.get('products', a.dataset.tradd)); q.value = ''; showRes(); return; }
        const inc = e.target.closest('[data-trinc]'), dec = e.target.closest('[data-trdec]'), del = e.target.closest('[data-trdel]');
        if (inc) { lines[inc.dataset.trinc].qty = round3(lines[inc.dataset.trinc].qty + 1); paintLines(); }
        if (dec) { const l = lines[dec.dataset.trdec]; l.qty = round3(Math.max(0, l.qty - 1)); paintLines(); }
        if (del) { lines.splice(Number(del.dataset.trdel), 1); paintLines(); }
        if (e.target.closest('[data-trscan]')) {
          await openScanner({
            title: 'Escanear lo que mandás',
            onCode: async (code, sc) => {
              const p = findCode(code);
              if (!p) { playError(); sc.flash(`No hay ningún producto con el código ${code}`, 'error'); return 'continue'; }
              add(p);
              sc.flash(`${p.name.slice(0, 40)} · ${fmtQty(lines.find(l => l.product_id === p.id).qty)}`);
              return 'continue';
            },
          });
        }
      });
      m.addEventListener('change', e => {
        if (e.target.id === 'tr-to') to = e.target.value;
        const qi = e.target.closest('[data-trq]');
        // Se vuelve a dibujar después del evento (si no, Chrome falla al sacar el campo que tiene el foco)
        if (qi) { const v = parseNum(qi.value); lines[qi.dataset.trq].qty = isFinite(v) && v > 0 ? round3(v) : 0; setTimeout(paintLines, 0); }
      });
      paintLines();
    },
    actions: [{ label: 'Cancelar', value: null }, {
      label: 'Enviar remito', kind: 'primary', id: 'tr-go', onClick: async (close, w) => {
        const b = $('#tr-go', w);
        b.disabled = true; b.textContent = 'Guardando…';
        try {
          const t = await createTransfer({ to_branch: $('#tr-to', w).value, items: lines, notes: $('#tr-notes', w).value });
          toast(`Remito N° ${nro(t)} enviado. Se descontó el stock de ${branchName(t.from_branch)}.`, 'ok', 4000);
          close(t);
        } catch (e) { $('#tr-err', w).textContent = e.message; b.disabled = false; b.textContent = 'Enviar remito'; }
      },
    }],
  });
}

// ---------- Ver / recibir / anular ----------

async function openTransfer(id) {
  const t = db.get('transfers', id);
  if (!t) return;
  if (t.status === 'enviado' && t.to_branch === ctx.branchId) { const r = await receiveDialog(t); paint(); if (r) await showTransfer(r, false); return; }
  await showTransfer(t, false);
  paint();
}

async function showTransfer(t, justSent) {
  const canVoid = t.status === 'enviado' && can(ctx.user, 'remitos');
  await modal({
    title: `Remito N° ${nro(t)}`,
    body: html`${justSent ? html`<div class="notice notice-ok"><p>${ic('check')} Enviado. Imprimilo y mandalo con la mercadería: en ${branchName(t.to_branch)} lo ven en “Remitos por recibir”.</p></div>` : ''}
      ${t.status === 'recibido' && (t.differences || []).length ? html`<div class="notice notice-warn"><p><b>Llegó con diferencias.</b> Quedaron registradas en el remito.</p></div>` : ''}
      <div id="tr-ticket">${transferHTML(t)}</div>`,
    actions: [
      ...(canVoid ? [{ label: 'Anular remito', kind: 'danger', onClick: async close => {
        if (!(await confirm(`El stock vuelve a ${branchName(t.from_branch)}. ¿Anular el remito N° ${nro(t)}?`, { title: 'Anular remito', ok: 'Sí, anular', danger: true }))) return;
        try { await voidTransfer(t.id); toast('Remito anulado. El stock volvió al origen.'); close(true); } catch (e) { toast(e.message, 'error', 5000); }
      } }] : []),
      { label: raw(icon('print') + ' Imprimir'), kind: canVoid ? 'ghost' : 'primary', onClick: () => printTransfer(db.get('transfers', t.id)) },
      { label: 'Cerrar', value: true },
    ],
  });
}

/** Controlar lo que llegó: se tipea o se escanea cada producto. Devuelve el remito recibido o null. */
async function receiveDialog(t) {
  const got = {}; // product_id -> cantidad recibida (vacío = todavía no se controló)
  return modal({
    title: `Recibir remito N° ${nro(t)} · desde ${branchName(t.from_branch)}`,
    size: 'wide',
    body: html`
      <p class="muted">Contá lo que llegó. Podés escanear cada producto (suma 1) o escribir la cantidad. Lo que no llegó queda registrado como faltante.</p>
      <div class="btn-row" style="margin-bottom:.6rem">
        <button type="button" class="btn ghost" data-rall>${ic('check')} Llegó todo bien</button>
        ${canScan() ? html`<button type="button" class="btn ghost" data-rscan>${ic('camera')} Escanear</button>` : ''}
      </div>
      <form id="rc-sf" class="searchbox" role="search" style="margin-bottom:.5rem">${ic('search')}
        <label for="rc-q" class="sr-only">Código (lector o teclado)</label>
        <input id="rc-q" autocomplete="off" enterkeyhint="go" placeholder="Código del producto (lector USB) + Enter"></form>
      <ul class="list">${t.items.map((it, i) => html`<li class="ret-line" data-rl="${it.product_id}">
        <div class="top"><span class="name">${it.name}</span><span class="small" data-rstate="${it.product_id}"></span></div>
        <div class="sub muted small">Enviado: <b>${fmtQty(it.qty)}</b></div>
        <div class="ctrl"><button type="button" class="qty-btn" data-rcdec="${it.product_id}" aria-label="Uno menos de ${it.name}">${ic('minus')}</button>
          <label class="sr-only" for="rc-${i}">Recibido de ${it.name}</label>
          <input id="rc-${i}" class="qty-val" data-rcq="${it.product_id}" inputmode="decimal" autocomplete="off" placeholder="—">
          <button type="button" class="qty-btn" data-rcinc="${it.product_id}" aria-label="Uno más de ${it.name}">${ic('plus')}</button></div></li>`)}</ul>
      ${t.notes ? html`<p class="small muted">Nota del envío: ${t.notes}</p>` : ''}
      <div class="field"><label for="rc-notes">Observaciones <span class="muted">(opcional)</span></label><input id="rc-notes" placeholder="Ej: una caja llegó rota"></div>
      <div class="change-box" id="rc-sum" aria-live="polite"></div>`,
    onMount(m) {
      const paintState = () => {
        for (const it of t.items) {
          const v = got[it.product_id];
          const el = m.querySelector(`[data-rstate="${it.product_id}"]`);
          const inp = m.querySelector(`[data-rcq="${it.product_id}"]`);
          if (document.activeElement !== inp) inp.value = v === undefined ? '' : fmtQty(v);
          const d = v === undefined ? null : round3(v - it.qty);
          el.innerHTML = v === undefined ? '<span class="muted">Sin controlar</span>' : d === 0 ? '<span class="badge ok">OK</span>'
            : d < 0 ? `<span class="badge err">Faltan ${fmtQty(-d)}</span>` : `<span class="badge warn">Sobran ${fmtQty(d)}</span>`;
          m.querySelector(`[data-rl="${it.product_id}"]`).classList.toggle('on', v !== undefined);
        }
        const diffs = transferDifferences(t.items, got);
        const pend = t.items.filter(it => got[it.product_id] === undefined).length;
        const box = $('#rc-sum', m);
        box.className = 'change-box ' + (!pend && !diffs.length ? 'ok' : diffs.length ? 'miss' : '');
        box.innerHTML = String(html`<div class="k">${pend ? `Faltan controlar ${pend} de ${t.items.length}` : diffs.length ? 'Hay diferencias' : 'Está todo'}</div>
          <div class="v" style="font-size:1.2rem" id="rc-diffs">${diffs.length ? diffs.map(x => `${x.name.slice(0, 28)}: ${x.diff > 0 ? '+' : ''}${fmtQty(x.diff)}`).join(' · ') : pend ? '' : 'Sin faltantes'}</div>`);
      };
      const bump = (pid, d) => { const it = t.items.find(x => x.product_id === pid); if (!it) return false; got[pid] = round3(Math.max(0, (got[pid] || 0) + d)); paintState(); return true; };
      m.addEventListener('click', async e => {
        if (e.target.closest('[data-rall]')) { for (const it of t.items) got[it.product_id] = it.qty; paintState(); return; }
        const inc = e.target.closest('[data-rcinc]'), dec = e.target.closest('[data-rcdec]');
        if (inc) bump(inc.dataset.rcinc, +1);
        if (dec) bump(dec.dataset.rcdec, -1);
        if (e.target.closest('[data-rscan]')) {
          await openScanner({
            title: 'Escanear lo que llegó',
            onCode: async (code, sc) => {
              const p = findCode(code);
              if (!p || !bump(p.id, 1)) { playError(); sc.flash(p ? `${p.name.slice(0, 30)} no está en este remito` : `Código ${code} desconocido`, 'error'); return 'continue'; }
              const it = t.items.find(x => x.product_id === p.id);
              sc.flash(`${p.name.slice(0, 30)}: ${fmtQty(got[p.id])} de ${fmtQty(it.qty)}`);
              return 'continue';
            },
          });
        }
      });
      $('#rc-sf', m).addEventListener('submit', e => {
        e.preventDefault();
        const inp = $('#rc-q', m);
        const p = findCode(inp.value);
        if (!p || !bump(p.id, 1)) { toast(p ? `${p.name} no está en este remito.` : `No hay ningún producto con el código ${inp.value.trim()}.`, 'warn'); }
        inp.value = ''; inp.focus();
      });
      m.addEventListener('input', e => {
        const qi = e.target.closest('[data-rcq]');
        if (!qi) return;
        const v = parseNum(qi.value);
        if (qi.value.trim() === '') delete got[qi.dataset.rcq]; else if (isFinite(v) && v >= 0) got[qi.dataset.rcq] = round3(v);
        paintState();
      });
      m.addEventListener('change', e => { if (e.target.closest('[data-rcq]')) { e.target.blur(); paintState(); } });
      paintState();
    },
    actions: [{ label: 'Más tarde', value: null }, {
      label: 'Confirmar recepción', kind: 'primary', id: 'rc-go', onClick: async (close, w) => {
        const pend = t.items.filter(it => got[it.product_id] === undefined);
        const diffs = transferDifferences(t.items, got);
        if (pend.length || diffs.length) {
          const msg = html`${pend.length ? html`<p>${pend.length} ${pend.length === 1 ? 'producto no se controló y se toma' : 'productos no se controlaron y se toman'} como <b>no recibidos</b>.</p>` : ''}
            ${diffs.length ? html`<p>Se van a registrar estas diferencias:</p><ul>${diffs.map(x => html`<li>${x.name}: enviado ${fmtQty(x.sent)}, recibido ${fmtQty(x.received)} (<b>${x.diff < 0 ? `faltan ${fmtQty(-x.diff)}` : `sobran ${fmtQty(x.diff)}`}</b>)</li>`)}</ul>` : ''}
            <p>Al stock de ${branchName(t.to_branch)} se suma solo lo recibido.</p>`;
          const ok = await modal({ title: 'Recibir con diferencias', body: msg, actions: [{ label: 'Volver', value: false }, { label: 'Sí, recibir así', kind: 'primary', value: true, id: 'rc-ok' }] });
          if (!ok) return;
        }
        try {
          const r = await receiveTransfer(t.id, got, $('#rc-notes', w).value);
          toast(`Remito recibido. Se sumó al stock de ${branchName(r.to_branch)}.`, 'ok', 4000);
          close(r);
        } catch (e) { toast(e.message, 'error', 6000); }
      },
    }],
  });
}
