// =====================================================================
// vender.js — Pantalla principal: buscar, cargar el carrito y cobrar.
// =====================================================================
import * as db from '../db.js';
import * as sync from '../sync.js';
import { ctx, settings, openSession, openCash, createSale, requestInvoice, stockOf, multiBranch, currentBranch, transfersToReceive } from '../ops.js';
import { html, raw, $, on, ic, icon, modal, toast, fieldError } from '../ui.js';
import {
  computeSale, calcPayment, discriminaIva, cbteTipo, cbteLetra, searchProducts, findByCode, parseNum, warmSearch,
  fmtMoney, fmtQty, fmtNum2, round2, round3, PAY_METHODS, payLabel, saleText, waLink, IVA_RATES, can as canDo,
} from '../logic.js';
import { openScanner, canScan, scanButton, codeVariants, playError } from '../scanner.js';
import { productForm } from './productos.js';
import { ticketHTML, printSale, drawQRs } from '../print.js';
import { pickCustomer } from './clientes.js';
import { checkSaleQty, checkPayments, priceJumpWarning, isManager } from '../control.js';
import { authorize, confirmWarnings, guardClock } from '../autoriza.js';
import { auditOps, audit } from '../seguridad.js';
import { expiringLots } from '../comercial.js';
import { lotsOf } from '../lotes.js';
import { sellers } from '../cuentas.js';
import { photoThumb } from '../fotos.js';
import { confirm as confirmBox } from '../ui.js';
import { computeSaleSGI, applyPromotions, docLetter } from '../comercial.js';
import { livePromotions, seedCatalogs, refreshPayLabels, convertOps, DOC_COLLS } from '../comercial-ops.js';
import { payModal } from './cobro.js';
import { branchPos } from '../ops.js';
import { uuid, discountMax } from '../logic.js';

// Estado del carrito: queda en memoria aunque cambies de pantalla, y se guarda en el equipo (meta "cart")
// en cada cambio: si se corta la luz o se cierra el navegador con una venta a medio cargar, se recupera.
// observations: observaciones del comprobante (como SGI); source: presupuesto / pedido que se está vendiendo
const state = { cart: [], discount: { type: 'pct', value: 0 }, customer_id: null, observations: '', source: null };
let restored = false;
// Vendedor de la venta (comisiones): el elegido, o el usuario si es vendedor. Queda elegido entre ventas.
state.seller_id = null;
const sellerList = () => sellers(db.all('users'));
function currentSeller() {
  if (state.seller_id === '-') return null;
  if (state.seller_id && sellerList().some(u => u.id === state.seller_id)) return state.seller_id;
  return ctx.user && ctx.user.role === 'vendedor' ? ctx.user.id : null;
}

function saveCart() {
  const v = state.cart.length ? { cart: state.cart, discount: state.discount, customer_id: state.customer_id, seller_id: state.seller_id, observations: state.observations, source: state.source, user_id: ctx.user && ctx.user.id, saved_at: Date.now() } : null;
  db.setMeta('cart', v).catch(e => console.warn('No se pudo guardar el carrito', e));
}

/** La primera vez que se abre Vender, trae el carrito que quedó guardado (venta a medio cargar) */
async function restoreCart() {
  if (restored) return false;
  restored = true;
  if (state.cart.length) return false;
  const v = await db.getMeta('cart', null).catch(() => null);
  if (!v || !Array.isArray(v.cart) || !v.cart.length) return false;
  // Si la venta llegó a guardarse justo antes del corte (y no se alcanzó a vaciar el carrito), no se recupera
  const sig = list => list.map(it => `${it.product_id || it.name}:${Number(it.qty)}`).sort().join('|');
  const key = sig(v.cart);
  if (db.all('sales').some(x => x.created_at >= (v.saved_at || 0) - 1000 && x.user_id === v.user_id && sig(x.items || []) === key)) {
    db.setMeta('cart', null).catch(() => {});
    return false;
  }
  // Solo productos que siguen existiendo (los montos libres no tienen product_id)
  state.cart = v.cart.filter(it => !it.product_id || (db.get('products', it.product_id) && !db.get('products', it.product_id).deleted));
  state.discount = v.discount || { type: 'pct', value: 0 };
  state.customer_id = v.customer_id && db.get('customers', v.customer_id) ? v.customer_id : null;
  if (v.seller_id) state.seller_id = v.seller_id;
  state.observations = v.observations || '';
  state.source = v.source || null;
  return state.cart.length > 0;
}

let main, app;

export function render(m, a) {
  main = m; app = a;
  main.innerHTML = String(html`
    <div id="hoy-strip"></div>
    <div id="venc-alert"></div>
    <div id="caja-alert"></div>
    <div class="pos">
      <section class="pos-search" aria-label="Buscar productos">
        <form class="searchbox${canScan() ? ' has-scan' : ''}" id="s-form" role="search">
          ${ic('search')}
          <label for="s-in" class="sr-only">Buscar producto por nombre o código</label>
          <input id="s-in" type="search" autocomplete="off" enterkeyhint="go" placeholder="Buscar o escanear código…">
          ${scanButton('data-act="scan" id="s-scan"', 'Escanear con la cámara')}
        </form>
        <div id="s-res" class="results hidden" role="listbox" aria-label="Resultados"></div>
      </section>
      <aside class="cart-panel" aria-label="Carrito" id="cart"></aside>
      <section class="pos-quick" aria-labelledby="q-title">
        <h2 id="q-title" style="margin-top:.5rem">Más vendidos</h2>
        <div class="tiles" id="tiles"></div>
      </section>
    </div>
    <div class="pay-bar hidden" id="paybar">
      <div class="tot"><small id="pb-count"></small><b id="pb-total"></b></div>
      <button type="button" class="btn primary big" data-act="cobrar">Cobrar</button>
    </div>`);
  renderVencAlert();
  renderCajaAlert();
  renderTiles();
  renderCart();
  renderHoyStrip();
  refreshPayLabels();
  seedCatalogs().catch(e => console.warn('tarjetas', e));
  restoreCart().then(ok => {
    if (!ok || !main.isConnected) return;
    renderCart();
    toast(`Recuperamos la venta que quedó a medio cargar (${state.cart.length} ${state.cart.length === 1 ? 'producto' : 'productos'}).`, 'ok', 4500);
  });

  const input = $('#s-in', main);
  let t = null;
  input.addEventListener('input', () => { clearTimeout(t); t = setTimeout(() => renderResults(input.value), 120); });
  $('#s-form', main).addEventListener('submit', e => { e.preventDefault(); onEnter(input.value); });
  input.addEventListener('keydown', e => {
    if (e.key === 'ArrowDown') { const f = $('#s-res .result', main); if (f) { e.preventDefault(); f.focus(); } }
    if (e.key === 'Escape') { input.value = ''; renderResults(''); }
  });
  $('#s-res', main).addEventListener('keydown', e => {
    const items = [...main.querySelectorAll('#s-res .result')];
    const i = items.indexOf(document.activeElement);
    if (e.key === 'ArrowDown' && i < items.length - 1) { e.preventDefault(); items[i + 1].focus(); }
    if (e.key === 'ArrowUp') { e.preventDefault(); (i > 0 ? items[i - 1] : input).focus(); }
  });

  const offs = [
    on(main, 'click', '[data-add]', (e, el) => { addProduct(db.get('products', el.dataset.add), false); }),
    on(main, 'click', '[data-act]', (e, el) => action(el.dataset.act, el)),
    on(main, 'click', '[data-inc]', (e, el) => changeQty(el.dataset.inc, +1)),
    on(main, 'click', '[data-dec]', (e, el) => changeQty(el.dataset.dec, -1)),
    on(main, 'click', '[data-qty]', (e, el) => editQty(el.dataset.qty)),
    on(main, 'click', '[data-del]', (e, el) => { state.cart = state.cart.filter(x => x.key !== el.dataset.del); renderCart(); }),
  ];
  // En PC el cursor queda listo en el buscador (para el lector de códigos)
  if (window.matchMedia('(min-width: 960px)').matches) input.focus();
  // Búsqueda lista de entrada: los nombres normalizados se calculan apenas la pantalla queda libre
  (window.requestIdleCallback || (f => setTimeout(f, 50)))(() => warmSearch(db.all('products')));
  return () => { offs.forEach(f => f()); document.body.classList.remove('has-paybar'); };
}

// ---------- Resumen de hoy (dueño y encargado) y remitos por recibir ----------

async function renderHoyStrip() {
  const box = $('#hoy-strip', main);
  if (!box || !ctx.user) return;
  const toRec = multiBranch() ? transfersToReceive().length : 0;
  let strip = '';
  if (canDo(ctx.user, 'tablero')) {
    const { todaySummary } = await import('./hoy.js');
    if (!box.isConnected) return;
    const D = todaySummary();
    const v = D.vsYesterday;
    strip = html`<a class="hoy-strip" href="#/hoy" id="hoy-link"><span class="k">Hoy</span><b class="money" id="hoy-total">${fmtMoney(D.today.total)}</b>
      <span class="muted">${D.today.count} ${D.today.count === 1 ? 'venta' : 'ventas'}</span>
      ${v !== null ? html`<span class="cmp ${v > 0 ? 'up' : v < 0 ? 'down' : ''}">${v > 0 ? '▲' : v < 0 ? '▼' : '='} ${Math.abs(v).toLocaleString('es-AR')}% vs ayer</span>` : ''}
      ${D.arca.pending.length + D.arca.rejected.length ? html`<span class="badge warn">${D.arca.pending.length + D.arca.rejected.length} ARCA</span>` : ''}
      <span class="go">Ver tablero ›</span></a>`;
  }
  box.innerHTML = String(html`${strip}${toRec ? html`<div class="notice notice-info" style="display:flex;align-items:center;gap:.75rem;flex-wrap:wrap">
    <p style="flex:1;margin:0"><b>${toRec} ${toRec === 1 ? 'remito' : 'remitos'} por recibir</b> de otra sucursal.</p>
    <a class="btn ghost sm" href="#/remitos">Recibir</a></div>` : ''}`);
}

// ---------- Caja ----------

/** Alerta ROJA de vencimientos (vencidos o que vencen en 7 días, en esta sucursal) */
function renderVencAlert() {
  const box = $('#venc-alert', main);
  if (!box) return;
  const list = expiringLots(db.COLLECTIONS.includes('product_lots') ? db.all('product_lots') : [], db.all('products'), { days: 7, branchId: ctx.branchId, productOf: id => db.get('products', id) });
  if (!list.length) { box.innerHTML = ''; return; }
  const gone = list.filter(x => x.expired).length;
  const goVer = canDo(ctx.user, 'editar_productos');
  box.innerHTML = String(html`<div class="notice venc-red" role="alert" style="display:flex;align-items:center;gap:.75rem;flex-wrap:wrap">
    <p style="flex:1;margin:0"><b>⚠ ${gone ? `${gone} ${gone === 1 ? 'producto VENCIDO' : 'productos VENCIDOS'}` : ''}${gone && list.length - gone ? ' y ' : ''}${list.length - gone ? `${list.length - gone} por vencer en 7 días` : ''}</b>
    <span class="small" style="display:block">${list.slice(0, 4).map(x => x.product.name).join(' · ')}${list.length > 4 ? '…' : ''}</span></p>
    ${goVer ? html`<a class="btn" href="#/vencimientos">Ver</a>` : ''}</div>`);
}

function renderCajaAlert() {
  const box = $('#caja-alert', main);
  if (openSession()) { box.innerHTML = ''; return; }
  box.innerHTML = String(html`<div class="notice notice-warn" style="display:flex;align-items:center;gap:.75rem;flex-wrap:wrap">
    <p style="flex:1;margin:0"><b>La caja${multiBranch() ? ` de ${(currentBranch() || {}).name || ''}` : ''} está cerrada.</b> Abrila para poder cobrar.</p>
    <button type="button" class="btn primary" data-act="abrir-caja">Abrir caja</button></div>`);
}

/** Pide el monto inicial y abre la caja. Devuelve true si quedó abierta. */
export async function askOpenCash() {
  const ok = await modal({
    title: multiBranch() ? `Abrir caja · ${(currentBranch() || {}).name || ''}` : 'Abrir caja',
    body: html`<form id="oc" novalidate><div class="field"><label for="oc-amt">¿Con cuánto efectivo empezás?</label>
      <input id="oc-amt" class="money-input" inputmode="decimal" placeholder="0,00" autocomplete="off"></div>
      <p class="hint muted">Es la plata que hay en el cajón para dar vuelto.</p></form>`,
    actions: [{ label: 'Cancelar', value: false }, {
      label: 'Abrir caja', kind: 'primary', id: 'oc-go', onClick: async (close, w) => {
        const inp = $('#oc-amt', w);
        const v = inp.value.trim() === '' ? 0 : parseNum(inp.value);
        if (!isFinite(v) || v < 0) return fieldError(inp, 'Escribí un monto válido (puede ser 0).');
        if (v >= 1e9) return fieldError(inp, 'Ese monto es demasiado alto: revisalo.');
        if (v > 5000000 && !(await confirmWarnings([`¿Seguro que empezás con ${fmtMoney(v)} en el cajón?`]))) return;
        if (!(await guardClock('abrir la caja'))) return;
        try { await openCash(v, auditOps('caja_apertura', 'cash_sessions', '', { opening: round2(v) })); close(true); } catch (e) { toast(e.message, 'error'); }
      },
    }],
    onMount(m, close) { $('#oc', m).addEventListener('submit', e => { e.preventDefault(); $('#oc-go', m).click(); }); },
  });
  if (ok) toast('Caja abierta. ¡Buenas ventas!');
  return !!ok;
}

// ---------- Búsqueda ----------

function products() { return db.all('products').filter(p => p.active !== 0); }

function renderResults(q) {
  const box = $('#s-res', main);
  if (!box) return; // la vista ya no está montada
  if (!q.trim()) { box.classList.add('hidden'); box.innerHTML = ''; return; }
  const list = searchProducts(products(), q, 30);
  box.classList.remove('hidden');
  if (!list.length) {
    box.innerHTML = String(html`<div class="empty">No encontramos “${q}”.<br><button type="button" class="btn soft" style="margin-top:.6rem" data-act="libre">Vender como monto libre</button></div>`);
    return;
  }
  box.innerHTML = String(html`${list.map(p => html`
    <button type="button" class="result" role="option" data-add="${p.id}">
      ${photoThumb(p, 'sm')}<span class="grow"><span class="title">${p.name}</span>
        <span class="sub muted small" style="display:block">${p.barcode || p.sku || p.category}${p.unit === 'kg' ? ' · por kg' : ''} · Stock ${fmtQty(stockOf(p))}</span></span>
      <span class="price money">${fmtMoney(p.price)}</span>
    </button>`)}`);
}

/** Enter en el buscador: código exacto (lector) o único resultado → al carrito */
function onEnter(q) {
  const v = q.trim();
  if (!v) return;
  const byCode = findByCode(products(), v);
  if (byCode) { addProduct(byCode, true); return; }
  const list = searchProducts(products(), v, 2);
  if (list.length === 1) { addProduct(list[0], true); return; }
  if (/^\d{6,14}$/.test(v)) { toast(`No hay ningún producto con el código ${v}.`, 'warn'); $('#s-in', main).select(); return; }
  const first = $('#s-res .result', main);
  if (first) first.focus();
}

function clearSearch(refocus) {
  const input = $('#s-in', main);
  input.value = '';
  renderResults('');
  if (refocus) input.focus();
}

// ---------- Carrito ----------

async function addProduct(p, fromKeyboard, quiet = false) {
  if (!p) return;
  warnExpiry(p);
  // Precio libre (ej: “Varios panadería”): pide el importe y va como un renglón aparte, con el producto para los informes
  if (p.open_price) {
    const amt = await askOpenPrice(p);
    if (!amt) { clearSearch(fromKeyboard); return; }
    state.cart.push({ key: p.id + ':' + Date.now(), product_id: p.id, name: p.name, unit_price: amt, iva_rate: p.iva_rate ?? 21, qty: 1, unit: 'u', open_price: 1 });
    clearSearch(fromKeyboard || window.matchMedia('(min-width: 960px)').matches);
    renderCart();
    if (!quiet && !window.matchMedia('(min-width: 960px)').matches) toast(`${p.name.slice(0, 40)} agregado`, 'ok', 1200);
    return;
  }
  let qty = 1;
  if (p.unit === 'kg') {
    qty = await askKg(p);
    if (!qty) return;
  }
  const ex = state.cart.find(x => x.product_id === p.id);
  if (ex && p.unit !== 'kg') {
    const nq = round3(ex.qty + qty);
    const chk = checkSaleQty(nq, 'u');
    if (chk.warning && !checkSaleQty(ex.qty, 'u').warning && !(await confirmWarnings([`${p.name}: ${chk.warning}`]))) { clearSearch(fromKeyboard); return; }
    ex.qty = nq;
  } else state.cart.push({ key: p.id + ':' + Date.now(), product_id: p.id, name: p.name, unit_price: p.price, iva_rate: p.iva_rate ?? 21, qty, unit: p.unit || 'u' });
  clearSearch(fromKeyboard || window.matchMedia('(min-width: 960px)').matches);
  renderCart();
  if (!quiet && !window.matchMedia('(min-width: 960px)').matches) toast(`${p.name.slice(0, 40)} agregado`, 'ok', 1200);
}

// ---------- Cámara ----------

/** Producto con ese código (de barras o interno), probando también UPC-A ⇄ EAN-13 y UPC-E */
function findScanned(code) {
  const list = products();
  for (const c of codeVariants(code)) { const p = findByCode(list, c); if (p) return p; }
  return null;
}

/**
 * Escanear con la cámara: cada código leído va al carrito (como el lector USB con Enter).
 * Con "Escanear varios seguidos" la cámara sigue abierta hasta tocar "Listo"; si hace falta
 * pedir los kilos o crear un producto, se cierra, se resuelve y se vuelve a abrir sola.
 */
async function scanVender() {
  for (;;) {
    let next = null, multi = false;
    await openScanner({
      title: 'Escanear productos',
      multi: { label: 'Escanear varios seguidos', key: 'jg-scan-multi' },
      onCode: async (code, sc) => {
        multi = sc.multi;
        const p = findScanned(code);
        if (!p) { playError(); next = { type: 'missing', code }; return 'close'; }
        if (p.unit === 'kg') { next = { type: 'kg', p }; return 'close'; }
        await addProduct(p, false, multi);
        if (!multi) return 'close';
        sc.flash(`Agregado: ${p.name.slice(0, 40)} · ${state.cart.length} en el carrito`);
        return 'continue';
      },
    });
    if (!next || !main.isConnected) return;
    if (next.type === 'kg') {
      await addProduct(next.p, false);
      if (!multi) return;
      continue;
    }
    const r = await notFound(next.code, multi);
    if (r === 'again') continue;
    if (r !== 'create') return;
    const p = await productForm({ barcode: next.code });
    if (p && p.id && !p.deleted && p.active !== 0) await addProduct(p, false);
    if (!multi) return;
  }
}

async function notFound(code, multi) {
  const canCreate = ctx.user && canDo(ctx.user, 'editar_productos');
  return modal({
    title: 'Código no encontrado',
    body: html`<p class="lead">No encontramos el código <b id="nf-code">${code}</b>.</p>
      ${canCreate ? html`<p class="muted">Podés crear el producto ahora, con este código ya cargado.</p>`
        : html`<p class="muted">Pedile al dueño o al encargado que lo cargue en Productos. Mientras tanto podés venderlo como monto libre.</p>`}`,
    actions: [
      { label: multi ? 'Terminar' : 'Cerrar', value: 'close' },
      { label: 'Escanear otro', value: 'again' },
      ...(canCreate ? [{ label: 'Crear producto con este código', kind: 'primary', value: 'create', id: 'nf-create' }] : []),
    ],
  });
}

async function askKg(p) {
  return modal({
    title: p.name,
    body: html`<p class="muted">${fmtMoney(p.price)} el kilo</p>
      <form id="kg" novalidate>
        <div class="field"><label for="kg-q">¿Cuántos kilos?</label><input id="kg-q" class="money-input" inputmode="decimal" placeholder="0,500" autocomplete="off"></div>
        <div class="quick-bills">${[0.25, 0.5, 1, 2].map(v => html`<button type="button" class="btn ghost" data-kg="${v}">${fmtQty(v)} kg</button>`)}</div>
        <div class="field"><label for="kg-m">…o por importe ($)</label><input id="kg-m" inputmode="decimal" placeholder="Ej: 1500" autocomplete="off"></div>
      </form>`,
    onMount(m) {
      m.addEventListener('click', e => { const b = e.target.closest('[data-kg]'); if (b) { $('#kg-q', m).value = fmtQty(Number(b.dataset.kg)); $('#kg-m', m).value = ''; } });
      $('#kg-m', m).addEventListener('input', e => {
        const amt = parseNum(e.target.value);
        if (isFinite(amt) && amt > 0 && p.price > 0) $('#kg-q', m).value = fmtQty(round3(amt / p.price));
      });
      $('#kg', m).addEventListener('submit', e => { e.preventDefault(); m.querySelector('.modal-foot .primary').click(); });
    },
    actions: [{ label: 'Cancelar', value: 0 }, {
      label: 'Agregar', kind: 'primary', onClick: async (close, w) => {
        const inp = $('#kg-q', w);
        const q = parseNum(inp.value);
        const chk = checkSaleQty(q, 'kg');
        if (chk.error) return fieldError(inp, chk.error);
        if (chk.warning && !(await confirmWarnings([chk.warning]))) return;
        close(round3(q));
      },
    }],
  });
}

/** Alerta roja si el lote que se vende primero de este producto está vencido o vence en 7 días */
function warnExpiry(p) {
  try {
    const l = lotsOf(p.id, ctx.branchId)[0];
    const exp = (l && l.expires_at) || p.expires_at;
    if (!exp) return;
    const d = Math.round((new Date(String(exp).slice(0, 10) + 'T12:00:00') - new Date(new Date().toISOString().slice(0, 10) + 'T12:00:00')) / 864e5);
    if (d < 0) { playError(); toast(`⚠ ${p.name.slice(0, 40)}: VENCIDO (${String(exp).slice(0, 10).split('-').reverse().join('/')}). No lo vendas.`, 'error', 6000); }
    else if (d <= 7) { playError(); toast(`⚠ ${p.name.slice(0, 40)}: vence ${d === 0 ? 'HOY' : `en ${d} ${d === 1 ? 'día' : 'días'}`}.`, 'error', 5000); }
  } catch (e) { /* sin lotes: nada */ }
}

/** Importe de un producto de precio libre (sugiere el último precio cargado, si tiene) */
async function askOpenPrice(p) {
  return modal({
    title: p.name,
    body: html`<form id="op" novalidate>
      <div class="field"><label for="op-amt">Importe</label><input id="op-amt" class="money-input" inputmode="decimal" placeholder="0,00" autocomplete="off" value="${p.price > 0 ? fmtNum2(p.price) : ''}"></div>
    </form>`,
    onMount(m) {
      const inp = $('#op-amt', m); setTimeout(() => { inp.focus(); inp.select(); }, 30);
      $('#op', m).addEventListener('submit', e => { e.preventDefault(); m.querySelector('.modal-foot .primary').click(); });
    },
    actions: [{ label: 'Cancelar', value: null }, {
      label: 'Agregar', kind: 'primary', onClick: (close, w) => {
        const inp = $('#op-amt', w);
        const v = parseNum(inp.value);
        if (!isFinite(v) || v <= 0) return fieldError(inp, 'Escribí el importe.');
        if (v >= 1e9 || (Number.isInteger(v) && v >= 1e7 && /^\d{8,}$/.test(inp.value.trim()))) return fieldError(inp, 'Ese importe parece un código de barras: revisalo.');
        close(round2(v));
      },
    }],
  });
}

async function addFree() {
  const item = await modal({
    title: 'Monto libre',
    body: html`<form id="fr" novalidate>
      <div class="field"><label for="fr-amt">Importe</label><input id="fr-amt" class="money-input" inputmode="decimal" placeholder="0,00" autocomplete="off"></div>
      <div class="field"><label for="fr-name">Descripción</label><input id="fr-name" value="Varios"></div>
      <div class="field"><label for="fr-iva">IVA</label><select id="fr-iva">${IVA_RATES.map(r => html`<option value="${r}" ${r === 21 ? 'selected' : ''}>${String(r).replace('.', ',')}%</option>`)}</select></div>
    </form>`,
    onMount(m) { $('#fr', m).addEventListener('submit', e => { e.preventDefault(); m.querySelector('.modal-foot .primary').click(); }); },
    actions: [{ label: 'Cancelar', value: null }, {
      label: 'Agregar', kind: 'primary', onClick: (close, w) => {
        const inp = $('#fr-amt', w);
        const v = parseNum(inp.value);
        if (!isFinite(v) || v <= 0) return fieldError(inp, 'Escribí el importe.');
        if (v >= 1e9 || (Number.isInteger(v) && v >= 1e7 && /^\d{8,}$/.test(inp.value.trim()))) return fieldError(inp, 'Ese importe parece un código de barras: revisalo.');
        close({ key: 'libre:' + Date.now(), product_id: null, name: $('#fr-name', w).value.trim() || 'Varios', unit_price: round2(v), iva_rate: Number($('#fr-iva', w).value), qty: 1, unit: 'u' });
      },
    }],
  });
  if (item) { state.cart.push(item); clearSearch(false); renderCart(); }
}

function changeQty(key, dir) {
  const it = state.cart.find(x => x.key === key);
  if (!it) return;
  const step = it.unit === 'kg' ? 0.1 : 1;
  it.qty = round3(it.qty + dir * step);
  if (it.qty <= 0) state.cart = state.cart.filter(x => x !== it);
  renderCart();
}

async function editQty(key) {
  const it = state.cart.find(x => x.key === key);
  if (!it) return;
  const v = await modal({
    title: 'Cantidad',
    body: html`<p class="muted">${it.name}</p><form id="eq" novalidate><div class="field"><label for="eq-in">${it.unit === 'kg' ? 'Kilos' : 'Unidades'}</label>
      <input id="eq-in" class="money-input" inputmode="decimal" value="${fmtQty(it.qty)}" autocomplete="off"></div>
      <div class="field"><label for="eq-p">Precio unitario</label><input id="eq-p" inputmode="decimal" value="${fmtNum2(it.unit_price)}" ${can() ? '' : 'readonly'}>
        ${can() ? '' : html`<button type="button" class="btn ghost sm" id="eq-unlock" style="margin-top:.4rem">${ic('lock')} Cambiar precio (con autorización)</button>`}</div></form>`,
    onMount(m) {
      $('#eq-in', m).select();
      $('#eq', m).addEventListener('submit', e => { e.preventDefault(); m.parentElement.querySelector('.modal-foot .primary').click(); });
      const un = $('#eq-unlock', m);
      if (un) un.onclick = async () => {
        const a = await authorize(`cambiar el precio de “${it.name}” en esta venta`, { action: 'precio_venta', perm: 'precio_venta' });
        if (!a) return;
        priceAuth = a;
        const pi = $('#eq-p', m); pi.readOnly = false; pi.focus(); pi.select(); un.remove();
      };
    },
    actions: [{ label: 'Cancelar', value: null }, {
      label: 'Listo', kind: 'primary', onClick: async (close, w) => {
        const q = parseNum($('#eq-in', w).value);
        const pr = parseNum($('#eq-p', w).value);
        if (!isFinite(q) || q < 0) return fieldError($('#eq-in', w), 'Cantidad inválida.');
        if (q > 0) {
          const chk = checkSaleQty(q, it.unit === 'kg' ? 'kg' : 'u');
          if (chk.error) return fieldError($('#eq-in', w), chk.error);
          if (chk.warning && !(await confirmWarnings([chk.warning]))) return;
        }
        if (!isFinite(pr) || pr < 0) return fieldError($('#eq-p', w), 'Precio inválido.');
        if (pr >= 1e9) return fieldError($('#eq-p', w), 'Ese precio es demasiado alto: revisalo.');
        if (round2(pr) !== round2(it.unit_price)) {
          const jump = priceJumpWarning(it.unit_price, pr);
          if (jump && !(await confirmWarnings([`${it.name}: ${jump}`]))) return;
          if (round2(pr) === 0 && !(await confirmWarnings([`${it.name} queda a $ 0 (regalado).`]))) return;
        }
        close({ q: round3(q), pr: round2(pr) });
      },
    }],
  });
  const auth = priceAuth; priceAuth = null;
  if (!v) return;
  if (v.pr !== round2(it.unit_price)) {
    await audit('precio_venta', 'products', it.product_id || '', { name: it.name, old: round2(it.unit_price), price: v.pr, qty: v.q }, auth && !auth.self ? auth : null);
  }
  it.qty = v.q; it.unit_price = v.pr;
  if (it.qty <= 0) state.cart = state.cart.filter(x => x !== it);
  renderCart();
}
// El precio en el carrito solo lo cambian dueño o encargado (el cajero / vendedor, con autorización)
function can() { return !!ctx.user && canDo(ctx.user, 'precio_venta'); }
let priceAuth = null;

function discountAmount(gross) {
  const d = state.discount;
  if (!d.value) return 0;
  return d.type === 'pct' ? round2(gross * Math.min(100, d.value) / 100) : Math.min(gross, round2(d.value));
}

/** Carrito con las promociones vigentes aplicadas (cada renglón, como mucho una) */
function promoItems() {
  const items = state.cart.map(c => ({ product_id: c.product_id, name: c.name, qty: c.qty, unit_price: c.unit_price, iva_rate: c.iva_rate, unit: c.unit }));
  const pr = applyPromotions(items, livePromotions(), { branchId: ctx.branchId, productOf: id => db.get('products', id) });
  items.forEach((it, i) => { if (pr.lines[i]) Object.assign(it, pr.lines[i]); });
  return { items, promos: pr };
}

function calc() {
  const st = settings();
  const { items, promos } = promoItems();
  const gross = round2(items.reduce((a, i) => a + round2(i.qty * i.unit_price), 0));
  // El descuento general (%) va sobre lo que queda después de las promociones
  const c = computeSaleSGI(items, { discount: discountAmount(round2(gross - promos.total)) }, discriminaIva(st.iva_condition));
  c.promos = promos.applied;
  c.cartItems = items;
  return c;
}

/** Próximo número del comprobante (interno) con el punto de venta de la sucursal: 0003-00000126 */
function nextDocNumber() {
  let max = 0;
  for (const s of db.all('sales', { includeDeleted: true })) if (Number(s.number) > max) max = Number(s.number);
  return `${String(branchPos()).padStart(4, '0')}-${String(max + 1).padStart(8, '0')}`;
}

/** Cargar en Vender un presupuesto / pedido (o cualquier carrito) para cobrarlo */
export function loadIntoCart({ cart, customer_id = null, discount = 0, source = null, observations = '' }) {
  state.cart = cart.map((it, i) => ({ key: (it.product_id || 'libre') + ':' + Date.now() + ':' + i, product_id: it.product_id || null, name: it.name, unit_price: round2(it.unit_price), iva_rate: it.iva_rate ?? 21, qty: round3(it.qty), unit: it.unit || 'u' }));
  state.customer_id = customer_id;
  state.discount = discount > 0 ? { type: 'amt', value: round2(discount) } : { type: 'pct', value: 0 };
  state.source = source;
  state.observations = observations;
  restored = true;
  saveCart();
}

function renderCart() {
  if (restored) saveCart();
  const c = calc();
  const cust = state.customer_id ? db.get('customers', state.customer_id) : null;
  const n = state.cart.length;
  if (!$('#cart', main)) return; // la vista ya no está montada
  $('#cart', main).innerHTML = String(html`
    <div class="card-head"><h2>Carrito ${n ? html`<span class="badge">${n}</span>` : ''}</h2>
      ${n ? html`<button type="button" class="btn ghost sm" data-act="vaciar">Vaciar</button>` : ''}</div>
    ${n ? html`<ul class="cart-list">${state.cart.map((it, i) => html`<li class="cart-item">
        <div class="top"><span class="name">${it.name}</span><span class="sub money">${fmtMoney(c.items[i].subtotal + c.items[i].discount)}</span></div>
        <div class="ctrl">
          <button type="button" class="qty-btn" data-dec="${it.key}" aria-label="Restar uno de ${it.name}">${ic('minus')}</button>
          <button type="button" class="qty-val" data-qty="${it.key}" aria-label="Cantidad de ${it.name}: ${fmtQty(it.qty)}. Tocá para cambiar">${fmtQty(it.qty)}${it.unit === 'kg' ? ' kg' : ''}</button>
          <button type="button" class="qty-btn" data-inc="${it.key}" aria-label="Sumar uno de ${it.name}">${ic('plus')}</button>
          <span class="unit money">${fmtMoney(it.unit_price)}${it.unit === 'kg' ? '/kg' : ' c/u'}</span>
          <button type="button" class="icon-btn" data-del="${it.key}" aria-label="Quitar ${it.name}">${ic('trash')}</button>
        </div>${c.items[i].promo_discount ? html`<div class="promo-line">${ic('tag')} ${c.items[i].promo_name} <span class="money">-${fmtMoney(c.items[i].promo_discount)}</span></div>` : ''}</li>`)}</ul>`
      : html`<p class="empty">Buscá un producto o tocá uno de los más vendidos.</p>`}
    <div class="cart-totals">
      <div class="doc-bar" id="doc-bar" aria-label="Comprobante">
        <span class="doc-kind">${docBarLabel(cust)}</span> <span class="doc-nro">N° ${nextDocNumber()}</span>
        ${state.source ? html`<span class="badge">${state.source.kind === 'quote' ? 'Presupuesto' : 'Pedido'} N° ${state.source.number}</span>` : ''}
        ${cust && Number(cust.balance) ? html`<span class="doc-bal ${Number(cust.balance) > 0 ? 'debe' : ''}" id="cust-balance">Saldo ${fmtMoney(cust.balance)}</span>` : ''}
      </div>
      <div class="cart-opts">
        <button type="button" class="btn ghost sm" data-act="cliente">${ic('user')} ${cust ? cust.name : 'Consumidor final'}</button>
        <button type="button" class="btn ghost sm" data-act="descuento">${ic('tag')} ${c.general_discount > 0 ? '-' + fmtMoney(c.general_discount) : 'Descuento'}</button>
        ${sellerList().length ? html`<button type="button" class="btn ghost sm" data-act="vendedor" id="v-seller">${ic('users')} ${currentSeller() ? `Vendedor: ${(db.get('users', currentSeller()) || {}).name || ''}` : 'Vendedor'}</button>` : ''}
        <button type="button" class="btn ghost sm" data-act="obs" id="v-obs">${ic('edit')} ${state.observations ? 'Obs.: ' + state.observations.slice(0, 18) + (state.observations.length > 18 ? '…' : '') : 'Observaciones'}</button>
        ${n ? html`<button type="button" class="btn ghost sm" data-act="guardar-doc" id="v-doc">${ic('receipt')} Presupuesto / pedido</button>` : ''}
      </div>
      ${c.discount > 0 ? html`<div class="line muted"><span>Subtotal</span><span class="money">${fmtMoney(c.gross)}</span></div>
        ${c.promo > 0 ? html`<div class="line muted" id="cart-promos"><span>Promociones</span><span class="money">-${fmtMoney(c.promo)}</span></div>` : ''}
        ${c.general_discount > 0 ? html`<div class="line muted"><span>Descuento${state.discount.type === 'pct' ? ` ${fmtQty(state.discount.value)} %` : ''}</span><span class="money">-${fmtMoney(c.general_discount)}</span></div>` : ''}` : ''}
      <div class="line" style="align-items:baseline"><span class="lead"><b>Total</b></span><span class="total" id="cart-total">${fmtMoney(c.total)}</span></div>
      <button type="button" class="btn primary big block" data-act="cobrar" ${n ? '' : 'disabled'} style="margin-top:.6rem">Cobrar ${n ? fmtMoney(c.total) : ''}</button>
    </div>`);
  $('#cart', main).classList.toggle('is-empty', !n);
  const bar = $('#paybar', main);
  if (!bar) return;
  bar.classList.toggle('hidden', !n);
  document.body.classList.toggle('has-paybar', !!n);
  $('#pb-count', main).textContent = `${n} ${n === 1 ? 'producto' : 'productos'}`;
  $('#pb-total', main).textContent = fmtMoney(c.total);
}

/** Nombre corto para los botones “a mano”: saca relleno (máquina vending, botón, x unid) */
function quickLabel(name) {
  const t = String(name || '').replace(/\s+/g, ' ')
    .replace(/\bM[AÁ]QUINA VENDING\b/gi, '').replace(/\b\d+\s?BOT[OÓ]N\b/gi, '')
    .replace(/\b(X|POR) UNI(D|DAD)\b\.?/gi, '').replace(/^CAFE A VASO CAFE /i, 'CAFE ').replace(/^CAFE A VASO /i, 'CAFE ')
    .replace(/\s+/g, ' ').trim();
  return t || String(name || '');
}

function renderTiles() {
  // Los más vendidos de las últimas ventas
  const counts = new Map();
  const sales = db.all('sales').sort((a, b) => b.created_at - a.created_at).slice(0, 400);
  for (const s of sales) for (const it of s.items || []) if (it.product_id) counts.set(it.product_id, (counts.get(it.product_id) || 0) + 1);
  let top = [...counts.entries()].sort((a, b) => b[1] - a[1]).map(([id]) => db.get('products', id)).filter(p => p && !p.deleted && p.active !== 0).slice(0, 11);
  if (top.length < 11) {
    const recent = products().sort((a, b) => b.updated_at - a.updated_at).filter(p => !top.includes(p)).slice(0, 11 - top.length);
    top = top.concat(recent);
  }
  // Productos “a mano”: fijos, al lado de Monto libre (los marca el dueño en la ficha del producto)
  // Orden: primero los de precio libre (Varios), después cafés, cigarrillos y el resto, por rubro y nombre
  const qRank = p => p.open_price ? 0 : /^CAF[EÉ]\b/i.test(p.name) ? 1 : /CIGARR/i.test(p.name) ? 2 : 3;
  const quick = products().filter(p => p.quick).sort((a, b) => qRank(a) - qRank(b) || String(a.category || '').localeCompare(String(b.category || ''), 'es') || String(a.name).localeCompare(String(b.name), 'es'));
  top = top.filter(p => !p.quick);
  $('#q-title', main).textContent = counts.size ? 'Más vendidos' : 'Productos';
  $('#tiles', main).innerHTML = String(html`
    <button type="button" class="tile libre" data-act="libre"><span class="t">${ic('plus')} Monto libre</span><span class="small muted">Varios / sin código</span></button>
    ${quick.map(p => html`<button type="button" class="tile quick${p.open_price ? ' libre' : ''}" data-add="${p.id}" title="${p.name}"><span class="t">${quickLabel(p.name)}</span><span class="p money">${p.open_price ? html`<small class="muted">Monto libre</small>` : html`${fmtMoney(p.price)}${p.unit === 'kg' ? html`<small class="muted">/kg</small>` : ''}`}</span></button>`)}
    ${top.map(p => html`<button type="button" class="tile" data-add="${p.id}"><span class="t">${p.name}</span><span class="p money">${fmtMoney(p.price)}${p.unit === 'kg' ? html`<small class="muted">/kg</small>` : ''}</span></button>`)}
    ${!top.length && !quick.length ? html`<p class="muted small" style="grid-column:1/-1">Todavía no hay productos. ${ctx.user.role !== 'cajero' ? html`<a href="#/productos">Cargá o importá productos</a>.` : ''}</p>` : ''}`);
}

// ---------- Acciones ----------

/** Elegir el vendedor de la venta (comisiones) */
async function pickSeller() {
  const list = sellerList();
  const cur = currentSeller();
  const r = await modal({
    title: 'Vendedor',
    body: html`<ul class="list">${list.map(u => html`<li><button type="button" class="row" data-seller="${u.id}"><span class="grow"><span class="title">${u.name}</span></span>${u.id === cur ? ic('check') : ''}</button></li>`)}
      <li><button type="button" class="row" data-seller=""><span class="grow">Sin vendedor</span>${!cur ? ic('check') : ''}</button></li></ul>`,
    onMount(m, close) { m.addEventListener('click', e => { const b = e.target.closest('[data-seller]'); if (b) close({ id: b.dataset.seller || null }); }); },
  });
  if (!r) return;
  state.seller_id = r.id;
  if (!r.id && ctx.user.role === 'vendedor') state.seller_id = '-'; // un vendedor puede vender "sin vendedor"
  renderCart();
}

async function action(act) {
  if (act === 'abrir-caja') { if (await askOpenCash()) renderCajaAlert(); return; }
  if (act === 'libre') return addFree();
  if (act === 'scan') return scanVender();
  if (act === 'vaciar') { state.cart = []; state.discount = { type: 'pct', value: 0 }; state.customer_id = null; state.observations = ''; state.source = null; discountAuth = null; renderCart(); return; }
  if (act === 'obs') return askObservations();
  if (act === 'guardar-doc') return saveAsDoc();
  if (act === 'cliente') {
    const r = await pickCustomer(state.customer_id);
    if (r !== undefined) {
      state.customer_id = r;
      // El vendedor asignado al cliente queda como vendedor de la venta (si no se eligió otro)
      const cu = r ? db.get('customers', r) : null;
      if (cu && cu.seller_id && !state.seller_id) state.seller_id = cu.seller_id;
      renderCart();
    }
    return;
  }
  if (act === 'vendedor') return pickSeller();
  if (act === 'descuento') return askDiscount();
  if (act === 'cobrar') return cobrar();
}

async function askDiscount() {
  const d = state.discount;
  const r = await modal({
    title: 'Descuento',
    body: html`<form id="ds" novalidate>
      <fieldset class="seg"><legend>Tipo</legend>
        <label><input type="radio" name="t" value="pct" ${d.type === 'pct' ? 'checked' : ''}><span>Porcentaje %</span></label>
        <label><input type="radio" name="t" value="amt" ${d.type === 'amt' ? 'checked' : ''}><span>Monto $</span></label></fieldset>
      <div class="field"><label for="ds-v">Valor</label><input id="ds-v" class="money-input" inputmode="decimal" value="${d.value ? fmtQty(d.value) : ''}" placeholder="0"></div>
      <div class="quick-bills">${[5, 10, 15, 20].map(v => html`<button type="button" class="btn ghost" data-pct="${v}">${v}%</button>`)}</div></form>`,
    onMount(m) {
      m.addEventListener('click', e => { const b = e.target.closest('[data-pct]'); if (b) { m.querySelector('[value=pct]').checked = true; $('#ds-v', m).value = b.dataset.pct; } });
      $('#ds', m).addEventListener('submit', e => { e.preventDefault(); m.querySelector('.modal-foot .primary').click(); });
    },
    actions: [{ label: 'Sin descuento', value: { type: 'pct', value: 0 } }, {
      label: 'Aplicar', kind: 'primary', onClick: (close, w) => {
        const t = w.querySelector('[name=t]:checked').value;
        const inp = $('#ds-v', w);
        const v = inp.value.trim() === '' ? 0 : parseNum(inp.value);
        if (!isFinite(v) || v < 0 || (t === 'pct' && v > 100)) return fieldError(inp, 'Valor inválido.');
        close({ type: t, value: v });
      },
    }],
  });
  if (!r) return;
  // Descuento: sin autorización hasta el % máximo de su permiso (Ajustes → Usuarios → Permisos)
  const base = state.cart.reduce((a, it) => a + (Number(it.qty) || 0) * (Number(it.unit_price) || 0), 0);
  const pct = r.type === 'pct' ? r.value : base > 0 ? (r.value / base) * 100 : 100;
  if (r.value > 0 && pct > discountMax(ctx.user) + 1e-9) {
    const a = await authorize(`hacer un descuento de ${r.type === 'pct' ? `${fmtQty(r.value)} %` : fmtMoney(r.value)}`, { action: 'descuento', perm: 'descuentos' });
    if (!a) return;
    discountAuth = a;
  } else if (!r.value) discountAuth = null;
  state.discount = r; renderCart();
}
let discountAuth = null;

// ---------- Cobro ----------

async function cobrar() {
  if (!state.cart.length) return;
  if (!(await guardClock('vender'))) return;
  if (!openSession()) {
    if (!(await askOpenCash())) return;
    renderCajaAlert();
  }
  const st = settings();
  const c = calc();
  const total = c.total;
  if (!(total > 0)) { toast('El total tiene que ser mayor a cero.', 'warn'); return; }
  const cust = state.customer_id ? db.get('customers', state.customer_id) : null;
  const facturaOn = st.arca_env !== 'off';
  const letra = cbteLetra(cbteTipo(st.iva_condition, cust ? cust.iva_condition : 'CF'));
  const saleId = uuid();
  const result = await payModal({
    baseTotal: total, facturaOn, letra, docNumber: nextDocNumber(), customer: cust, saleId,
    onConfirm: async ({ payments, wantFactura, extraOps: payOps }) => {
      const extraOps = c.general_discount > 0 ? auditOps('descuento', 'sales', '', { amount: c.general_discount, gross: c.gross, total: c.total, type: state.discount.type, value: state.discount.value }, discountAuth && !discountAuth.self ? discountAuth : null) : [];
      // Presupuesto / pedido que se está vendiendo: queda "convertido" en la misma transacción
      const srcOps = state.source ? convertOps(state.source.kind, state.source.id, saleId) : [];
      const args = { cart: c.cartItems, discount: c.general_discount, payments, customer_id: state.customer_id, wantFactura, extraOps: [...extraOps, ...payOps, ...srcOps], seller_id: currentSeller(), extra: { id: saleId, observations: state.observations } };
      try { return await createSale(args); } catch (e) {
        // Límite de crédito: dueño o encargado pueden autorizarlo
        if (e.code !== 'CREDIT_LIMIT' || !(await confirmBox(e.message + ' ¿Vendés igual?', { title: 'Límite de crédito', ok: 'Vender igual', danger: true }))) throw e;
        return createSale({ ...args, allowOverLimit: true, extraOps: [...args.extraOps, ...auditOps('limite_credito', 'sales', '', { customer_id: state.customer_id, total: c.total })] });
      }
    },
  });
  if (!result) return;
  // Venta guardada: limpiamos y mostramos el comprobante
  state.cart = []; state.discount = { type: 'pct', value: 0 }; state.customer_id = null; state.observations = ''; state.source = null; discountAuth = null;
  renderCart(); renderTiles();
  afterSale(result);
}

/** Texto del comprobante en el carrito: "Factura B o interno X" / "Comprobante interno X" */
function docBarLabel(cust) {
  const st = settings();
  if (st.arca_env === 'off') return 'FC · Interno X';
  return `FC · Factura ${docLetter(st.iva_condition, cust ? cust.iva_condition : 'CF', true)} o interno X`;
}

async function askObservations() {
  const v = await modal({
    title: 'Observaciones del comprobante',
    body: html`<div class="field"><label for="obs-in">Salen impresas en el ticket o factura</label><textarea id="obs-in" rows="3" maxlength="300">${state.observations}</textarea></div>`,
    actions: [{ label: 'Cancelar', value: null }, { label: 'Listo', kind: 'primary', onClick: (close, w) => close({ v: $('#obs-in', w).value.trim() }) }],
  });
  if (!v) return;
  state.observations = v.v;
  renderCart();
}

/** Guardar el carrito como presupuesto o pedido de cliente */
async function saveAsDoc() {
  const { saveAsDocModal } = await import('./presupuestos.js');
  const c = calc();
  const saved = await saveAsDocModal({ cart: state.cart, customer_id: state.customer_id, discount: c.general_discount, notes: state.observations, source: state.source });
  if (!saved) return;
  if (await confirmBox('¿Vaciás el carrito? (el presupuesto / pedido quedó guardado y lo podés vender cuando quieras)', { title: 'Guardado', ok: 'Vaciar', cancel: 'Seguir vendiendo' })) {
    state.cart = []; state.discount = { type: 'pct', value: 0 }; state.customer_id = null; state.observations = ''; state.source = null;
    renderCart();
  }
}

async function afterSale(sale) {
  const st = settings();
  const isFactura = sale.doc && sale.doc.kind === 'factura';
  let current = sale;
  const cust = sale.customer_id ? db.get('customers', sale.customer_id) : null;
  await modal({
    title: `Venta N° ${sale.number} guardada`,
    body: html`
      ${sale.change > 0 ? html`<div class="change-box ok"><div class="k">Vuelto</div><div class="v" id="done-change">${fmtMoney(sale.change)}</div></div>` : ''}
      <div id="doc-status">${isFactura ? html`<div class="notice notice-info"><p><b>Pidiendo la factura a ARCA…</b></p></div>`
        : html`<div class="notice notice-ok"><p>${ic('check')} Venta registrada con <b>ticket no fiscal</b>.</p></div>`}</div>
      <div id="ticket-prev">${ticketHTML(sale)}</div>`,
    onMount(m) {
      drawQRs(m);
      if (!isFactura) return;
      requestInvoice(sale.id).then(r => {
        current = db.get('sales', sale.id);
        const box = $('#doc-status', m);
        if (!box) return;
        box.innerHTML = r.ok
          ? String(html`<div class="notice notice-ok"><p><b>Factura ${cbteLetra(r.doc.cbte_tipo)} autorizada.</b> CAE ${r.doc.cae}</p></div>`)
          : String(html`<div class="notice notice-warn"><p><b>La venta está guardada. La factura quedó PENDIENTE</b> (ARCA no respondió): se pide sola cuando ARCA vuelva, no hace falta hacer nada. Podés seguir vendiendo.</p><p class="small">${r.error}</p><p class="small">Este ticket todavía no es la factura. Cuando ARCA la autorice aparece en <b>Hoy → Facturas para mandar</b>.</p>
            <div class="field" style="margin-top:.5rem"><label for="done-contact">WhatsApp o mail del cliente para mandarle la factura (opcional)</label>
            <div class="btn-row"><input id="done-contact" autocomplete="off" placeholder="Ej: 2616123456 o cliente@mail.com" value="${cust ? (cust.phone || cust.email || '') : ''}" style="flex:1"><button type="button" class="btn ghost" id="done-contact-save">Guardar</button></div></div></div>`);
        $('#ticket-prev', m).innerHTML = String(ticketHTML(current));
        drawQRs(m);
        const sv = $('#done-contact-save', m);
        if (sv) sv.addEventListener('click', async () => {
          const v = $('#done-contact', m).value.trim();
          if (!v) return;
          const { saveDocContact } = await import('./mandar-factura.js');
          await saveDocContact(sale.id, v);
          sv.textContent = 'Guardado'; sv.disabled = true;
        });
      });
    },
    actions: [
      { label: raw(icon('print') + ' Imprimir'), onClick: () => printSale(current) },
      { label: raw(icon('whatsapp') + ' WhatsApp'), onClick: () => window.open(waLink(saleText(current, st, cust ? cust.name : ''), cust ? cust.phone : ''), '_blank', 'noopener') },
      { label: 'Nueva venta', kind: 'primary', value: true },
    ],
  });
  const input = $('#s-in', main);
  if (input && window.matchMedia('(min-width: 960px)').matches) input.focus();
  if (sync.isConfigured()) sync.syncNow();
}

/** Billetes sugeridos para "paga con": redondeos hacia arriba del total */
function billSuggestions(total) {
  const out = new Set();
  for (const b of [1000, 2000, 5000, 10000, 20000]) {
    const v = Math.ceil(total / b) * b;
    if (v > total) out.add(v);
  }
  return [...out].sort((a, b) => a - b).slice(0, 4);
}
