// =====================================================================
// clientes.js — Clientes con CUIT/condición IVA y cuenta corriente.
// =====================================================================
import * as db from '../db.js';
import { ctx, registerCustomerPayment, openSession } from '../ops.js';
import { html, $, on, ic, modal, toast, formData, fieldError, confirm } from '../ui.js';
import { fmtMoney, fmtDateTime, norm, parseNum, validCuit, payLabel, round2 } from '../logic.js';
import { ivaName } from '../print.js';
import { customerDetail, customerBalanceText } from './clientes-cuenta.js';
import { sellers, toCents, fromCents } from '../cuentas.js';

let main;

export function render(m) {
  main = m;
  main.innerHTML = String(html`
    <div class="page-head"><h1>Clientes</h1>
      <button type="button" class="btn primary" data-act="new">${ic('plus')} Nuevo cliente</button></div>
    <div class="field searchbox">${ic('search')}<label class="sr-only" for="c-q">Buscar cliente</label>
      <input id="c-q" type="search" placeholder="Buscar por nombre, CUIT o teléfono" autocomplete="off"></div>
    <div class="chips" role="group" aria-label="Filtro">
      <button type="button" class="chip" aria-pressed="true" data-f="all">Todos</button>
      <button type="button" class="chip" aria-pressed="false" data-f="debt">Con deuda</button>
      <button type="button" class="chip" aria-pressed="false" data-f="favor">Saldo a favor</button>
      <button type="button" class="chip" aria-pressed="false" data-f="ri">Resp. inscriptos</button>
      <button type="button" class="chip" aria-pressed="false" data-f="inactive">Inactivos</button></div>
    <p class="muted small" id="c-sum" aria-live="polite"></p>
    <div class="card"><ul class="list" id="c-list"></ul></div>`);
  // Filtro recordado en este equipo
  let filter = 'all';
  try { filter = localStorage.getItem('jg-filtro-clientes') || 'all'; } catch (e) { /* nada */ }
  main.querySelectorAll('[data-f]').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.f === filter)));
  const paint = () => {
    const q = norm($('#c-q', main).value);
    let list = db.all('customers').sort((a, b) => String(a.name || '').localeCompare(String(b.name || ''), 'es'));
    if (filter === 'debt') list = list.filter(c => (c.balance || 0) > 0.004);
    if (filter === 'favor') list = list.filter(c => (c.balance || 0) < -0.004);
    if (filter === 'ri') list = list.filter(c => c.iva_condition === 'RI');
    if (filter === 'inactive') list = list.filter(c => c.active === 0);
    // Clientes con saldo y total que deben (de todos, sin el filtro)
    const debt = db.all('customers').filter(c => (c.balance || 0) > 0.004);
    $('#c-sum', main).textContent = debt.length ? `${debt.length} ${debt.length === 1 ? 'cliente debe' : 'clientes deben'} en total ${fmtMoney(fromCents(debt.reduce((a, c) => a + toCents(c.balance), 0)))}` : 'Ningún cliente debe plata.';
    // Todas las palabras, sin importar acentos ni mayúsculas (nombre, documento, teléfono, email o dirección)
    if (q) list = list.filter(c => q.split(/\s+/).every(w => norm(`${c.name} ${c.doc_number} ${c.phone} ${c.email || ''} ${c.address || ''}`).includes(w)));
    $('#c-list', main).innerHTML = list.length ? String(html`${list.slice(0, 200).map(c => html`<li>
      <button type="button" class="row" data-open="${c.id}">
        <span class="avatar" aria-hidden="true">${c.name[0].toUpperCase()}</span>
        <span class="grow"><span class="title">${c.name}${c.active === 0 ? html` <span class="badge">inactivo</span>` : ''}</span><span class="sub" style="display:block">${c.doc_number ? `${c.doc_type} ${c.doc_number} · ` : ''}${ivaName(c.iva_condition)}${Number(c.credit_limit) > 0 ? ` · límite ${fmtMoney(c.credit_limit)}` : ''}</span></span>
        ${(c.balance || 0) > 0 ? html`<span class="badge err money">Debe ${fmtMoney(c.balance)}</span>` : (c.balance || 0) < 0 ? html`<span class="badge ok money">A favor ${fmtMoney(-c.balance)}</span>` : ''}
      </button></li>`)}`) : String(html`<li class="empty">No hay clientes${q ? ' con esa búsqueda' : ''}.</li>`);
  };
  paint();
  $('#c-q', main).addEventListener('input', paint);
  on(main, 'click', '[data-f]', (e, el) => { filter = el.dataset.f; try { localStorage.setItem('jg-filtro-clientes', filter); } catch (er) { /* nada */ } main.querySelectorAll('[data-f]').forEach(b => b.setAttribute('aria-pressed', String(b === el))); paint(); });
  on(main, 'click', '[data-act=new]', async () => { if (await customerForm()) paint(); });
  on(main, 'click', '[data-open]', async (e, el) => { await customerDetail(el.dataset.open); paint(); });
}

/** Formulario de alta/edición. Devuelve el cliente guardado o null. */
export async function customerForm(c = {}) {
  return modal({
    title: c.id ? 'Editar cliente' : 'Nuevo cliente',
    body: html`<form id="cf" novalidate>
      <div class="field"><label for="cf-name">Nombre o razón social</label><input id="cf-name" name="name" value="${c.name || ''}" autocomplete="off"></div>
      <div class="grid2">
        <div class="field"><label for="cf-dt">Documento</label><select id="cf-dt" name="doc_type">
          ${['CF', 'DNI', 'CUIT'].map(t => html`<option value="${t}" ${(c.doc_type || 'DNI') === t ? 'selected' : ''}>${t === 'CF' ? 'Sin documento' : t}</option>`)}</select></div>
        <div class="field"><label for="cf-dn">Número</label><input id="cf-dn" name="doc_number" inputmode="numeric" value="${c.doc_number || ''}"></div>
      </div>
      <div class="field"><label for="cf-iva">Condición IVA</label><select id="cf-iva" name="iva_condition">
        ${[['CF', 'Consumidor final'], ['RI', 'Responsable inscripto'], ['MT', 'Monotributo'], ['EX', 'Exento']].map(([v, l]) => html`<option value="${v}" ${(c.iva_condition || 'CF') === v ? 'selected' : ''}>${l}</option>`)}</select>
        <div class="hint">Si es Responsable inscripto y vos también, se le hace Factura A (necesita CUIT).</div></div>
      <div class="grid2">
        <div class="field"><label for="cf-ph">Teléfono / WhatsApp</label><input id="cf-ph" name="phone" type="tel" value="${c.phone || ''}"></div>
        <div class="field"><label for="cf-em">Email</label><input id="cf-em" name="email" type="email" value="${c.email || ''}"></div>
      </div>
      <div class="field"><label for="cf-ad">Dirección</label><input id="cf-ad" name="address" value="${c.address || ''}"></div>
      <div class="grid2">
        <div class="field"><label for="cf-lim">Límite de crédito <span class="muted">(cuenta corriente)</span></label><input id="cf-lim" name="credit_limit" class="money-input" inputmode="decimal" value="${Number(c.credit_limit) > 0 ? fmtMoney(c.credit_limit).replace('$ ', '') : ''}" placeholder="Sin límite">
          <div class="hint">Si una venta a cuenta lo pasa, el cajero no puede hacerla; dueño o encargado sí, confirmando.</div></div>
        <div class="field"><label for="cf-sel">Vendedor</label><select id="cf-sel" name="seller_id"><option value="">— Ninguno —</option>
          ${sellers(db.all('users')).map(u => html`<option value="${u.id}" ${c.seller_id === u.id ? 'selected' : ''}>${u.name}</option>`)}</select>
          <div class="hint">Sus cobros de cuenta corriente cuentan para la comisión “por cobranza”.</div></div>
      </div>
      <div class="field"><label for="cf-no">Notas</label><textarea id="cf-no" name="notes">${c.notes || ''}</textarea></div>
      ${c.id ? html`<label class="check"><input type="checkbox" name="active" ${c.active === 0 ? '' : 'checked'}> Activo (aparece para vender)</label>` : ''}
    </form>`,
    onMount(m) { $('#cf', m).addEventListener('submit', e => { e.preventDefault(); m.querySelector('.modal-foot .primary').click(); }); },
    actions: [{ label: 'Cancelar', value: null }, {
      label: 'Guardar', kind: 'primary', onClick: async (close, w) => {
        const f = formData($('#cf', w));
        if (!f.name.trim()) return fieldError($('#cf-name', w), 'Escribí el nombre.');
        if (f.doc_type === 'CUIT' && !validCuit(f.doc_number)) return fieldError($('#cf-dn', w), 'El CUIT no es válido.');
        if (f.iva_condition === 'RI' && f.doc_type !== 'CUIT') return fieldError($('#cf-dt', w), 'Un Responsable inscripto necesita CUIT.');
        if (f.doc_type === 'DNI' && f.doc_number && !/^\d{7,8}$/.test(f.doc_number.replace(/\D/g, ''))) return fieldError($('#cf-dn', w), 'El DNI tiene 7 u 8 números.');
        const lim = f.credit_limit.trim() ? parseNum(f.credit_limit) : 0;
        if (!isFinite(lim) || lim < 0) return fieldError($('#cf-lim', w), 'Límite inválido (vacío = sin límite).');
        const rec = await db.put('customers', {
          ...(c.id ? { id: c.id } : { balance: 0 }),
          name: f.name.trim(), doc_type: f.doc_type, doc_number: f.doc_number.replace(/[^\d]/g, ''), iva_condition: f.iva_condition,
          phone: f.phone.trim(), email: f.email.trim(), address: f.address.trim(),
          credit_limit: round2(lim), seller_id: f.seller_id || null, notes: f.notes.trim(), active: c.id ? (f.active ? 1 : 0) : 1,
        });
        toast('Cliente guardado.');
        close(rec);
      },
    }],
  });
}

/** Elegir cliente para una venta. Devuelve id, null (consumidor final) o undefined (canceló). */
export async function pickCustomer(currentId) {
  const r = await modal({
    title: 'Cliente',
    body: html`<div class="field searchbox">${ic('search')}<label class="sr-only" for="pc-q">Buscar cliente</label>
      <input id="pc-q" type="search" placeholder="Buscar cliente" autocomplete="off"></div>
      <div class="btn-row" style="margin-bottom:.75rem">
        <button type="button" class="btn ${currentId ? 'ghost' : 'soft'}" data-pick="">Consumidor final</button>
        <button type="button" class="btn ghost" data-new>${ic('plus')} Nuevo</button></div>
      <ul class="list" id="pc-list"></ul>`,
    onMount(m, close) {
      const paint = () => {
        const q = norm($('#pc-q', m).value);
        const list = db.all('customers').filter(c => c.active !== 0 || c.id === currentId).filter(c => !q || norm(`${c.name} ${c.doc_number} ${c.phone}`).includes(q)).sort((a, b) => String(a.name || '').localeCompare(String(b.name || ''), 'es')).slice(0, 50);
        $('#pc-list', m).innerHTML = String(html`${list.map(c => html`<li><button type="button" class="row" data-pick="${c.id}">
          <span class="grow"><span class="title">${c.name}</span><span class="sub" style="display:block">${ivaName(c.iva_condition)}${c.doc_number ? ` · ${c.doc_number}` : ''}${(c.balance || 0) > 0.004 ? ` · ${customerBalanceText(c.balance)}` : ''}</span></span>
          ${c.id === currentId ? ic('check') : ''}</button></li>`)}${!list.length ? html`<li class="empty">Sin resultados.</li>` : ''}`);
      };
      paint();
      $('#pc-q', m).addEventListener('input', paint);
      m.addEventListener('click', async e => {
        const b = e.target.closest('[data-pick]');
        if (b) close({ id: b.dataset.pick || null });
        if (e.target.closest('[data-new]')) {
          const c = await customerForm();
          if (c) close({ id: c.id });
        }
      });
    },
  });
  return r ? r.id : undefined;
}

// Ficha del cliente, estado de cuenta y cobros: clientes-cuenta.js
