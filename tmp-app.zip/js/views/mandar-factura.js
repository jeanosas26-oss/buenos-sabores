// Mandar la factura en PDF al cliente (WhatsApp, mail o compartir) y marcarla como mandada.
import * as db from '../db.js';
import { settings } from '../ops.js';
import { html, $, modal, toast, download } from '../ui.js';
import { fmtMoney, cbteNombre, fmtCbteNro, waLink } from '../logic.js';
import { facturaPdf, isEmail } from '../factura-pdf.js';

/** Guarda a quién mandarle la factura (WhatsApp o mail) */
export async function saveDocContact(saleId, contact) {
  await db.put('sales', { id: saleId, doc_contact: String(contact || '').trim().slice(0, 120) });
}

export async function markSent(saleId) {
  await db.put('sales', { id: saleId, doc_sent_at: Date.now() });
}

export async function mandarFacturaDialog(saleId) {
  const s = db.get('sales', saleId);
  const d = (s && s.doc) || {};
  const st = settings();
  const cust = s.customer_id ? db.get('customers', s.customer_id) : null;
  const def = s.doc_contact || (cust && (cust.phone || cust.email)) || '';
  const nro = `${cbteNombre(d.cbte_tipo)} N° ${fmtCbteNro(d.pto_vta, d.cbte_nro)}`;
  const texto = `Hola${cust ? ' ' + cust.name : ''}! Te mandamos la ${nro} de ${st.business_name || 'nuestro comercio'} por ${fmtMoney(s.total)} (CAE ${d.cae}). Gracias por tu compra.`;
  let pdf = null;
  const getPdf = async () => (pdf = pdf || await facturaPdf(db.get('sales', saleId)));
  return modal({
    title: 'Mandar factura al cliente',
    body: html`<p><b>${nro}</b> · ${fmtMoney(s.total)}${s.doc_sent_at ? html` · <span class="badge ok">ya mandada</span>` : ''}</p>
      <div class="field"><label for="mf-c">WhatsApp o mail del cliente</label><input id="mf-c" value="${def}" autocomplete="off" placeholder="Ej: 2616123456 o cliente@mail.com"></div>
      <p class="small muted"><b>Compartir PDF</b> abre WhatsApp, mail u otra app con el PDF adjunto. En la PC, si no aparece, usá <b>Bajar PDF</b> y adjuntalo en el chat o en el mail que se abre.</p>
      <p id="mf-err" class="field-err" role="alert"></p>`,
    actions: [
      { label: 'Cerrar', value: null },
      { label: 'Bajar PDF', onClick: async (close, w) => {
        try { const { file } = await getPdf(); download(file.name, file); } catch (e) { $('#mf-err', w).textContent = e.message; }
      } },
      { label: 'Ya se la mandé', onClick: async (close, w) => {
        await saveDocContact(saleId, $('#mf-c', w).value); await markSent(saleId); toast('Factura marcada como mandada.'); close(true);
      } },
      { label: 'Compartir PDF', kind: 'primary', onClick: async (close, w) => {
        const err = $('#mf-err', w); err.textContent = '';
        const contact = $('#mf-c', w).value.trim();
        try {
          const { file, qr } = await getPdf();
          await saveDocContact(saleId, contact);
          if (navigator.canShare && navigator.canShare({ files: [file] })) {
            await navigator.share({ files: [file], title: nro, text: texto });
          } else {
            download(file.name, file);
            if (isEmail(contact)) window.open(`mailto:${encodeURIComponent(contact)}?subject=${encodeURIComponent(nro)}&body=${encodeURIComponent(texto + '\n\n(Va adjunta en PDF)')}`, '_blank');
            else window.open(waLink(texto, contact), '_blank', 'noopener');
            toast('Se bajó el PDF: adjuntalo en el chat o mail que se abrió.', 'ok', 6000);
          }
          if (!qr) toast('El PDF salió sin el QR de ARCA (no había internet para dibujarlo).', 'warn', 6000);
          await markSent(saleId);
          close(true);
        } catch (e) {
          if (e && e.name === 'AbortError') return;
          err.textContent = e.message || String(e);
        }
      } },
    ],
  });
}
