// =====================================================================
// reportes.js — Ventas de hoy/semana/mes, medios de pago, más vendidos,
// ganancia estimada y Libro IVA Ventas (exportable a Excel).
// =====================================================================
import * as db from '../db.js';
import { settings, multiBranch, branches, inBranch, stockOf, branchName } from '../ops.js';
import { html, $, on, ic, exportTable } from '../ui.js';
import { ivaBookBreakdown } from '../compras-calc.js';
import {
  salesReport, periodRange, fmtMoney, fmtQty, fmtDate, payLabel, ivaBreakdown, discriminaIva,
  cbteLetra, fmtCbteNro, round2, toISODate,
} from '../logic.js';

let main;
let period = 'hoy';
let ivaMonth = toISODate(Date.now()).slice(0, 7);
let includeNoFiscal = false;
// Sucursal del reporte: 'all' = todas (con desglose por sucursal) o el id de una
let rBranch = 'all';

/** Ventas de la sucursal elegida (todas si el comercio tiene una sola) */
function branchSales(coll = 'sales') {
  const all = db.all(coll);
  if (!multiBranch() || rBranch === 'all' || !db.get('branches', rBranch)) return all;
  return all.filter(s => inBranch(s, rBranch));
}
/** Devoluciones / notas de crédito de la sucursal elegida (restan en todo) */
const branchReturns = () => branchSales('returns');

export function render(m) {
  main = m;
  paint();
  return on(main, 'click', '[data-p], [data-act], [data-rb]', (e, el) => {
    if (el.dataset.p) { period = el.dataset.p; paint(); }
    if (el.dataset.rb) { rBranch = el.dataset.rb; paint(); }
    if (el.dataset.act === 'iva-export') exportIva();
  });
}

function paint() {
  const { from, to } = periodRange(period);
  const multi = multiBranch();
  if (multi && rBranch !== 'all' && !db.get('branches', rBranch)) rBranch = 'all';
  const costOf = id => (db.get('products', id) || {}).cost || 0;
  const r = salesReport(branchSales(), { from, to, costOf, returns: branchReturns() });
  const maxM = Math.max(1, ...Object.values(r.byMethod));
  // Stock bajo: en la sucursal elegida; con "Todas", en cualquiera de las sucursales activas
  const lowIn = multi && rBranch === 'all' ? branches().map(b => b.id) : [multi ? rBranch : null];
  const lows = db.all('products').filter(p => p.active !== 0 && Number(p.stock_min) > 0 && lowIn.some(b => (b ? stockOf(p, b) : Number(p.stock)) <= Number(p.stock_min))).length;
  // Desglose por sucursal (solo con "Todas")
  const per = multi && rBranch === 'all' ? branches({ includeInactive: true }).map(b => ({ b, r: salesReport(db.all('sales').filter(s => inBranch(s, b.id)), { from, to, costOf, returns: db.all('returns').filter(x => inBranch(x, b.id)) }) })).filter(x => x.b.active !== 0 || x.r.count) : [];
  const maxB = Math.max(1, ...per.map(x => x.r.total));
  main.innerHTML = String(html`
    <div class="page-head"><h1>Reportes</h1></div>
    ${multi ? html`<div class="chips" role="group" aria-label="Sucursal">
      <button type="button" class="chip" data-rb="all" aria-pressed="${rBranch === 'all'}">${ic('store')} Todas</button>
      ${branches().map(b => html`<button type="button" class="chip" data-rb="${b.id}" aria-pressed="${rBranch === b.id}">${b.name}</button>`)}
    </div>` : ''}
    <div class="chips" role="group" aria-label="Período">
      ${[['hoy', 'Hoy'], ['semana', 'Esta semana'], ['mes', 'Este mes']].map(([k, l]) => html`<button type="button" class="chip" data-p="${k}" aria-pressed="${period === k}">${l}</button>`)}
    </div>
    <p class="muted small">Del ${fmtDate(from)} al ${fmtDate(to)}${multi ? ` · ${rBranch === 'all' ? 'Todas las sucursales' : 'Sucursal ' + branchName(rBranch)}` : ''}</p>
    <div class="stats">
      <div class="stat hero"><div class="k">Total vendido${r.returns ? ' (neto de devoluciones)' : ''}</div><div class="v money" id="r-total">${fmtMoney(r.total)}</div></div>
      <div class="stat"><div class="k">Ventas</div><div class="v">${r.count}</div></div>
      <div class="stat"><div class="k">Ticket promedio</div><div class="v money">${fmtMoney(r.avg)}</div></div>
      <div class="stat"><div class="k">Ganancia estimada</div><div class="v money">${fmtMoney(r.profit)}</div></div>
      <div class="stat"><div class="k">IVA de las ventas</div><div class="v money">${fmtMoney(r.iva)}</div></div>
      ${r.returnsCount ? html`<div class="stat"><div class="k">Devoluciones / NC (${r.returnsCount})</div><div class="v money" id="r-devs">-${fmtMoney(r.returns)}</div></div>` : ''}
    </div>
    ${per.length ? html`<div class="card" id="r-branches"><h2>Por sucursal</h2>
      <ul class="bars">${per.map(({ b, r: x }) => html`<li data-branch-report="${b.id}">
        <div class="lbl"><span>${b.name}</span><span class="money">${fmtMoney(x.total)}</span></div>
        <div class="sub-lbl">${x.count} ${x.count === 1 ? 'venta' : 'ventas'}${x.count ? ` · promedio ${fmtMoney(x.avg)}` : ''}${r.total > 0 ? ` · ${Math.round((x.total / r.total) * 100)}%` : ''}</div>
        <div class="track" aria-hidden="true"><div class="fill" style="width:${Math.max(2, (x.total / maxB) * 100)}%"></div></div></li>`)}</ul></div>` : ''}
    ${!r.costKnown && r.count ? html`<p class="muted small">La ganancia es estimada: precio de venta menos el costo actual. Hay productos sin costo cargado (o montos libres) que se cuentan como ganancia total.</p>` : ''}
    ${lows ? html`<div class="notice notice-warn"><p>${ic('alert')} Hay <b>${lows}</b> productos con stock bajo. <a href="#/productos">Ver productos</a></p></div>` : ''}
    <div class="grid2" style="grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:1rem">
      <div class="card"><h2>Por medio de pago</h2>
        ${Object.keys(r.byMethod).length ? html`<ul class="bars">${Object.entries(r.byMethod).sort((a, b) => b[1] - a[1]).map(([k, v]) => html`<li>
          <div class="lbl"><span>${payLabel(k)}</span><span class="money">${fmtMoney(v)}</span></div>
          <div class="track" aria-hidden="true"><div class="fill" style="width:${Math.max(2, (v / maxM) * 100)}%"></div></div></li>`)}</ul>`
          : html`<p class="muted">Sin ventas en este período.</p>`}</div>
      <div class="card"><h2>Más vendidos</h2>
        ${r.top.length ? html`<div class="table-wrap"><table><thead><tr><th>Producto</th><th class="r">Cant.</th><th class="r">Total</th></tr></thead><tbody>
          ${r.top.map(t => html`<tr><td style="white-space:normal">${t.name}</td><td class="r">${fmtQty(t.qty)}</td><td class="r">${fmtMoney(t.total)}</td></tr>`)}</tbody></table></div>`
          : html`<p class="muted">Sin ventas en este período.</p>`}</div>
    </div>
    <div class="card" id="iva">${ivaSection()}</div>`);
  bindIva();
}

function bindIva() {
  $('#iva-m', main).onchange = e => { ivaMonth = e.target.value || ivaMonth; $('#iva', main).innerHTML = String(ivaSection()); bindIva(); };
  $('#iva-nf', main).onchange = e => { includeNoFiscal = e.target.checked; $('#iva', main).innerHTML = String(ivaSection()); bindIva(); };
}

/** Filas del Libro IVA Ventas del mes elegido */
function ivaRows() {
  const st = settings();
  const disc = discriminaIva(st.iva_condition);
  const [y, mo] = ivaMonth.split('-').map(Number);
  const from = new Date(y, mo - 1, 1).getTime(), to = new Date(y, mo, 1).getTime() - 1;
  const rows = [];
  for (const s of branchSales().filter(x => x.created_at >= from && x.created_at <= to).sort((a, b) => a.created_at - b.created_at)) {
    const d = s.doc || {};
    const fiscal = d.kind === 'factura' && d.status === 'autorizado';
    if (!fiscal && (!includeNoFiscal || s.status !== 'ok')) continue;
    const c = s.customer_id ? db.get('customers', s.customer_id) : null;
    // Mismo reparto por alícuota que ARCA (y el IVA que informó ARCA si el comprobante lo trae): así cuadra con lo facturado
    const br = ivaBookBreakdown(s.items, s.total, disc, fiscal ? d.iva : null);
    const g = k => br[k] || { net: 0, iva: 0, total: 0 };
    const base = {
      fecha: fmtDate(s.created_at), _t: s.created_at,
      tipo: fiscal ? 'Factura ' + cbteLetra(d.cbte_tipo) : 'No fiscal',
      numero: fiscal ? fmtCbteNro(d.pto_vta, d.cbte_nro) : String(s.number),
      cliente: c ? c.name : 'Consumidor final',
      doc: c && c.doc_number ? `${c.doc_type} ${c.doc_number}` : '',
      n21: g('21').net, i21: g('21').iva, n105: g('10.5').net, i105: g('10.5').iva, n27: g('27').net, i27: g('27').iva,
      exento: g('0').total, total: s.total,
    };
    rows.push(base);
    // Una venta facturada y después anulada: su nota de crédito resta en el mismo libro
    if (fiscal && s.status === 'anulada' && d.credit_note) {
      const nc = d.credit_note;
      const neg = {};
      for (const k of ['n21', 'i21', 'n105', 'i105', 'n27', 'i27', 'exento', 'total']) neg[k] = -base[k];
      rows.push({ ...base, ...neg, tipo: 'N. Crédito ' + cbteLetra(nc.cbte_tipo), numero: fmtCbteNro(nc.pto_vta, nc.cbte_nro), fecha: fmtDate(s.voided_at || s.created_at), _t: s.voided_at || s.created_at });
    }
  }
  // Devoluciones (notas de crédito parciales): restan en el mes de la devolución, por alícuota
  for (const r of branchReturns().filter(x => x.created_at >= from && x.created_at <= to && !x.test)) {
    const d = r.doc || {};
    const fiscal = d.kind === 'nota_credito' && d.status === 'autorizado';
    if (!fiscal && !includeNoFiscal) continue;
    const sale = db.get('sales', r.sale_id) || {};
    const c = r.customer_id ? db.get('customers', r.customer_id) : null;
    const br = ivaBookBreakdown(r.items, r.total, disc, fiscal ? d.iva : null);
    const g = k => br[k] || { net: 0, iva: 0, total: 0 };
    rows.push({
      fecha: fmtDate(r.created_at), _t: r.created_at,
      tipo: fiscal ? 'N. Crédito ' + cbteLetra(d.cbte_tipo) : 'Devolución no fiscal',
      numero: fiscal ? fmtCbteNro(d.pto_vta, d.cbte_nro) : `${r.number} (venta ${sale.number || '—'})`,
      cliente: c ? c.name : 'Consumidor final',
      doc: c && c.doc_number ? `${c.doc_type} ${c.doc_number}` : '',
      n21: -g('21').net, i21: -g('21').iva, n105: -g('10.5').net, i105: -g('10.5').iva, n27: -g('27').net, i27: -g('27').iva,
      exento: -g('0').total, total: -r.total,
    });
  }
  return rows.sort((a, b) => a._t - b._t);
}

const COLS = [['n21', 'Neto 21%'], ['i21', 'IVA 21%'], ['n105', 'Neto 10,5%'], ['i105', 'IVA 10,5%'], ['n27', 'Neto 27%'], ['i27', 'IVA 27%'], ['exento', 'Exento / no grav.'], ['total', 'Total']];

function ivaSection() {
  const rows = ivaRows();
  const sum = {};
  for (const [k] of COLS) sum[k] = round2(rows.reduce((a, r) => a + r[k], 0));
  const st = settings();
  return html`<div class="card-head"><h2>Libro IVA Ventas</h2>
      <button type="button" class="btn ghost sm" data-act="iva-export" ${rows.length ? '' : 'disabled'}>${ic('download')} Exportar Excel</button></div>
    ${st.iva_condition !== 'RI' ? html`<p class="muted small">Sos ${st.iva_condition === 'MT' ? 'monotributista' : 'exento'}: tus comprobantes son Factura C y no discriminan IVA (todo figura como no gravado).</p>` : ''}
    <div class="grid2">
      <div class="field"><label for="iva-m">Mes</label><input id="iva-m" type="month" value="${ivaMonth}"></div>
      <label class="check" style="align-self:end"><input type="checkbox" id="iva-nf" ${includeNoFiscal ? 'checked' : ''}> Incluir tickets no fiscales</label>
    </div>
    ${rows.length ? html`<div class="table-wrap"><table><thead><tr><th>Fecha</th><th>Comprobante</th><th>Número</th><th>Cliente</th>${COLS.map(([, l]) => html`<th class="r">${l}</th>`)}</tr></thead><tbody>
      ${rows.map(r => html`<tr><td>${r.fecha}</td><td>${r.tipo}</td><td>${r.numero}</td><td>${r.cliente}</td>${COLS.map(([k]) => html`<td class="r">${fmtMoney(r[k])}</td>`)}</tr>`)}
      </tbody><tfoot><tr><td colspan="4">Totales (${rows.length})</td>${COLS.map(([k]) => html`<td class="r">${fmtMoney(sum[k])}</td>`)}</tr></tfoot></table></div>`
      : html`<p class="muted">No hay comprobantes fiscales en ese mes.${includeNoFiscal ? '' : ' Podés tildar “Incluir tickets no fiscales” para ver todas las ventas.'}</p>`}`;
}

async function exportIva() {
  const rows = ivaRows();
  const table = [['Fecha', 'Comprobante', 'Número', 'Cliente', 'Documento', ...COLS.map(c => c[1])]];
  for (const r of rows) table.push([r.fecha, r.tipo, r.numero, r.cliente, r.doc, ...COLS.map(([k]) => r[k])]);
  table.push(['', '', '', 'TOTALES', '', ...COLS.map(([k]) => round2(rows.reduce((a, r) => a + r[k], 0)))]);
  await exportTable(`libro-iva-ventas-${ivaMonth}`, 'Libro IVA Ventas', table);
}
