// =====================================================================
// compras.js — Compras como SGI Libra: comprobante completo del proveedor (FC/NC/ND, letra, número, fecha y hora),
// renglones con Dto1/Dto2, panel de totales (descuentos generales, IVA por alícuota editable, no gravados,
// percepciones y retenciones) con control contra el TOTAL FACTURA, condición (contado, cta. cte., Mercado Pago,
// transferencia, cheque), "a Caja" y "Actualiza costos". Listado tipo SGI, detalle, Libro IVA Compras y proveedores.
// =====================================================================
import * as db from '../db.js';
import { userName, stockOf, multiBranch, currentBranch, branchName, settings, openSession, ctx, mainBranchId } from '../ops.js';
import { html, $, on, ic, modal, toast, fieldError, confirm, exportTable } from '../ui.js';
import { fmtMoney, fmtQty, fmtNum2, fmtDate, fmtTime, parseNum, searchProducts, round2, round3, toISODate, dayStart, dayEnd, can, branchOf } from '../logic.js';
import { productForm, productByCode } from './productos.js';
import { mountSuppliers, mountLiquidacion, supplierForm as fullSupplierForm, balanceText } from './proveedores.js';
import { purchaseDebt } from '../cuentas.js';
import { openScanner, canScan, scanButton, playError } from '../scanner.js';
import {
  computePurchase, defaultLetter, DOC_TYPES, LETTERS, PURCHASE_PAYMENTS, PURCHASE_RATES, paymentLabel, purchaseDocLabel, purchaseSign,
  purchaseIvaRow, IVA_BOOK_PURCHASE_COLS, purchaseDate, isVoidPurchase, toCents, fromCents,
  costForProduct, suggestPrice, changePct, BIG_RISE_PCT,
} from '../compras-calc.js';
import { buildIndex, matchSupplier, matchLine } from '../ia-match.js';
import { savePurchaseFull, voidPurchase } from '../compras-ops.js';
import { walletPickerHTML, pickedCheques } from './cheque-ui.js';
import { printA4, printHead } from './ctacte.js';

let main;
let tab = 'compras';
const TABS = [['compras', 'Compras'], ['iva', 'Libro IVA Compras'], ['proveedores', 'Proveedores'], ['liquidacion', 'Liquidación']];
/** Dueño y encargado: todo. Cajero y vendedor: solo el listado de lo que cargaron y "Cargar compra" (sin proveedores,
 * saldos, Libro IVA, liquidación, anular, cheques ni recalcular precios). */
const isMgr = () => !!ctx.user && can(ctx.user, 'compras');
const IVA_LABEL = { CF: 'Consumidor final', RI: 'Responsable inscripto', MT: 'Monotributo', EX: 'Exento' };

export function render(m) {
  main = m;
  // #/compras?tab=proveedores, ?tab=liquidacion o ?tab=iva abre esa pestaña
  const qt = new URLSearchParams(location.hash.split('?')[1] || '').get('tab');
  if (qt && TABS.some(t => t[0] === qt)) tab = qt;
  else if (/^#\/proveedores/.test(location.hash)) tab = 'proveedores';
  else if (/^#\/compras/.test(location.hash) && !qt) tab = 'compras';
  if (!isMgr()) tab = 'compras';
  paint();
  bindPurchaseFilters(main, paint);
  return on(main, 'click', '[data-act], [data-tab], [data-sup], [data-pur]', (e, el) => {
    if (el.dataset.tab) { tab = isMgr() ? el.dataset.tab : 'compras'; paint(); return; }
    if (el.dataset.pur) { purchaseDetail(db.get('purchases', el.dataset.pur)).then(paint); return; }
    if (el.dataset.act === 'new-purchase') purchaseForm().then(r => r && paint());
    if (el.dataset.act === 'photo-purchase') photoPurchase().then(r => r && paint());
    if (!isMgr()) return;
    if (el.dataset.act === 'export') exportPurchases();
    if (el.dataset.act === 'iva-export') exportIvaBook();
    if (el.dataset.act === 'iva-print') printIvaBook();
  });
}

function paint() {
  const mgr = isMgr();
  if (!mgr) tab = 'compras';
  main.innerHTML = String(html`
    <div class="page-head"><h1>${mgr ? 'Compras y proveedores' : 'Compras'}</h1></div>
    ${mgr ? html`<div class="chips" role="tablist">
      ${TABS.map(([k, l]) => html`<button type="button" class="chip" role="tab" data-tab="${k}" aria-pressed="${tab === k}" aria-selected="${tab === k}">${l}</button>`)}
    </div>` : html`<p class="muted" id="cp-limited">Cargá acá las facturas y notas de crédito de los proveedores que llegan: se suma el stock y se actualiza el costo. Ves las compras que cargaste vos${multiBranch() ? ' en esta sucursal' : ''}.</p>`}
    ${tab === 'compras' ? purchasesView() : tab === 'iva' ? ivaBookView() : html`<div id="cp-tab"></div>`}`);
  if (tab === 'proveedores') mountSuppliers($('#cp-tab', main));
  if (tab === 'liquidacion') mountLiquidacion($('#cp-tab', main));
  if (tab === 'iva') {
    const inp = $('#ivc-m', main);
    if (inp) inp.addEventListener('change', e => { ivaMonth = e.target.value || ivaMonth; paint(); });
  }
}

// ---------- Listado (columnas como SGI) ----------

// Filtros de compras (se recuerdan en este equipo)
const pf = { sup: '', from: '', to: '', due: false, type: '', pay: '' };
try { Object.assign(pf, JSON.parse(localStorage.getItem('jg-filtros-compras') || '{}')); } catch (e) { /* nada */ }

/** Saldo pendiente de cada compra a cuenta corriente: lo que sumó menos los pagos aplicados a ella (por orden de fecha) */
function purchaseBalances() {
  const out = new Map();
  for (const p of db.all('purchases')) { const d = purchaseDebt(p); if (d > 0) out.set(p.id, toCents(d)); }
  const pays = db.all('supplier_payments').filter(x => (x.kind || 'pago') === 'pago' && Array.isArray(x.applies_to) && x.applies_to.length).sort((a, b) => a.created_at - b.created_at);
  for (const pay of pays) {
    let left = toCents(pay.amount);
    const targets = pay.applies_to.map(id => db.get('purchases', id)).filter(Boolean).sort((a, b) => a.created_at - b.created_at);
    for (const p of targets) {
      if (left <= 0) break;
      const cur = out.get(p.id) || 0;
      const take = Math.min(cur, left);
      out.set(p.id, cur - take); left -= take;
    }
  }
  return out;
}
const toPay = (p, bal) => (bal.get(p.id) || 0) > 0;

/** Compras que ve este usuario: dueño y encargado, todas; cajero y vendedor, las que cargó él en esta sucursal */
function visiblePurchases() {
  const all = db.all('purchases');
  if (isMgr()) return all;
  const me = ctx.user.id, b = ctx.branchId || mainBranchId(), mainId = mainBranchId();
  return all.filter(p => p.user_id === me && branchOf(p, mainId) === b);
}

function filteredPurchases(bal) {
  const from = pf.from ? dayStart(pf.from) : 0, to = pf.to ? dayEnd(pf.to) : Infinity;
  const mgr = isMgr();
  return visiblePurchases().filter(p => (!pf.sup || (pf.sup === '-' ? !p.supplier_id : p.supplier_id === pf.sup))
    && purchaseDate(p) >= from && purchaseDate(p) <= to && (!mgr || !pf.due || toPay(p, bal))
    && (!pf.type || (p.doc_type || 'FC') === pf.type) && (!pf.pay || (p.payment || 'contado') === pf.pay))
    .sort((a, b) => purchaseDate(b) - purchaseDate(a) || b.created_at - a.created_at);
}
export function bindPurchaseFilters(root, repaint) {
  root.addEventListener('change', e => {
    if (!e.target.closest('#cf-f')) return;
    pf.sup = $('#cf-sup', root).value; pf.from = $('#cf-from', root).value; pf.to = $('#cf-to', root).value; pf.due = $('#cf-due', root).checked;
    pf.type = $('#cf-type', root).value; pf.pay = $('#cf-pay', root).value;
    try { localStorage.setItem('jg-filtros-compras', JSON.stringify(pf)); } catch (er) { /* nada */ }
    repaint();
  });
}

const docText = p => purchaseDocLabel(p) || 'Sin comprobante';
const supName = p => (db.get('suppliers', p.supplier_id) || {}).name || 'Sin proveedor';
const signed = p => purchaseSign(p) * (Number(p.total) || 0);

function purchasesView() {
  const multi = multiBranch();
  const mgr = isMgr();
  // El saldo pendiente de cada compra sale de los pagos al proveedor: solo para dueño y encargado
  const bal = mgr ? purchaseBalances() : new Map();
  const all = filteredPurchases(bal);
  const list = all.slice(0, 150);
  const sups = db.all('suppliers').sort((a, b) => String(a.name || '').localeCompare(String(b.name || ''), 'es'));
  const filtering = pf.sup || pf.from || pf.to || (mgr && pf.due) || pf.type || pf.pay;
  const sum = fromCents(all.filter(p => !isVoidPurchase(p)).reduce((a, p) => a + toCents(signed(p)), 0));
  const due = fromCents(all.reduce((a, p) => a + (bal.get(p.id) || 0), 0));
  const pays = mgr ? PURCHASE_PAYMENTS : PURCHASE_PAYMENTS.filter(([k]) => k !== 'cheque');
  return html`<div class="btn-row" style="margin-bottom:1rem">
      <button type="button" class="btn primary big" data-act="new-purchase">${ic('plus')} Cargar compra</button>
      <button type="button" class="btn soft big" data-act="photo-purchase" id="cp-photo">${ic('camera')} Cargar desde foto</button>
      ${mgr ? html`<button type="button" class="btn ghost" data-act="export">${ic('download')} Exportar Excel</button>` : ''}</div>
    <form class="card filters" id="cf-f" aria-label="Filtros de compras">
      <div class="field"><label for="cf-sup">Proveedor</label><select id="cf-sup"><option value="">Todos</option>${sups.map(s => html`<option value="${s.id}" ${pf.sup === s.id ? 'selected' : ''}>${s.name}</option>`)}<option value="-" ${pf.sup === '-' ? 'selected' : ''}>Sin proveedor</option></select></div>
      <div class="field"><label for="cf-from">Desde</label><input id="cf-from" type="date" value="${pf.from}"></div>
      <div class="field"><label for="cf-to">Hasta</label><input id="cf-to" type="date" value="${pf.to}"></div>
      <div class="field"><label for="cf-type">Comprobante</label><select id="cf-type"><option value="">Todos</option>${DOC_TYPES.map(([k, l]) => html`<option value="${k}" ${pf.type === k ? 'selected' : ''}>${l}</option>`)}</select></div>
      <div class="field"><label for="cf-pay">Condición</label><select id="cf-pay"><option value="">Todas</option>${pays.map(([k]) => html`<option value="${k}" ${pf.pay === k ? 'selected' : ''}>${paymentLabel(k)}</option>`)}</select></div>
      <label class="check${mgr ? '' : ' hidden'}" style="align-self:end"><input type="checkbox" id="cf-due" ${pf.due ? 'checked' : ''}> Solo a pagar</label>
    </form>
    <p class="muted small" id="cf-count">${all.length} ${all.length === 1 ? 'comprobante' : 'comprobantes'} · ${fmtMoney(sum)}${due ? ` · saldo a pagar ${fmtMoney(due)}` : ''}${all.length > list.length ? ` (se muestran los ${list.length} más recientes)` : ''}</p>
    <div class="card">${list.length ? html`
      <div class="table-wrap cp-table"><table id="cp-list-t"><thead><tr><th>Fecha</th><th>Hora</th><th>Comprobante</th><th>Proveedor</th><th class="r">Total</th>${mgr ? html`<th class="r">Saldo</th>` : ''}<th>Condición</th><th>A caja</th><th>Act. costo</th></tr></thead><tbody>
      ${list.map(p => html`<tr class="${isVoidPurchase(p) ? 'void' : ''}" data-pur="${p.id}" tabindex="0" role="button" aria-label="Ver compra ${docText(p)}">
        <td>${fmtDate(purchaseDate(p))}</td><td>${p.time || fmtTime(p.created_at)}</td><td>${docText(p)}${isVoidPurchase(p) ? html` <span class="badge err">Anulada</span>` : ''}</td>
        <td style="white-space:normal">${supName(p)}${multi ? html` <span class="branch-tag">${branchName(p.branch_id)}</span>` : ''}</td>
        <td class="r money">${fmtMoney(signed(p))}</td>${mgr ? html`<td class="r money">${bal.get(p.id) ? fmtMoney(fromCents(bal.get(p.id))) : '—'}</td>` : ''}
        <td>${paymentLabel(p.payment)}</td><td>${p.to_cash ? 'Sí' : 'No'}</td><td>${p.update_costs === 0 ? 'No' : 'Sí'}</td></tr>`)}
      </tbody></table></div>
      <ul class="list cp-cards">${list.map(p => html`<li><button type="button" class="row" data-pur="${p.id}">
        <span class="grow"><span class="title">${supName(p)}</span>
        <span class="sub" style="display:block">${fmtDate(purchaseDate(p))} ${p.time || fmtTime(p.created_at)} · ${docText(p)} · ${paymentLabel(p.payment)}${p.to_cash ? ' · a caja' : ''}${multi ? html` · <span class="branch-tag">${branchName(p.branch_id)}</span>` : ''}</span></span>
        <b class="money">${fmtMoney(signed(p))}</b>${isVoidPurchase(p) ? html` <span class="badge err">Anulada</span>` : toPay(p, bal) ? html` <span class="badge warn">A pagar</span>` : ''}</button></li>`)}</ul>`
      : html`<p class="empty">${filtering ? 'No hay compras con esos filtros.' : 'Todavía no cargaste compras. Al cargarlas se suma el stock y se actualiza el costo.'}</p>`}</div>`;
}

/** Alta / edición de proveedor (formulario completo en proveedores.js) */
export const supplierForm = fullSupplierForm;

// ---------- Carga de comprobante ----------

const numOr0 = v => { const s = String(v ?? '').trim(); if (!s) return 0; const n = parseNum(s); return Number.isFinite(n) ? n : NaN; };
const ivaKey = r => String(r).replace('.', '');

/**
 * Pantalla de carga de compra. pre: lo leído con IA (ver photoPurchase), ya con cada renglón buscado: el formulario abre
 * PRELLENADO para revisar; nunca se guarda solo.
 */
async function purchaseForm(pre = null) {
  const st = settings();
  // {product_id, name, barcode, qty, unit_cost, disc1, disc2, iva_rate} (textos tal cual se tipean)
  // + con IA: src {codigo, ean, descripcion}, light, how, cands, noProduct, priceApply, newPrice, priceTouched
  const items = pre ? pre.items : [];
  const suppliers = db.all('suppliers').filter(s => s.active !== 0).sort((a, b) => String(a.name || '').localeCompare(String(b.name || ''), 'es'));
  const now = Date.now();
  let letterTouched = !!pre;
  let getInput = null; // lee el formulario (lo arma onMount)
  let assignTo = null; // renglón leído con IA al que se le está eligiendo el producto (con el buscador)
  const session = openSession();
  const mgr = isMgr();
  // Precio de venta renglón por renglón: quien cambia precios y ve costos
  const canPrice = mgr && can(ctx.user, 'editar_productos') && can(ctx.user, 'ver_costos');
  const pays = mgr ? PURCHASE_PAYMENTS : PURCHASE_PAYMENTS.filter(([k]) => k !== 'cheque');
  const hideLimited = mgr ? '' : ' hidden';
  // Renglón leído con IA: semáforo, lo que se leyó, cómo elegir el producto y (con permiso) costo y precio viejo → nuevo
  const iaLine = (it, i) => html`<div class="cp-ia">
    ${it.src ? html`<div class="cp-ia-read"><span class="ia-light ia-${it.light}" role="img" aria-label="${LIGHT_TXT[it.light]}"></span>
      <span class="small"><b>${LIGHT_TXT[it.light]}</b>${it.product_id && it.how ? ` (${HOW_TXT[it.how] || ''})` : ''} · Leído: “${it.src.descripcion}”${it.src.codigo ? ` · cód. ${it.src.codigo}` : ''}${it.src.ean ? ` · EAN ${it.src.ean}` : ''}${it.src.revisar && it.src.revisar.length ? ' · revisá cantidad e importe' : ''}</span></div>
      ${!it.product_id && !it.noProduct ? html`<div class="btn-row cp-ia-acts">${(it.cands || []).slice(0, 3).map(c => html`<button type="button" class="chip" data-cand="${i}" data-pid="${c.id}" title="Parecido ${Math.round(c.score * 100)} %">${c.name}</button>`)}
        <button type="button" class="btn ghost sm" data-assign="${i}">${ic('search')} Buscar</button>
        <button type="button" class="btn ghost sm" data-newfor="${i}">${ic('plus')} Crear producto nuevo</button>
        <button type="button" class="btn ghost sm" data-noprod="${i}">Sin producto</button></div>`
      : html`<div class="btn-row cp-ia-acts"><button type="button" class="btn ghost sm" data-assign="${i}">Cambiar producto</button></div>`}` : ''}
    ${canPrice && it.product_id ? html`<div class="cp-ia-price hidden" data-pi="${i}"><span class="small" data-pcost="${i}"></span>
      <label class="check small"><input type="checkbox" data-papply="${i}" ${it.priceApply ? 'checked' : ''}> Precio <span data-pold="${i}"></span> →</label>
      <input data-pnew="${i}" class="money-input" inputmode="decimal" autocomplete="off" aria-label="Precio de venta nuevo de ${it.name}" value="${it.newPrice ?? ''}">
      <span class="badge warn hidden" data-pwarn="${i}"></span></div>` : ''}
  </div>`;
  return modal({
    title: (pre ? 'Revisar compra leída con IA' : 'Cargar compra') + (multiBranch() ? ` · ${(currentBranch() || {}).name || ''}` : ''),
    size: 'wide',
    body: html`<form id="cp" novalidate class="cp-form">
      ${pre ? iaNotice(pre) : ''}
      ${multiBranch() ? html`<div class="notice notice-info"><p>El stock se suma en <b>${(currentBranch() || {}).name || ''}</b> (la sucursal de este equipo).</p></div>` : ''}
      <div class="cp-head">
        <div class="field cp-sup"><label for="cp-s">Proveedor</label><select id="cp-s"><option value="">— Sin proveedor —</option>${suppliers.map(s => html`<option value="${s.id}">${s.name}</option>`)}</select>
          <div class="hint" id="cp-sinfo" aria-live="polite"></div></div>
        <div class="field"><label for="cp-type">Tipo</label><select id="cp-type">${DOC_TYPES.map(([k, l]) => html`<option value="${k}">${k} · ${l}</option>`)}</select></div>
        <div class="field"><label for="cp-letter">Letra</label><select id="cp-letter">${LETTERS.map(l => html`<option value="${l}" ${l === 'X' ? 'selected' : ''}>${l}</option>`)}</select></div>
        <div class="field"><label for="cp-r">N° de comprobante</label><input id="cp-r" placeholder="00005-00042169" autocomplete="off"></div>
        <div class="field"><label for="cp-date">Fecha</label><input id="cp-date" type="date" value="${toISODate(now)}"></div>
        <div class="field"><label for="cp-time">Hora</label><input id="cp-time" type="time" value="${fmtTime(now)}"></div>
      </div>
      <fieldset class="seg"><legend>Condición</legend>
        ${pays.map(([k], i) => html`<label><input type="radio" name="cp-pay" value="${k}" ${i === 0 ? 'checked' : ''}><span>${paymentLabel(k)}</span></label>`)}</fieldset>
      <div class="grid2 hidden" id="cp-cc">
        <div class="field${hideLimited}"><label for="cp-paid">Pagado al comprar <span class="muted">(opcional)</span></label><input id="cp-paid" class="money-input" inputmode="decimal" placeholder="0,00" autocomplete="off"></div>
        <div class="field"><label for="cp-due">Vencimiento</label><input id="cp-due" type="date"></div>
        <p class="small muted" id="cp-sbal" style="grid-column:1/-1"></p></div>
      <div class="hidden" id="cp-chq"><p class="small"><b>Cheques de la cartera que le entregás</b> (tienen que sumar lo que hay que pagar)</p>${walletPickerHTML('cpc')}</div>
      <div class="cp-opts">
        <fieldset class="seg${hideLimited}" id="cp-cashrow"><legend>A Caja</legend>
          <label><input type="radio" name="cp-cash" value="1"><span>Sí</span></label><label><input type="radio" name="cp-cash" value="0" checked><span>No</span></label></fieldset>
        <fieldset class="seg${hideLimited}" id="cp-updrow"><legend>Actualiza costos</legend>
          <label><input type="radio" name="cp-upd" value="1" checked><span>Sí</span></label><label><input type="radio" name="cp-upd" value="0"><span>No</span></label></fieldset>
        <div class="field${hideLimited}" id="cp-pmrow"><label for="cp-pm">Precio de venta</label><select id="cp-pm"><option value="no">No cambiar</option><option value="keep">Recalcular manteniendo el margen</option><option value="pct">Recalcular con margen %</option>${canPrice ? html`<option value="lines">Revisar uno por uno (margen de cada producto)</option>` : ''}</select>
          <input id="cp-pct" class="hidden" inputmode="decimal" placeholder="Margen %, ej: 35" aria-label="Margen en por ciento" style="margin-top:.4rem"></div>
      </div>
      ${mgr ? '' : html`<p class="small muted" id="cp-costinfo">La compra suma el stock y actualiza el costo de los productos. El precio de venta no cambia (lo cambia el dueño o el encargado).</p>`}
      <p class="small muted" id="cp-cashinfo" aria-live="polite"></p>
      <div class="field searchbox${canScan() ? ' has-scan' : ''}">${ic('search')}<label class="sr-only" for="cp-q">Buscar producto para agregar</label>
        <input id="cp-q" type="search" placeholder="Código (lector), nombre o escanear" autocomplete="off">
        ${scanButton('data-scan id="cp-scan"', 'Agregar con la cámara')}</div>
      <p id="cp-assign" class="notice notice-info hidden" aria-live="polite"></p>
      <div id="cp-res" class="results hidden"></div>
      <div id="cp-items" style="margin-top:1rem"></div>
      <div id="cp-tot" class="cp-tot"></div>
      <div class="field"><label for="cp-notes">Observaciones</label><input id="cp-notes" autocomplete="off"></div>
    </form>`,
    onMount(m) {
      const q = $('#cp-q', m);
      const val = id => ($(id, m) || { value: '' }).value;
      const letter = () => val('#cp-letter');
      const pay = () => m.querySelector('[name=cp-pay]:checked').value;
      const ivaOv = () => {
        const o = {};
        for (const r of PURCHASE_RATES) { const v = val('#cp-iva-' + ivaKey(r)).trim(); if (v !== '') o[r] = numOr0(v); }
        return o;
      };
      const input = () => ({
        items: items.map(it => ({ qty: numOr0(it.qty), unit_cost: numOr0(it.unit_cost), disc1: numOr0(it.disc1), disc2: numOr0(it.disc2), iva_rate: it.iva_rate })),
        discounts: [val('#cp-g1'), val('#cp-g2'), val('#cp-g3')].map(numOr0), letter: letter(), iva_override: ivaOv(),
        non_taxed: numOr0(val('#cp-ng')), perc_iva: numOr0(val('#cp-piva')), ret_iva: numOr0(val('#cp-riva')), ret_gan: numOr0(val('#cp-rgan')),
        ret_iibb: numOr0(val('#cp-riibb')), perc_iibb: numOr0(val('#cp-piibb')), other_taxes: numOr0(val('#cp-oth')),
        invoice_total: val('#cp-inv').trim() === '' ? null : numOr0(val('#cp-inv')),
      });
      getInput = input;
      const safe = x => (Number.isFinite(x) ? x : 0);
      const calcNow = () => {
        const i = input();
        i.items = i.items.map(x => ({ ...x, qty: safe(x.qty), unit_cost: safe(x.unit_cost), disc1: safe(x.disc1), disc2: safe(x.disc2) }));
        for (const k of ['non_taxed', 'perc_iva', 'ret_iva', 'ret_gan', 'ret_iibb', 'perc_iibb', 'other_taxes']) i[k] = safe(i[k]);
        i.discounts = i.discounts.map(safe);
        if (i.invoice_total !== null && !Number.isFinite(i.invoice_total)) i.invoice_total = null;
        return computePurchase(i);
      };
      const paintTotals = () => {
        const c = calcNow();
        const A = c.discriminates;
        const set = (sel, v) => { const el = $(sel, m); if (el) el.textContent = v; };
        set('#cp-neto', fmtMoney(c.neto));
        let k = 0;
        [1, 2, 3].forEach(i => { const pct = numOr0(val('#cp-g' + i)); const el = $('#cp-g' + i + 'a', m); if (!el) return; if (pct) { el.textContent = '− ' + fmtMoney((c.discounts[k] || {}).amount || 0); k++; } else el.textContent = ''; });
        set('#cp-sub', fmtMoney(c.subtotal));
        for (const r of PURCHASE_RATES) {
          const row = $('#cp-ivr-' + ivaKey(r), m);
          if (!row) continue;
          const l = c.iva_lines.find(x => x.rate === r);
          const inp = $('#cp-iva-' + ivaKey(r), m);
          inp.placeholder = fmtNum2(l ? l.amount : 0); // calculado (con el ajuste de redondeo, si hubo)
          set('#cp-ivb-' + ivaKey(r), l && l.base ? `base ${fmtMoney(l.base)}` : '');
          row.classList.toggle('hidden', !A || (!l && r !== 21 && r !== 10.5 && r !== 27 && inp.value.trim() === ''));
        }
        set('#cp-grav', fmtMoney(c.gravado));
        set('#cp-ivat', fmtMoney(c.iva));
        $('#cp-ivabox', m).classList.toggle('hidden', !A);
        $('#cp-noiva', m).classList.toggle('hidden', A);
        set('#cp-total', fmtMoney(c.total));
        set('#cp-topay', c.ret ? `A pagar (menos retenciones): ${fmtMoney(c.to_pay)}` : '');
        const d = $('#cp-diff', m);
        if (c.invoice_total === null) { d.className = 'cp-diff muted'; d.textContent = 'Tipeá el TOTAL FACTURA para controlar que cuadre.'; }
        else if (c.adjusted) { d.className = 'cp-diff ok'; d.textContent = `Cuadra con la factura (se ajustan ${fmtMoney(c.adjusted)} de redondeo${A ? ' en el IVA' : ''}).`; }
        else if (c.ok) { d.className = 'cp-diff ok'; d.textContent = 'Cuadra con la factura.'; }
        else { d.className = 'cp-diff err'; d.textContent = `No cuadra: la factura dice ${fmtMoney(c.invoice_total)} y el cálculo da ${fmtMoney(c.total)} (diferencia ${fmtMoney(c.diff)}). Revisá IVA, percepciones o descuentos.`; }
        items.forEach((it, i) => set(`[data-sub="${i}"]`, fmtMoney(c.lines[i] ? c.lines[i].cents : 0)));
        // Precio de venta renglón por renglón: costo nuevo × (1 + margen), con el redondeo de Ajustes → Precios
        const pmode = canPrice && val('#cp-pm') === 'lines' && m.querySelector('[name=cp-upd]:checked').value === '1' && val('#cp-type') === 'FC';
        items.forEach((it, i) => {
          const row = m.querySelector(`[data-pi="${i}"]`);
          if (!row) return;
          row.classList.toggle('hidden', !pmode);
          const p = pmode && db.get('products', it.product_id);
          const ln = c.lines[i];
          if (!p || !ln) return;
          const cost = costForProduct({ netUnit: fromCents(toCents(ln.net_unit)), ivaRate: p.iva_rate ?? it.iva_rate, letter: letter(), businessIva: st.iva_condition });
          const ch = changePct(p.cost, cost);
          set(`[data-pcost="${i}"]`, `Costo ${fmtMoney(p.cost || 0)} → ${fmtMoney(cost)}${ch !== null ? ` (${ch > 0 ? '+' : ''}${fmtNum2(ch)} %)` : ''}`);
          set(`[data-pold="${i}"]`, fmtMoney(p.price || 0));
          const sug = cost > 0 ? suggestPrice({ product: p, newCost: cost, settings: st, businessIva: st.iva_condition }) : null;
          const inp = row.querySelector('[data-pnew]'), chk = row.querySelector('[data-papply]'), warn = row.querySelector('[data-pwarn]');
          if (!it.priceTouched) { it.newPrice = fmtNum2(sug ? sug.price : p.price || 0); if (inp !== document.activeElement) inp.value = it.newPrice; }
          const big = ch !== null && ch > BIG_RISE_PCT;
          if (it.priceApply === undefined || it.autoApply) { it.autoApply = true; it.priceApply = !!sug && !big && round2(sug.price) !== round2(p.price || 0); chk.checked = it.priceApply; }
          warn.classList.toggle('hidden', !big);
          warn.textContent = big ? `El costo sube ${fmtNum2(ch)} %: revisalo antes de aplicar` : '';
        });
        payPaint(c);
      };
      const moneyIn = (id, label, extra = '') => html`<div class="cp-trow ${extra}"><label for="${id}">${label}</label><input id="${id}" class="money-input" inputmode="decimal" autocomplete="off" placeholder="0,00"></div>`;
      $('#cp-tot', m).innerHTML = String(html`
        <div class="cp-trow cp-inv"><label for="cp-inv"><b>TOTAL FACTURA</b></label><input id="cp-inv" class="money-input" inputmode="decimal" autocomplete="off" placeholder="El total que dice el papel"></div>
        <p id="cp-diff" class="cp-diff muted" aria-live="polite"></p>
        <div class="cp-trow"><span>Neto (renglones)</span><b id="cp-neto" class="money"></b></div>
        ${[1, 2, 3].map(i => html`<div class="cp-trow"><label for="cp-g${i}">Dto${i} % general</label><span class="cp-pair"><input id="cp-g${i}" inputmode="decimal" autocomplete="off" placeholder="0" class="pct-input"><span id="cp-g${i}a" class="money muted"></span></span></div>`)}
        <div class="cp-trow"><span>Subtotal</span><b id="cp-sub" class="money"></b></div>
        <div id="cp-ivabox">
          <div class="cp-trow"><span>Total gravado</span><b id="cp-grav" class="money"></b></div>
          ${PURCHASE_RATES.map(r => html`<div class="cp-trow" id="cp-ivr-${ivaKey(r)}"><label for="cp-iva-${ivaKey(r)}">IVA ${String(r).replace('.', ',')} % <small class="muted" id="cp-ivb-${ivaKey(r)}"></small></label><input id="cp-iva-${ivaKey(r)}" class="money-input" inputmode="decimal" autocomplete="off"></div>`)}
          <p class="small muted">El IVA se calcula solo; si la factura dice otro importe, escribilo encima.</p>
          <div class="cp-trow"><span>Total IVA</span><b id="cp-ivat" class="money"></b></div>
        </div>
        <p id="cp-noiva" class="small muted hidden">Factura B, C o X: el IVA está incluido en los importes (no se discrimina).</p>
        ${moneyIn('cp-ng', 'Conceptos no gravados')}
        ${moneyIn('cp-piva', 'Percepción IVA')}
        ${moneyIn('cp-piibb', 'Percepción IIBB')}
        ${moneyIn('cp-oth', 'Otros impuestos')}
        <details class="cp-rets"><summary>Retenciones (IVA, Ganancias, IIBB)</summary>
          ${moneyIn('cp-riva', 'Retención IVA')}${moneyIn('cp-rgan', 'Retención Ganancias')}${moneyIn('cp-riibb', 'Retención IIBB')}
          <p class="small muted">Las retenciones las hace el comercio al pagar: bajan lo que se le paga al proveedor.</p></details>
        <div class="cp-trow cp-total"><span>TOTAL calculado</span><b id="cp-total" class="money"></b></div>
        <p class="small" id="cp-topay"></p>`);
      const paintRes = () => {
        const box = $('#cp-res', m);
        const list = q.value.trim() ? searchProducts(db.all('products'), q.value, 15) : [];
        box.classList.toggle('hidden', !q.value.trim());
        box.innerHTML = String(html`${list.map(p => html`<button type="button" class="result" data-pick="${p.id}"><span class="grow"><span class="title">${p.name}</span>
          <span class="sub small muted" style="display:block">${p.barcode ? p.barcode + ' · ' : ''}${mgr ? `Costo actual ${fmtMoney(p.cost)} · ` : ''}Stock ${fmtQty(stockOf(p))}</span></span></button>`)}
          <button type="button" class="result" data-newp><span class="grow">${ic('plus')} ${newLabel(q.value.trim())}</span></button>`);
      };
      const paintItems = () => {
        const A = letter() === 'A';
        $('#cp-items', m).innerHTML = items.length ? String(html`<div class="cp-lines" role="table" aria-label="Artículos de la compra">
          <div class="cp-line cp-lhead" role="row"><span>Código y descripción</span><span class="r">Cantidad</span><span class="r">Importe unit.</span><span class="r">Dto1 %</span><span class="r">Dto2 %</span>${A ? html`<span class="r">IVA</span>` : html`<span></span>`}<span class="r">Total</span><span></span></div>
          ${items.map((it, i) => html`<div class="cp-line" role="row">
            <span class="cp-name">${it.product_id ? it.name : it.noProduct ? html`${it.name} <span class="badge">sin producto</span>` : html`<span class="ia-pick">Elegí el producto ↓</span>`}<small class="cp-code muted">${it.product_id ? it.barcode || 'sin código' : ''}</small></span>
            <label class="cp-f"><span class="cp-lbl">Cantidad</span><input id="cq-${i}" data-q="${i}" inputmode="decimal" value="${it.qty}" aria-label="Cantidad de ${it.name}"></label>
            <label class="cp-f"><span class="cp-lbl">Importe unit.</span><input id="cc-${i}" data-c="${i}" inputmode="decimal" value="${it.unit_cost}" aria-label="Importe unitario de ${it.name}"></label>
            <label class="cp-f"><span class="cp-lbl">Dto1 %</span><input data-d1="${i}" inputmode="decimal" value="${it.disc1}" placeholder="0" aria-label="Descuento 1 de ${it.name}"></label>
            <label class="cp-f"><span class="cp-lbl">Dto2 %</span><input data-d2="${i}" inputmode="decimal" value="${it.disc2}" placeholder="0" aria-label="Descuento 2 de ${it.name}"></label>
            ${A ? html`<label class="cp-f"><span class="cp-lbl">IVA</span><select data-rt="${i}" aria-label="IVA de ${it.name}">${[0, ...PURCHASE_RATES].map(r => html`<option value="${r}" ${Number(it.iva_rate) === r ? 'selected' : ''}>${String(r).replace('.', ',')}%</option>`)}</select></label>` : html`<span></span>`}
            <b class="money r cp-lt" data-sub="${i}"></b>
            <button type="button" class="icon-btn" data-rm="${i}" aria-label="Quitar ${it.name || 'renglón'}">${ic('trash')}</button>
            ${it.src || (canPrice && val('#cp-pm') === 'lines') ? iaLine(it, i) : ''}</div>`)}
          </div>`)
          : String(html`<p class="muted">Pasá el lector por el código o buscá los productos que llegaron. Después cargá cantidad, importe y descuentos.</p>`);
        paintTotals();
      };
      // Producto que no existe: se crea ahí mismo (con el código leído o el nombre escrito y el proveedor de la compra)
      const isCode = t => /^\d{4,}$/.test(t);
      const newLabel = t => !t ? 'Crear producto nuevo' : isCode(t) ? `Crear producto nuevo con el código ${t}` : `Crear producto nuevo “${t}”`;
      const createNew = async text => {
        const t = String(text || '').trim();
        const init = isCode(t) ? { barcode: t } : { name: t };
        if (val('#cp-s')) init.supplier_id = val('#cp-s');
        const p = await productForm(init);
        if (p && p.id && !p.deleted) add(p);
        else q.focus();
      };
      const paintAssign = () => {
        const el = $('#cp-assign', m);
        const it = assignTo !== null ? items[assignTo] : null;
        el.classList.toggle('hidden', !it);
        el.innerHTML = it ? String(html`Elegí el producto para el renglón leído <b>“${it.src ? it.src.descripcion : it.name}”</b>: buscalo acá abajo o escaneá el código. <button type="button" class="btn ghost sm" data-assign-cancel>Cancelar</button>`) : '';
      };
      const add = p => {
        if (!p) return;
        if (assignTo !== null && items[assignTo]) {
          const it = items[assignTo];
          Object.assign(it, { product_id: p.id, name: p.name, barcode: p.barcode || '', light: 'verde', how: 'manual', noProduct: false, priceApply: undefined, autoApply: false, priceTouched: false });
          if (!it.iva_rate && it.iva_rate !== 0) it.iva_rate = Number(p.iva_rate ?? 21);
          assignTo = null;
          q.value = ''; paintAssign(); paintRes(); paintItems();
          return;
        }
        const ex = items.find(i => i.product_id === p.id);
        if (ex) ex.qty = fmtQty(round3((parseNum(ex.qty) || 0) + 1));
        // Cajero y vendedor no ven costos: el importe lo copian de la factura
        else items.push({ product_id: p.id, name: p.name, barcode: p.barcode || '', qty: '1', unit_cost: mgr && p.cost ? fmtNum2(p.cost) : '', disc1: '', disc2: '', iva_rate: Number(p.iva_rate ?? 21) });
        q.value = ''; paintRes(); paintItems();
        const last = m.querySelector(`[data-c="${items.indexOf(ex || items[items.length - 1])}"]`);
        if (last) last.focus();
      };
      q.addEventListener('input', paintRes);
      q.addEventListener('keydown', async e => {
        if (e.key !== 'Enter') return;
        e.preventDefault();
        const code = q.value.trim();
        const byCode = code && productByCode(code);
        if (byCode) { add(byCode); return; }
        const list = searchProducts(db.all('products'), q.value, 2);
        if (list.length === 1 || (list[0] && list[0].barcode === code)) { add(list[0]); return; }
        if (code && !list.length) {
          if (isCode(code)) playError();
          const r = await modal({
            title: 'El producto no existe',
            body: html`<p class="lead">No hay ningún producto ${isCode(code) ? html`con el código <b>${code}</b>` : html`que coincida con <b>${code}</b>`}.</p><p class="muted">Podés crearlo ahora y se agrega a esta compra.</p>`,
            actions: [{ label: 'Cancelar', value: 'no' }, { label: 'Crear producto nuevo', kind: 'primary', value: 'create' }],
          });
          if (r === 'create') await createNew(code); else q.focus();
        }
      });
      // Cámara: cada código leído se suma a la compra; con "varios seguidos" la cámara sigue abierta
      const scan = async () => {
        for (;;) {
          let missing = null, multi = false;
          await openScanner({
            title: 'Agregar productos a la compra',
            multi: { label: 'Escanear varios seguidos', key: 'jg-scan-multi-compras' },
            onCode: async (code, sc) => {
              multi = sc.multi;
              const p = productByCode(code);
              if (!p) { playError(); missing = code; return 'close'; }
              add(p);
              if (!multi) return 'close';
              const it = items.find(i => i.product_id === p.id);
              sc.flash(`Agregado: ${p.name.slice(0, 40)} · cantidad ${it ? it.qty : 1}`);
              return 'continue';
            },
          });
          if (!missing || !m.isConnected) return;
          const r = await modal({
            title: 'Código no encontrado',
            body: html`<p class="lead">No encontramos el código <b>${missing}</b>.</p>`,
            actions: [{ label: 'Cerrar', value: 'close' }, { label: 'Escanear otro', value: 'again' }, { label: 'Crear producto con este código', kind: 'primary', value: 'create' }],
          });
          if (r === 'again') continue;
          if (r !== 'create') return;
          await createNew(missing);
          if (!multi) return;
        }
      };
      m.addEventListener('click', async e => {
        if (e.target.closest('[data-scan]')) { scan(); return; }
        const pk = e.target.closest('[data-pick]');
        if (pk) add(db.get('products', pk.dataset.pick));
        if (e.target.closest('[data-newp]')) await createNew(q.value);
        const rm = e.target.closest('[data-rm]');
        if (rm) { items.splice(Number(rm.dataset.rm), 1); assignTo = null; paintAssign(); paintItems(); }
        // Renglones leídos con IA
        const cand = e.target.closest('[data-cand]');
        if (cand) { assignTo = Number(cand.dataset.cand); add(db.get('products', cand.dataset.pid)); return; }
        const as = e.target.closest('[data-assign]');
        if (as) {
          assignTo = Number(as.dataset.assign);
          const it = items[assignTo];
          paintAssign();
          q.value = it && it.src ? tokensHint(it.src.descripcion) : '';
          paintRes(); q.focus();
          return;
        }
        if (e.target.closest('[data-assign-cancel]')) { assignTo = null; paintAssign(); q.value = ''; paintRes(); return; }
        const nf = e.target.closest('[data-newfor]');
        if (nf) {
          assignTo = Number(nf.dataset.newfor);
          const it = items[assignTo];
          paintAssign();
          const init = { name: niceName(it.src ? it.src.descripcion : ''), barcode: (it.src && it.src.ean) || '' };
          if (val('#cp-s')) init.supplier_id = val('#cp-s');
          const p = await productForm(init);
          if (p && p.id && !p.deleted) add(p); else { assignTo = null; paintAssign(); }
          return;
        }
        const np = e.target.closest('[data-noprod]');
        if (np) { const it = items[Number(np.dataset.noprod)]; it.noProduct = true; it.name = niceName(it.src ? it.src.descripcion : it.name); paintItems(); return; }
        if (e.target.closest('[data-sup-create]')) { await createReadSupplier(); }
      });
      m.addEventListener('input', e => {
        const a = e.target.dataset;
        if (a.pnew !== undefined) {
          const it = items[Number(a.pnew)];
          it.newPrice = e.target.value; it.priceTouched = true; it.priceApply = true; it.autoApply = false;
          const chk = m.querySelector(`[data-papply="${a.pnew}"]`);
          if (chk) chk.checked = true;
          return;
        }
        const i = Number(a.q ?? a.c ?? a.d1 ?? a.d2);
        if (a.q !== undefined) items[i].qty = e.target.value;
        else if (a.c !== undefined) items[i].unit_cost = e.target.value;
        else if (a.d1 !== undefined) items[i].disc1 = e.target.value;
        else if (a.d2 !== undefined) items[i].disc2 = e.target.value;
        if (e.target.closest('#cp-tot') || a.q !== undefined || a.c !== undefined || a.d1 !== undefined || a.d2 !== undefined || e.target.id === 'cp-paid') paintTotals();
      });
      $('#cp', m).addEventListener('submit', e => e.preventDefault());
      // Condición: a cuenta corriente lo que no se paga al comprar suma a la cuenta del proveedor
      const payPaint = (c = calcNow()) => {
        const p = pay();
        const cc = p === 'cuenta_corriente';
        $('#cp-cc', m).classList.toggle('hidden', !cc);
        $('#cp-chq', m).classList.toggle('hidden', p !== 'cheque');
        $('#cp-cashrow', m).classList.toggle('hidden', !mgr || cc || p === 'transferencia');
        const sup = db.get('suppliers', val('#cp-s'));
        const nc = val('#cp-type') === 'NC';
        // El saldo del proveedor lo ven solo dueño y encargado
        const ccText = nc ? 'La nota de crédito resta de su cuenta corriente.' : 'Lo que no pagues ahora suma a su cuenta corriente.';
        $('#cp-sbal', m).textContent = cc ? (sup ? (mgr ? `${sup.name}: ${balanceText(sup.balance)}. ${ccText}` : `${ccText} El pago al proveedor lo hace el dueño o el encargado.`) : 'Elegí el proveedor: la compra suma a su cuenta corriente.') : '';
        const toCash = mgr ? m.querySelector('[name=cp-cash]:checked').value === '1' && !cc && p !== 'transferencia'
          : p === 'contado' || (p === 'mercadopago' && !!session);
        const who = mgr ? 'la caja abierta' : 'tu caja';
        $('#cp-cashinfo', m).textContent = toCash ? (session ? `${nc ? 'Entra a' : 'Sale de'} ${who}: ${fmtMoney(c.to_pay)}${p === 'contado' ? ' en efectivo (cambia el arqueo)' : p === 'mercadopago' ? ' por Mercado Pago (no cambia el efectivo)' : ' en cheques'}.` : (mgr ? 'La caja está cerrada: abrila para que la compra salga de la caja.' : 'Tu caja está cerrada: abrila para pagar de contado (la plata sale de ahí).'))
          : !mgr && p === 'transferencia' ? 'Transferencia: no sale plata de la caja.' : !mgr && p === 'mercadopago' ? 'La caja está cerrada: el pago por Mercado Pago no queda en la caja.' : '';
        if (p === 'cheque') {
          const pc = pickedCheques(m, 'cpc');
          const note = $('#cp-chq p', m);
          if (note) note.innerHTML = String(html`<b>Cheques de la cartera que le entregás</b> · elegidos ${fmtMoney(fromCents(pc.cents))} de ${fmtMoney(c.to_pay)}`);
        }
      };
      const supInfo = () => {
        const sup = db.get('suppliers', val('#cp-s'));
        $('#cp-sinfo', m).textContent = sup ? [IVA_LABEL[sup.iva_condition] || 'Sin condición de IVA', sup.cuit ? 'CUIT ' + sup.cuit : 'sin CUIT'].join(' · ') : '';
        if (!letterTouched) {
          $('#cp-letter', m).value = sup ? defaultLetter(st.iva_condition, sup.iva_condition) : 'X';
          paintItems();
        }
      };
      m.addEventListener('change', e => {
        if (e.target.id === 'cp-letter') { letterTouched = true; paintItems(); return; }
        if (e.target.id === 'cp-s') { supInfo(); payPaint(); return; }
        if (e.target.matches('[data-rt]')) { items[Number(e.target.dataset.rt)].iva_rate = Number(e.target.value); paintTotals(); return; }
        if (e.target.matches('[data-papply]')) { const it = items[Number(e.target.dataset.papply)]; it.priceApply = e.target.checked; it.autoApply = false; return; }
        if (e.target.id === 'cp-pm') { $('#cp-pct', m).classList.toggle('hidden', e.target.value !== 'pct'); paintItems(); return; }
        if (e.target.matches('[name=cp-upd]')) { $('#cp-pmrow', m).classList.toggle('hidden', e.target.value !== '1'); paintItems(); return; }
        if (e.target.id === 'cp-type') paintTotals();
        if (e.target.matches('[name=cp-pay], [name=cp-cash], #cp-type, [data-cpc]')) payPaint();
      });
      // Proveedor leído que no está cargado: crearlo con los datos del comprobante (dueño o encargado)
      const createReadSupplier = async () => {
        const pv = pre && pre.reading.proveedor;
        if (!pv) return;
        try {
          const { saveSupplier } = await import('../cuentas-ops.js');
          const name = niceName(pv.razon_social || 'Proveedor ' + (pv.cuit || ''));
          const s = await saveSupplier({ name, legal_name: pv.razon_social || '', cuit: pv.cuit_valido ? pv.cuit : '', iva_condition: pv.iva || null });
          const sel = $('#cp-s', m);
          sel.insertAdjacentHTML('beforeend', String(html`<option value="${s.id}">${s.name}</option>`));
          sel.value = s.id;
          pre.supplier_id = s.id;
          const box = $('#cp-ia-sup', m);
          if (box) box.innerHTML = String(html`${ic('check')} Proveedor creado: <b>${s.name}</b>${s.cuit ? ` · CUIT ${s.cuit}` : ''}.`);
          supInfo(); payPaint();
          toast('Proveedor creado con los datos del comprobante.', 'ok');
        } catch (er) { toast(er.message, 'error', 6000); }
      };
      if (pre) {
        const setv = (id, v) => { const el = $(id, m); if (el && v !== null && v !== undefined && v !== '') el.value = v; };
        if (pre.supplier_id) setv('#cp-s', pre.supplier_id);
        setv('#cp-type', pre.doc_type);
        setv('#cp-letter', pre.letter);
        setv('#cp-r', pre.doc_number);
        setv('#cp-date', pre.doc_date);
        if (pre.total) setv('#cp-inv', fmtNum2(pre.total));
        if (pre.letter === 'A') for (const l of pre.ivas) if (PURCHASE_RATES.includes(l.alicuota) && l.importe) setv('#cp-iva-' + ivaKey(l.alicuota), fmtNum2(l.importe));
        const pc = pre.perc || {};
        if (pc.iva) setv('#cp-piva', fmtNum2(pc.iva));
        if (pc.iibb) setv('#cp-piibb', fmtNum2(pc.iibb));
        if (pc.otras) setv('#cp-oth', fmtNum2(pc.otras));
        if (canPrice) setv('#cp-pm', 'lines');
        m.addEventListener('click', e => { const dv = e.target.closest('[data-docview]'); if (dv) viewDoc(pre.docs[Number(dv.dataset.docview)], `Página ${Number(dv.dataset.docview) + 1}`); });
      }
      paintItems();
      supInfo();
      if (pre) payPaint();
    },
    actions: [{ label: 'Cancelar', value: null }, {
      label: 'Guardar compra', kind: 'primary', id: 'cp-save', onClick: async (close, w) => {
        const open = items.findIndex(it => !it.product_id && !it.noProduct);
        if (open >= 0) {
          const b = w.querySelector(`[data-assign="${open}"]`) || w.querySelector(`[data-q="${open}"]`);
          if (b) b.scrollIntoView({ block: 'center' });
          toast(`Falta elegir el producto del renglón ${open + 1} (“${items[open].src ? items[open].src.descripcion : ''}”): buscalo, crealo o marcá “Sin producto”.`, 'warn', 6000);
          return;
        }
        for (let i = 0; i < items.length; i++) {
          const qv = parseNum(items[i].qty), cv = String(items[i].unit_cost).trim() === '' ? 0 : parseNum(items[i].unit_cost);
          if (!isFinite(qv) || qv <= 0) return fieldError($(`[data-q="${i}"]`, w), 'Cantidad inválida.');
          if (!isFinite(cv) || cv < 0) return fieldError($(`[data-c="${i}"]`, w), 'Importe inválido.');
          for (const k of ['disc1', 'disc2']) {
            const d = numOr0(items[i][k]);
            if (!isFinite(d) || d < 0 || d >= 100) return fieldError($(`[data-${k === 'disc1' ? 'd1' : 'd2'}="${i}"]`, w), 'Descuento inválido (0 a 99,99).');
          }
        }
        const data = getInput();
        for (const [k, id] of [['non_taxed', 'cp-ng'], ['perc_iva', 'cp-piva'], ['ret_iva', 'cp-riva'], ['ret_gan', 'cp-rgan'], ['ret_iibb', 'cp-riibb'], ['perc_iibb', 'cp-piibb'], ['other_taxes', 'cp-oth']]) {
          if (!isFinite(data[k]) || data[k] < 0) return fieldError($('#' + id, w), 'Importe inválido.');
        }
        if (data.invoice_total !== null && !isFinite(data.invoice_total)) return fieldError($('#cp-inv', w), 'Importe inválido.');
        const payment = w.querySelector('[name=cp-pay]:checked').value;
        const paidTxt = $('#cp-paid', w).value.trim();
        const paid = paidTxt ? parseNum(paidTxt) : 0;
        if (payment === 'cuenta_corriente') {
          if (!$('#cp-s', w).value) return fieldError($('#cp-s', w), 'Para comprar a cuenta corriente elegí el proveedor.');
          if (!isFinite(paid) || paid < 0) return fieldError($('#cp-paid', w), 'Importe inválido.');
        }
        const pm = mgr ? $('#cp-pm', w).value : 'no';
        const pct = pm === 'pct' ? parseNum($('#cp-pct', w).value) : 0;
        if (pm === 'pct' && !(pct >= 0)) return fieldError($('#cp-pct', w), 'Escribí el margen en %.');
        const payload = {
          ...data, payment, paid: mgr ? paid : 0, due_date: $('#cp-due', w).value, supplier_id: $('#cp-s', w).value,
          doc_type: $('#cp-type', w).value, doc_number: $('#cp-r', w).value, doc_date: $('#cp-date', w).value, time: $('#cp-time', w).value,
          update_costs: mgr ? w.querySelector('[name=cp-upd]:checked').value === '1' : true, price_mode: pm, price_pct: pct,
          to_cash: mgr ? w.querySelector('[name=cp-cash]:checked').value === '1' : payment === 'contado' || (payment === 'mercadopago' && !!openSession()),
          cheque_ids: mgr && payment === 'cheque' ? pickedCheques(w, 'cpc').ids : [],
          notes: $('#cp-notes', w).value,
          items: items.map((it, i) => ({ product_id: it.product_id || null, name: it.name, barcode: it.barcode, qty: parseNum(it.qty), unit_cost: String(it.unit_cost).trim() === '' ? 0 : parseNum(it.unit_cost), disc1: numOr0(it.disc1), disc2: numOr0(it.disc2), iva_rate: data.items[i].iva_rate })),
        };
        if (pm === 'lines') {
          payload.price_updates = {};
          for (const it of items) {
            if (!it.product_id || !it.priceApply) continue;
            const v = parseNum(it.newPrice);
            if (!(v > 0)) return fieldError(w.querySelector(`[data-pnew="${items.indexOf(it)}"]`), 'Precio inválido.');
            payload.price_updates[it.product_id] = round2(v);
          }
        }
        if (pre) {
          payload.docs = pre.docs || [];
          payload.learn = items.filter(it => it.src && it.product_id).map(it => ({ codigo: it.src.codigo, ean: it.src.ean, descripcion: it.src.descripcion, product_id: it.product_id, unit_cost: parseNum(it.unit_cost) || 0 }));
          payload.ai = { engine: pre.engine, lights: ['verde', 'amarillo', 'rojo'].map(k => pre.lights[k] || 0).join('/') };
        }
        try {
          let r;
          try { r = await savePurchaseFull(payload); } catch (e) {
            if (e.code !== 'MISMATCH') throw e;
            const c = e.calc;
            const go = await confirm(`El TOTAL FACTURA (${fmtMoney(c.invoice_total)}) no coincide con el calculado (${fmtMoney(c.total)}): hay ${fmtMoney(Math.abs(c.diff))} de diferencia. Lo mejor es revisar el IVA, las percepciones y los descuentos. ¿Guardar igual con el total calculado?`, { title: 'No cuadra con la factura', ok: 'Guardar igual', cancel: 'Revisar' });
            if (!go) return;
            r = await savePurchaseFull({ ...payload, force: true });
          }
          const p = r.purchase;
          const extra = p.payment === 'cuenta_corriente' ? ` ${p.doc_type === 'NC' ? 'Resta' : 'Suma'} ${fmtMoney(Math.abs(purchaseDebt(p)))} ${p.doc_type === 'NC' ? 'de' : 'a'} la cuenta del proveedor.` : '';
          toast(`${p.doc_type === 'NC' ? 'Nota de crédito' : 'Compra'} guardada: ${fmtMoney(p.total)}. Stock actualizado.${extra}${r.priceChanges.length ? ` ${r.priceChanges.length} precios recalculados.` : ''}`, 'ok', 4000);
          close(p);
        } catch (e) { toast(e.message, 'error', 6000); }
      },
    }],
  });
}

// ---------- Cargar desde foto (IA) ----------

const LIGHT_TXT = { verde: 'Seguro', amarillo: 'Parecido: revisalo', rojo: 'No encontrado' };
const HOW_TXT = { ean: 'por código de barras', aprendido: 'como la última vez con este proveedor', nombre: 'por el nombre', manual: 'elegido a mano' };
/** "YERBA PLAYADITO 1KG" → "Yerba Playadito 1kg" */
const niceName = t => String(t || '').toLowerCase().replace(/(^|[\s(/-])(\p{L})/gu, (x, a, b) => a + b.toUpperCase()).replace(/\s+/g, ' ').trim().slice(0, 120);
/** Dos palabras de la descripción para arrancar la búsqueda */
const tokensHint = t => String(t || '').split(/\s+/).filter(w => w.replace(/\W/g, '').length > 2 && !/\d/.test(w)).slice(0, 2).join(' ').toLowerCase();

/** Aviso arriba del formulario prellenado: motor, semáforo, proveedor leído, controles de sumas e imágenes */
function iaNotice(pre) {
  const r = pre.reading, pv = r.proveedor || {}, L = pre.lights;
  const readSup = pv.razon_social || pv.cuit;
  return html`<div class="notice notice-info ia-notice" id="cp-ia-notice">
    <p><b>Leído con ${pre.engine === 'claude' ? 'Claude' : 'IA gratis'}: revisá todo antes de guardar.</b>
      <span class="ia-sum"><span class="ia-light ia-verde" aria-hidden="true"></span> ${L.verde} ${L.verde === 1 ? 'seguro' : 'seguros'}
      <span class="ia-light ia-amarillo" aria-hidden="true"></span> ${L.amarillo} para revisar <span class="ia-light ia-rojo" aria-hidden="true"></span> ${L.rojo} sin encontrar</span></p>
    ${!pre.supplier_id && readSup ? html`<p id="cp-ia-sup">Proveedor leído: <b>${pv.razon_social || 'sin nombre'}</b>${pv.cuit ? ` · CUIT ${pv.cuit}${pv.cuit_valido ? '' : ' (no es válido)'}` : ''}. No está cargado:
      ${can(ctx.user, 'compras') ? html`<button type="button" class="btn ghost sm" data-sup-create>${ic('plus')} Crear proveedor con estos datos</button>` : 'elegilo en la lista o pedile al dueño que lo cargue.'}</p>`
      : pre.supHow === 'nombre' ? html`<p id="cp-ia-sup">Proveedor elegido por el nombre (${pv.razon_social}): fijate que sea el correcto.</p>` : ''}
    ${r.controles && r.controles.length ? html`<ul class="small" id="cp-ia-ctl">${r.controles.map(t => html`<li>${t}</li>`)}</ul>` : ''}
    ${pre.docs && pre.docs.length ? html`<div class="ia-thumbs">${pre.docs.map((d, i) => html`<button type="button" class="ia-thumb" data-docview="${i}" aria-label="Ver la página ${i + 1}"><img src="${d}" alt=""></button>`)}</div>` : ''}
  </div>`;
}

/** Ver una imagen del comprobante en grande */
function viewDoc(src, title = 'Comprobante') {
  return modal({ title, size: 'wide', body: html`<div class="ia-docbig"><img src="${src}" alt="Imagen del comprobante"></div>`, actions: [{ label: 'Cerrar', kind: 'primary', value: true }] });
}

/** Lo que leyó la IA → datos para abrir el formulario de compra prellenado (proveedor y productos ya buscados) */
export function buildPrefill(res, docs = []) {
  const r = res.data;
  const ms = matchSupplier(r.proveedor, db.all('suppliers').filter(x => x.active !== 0));
  const supplier_id = ms ? ms.supplier.id : '';
  const index = buildIndex(db.all('products'));
  const learned = db.COLLECTIONS.includes('supplier_items') ? db.all('supplier_items') : [];
  const productOf = id => db.get('products', id);
  const lights = { verde: 0, amarillo: 0, rojo: 0 };
  const items = (r.renglones || []).map(l => {
    const mt = matchLine(l, { index, supplierId: supplier_id, learned, productOf });
    lights[mt.light]++;
    const p = mt.product;
    return {
      product_id: p ? p.id : null, name: p ? p.name : niceName(l.descripcion), barcode: p ? p.barcode || '' : '',
      qty: fmtQty(l.cantidad), unit_cost: l.precio_unitario === null ? '' : fmtNum2(l.precio_unitario),
      disc1: l.dto1 ? fmtNum2(l.dto1) : '', disc2: l.dto2 ? fmtNum2(l.dto2) : '',
      iva_rate: Number(l.iva ?? (p ? p.iva_rate : null) ?? 21),
      src: { codigo: l.codigo, ean: l.ean, descripcion: l.descripcion, revisar: l.revisar || [] },
      light: mt.light, how: mt.how, cands: mt.candidates.map(c => ({ id: c.product.id, name: c.product.name, score: c.score })),
    };
  });
  return {
    reading: r, engine: res.engine, supplier_id, supHow: ms ? ms.how : null, items, lights, docs,
    doc_type: r.tipo || 'FC', letter: r.letra || 'X', doc_number: r.doc_number || '', doc_date: r.fecha || '', total: r.total,
    ivas: r.iva_por_alicuota || [], perc: r.percepciones || {},
  };
}

/** Compras → "Cargar desde foto": fotos (cámara o archivos, hasta 4 páginas) → IA en la nube → formulario prellenado */
async function photoPurchase() {
  const ia = await import('../ia.js');
  const files = [];
  const st = await ia.aiStatus();
  const go = await modal({
    title: 'Cargar compra desde foto',
    body: html`<div id="pf-ia"><p class="lead">Sacale una foto a la factura o nota del proveedor: de frente, con buena luz y que se vea entera. Si tiene varias hojas, agregalas (hasta 4).</p>
      <p class="small muted" id="pf-ia-st">${ia.statusLabel(st)}</p>
      <div class="btn-row"><button type="button" class="btn primary big" data-ph="cam" id="pf-ia-cam">${ic('camera')} Sacar foto</button>
        <button type="button" class="btn ghost big" data-ph="file" id="pf-ia-file">${ic('upload')} Elegir fotos</button></div>
      <p id="pf-ia-list" class="lead" aria-live="polite"></p>
      <p class="small muted">La IA completa la compra para que la revises: no se guarda nada hasta que toques “Guardar compra”.</p></div>`,
    onMount(m) {
      const list = () => {
        $('#pf-ia-list', m).textContent = files.length ? `${files.length} ${files.length === 1 ? 'página lista' : 'páginas listas'}.` : '';
        const b = $('#pf-ia-go', m); if (b) b.disabled = !files.length;
      };
      m.addEventListener('click', async e => {
        const b = e.target.closest('[data-ph]');
        if (!b) return;
        if (files.length >= 4) { toast('Como mucho 4 páginas por comprobante.', 'warn'); return; }
        const got = await ia.pickImages({ capture: b.dataset.ph === 'cam', multiple: b.dataset.ph === 'file', root: m });
        files.push(...got.slice(0, 4 - files.length));
        list();
      });
      list();
    },
    actions: [{ label: 'Cancelar', value: null }, { label: 'Leer comprobante', kind: 'primary', id: 'pf-ia-go', value: 'go' }],
  });
  if (go !== 'go' || !files.length) return null;
  const done = ia.busy('Leyendo el comprobante con IA…');
  let res, docs;
  try {
    const imgs = [];
    docs = [];
    for (const f of files) { imgs.push(await ia.compressImage(f)); docs.push(await ia.docImage(f)); }
    res = await ia.readInvoice(imgs);
  } catch (e) { done(); await ia.showAiError(e); return null; }
  done();
  return purchaseForm(buildPrefill(res, docs));
}

// ---------- Detalle ----------

async function purchaseDetail(p) {
  if (!p) return;
  await db.whenLoaded(); // las imágenes de los comprobantes se leen en segundo plano
  const docs = db.COLLECTIONS.includes('purchase_docs') ? db.all('purchase_docs').filter(d => d.purchase_id === p.id && d.photo).sort((a, b) => (a.page || 0) - (b.page || 0)) : [];
  const mgr = ctx.user && can(ctx.user, 'compras');
  const sign = purchaseSign(p);
  const disc = Array.isArray(p.discounts) ? p.discounts : [];
  const row = (l, v) => html`<div class="cp-trow"><span>${l}</span><b class="money">${v}</b></div>`;
  const hasNew = p.doc_type || p.letter;
  const r = await modal({
    title: `${docText(p)} · ${fmtDate(purchaseDate(p))}`,
    size: 'wide',
    body: html`<p class="muted">${supName(p)}${p.supplier_cuit ? ` · CUIT ${p.supplier_cuit}` : ''}${p.supplier_iva ? ` · ${IVA_LABEL[p.supplier_iva] || p.supplier_iva}` : ''} · Cargó ${userName(p.user_id)} el ${fmtDate(p.created_at)} ${fmtTime(p.created_at)}${multiBranch() ? ` · Sucursal ${branchName(p.branch_id)}` : ''}</p>
      ${isVoidPurchase(p) ? html`<div class="notice notice-error"><p><b>Compra anulada.</b> ${p.notes || ''}</p></div>` : ''}
      <p><b>Condición: ${paymentLabel(p.payment)}</b>${p.payment === 'cuenta_corriente' ? ` · pagado al comprar ${fmtMoney(p.paid || 0)}${p.due_date ? ` · vence ${fmtDate(dayStart(p.due_date))}` : ''}` : ''} · A caja: ${p.to_cash ? 'Sí' : 'No'} · Actualiza costos: ${p.update_costs === 0 ? 'No' : 'Sí'}</p>
      <div class="table-wrap"><table><thead><tr><th>Código</th><th>Artículo</th><th class="r">Cant.</th><th class="r">Unitario</th><th class="r">Dto1</th><th class="r">Dto2</th><th class="r">Neto unit.</th><th class="r">Total</th></tr></thead><tbody>
      ${(p.items || []).map(it => html`<tr><td>${it.barcode || ''}</td><td style="white-space:normal">${it.name}</td><td class="r">${fmtQty(it.qty)}</td><td class="r">${fmtMoney(it.unit_cost)}</td>
        <td class="r">${it.disc1 ? fmtNum2(it.disc1) + '%' : ''}</td><td class="r">${it.disc2 ? fmtNum2(it.disc2) + '%' : ''}</td><td class="r">${fmtMoney(it.unit_net ?? it.unit_cost)}</td>
        <td class="r">${fmtMoney(it.subtotal ?? round2(it.qty * it.unit_cost))}</td></tr>`)}
      </tbody></table></div>
      <div class="cp-tot cp-tot-ro">
        ${hasNew ? html`${disc.map((d, i) => row(`Dto${i + 1} ${fmtNum2(d.pct)} %`, '− ' + fmtMoney(d.amount)))}
          ${row(p.letter === 'A' ? 'Total gravado' : 'Subtotal', fmtMoney(p.net))}
          ${(p.iva_lines || []).map(l => row(`IVA ${String(l.rate).replace('.', ',')} % (base ${fmtMoney(l.base)})`, fmtMoney(l.amount)))}
          ${p.non_taxed ? row('No gravados / exentos', fmtMoney(p.non_taxed)) : ''}${p.perc_iva ? row('Percepción IVA', fmtMoney(p.perc_iva)) : ''}
          ${p.perc_iibb ? row('Percepción IIBB', fmtMoney(p.perc_iibb)) : ''}${p.other_taxes ? row('Otros impuestos', fmtMoney(p.other_taxes)) : ''}
          ${p.ret_iva ? row('Retención IVA', fmtMoney(p.ret_iva)) : ''}${p.ret_gan ? row('Retención Ganancias', fmtMoney(p.ret_gan)) : ''}${p.ret_iibb ? row('Retención IIBB', fmtMoney(p.ret_iibb)) : ''}` : ''}
        <div class="cp-trow cp-total"><span>TOTAL${sign < 0 ? ' (nota de crédito, resta)' : ''}</span><b class="money">${fmtMoney(p.total)}</b></div>
      </div>
      ${p.notes && !isVoidPurchase(p) ? html`<p class="small">Observaciones: ${p.notes}</p>` : ''}
      ${docs.length ? html`<h3 class="small" style="margin-top:1rem">Imagen del comprobante</h3><div class="ia-thumbs" id="cp-docs">${docs.map((d, i) => html`<button type="button" class="ia-thumb" data-docfull="${i}" aria-label="Ver la página ${i + 1}"><img src="${d.photo}" alt=""></button>`)}</div>` : ''}`,
    onMount(m) { m.addEventListener('click', e => { const b = e.target.closest('[data-docfull]'); if (b) viewDoc(docs[Number(b.dataset.docfull)].photo, `${docText(p)} · página ${Number(b.dataset.docfull) + 1}`); }); },
    actions: [
      ...(mgr && !isVoidPurchase(p) ? [{ label: 'Anular compra', kind: 'danger', value: 'void' }] : []),
      { label: 'Cerrar', kind: 'primary', value: true },
    ],
  });
  if (r !== 'void') return;
  if (!(await confirm('¿Anular esta compra? Se devuelve el stock, se saca de la cuenta del proveedor y los cheques vuelven a la cartera. Los costos no cambian.', { title: 'Anular compra', ok: 'Anular', danger: true }))) return;
  try {
    const res = await voidPurchase(p.id);
    toast('Compra anulada.' + (res.cashNote ? ' ' + res.cashNote : ''), 'ok', 5000);
  } catch (e) { toast(e.message, 'error'); }
}

async function exportPurchases() {
  const bal = purchaseBalances();
  const rows = [['fecha', 'hora', 'sucursal', 'comprobante', 'proveedor', 'cuit', 'condicion', 'a_caja', 'actualiza_costo', 'estado', 'total_comprobante', 'saldo', 'codigo', 'producto', 'cantidad', 'importe_unitario', 'dto1', 'dto2', 'neto_unitario', 'total_renglon']];
  for (const p of filteredPurchases(bal).reverse()) {
    const head = [fmtDate(purchaseDate(p)), p.time || fmtTime(p.created_at), branchName(p.branch_id), docText(p), supName(p), p.supplier_cuit || '', paymentLabel(p.payment), p.to_cash ? 'Sí' : 'No', p.update_costs === 0 ? 'No' : 'Sí', isVoidPurchase(p) ? 'anulada' : 'ok', signed(p), fromCents(bal.get(p.id) || 0)];
    const its = p.items && p.items.length ? p.items : [{}];
    for (const it of its) rows.push([...head, it.barcode || '', it.name || '', Number(it.qty) || 0, round2(it.unit_cost || 0), Number(it.disc1) || 0, Number(it.disc2) || 0, round2(it.unit_net ?? it.unit_cost ?? 0), round2(it.subtotal ?? (it.qty || 0) * (it.unit_cost || 0))]);
  }
  await exportTable('compras-' + toISODate(Date.now()), 'Compras', rows);
}

// ---------- Libro IVA Compras ----------

let ivaMonth = toISODate(Date.now()).slice(0, 7);
function ivaBookRows() {
  const [y, mo] = ivaMonth.split('-').map(Number);
  const from = new Date(y, mo - 1, 1).getTime(), to = new Date(y, mo, 1).getTime() - 1;
  return db.all('purchases').filter(p => !isVoidPurchase(p) && purchaseDate(p) >= from && purchaseDate(p) <= to).sort((a, b) => purchaseDate(a) - purchaseDate(b))
    .map(p => {
      const s = db.get('suppliers', p.supplier_id) || {};
      return { p, fecha: fmtDate(purchaseDate(p)), tipo: [p.doc_type || 'FC', p.letter || ''].join(' ').trim(), numero: p.doc_number || p.invoice_ref || '', proveedor: s.legal_name || s.name || 'Sin proveedor', cuit: p.supplier_cuit || s.cuit || '', cond: p.supplier_iva || s.iva_condition || '', ...purchaseIvaRow(p) };
    });
}
const sumCol = (rows, k) => fromCents(rows.reduce((a, r) => a + toCents(r[k]), 0));

function ivaBookView() {
  const rows = ivaBookRows();
  const cols = IVA_BOOK_PURCHASE_COLS.filter(([k]) => rows.some(r => r[k]) || ['n21', 'i21', 'nograv', 'total'].includes(k));
  return html`<div class="card"><div class="card-head"><h2>Libro IVA Compras</h2>
      <div class="btn-row"><button type="button" class="btn ghost sm" data-act="iva-print" ${rows.length ? '' : 'disabled'}>${ic('print')} Imprimir</button>
      <button type="button" class="btn ghost sm" data-act="iva-export" ${rows.length ? '' : 'disabled'}>${ic('download')} Exportar Excel</button></div></div>
    <p class="muted small">Por fecha del comprobante. Factura A: neto e IVA por alícuota (crédito fiscal). B, C y X: van completas a “sin crédito fiscal”. Las notas de crédito restan. Las retenciones van aparte (no suman al total).</p>
    <div class="grid2"><div class="field"><label for="ivc-m">Mes</label><input id="ivc-m" type="month" value="${ivaMonth}"></div></div>
    ${rows.length ? html`<div class="table-wrap"><table id="ivc-t"><thead><tr><th>Fecha</th><th>Comprobante</th><th>Número</th><th>Proveedor</th><th>CUIT</th>${cols.map(([, l]) => html`<th class="r">${l}</th>`)}</tr></thead><tbody>
      ${rows.map(r => html`<tr><td>${r.fecha}</td><td>${r.tipo}</td><td>${r.numero}</td><td style="white-space:normal">${r.proveedor}</td><td>${r.cuit}</td>${cols.map(([k]) => html`<td class="r">${fmtMoney(r[k])}</td>`)}</tr>`)}
      </tbody><tfoot><tr><td colspan="5">Totales (${rows.length})</td>${cols.map(([k]) => html`<td class="r">${fmtMoney(sumCol(rows, k))}</td>`)}</tr></tfoot></table></div>
      <div class="stats" style="margin-top:1rem"><div class="stat"><div class="k">Crédito fiscal IVA</div><div class="v money" id="ivc-cf">${fmtMoney(fromCents(['i21', 'i105', 'i27', 'iotras'].reduce((a, k) => a + toCents(sumCol(rows, k)), 0)))}</div></div>
        <div class="stat"><div class="k">Percepciones IVA</div><div class="v money">${fmtMoney(sumCol(rows, 'perc_iva'))}</div></div>
        <div class="stat"><div class="k">Percepciones IIBB</div><div class="v money">${fmtMoney(sumCol(rows, 'perc_iibb'))}</div></div>
        <div class="stat"><div class="k">Total compras</div><div class="v money" id="ivc-total">${fmtMoney(sumCol(rows, 'total'))}</div></div></div>`
      : html`<p class="muted">No hay compras en ese mes.</p>`}</div>`;
}

async function exportIvaBook() {
  const rows = ivaBookRows();
  const table = [['Fecha', 'Comprobante', 'Número', 'Proveedor', 'CUIT', 'Cond. IVA', ...IVA_BOOK_PURCHASE_COLS.map(c => c[1])]];
  for (const r of rows) table.push([r.fecha, r.tipo, r.numero, r.proveedor, r.cuit, r.cond, ...IVA_BOOK_PURCHASE_COLS.map(([k]) => r[k])]);
  table.push(['', '', '', 'TOTALES', '', '', ...IVA_BOOK_PURCHASE_COLS.map(([k]) => sumCol(rows, k))]);
  await exportTable(`libro-iva-compras-${ivaMonth}`, 'Libro IVA Compras', table);
}

async function printIvaBook() {
  const rows = ivaBookRows();
  const cols = IVA_BOOK_PURCHASE_COLS.filter(([k]) => rows.some(r => r[k]) || ['n21', 'i21', 'total'].includes(k));
  await printA4(html`<div class="ticket doc-a4">${printHead('Libro IVA Compras', [`Mes ${ivaMonth.split('-').reverse().join('/')}`])}
    <table class="ptable"><thead><tr><th>Fecha</th><th>Comp.</th><th>Número</th><th>Proveedor</th><th>CUIT</th>${cols.map(([, l]) => html`<th class="r">${l}</th>`)}</tr></thead><tbody>
    ${rows.map(r => html`<tr><td>${r.fecha}</td><td>${r.tipo}</td><td>${r.numero}</td><td>${r.proveedor}</td><td>${r.cuit}</td>${cols.map(([k]) => html`<td class="r">${fmtNum2(r[k])}</td>`)}</tr>`)}
    </tbody><tfoot><tr><td colspan="5">Totales (${rows.length})</td>${cols.map(([k]) => html`<td class="r">${fmtNum2(sumCol(rows, k))}</td>`)}</tr></tfoot></table></div>`);
}
