// =====================================================================
// hoy.js — Tablero del día para el dueño y el encargado.
// Arriba lo que más se mira (vendido hoy y cómo viene contra ayer y contra
// el mismo día de la semana pasada, a la misma hora), después "Para atender"
// (lo que necesita una acción) y abajo el detalle. Inspirado en el "Home" de
// Square / Shopify POS y el tablero de Lightspeed, sin recargar.
// =====================================================================
import * as db from '../db.js';
import * as sync from '../sync.js';
import { ctx, multiBranch, branches, branchName, mainBranchId, userName, retryPendingArca, inBranch } from '../ops.js';
import { html, $, on, ic, toast } from '../ui.js';
import { fmtMoney, fmtQty, fmtTime, fmtDate, fmtDateTime, payLabel, daysSince } from '../logic.js';
import { dayDashboard } from '../negocio.js';
import { expiringLots } from '../comercial.js';
import { facturaParaMandar } from '../factura-pdf.js';

let main, app;
let hBranch = 'all';
const DIAS = ['domingo', 'lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado'];

/** Resumen corto (para la tira de arriba de Vender) */
export function todaySummary() {
  const d = data();
  return dayDashboard(d, { now: Date.now(), branch: 'all', mainId: mainBranchId(), costOf });
}

function data() {
  const all = c => db.all(c);
  return {
    sales: all('sales'), returns: all('returns'), cash_sessions: all('cash_sessions'), cash_movements: all('cash_movements'),
    transfers: all('transfers'), products: all('products'), customers: all('customers'), branches: branches({ includeInactive: true }),
  };
}
const costOf = id => (db.get('products', id) || {}).cost || 0;

export function render(m, a) {
  main = m; app = a;
  if (hBranch !== 'all' && !db.get('branches', hBranch)) hBranch = 'all';
  paint();
  const t = setInterval(() => { if (!document.querySelector('.modal-wrap')) paint(); }, 60000);
  const off = on(main, 'click', '[data-hb], [data-go]', (e, el) => {
    if (el.dataset.hb) { hBranch = el.dataset.hb; paint(); }
    if (el.dataset.go) go(el.dataset.go);
  });
  return () => { clearInterval(t); off(); };
}

async function go(where) {
  if (where === 'arca-retry') {
    const r = await retryPendingArca({ force: true });
    toast(r.tried ? `Se reintentaron ${r.tried}: ${r.ok} autorizadas.` : (sync.isConfigured() ? 'No hay comprobantes para reintentar desde este equipo.' : 'Conectá la nube para facturar.'), r.ok ? 'ok' : 'warn', 5000);
    paint();
    return;
  }
  if (where === 'ventas-pend') {
    const v = await import('./ventas.js');
    if (v.presetFilter) v.presetFilter({ status: 'pendiente', days: 15 });
    return app.navigate('ventas');
  }
  if (where === 'ventas-mandar') {
    const v = await import('./ventas.js');
    if (v.presetFilter) v.presetFilter({ status: 'mandar', days: 60 });
    return app.navigate('ventas');
  }
  if (where === 'ventas-dev') {
    const v = await import('./ventas.js');
    if (v.presetFilter) v.presetFilter({ status: 'devoluciones', days: 0 });
    return app.navigate('ventas');
  }
  app.navigate(where);
}

const arrow = v => (v === null ? '' : v > 0 ? '▲' : v < 0 ? '▼' : '=');
function cmp(label, v, base) {
  if (v === null) return html`<span class="cmp">${label}: <b>${base > 0 ? fmtMoney(base) : 'sin ventas'}</b></span>`;
  const cls = v > 0 ? 'up' : v < 0 ? 'down' : '';
  return html`<span class="cmp ${cls}" title="${label}: ${fmtMoney(base)}">${arrow(v)} <b>${Math.abs(v).toLocaleString('es-AR')}%</b> ${label}</span>`;
}

async function paint() {
  if (!main || !main.isConnected) return;
  const now = Date.now();
  const multi = multiBranch();
  const branch = multi ? hBranch : 'all';
  const D = dayDashboard(data(), { now, branch, mainId: mainBranchId(), costOf });
  const r = D.today;
  const lastBackup = await db.getMeta('last_backup', 0);
  const s = sync.status;
  const maxM = Math.max(1, ...Object.values(r.byMethod).map(Math.abs));
  const maxB = Math.max(1, ...D.perBranch.map(x => x.total));
  const maxH = Math.max(1, ...D.byHour.map(x => x.total));
  const wd = DIAS[new Date(now - 7 * 86400000).getDay()];
  const pend = D.arca.pending.length, rej = D.arca.rejected.length;
  const toReceive = D.transfers.filter(t => t.to_branch === ctx.branchId).length;
  const backupDays = daysSince(lastBackup, now);

  // "Para atender": solo lo que necesita una acción
  const todo = [];
  if (rej) todo.push(html`<li class="todo err"><span class="grow"><b>${rej} ${rej === 1 ? 'comprobante rechazado' : 'comprobantes rechazados'} por ARCA</b><span class="sub">Revisá el error y corregilo.</span></span><button type="button" class="btn sm ghost" data-go="ventas-pend">Ver</button></li>`);
  const mandar = db.all('sales').filter(x => facturaParaMandar(x) && (branch === 'all' || inBranch(x, branch))).length;
  if (mandar) todo.push(html`<li class="todo warn"><span class="grow"><b>${mandar} ${mandar === 1 ? 'factura para mandar' : 'facturas para mandar'} al cliente</b><span class="sub">Se autorizaron después de la venta (ARCA estaba caído): mandalas en PDF por WhatsApp o mail.</span></span><button type="button" class="btn sm ghost" data-go="ventas-mandar">Mandar</button></li>`);
  if (pend) todo.push(html`<li class="todo warn"><span class="grow"><b>${pend} ${pend === 1 ? 'factura o NC pendiente' : 'facturas o NC pendientes'} de CAE</b><span class="sub">Se reintentan solas al volver internet.</span></span><button type="button" class="btn sm ghost" data-go="arca-retry">Reintentar</button></li>`);
  if (D.transfers.length) todo.push(html`<li class="todo info"><span class="grow"><b>${D.transfers.length} ${D.transfers.length === 1 ? 'remito en camino' : 'remitos en camino'}</b><span class="sub">${toReceive ? `${toReceive} para recibir en esta sucursal` : 'Esperando que los reciban'}</span></span><button type="button" class="btn sm ghost" data-go="remitos">Ver</button></li>`);
  if (D.lowStock.length) todo.push(html`<li class="todo warn"><span class="grow"><b>${D.lowStock.length} ${D.lowStock.length === 1 ? 'producto' : 'productos'} con stock bajo</b><span class="sub">${D.lowStock.slice(0, 3).map(p => p.name).join(', ')}${D.lowStock.length > 3 ? '…' : ''}</span></span><button type="button" class="btn sm ghost" data-go="productos">Ver</button></li>`);
  // Vencimientos (lotes por sucursal y vencimiento del producto): vencidos y los que vencen en 7 días
  const exp = db.COLLECTIONS.includes('product_lots') ? expiringLots(db.all('product_lots'), db.all('products'), { days: 7, branchId: ctx.branchId, productOf: id => db.get('products', id) }) : [];
  if (exp.length) { const gone = exp.filter(x => x.expired).length; todo.push(html`<li class="todo ${gone ? 'err' : 'warn'}" id="h-venc"><span class="grow"><b>${exp.length} ${exp.length === 1 ? 'artículo vence' : 'artículos vencen'} en 7 días${gone ? ` (${gone} ya ${gone === 1 ? 'vencido' : 'vencidos'})` : ''}</b><span class="sub">${exp.slice(0, 3).map(x => x.product.name).join(', ')}${exp.length > 3 ? '…' : ''}</span></span><button type="button" class="btn sm ghost" data-go="vencimientos">Ver</button></li>`); }
  if (backupDays > 7) todo.push(html`<li class="todo warn"><span class="grow"><b>${lastBackup ? `Hace ${backupDays} días que no hay copia de seguridad` : 'Todavía no hay copia de seguridad'}</b><span class="sub">Bajala desde Ajustes.</span></span><button type="button" class="btn sm ghost" data-go="ajustes">Ajustes</button></li>`);
  if (s.configured && (s.error || s.authError)) todo.push(html`<li class="todo err"><span class="grow"><b>La nube no sincroniza</b><span class="sub">${s.authError ? 'Volvé a conectar la nube en Ajustes.' : s.error}</span></span></li>`);

  main.innerHTML = String(html`
    <div class="page-head"><h1>Hoy <span class="muted" style="font-size:1rem;font-weight:600">${DIAS[new Date(now).getDay()]} ${fmtDate(now)} · ${fmtTime(now)}</span></h1></div>
    ${multi ? html`<div class="chips" role="group" aria-label="Sucursal">
      <button type="button" class="chip" data-hb="all" aria-pressed="${branch === 'all'}">${ic('store')} Todas</button>
      ${branches().map(b => html`<button type="button" class="chip" data-hb="${b.id}" aria-pressed="${branch === b.id}">${b.name}</button>`)}</div>` : ''}

    <div class="stats dash">
      <div class="stat hero"><div class="k">Vendido hoy${multi ? ` · ${branch === 'all' ? 'todas las sucursales' : branchName(branch)}` : ''}</div>
        <div class="v money" id="h-total">${fmtMoney(r.total)}</div>
        <div class="hero-sub"><span id="h-count">${r.count} ${r.count === 1 ? 'venta' : 'ventas'}</span> · ticket promedio <b id="h-avg">${fmtMoney(r.avg)}</b></div>
        <div class="cmps" id="h-cmp">${cmp('vs ayer a esta hora', D.vsYesterday, D.yesterdaySoFar)} ${cmp(`vs el ${wd} pasado`, D.vsLastWeek, D.lastWeekSoFar)}</div>
      </div>
      <div class="stat"><div class="k">Ganancia bruta estimada</div><div class="v money" id="h-profit">${fmtMoney(r.profit)}</div>
        <div class="small muted">${D.margin !== null ? `${D.margin.toLocaleString('es-AR')}% de margen` : '—'}${!r.costKnown && r.count ? ' · hay productos sin costo' : ''}</div></div>
      <div class="stat"><div class="k">Efectivo en cajas abiertas</div><div class="v money" id="h-cash">${fmtMoney(D.cashExpected)}</div>
        <div class="small muted">${D.cash.length ? `${D.cash.length} ${D.cash.length === 1 ? 'caja abierta' : 'cajas abiertas'}` : 'Ninguna caja abierta'}</div></div>
      <div class="stat"><div class="k">Devoluciones / NC</div><div class="v money" id="h-devs">${D.returnsToday.total ? '-' : ''}${fmtMoney(D.returnsToday.total)}</div>
        <div class="small muted">${D.returnsToday.count ? html`<button type="button" class="linkbtn" data-go="ventas-dev">${D.returnsToday.count} hoy · ver</button>` : 'Ninguna hoy'}</div></div>
      <div class="stat"><div class="k">Egresos de caja</div><div class="v money" id="h-egr">${D.egresosTotal ? '-' : ''}${fmtMoney(D.egresosTotal)}</div>
        <div class="small muted">${D.egresos.length ? `${D.egresos.length} · ${D.egresos.slice(0, 2).map(x => x.reason).join(', ')}` : 'Ninguno hoy'}</div></div>
    </div>

    <section class="card" id="h-todo" aria-labelledby="h-todo-t"><h2 id="h-todo-t">Para atender</h2>
      ${todo.length ? html`<ul class="todos">${todo}</ul>` : html`<p class="ok-line">${ic('check')} Todo en orden: sin facturas pendientes, remitos ni alertas.</p>`}</section>

    <div class="dash-grid">
      <section class="card" aria-labelledby="h-pm"><h2 id="h-pm">Por medio de pago</h2>
        ${Object.keys(r.byMethod).length ? html`<ul class="bars">${Object.entries(r.byMethod).sort((a, b) => b[1] - a[1]).map(([k, v]) => html`<li>
          <div class="lbl"><span>${payLabel(k)}</span><span class="money">${fmtMoney(v)}</span></div>
          <div class="track" aria-hidden="true"><div class="fill" style="width:${Math.max(2, (Math.abs(v) / maxM) * 100)}%"></div></div></li>`)}</ul>`
          : html`<p class="muted">Sin ventas todavía.</p>`}</section>

      ${D.perBranch.length > 1 ? html`<section class="card" id="h-branches" aria-labelledby="h-pb"><h2 id="h-pb">Por sucursal</h2>
        <ul class="bars">${D.perBranch.map(x => html`<li data-hbranch="${x.branch.id}"><div class="lbl"><span>${x.branch.name}</span><span class="money">${fmtMoney(x.total)}</span></div>
          <div class="sub-lbl">${x.count} ${x.count === 1 ? 'venta' : 'ventas'}${x.count ? ` · promedio ${fmtMoney(x.avg)}` : ''}</div>
          <div class="track" aria-hidden="true"><div class="fill" style="width:${Math.max(2, (Math.max(0, x.total) / maxB) * 100)}%"></div></div></li>`)}</ul></section>` : ''}

      ${D.byHour.length ? html`<section class="card" aria-labelledby="h-ph"><h2 id="h-ph">Ventas por hora</h2>
        <div class="hours" role="img" aria-label="Ventas por hora de hoy">${D.byHour.map(x => html`<div class="h" title="${x.hour} h: ${fmtMoney(x.total)}">
          <div class="b" style="height:${Math.max(3, (x.total / maxH) * 100)}%"></div><span>${x.hour}</span></div>`)}</div></section>` : ''}

      <section class="card" aria-labelledby="h-cj"><div class="card-head"><h2 id="h-cj">Cajas abiertas</h2><a href="#/caja" class="small">Ir a Caja</a></div>
        ${D.cash.length ? html`<ul class="list">${D.cash.map(c => html`<li class="row"><span class="grow"><span class="title">${multi ? branchName(c.branch_id) : 'Caja'}</span>
          <span class="sub" style="display:block">Desde ${fmtDateTime(c.opened_at)} · ${userName(c.opened_by)} · ${c.count} ${c.count === 1 ? "venta" : "ventas"}</span></span>
          <b class="money">${fmtMoney(c.expected)}</b></li>`)}</ul>` : html`<p class="muted">No hay cajas abiertas.</p>`}</section>

      <section class="card" aria-labelledby="h-top"><h2 id="h-top">Lo más vendido hoy</h2>
        ${r.top.length ? html`<div class="table-wrap"><table><thead><tr><th>Producto</th><th class="r">Cant.</th><th class="r">Total</th></tr></thead><tbody>
          ${r.top.map(t => html`<tr><td style="white-space:normal">${t.name}</td><td class="r">${fmtQty(t.qty)}</td><td class="r">${fmtMoney(t.total)}</td></tr>`)}</tbody></table></div>`
          : html`<p class="muted">Sin ventas todavía.</p>`}</section>

      <section class="card" aria-labelledby="h-cc"><div class="card-head"><h2 id="h-cc">Cuentas corrientes</h2><a href="#/clientes" class="small">Ver clientes</a></div>
        <p class="lead" style="margin:0">A cobrar: <b class="money" id="h-recv">${fmtMoney(D.receivable)}</b></p>
        <p class="muted small" style="margin:0">${D.debtors ? `${D.debtors} ${D.debtors === 1 ? 'cliente debe' : 'clientes deben'}` : 'Nadie debe'}</p></section>
    </div>

    <p class="muted small" id="h-foot">${ic(s.configured ? 'cloud' : 'device')} ${sync.statusText(s)}${s.lastSync ? ` · última sincronización ${fmtDateTime(s.lastSync)}` : ''}
      · Copia de seguridad: ${lastBackup ? fmtDateTime(lastBackup) : 'nunca'}</p>`);
}
