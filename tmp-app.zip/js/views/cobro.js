// =====================================================================
// cobro.js — Ventana "Cobrar" como SGI: Contado (efectivo), Tarjeta (catálogo con crédito/débito, cuotas y % de
// recargo → intereses, importe de la cuota y total), Mercado Pago, QR, Transferencia, Cta. Cte., cheque (si hay
// cartera) y medios propios ("Coca Cola"). Pago mixto (tarjetas + Mercado Pago + efectivo + resto); el vuelto es
// solo sobre el efectivo. El recargo de las tarjetas SUBE el total de la venta.
// =====================================================================
import * as db from '../db.js';
import { ctx, openSession, mainBranchId } from '../ops.js';
import { html, $, ic, modal } from '../ui.js';
import { fmtMoney, fmtNum2, fmtQty, parseNum, round2, toISODate, uuid, can } from '../logic.js';
import { calcPaymentsSGI, cardPct, cardInstallments } from '../comercial.js';
import { cardList, methodList } from '../comercial-ops.js';
import { checkPayments, isManager } from '../control.js';
import { confirmWarnings } from '../autoriza.js';

const MAX_LINES = 4;

/** Billetes sugeridos para "paga con": redondeos hacia arriba del total */
export function billSuggestions(total) {
  const out = new Set();
  for (const b of [1000, 2000, 5000, 10000, 20000]) { const v = Math.ceil(total / b) * b; if (v > total) out.add(v); }
  return [...out].sort((a, b) => a - b).slice(0, 4);
}

/**
 * Abre la ventana de cobro. baseTotal = total de la venta sin recargo.
 * onConfirm({payments, wantFactura, extraOps}) guarda la venta (tira error si no se pudo) y devuelve la venta.
 * Devuelve la venta guardada o null.
 */
export function payModal({ baseTotal, facturaOn, letra, docNumber, customer, saleId, onConfirm }) {
  const methods = methodList();
  const cards = cardList();
  const mOf = code => methods.find(m => m.code === code) || { code, name: code, kind: 'otro' };
  const defCard = (cards.find(c => c.name === 'DEBITO') || cards[0] || {}).id || '';
  const manager = !!ctx.user && can(ctx.user, 'descuentos');
  const banks = db.COLLECTIONS.includes('banks') ? db.all('banks').filter(b => b.active !== 0) : [];
  const newLine = (m = 'efectivo', amount = '') => ({ m, amount, card: defCard, inst: 1, pct: null, ch: { number: '', bank_id: '', due: toISODate(Date.now()) } });
  let lines = [newLine()];
  // Comprobante automático: pagos electrónicos (tarjeta, Mercado Pago, QR, transferencia) → Factura;
  // efectivo y el resto → Interno X. Si el cajero lo cambia a mano, se respeta lo que eligió.
  const ELECTRONICOS = ['tarjeta', 'mercadopago', 'qr', 'transferencia'];
  let docTouched = false;
  const cardOf = l => cards.find(c => c.id === l.card) || null;
  const pctOf = l => (l.pct !== null && l.pct !== '' && Number.isFinite(parseNum(l.pct)) ? parseNum(l.pct) : cardPct(cardOf(l), l.inst));
  const isCard = l => mOf(l.m).kind === 'tarjeta';

  /** Pagos para calcPaymentsSGI */
  const payments = () => lines.map((l, i) => {
    let a = parseNum(l.amount);
    if (String(l.amount).trim() === '') a = lines.length === 1 ? baseTotal : 0;
    const amount = isFinite(a) ? a : 0;
    const m = mOf(l.m);
    if (m.kind === 'tarjeta') {
      const c = cardOf(l);
      return { method: c ? (c.kind === 'debito' ? 'debito' : 'credito') : 'credito', amount, card_type_id: c ? c.id : 'sin-tarjeta', card_name: c ? c.name : '', installments: Number(l.inst) || 1, surcharge_pct: pctOf(l), _i: i };
    }
    if (l.m === 'cheque') return { method: 'cheque', amount, cheque_id: l.chId || (l.chId = uuid()), _i: i };
    if (m.kind === 'efectivo') return l.m === 'efectivo' ? { method: 'efectivo', amount, _i: i } : { method: 'efectivo', amount, pm_code: l.m, _i: i };
    if (!m.builtin) return { method: l.m, amount, pm_code: l.m, _i: i };
    return { method: l.m, amount, _i: i };
  });

  const cardRow = (l, i) => {
    const c = cardOf(l);
    const inst = cardInstallments(c);
    return html`<div class="card-row" data-cardrow="${i}">
      <label class="sr-only" for="pc-${i}">Tarjeta</label>
      <select id="pc-${i}" data-lc="${i}" aria-label="Tarjeta">${cards.length ? cards.map(x => html`<option value="${x.id}" ${x.id === l.card ? 'selected' : ''}>${x.name} (${x.kind === 'debito' ? 'débito' : 'crédito'})</option>`) : html`<option value="">No hay tarjetas cargadas</option>`}</select>
      <label class="sr-only" for="pq-${i}">Cuotas</label>
      <select id="pq-${i}" data-lq="${i}" aria-label="Cuotas">${inst.map(n => html`<option value="${n}" ${n === Number(l.inst) ? 'selected' : ''}>${n === 1 ? '1 pago' : n + ' cuotas'}</option>`)}</select>
      <span class="pct-wrap"><label for="pp-${i}" class="small">Recargo %</label>
      <input id="pp-${i}" data-lp="${i}" inputmode="decimal" autocomplete="off" value="${fmtQty(pctOf(l))}" ${manager ? '' : 'readonly'} aria-label="Recargo en porcentaje"></span>
      <div class="card-info small" id="pi-${i}" aria-live="polite"></div>
    </div>`;
  };
  const chequeRow = (l, i) => html`<div class="card-row" data-chrow="${i}">
    <input id="pcn-${i}" data-chn="${i}" placeholder="N° de cheque" value="${l.ch.number}" aria-label="Número de cheque" autocomplete="off">
    ${banks.length ? html`<select data-chb="${i}" aria-label="Banco"><option value="">Banco…</option>${banks.map(b => html`<option value="${b.id}" ${b.id === l.ch.bank_id ? 'selected' : ''}>${b.name}</option>`)}</select>` : ''}
    <label class="small" for="pcd-${i}">Vence</label><input id="pcd-${i}" type="date" data-chd="${i}" value="${l.ch.due}">
  </div>`;

  return modal({
    title: 'Cobrar',
    body: html`
      <div class="pay-total"><div class="muted">Total a cobrar</div><div class="v" id="p-total">${fmtMoney(baseTotal)}</div>
        <div class="small muted" id="p-sur"></div></div>
      <fieldset class="seg"><legend>Comprobante · N° <b id="p-docnro">${docNumber}</b></legend>
        <label><input type="radio" name="doc" value="no_fiscal" checked><span>Interno X (no fiscal)</span></label>
        <label><input type="radio" name="doc" value="factura" ${facturaOn ? '' : 'disabled'}><span>Factura ${letra}</span></label>
      </fieldset>
      ${facturaOn ? html`<p class="small muted" style="margin-top:-.6rem">Tarjeta, Mercado Pago, QR y transferencia salen con factura; efectivo sin factura. Podés cambiarlo acá.</p>` : html`<p class="small muted" style="margin-top:-.6rem">La factura electrónica está desactivada. Se activa en Ajustes → Facturación ARCA.</p>`}
      ${customer ? html`<p class="small" id="p-cust">${ic('user')} ${customer.name}${Number(customer.balance) ? html` · saldo <b class="money">${fmtMoney(customer.balance)}</b>` : ''}</p>` : ''}
      <div class="label">Medio de pago</div>
      <div class="methods" id="p-methods">${methods.map(m => html`<button type="button" class="btn ghost" data-m="${m.code}" aria-pressed="${m.code === 'efectivo'}">${m.name}</button>`)}</div>
      <div id="p-lines"></div>
      <button type="button" class="btn ghost sm" id="p-split">${ic('plus')} Pagar con otro medio también</button>
      <div class="change-box" id="p-change" aria-live="polite"></div>
      <p id="p-err" class="field-err" role="alert"></p>`,
    onMount(m) {
      const paint = () => {
        const split = lines.length > 1;
        m.querySelectorAll('[data-m]').forEach(b => {
          const on = !split && lines[0].m === b.dataset.m;
          b.setAttribute('aria-pressed', String(on));
          b.className = 'btn ' + (on ? 'primary' : 'ghost');
        });
        $('#p-lines', m).innerHTML = String(html`${lines.map((l, i) => html`
          <div class="pay-block">
          <div class="pay-line">
            ${split ? html`<label class="sr-only" for="pm-${i}">Medio ${i + 1}</label><select id="pm-${i}" class="m" data-lm="${i}">${methods.map(x => html`<option value="${x.code}" ${x.code === l.m ? 'selected' : ''}>${x.name}</option>`)}</select>`
              : html`<span class="m">${l.m === 'efectivo' ? 'Paga con' : mOf(l.m).name}</span>`}
            <label class="sr-only" for="pa-${i}">Importe</label>
            <input id="pa-${i}" data-la="${i}" inputmode="decimal" autocomplete="off" value="${l.amount}" placeholder="${l.m === 'efectivo' && !split ? 'Justo: ' + fmtNum2(baseTotal) : fmtNum2(baseTotal)}" ${!split && l.m !== 'efectivo' ? 'readonly' : ''}>
            ${split ? html`<button type="button" class="icon-btn" data-rm="${i}" aria-label="Quitar este pago">${ic('x')}</button>` : ''}
          </div>
          ${isCard(l) ? cardRow(l, i) : ''}${l.m === 'cheque' ? chequeRow(l, i) : ''}
          </div>`)}
          ${!split && lines[0].m === 'efectivo' ? html`<div class="quick-bills">
            ${billSuggestions(baseTotal).map(b => html`<button type="button" class="btn ghost" data-bill="${b}">${fmtMoney(b).replace(',00', '')}</button>`)}
            <button type="button" class="btn ghost" data-bill="exact">Justo</button></div>` : ''}
          ${split ? html`<p class="small muted">En las tarjetas poné cuánto del total se paga con cada una: el recargo se suma solo. El efectivo es con cuánto paga (da vuelto).</p>` : ''}`);
        $('#p-split', m).classList.toggle('hidden', lines.length >= MAX_LINES);
        autoDoc();
        recalc();
      };
      const autoDoc = () => {
        if (docTouched || !facturaOn) return;
        const want = lines.some(l => ELECTRONICOS.includes(mOf(l.m).kind)) ? 'factura' : 'no_fiscal';
        const r = m.querySelector(`[name=doc][value=${want}]`);
        if (r) r.checked = true;
      };
      const recalc = () => {
        const pays = payments();
        const pay = calcPaymentsSGI(baseTotal, pays);
        $('#p-total', m).textContent = fmtMoney(pay.ok ? pay.total : baseTotal + (pay.surcharge || 0));
        $('#p-sur', m).textContent = pay.ok && pay.surcharge > 0 ? `${fmtMoney(baseTotal)} + intereses de tarjeta ${fmtMoney(pay.surcharge)}` : '';
        // Detalle de cada tarjeta: recargo, cuotas y total con la tarjeta
        lines.forEach((l, i) => {
          const box = $('#pi-' + i, m);
          if (!box) return;
          const row = pay.ok ? pay.applied.filter(p => p.card_type_id)[lines.slice(0, i).filter(isCard).length] : null;
          box.textContent = row ? `${row.installments > 1 ? `${row.installments} cuotas de ${fmtMoney(row.installment_amount)}` : '1 pago'} · recargo ${fmtMoney(row.surcharge)} · total tarjeta ${fmtMoney(row.amount)}` : '';
        });
        const box = $('#p-change', m);
        if (pay.ok) {
          box.className = 'change-box ok';
          box.innerHTML = String(html`<div class="k">Vuelto</div><div class="v" id="p-vuelto">${fmtMoney(pay.change)}</div>`);
        } else {
          box.className = 'change-box miss';
          box.innerHTML = String(html`<div class="k">${pay.missing ? 'Falta' : 'Revisá los importes'}</div><div class="v">${pay.missing ? fmtMoney(pay.missing) : ''}</div>`);
        }
        const needsCust = lines.some(l => mOf(l.m).kind === 'cuenta_corriente') && !customer;
        const noCard = lines.some(l => isCard(l) && !cardOf(l));
        const noCheque = lines.some(l => l.m === 'cheque' && !String(l.ch.number).trim());
        $('#p-err', m).textContent = needsCust ? 'Para cuenta corriente elegí un cliente (cerrá y tocá “Consumidor final”).'
          : noCard ? 'Elegí la tarjeta.' : noCheque ? 'Escribí el número del cheque.' : (pay.ok ? '' : pay.error);
        const go = $('#p-go', m.parentElement);
        if (go) go.disabled = !pay.ok || needsCust || noCard || noCheque;
        return pay;
      };
      m.addEventListener('click', e => {
        const mb = e.target.closest('[data-m]');
        if (mb) { lines = [newLine(mb.dataset.m)]; paint(); if (mb.dataset.m === 'efectivo') $('#pa-0', m).focus(); return; }
        const bill = e.target.closest('[data-bill]');
        if (bill) { lines[0].amount = bill.dataset.bill === 'exact' ? '' : fmtNum2(Number(bill.dataset.bill)); paint(); return; }
        const rm = e.target.closest('[data-rm]');
        if (rm) { lines.splice(Number(rm.dataset.rm), 1); if (lines.length === 1 && lines[0].m !== 'efectivo') lines[0].amount = ''; paint(); return; }
        if (e.target.closest('#p-split')) {
          // Lo que ya se escribió queda; la línea nueva propone el resto. Con una sola línea sin importe, pasa a "el total".
          if (lines.length === 1 && String(lines[0].amount).trim() === '' && lines[0].m !== 'efectivo') lines[0].amount = fmtNum2(baseTotal);
          const typed = lines.filter(l => String(l.amount).trim() !== '').reduce((a, l) => a + (parseNum(l.amount) || 0), 0);
          const rest = round2(baseTotal - typed);
          const used = lines.map(l => l.m);
          const next = methods.find(x => !used.includes(x.code) && x.kind !== 'cuenta_corriente') || methods[0];
          lines.push(newLine(next.code, typed > 0 && rest > 0 ? fmtNum2(rest) : ''));
          paint();
          const inputs = m.querySelectorAll('[data-la]');
          inputs[typed > 0 ? inputs.length - 1 : 0].focus();
        }
      });
      m.addEventListener('input', e => {
        const t = e.target;
        if (t.matches('[data-la]')) { lines[Number(t.dataset.la)].amount = t.value; recalc(); }
        if (t.matches('[data-lp]')) { lines[Number(t.dataset.lp)].pct = t.value; recalc(); }
        if (t.matches('[data-chn]')) { lines[Number(t.dataset.chn)].ch.number = t.value; recalc(); }
      });
      m.addEventListener('change', e => {
        const t = e.target;
        if (t.matches('[name=doc]')) docTouched = true;
        if (t.matches('[data-lm]')) { const l = lines[Number(t.dataset.lm)]; l.m = t.value; paint(); }
        if (t.matches('[data-lc]')) { const l = lines[Number(t.dataset.lc)]; l.card = t.value; l.inst = 1; l.pct = null; paint(); }
        if (t.matches('[data-lq]')) { const l = lines[Number(t.dataset.lq)]; l.inst = Number(t.value) || 1; l.pct = null; paint(); }
        if (t.matches('[data-chb]')) lines[Number(t.dataset.chb)].ch.bank_id = t.value;
        if (t.matches('[data-chd]')) lines[Number(t.dataset.chd)].ch.due = t.value;
      });
      m.addEventListener('keydown', e => {
        if (e.key === 'Enter' && e.target.matches('input')) { e.preventDefault(); const go = $('#p-go', m.parentElement); if (go && !go.disabled) go.click(); }
      });
      m.recalc = recalc;
      m.payments = payments;
      m.lines = () => lines;
      paint();
      setTimeout(() => { const f = $('#pa-0', m); if (f && !f.readOnly) f.focus(); }, 60);
    },
    actions: [{ label: 'Volver', value: null }, {
      label: 'Confirmar venta', kind: 'primary', id: 'p-go', onClick: async (close, w) => {
        const m = $('.modal', w);
        const pay = m.recalc();
        if (!pay.ok) return;
        const pays = m.payments();
        const pchk = checkPayments(baseTotal, pays);
        if (pchk.error) { $('#p-err', w).textContent = pchk.error; return; }
        if (pchk.warning && !(await confirmWarnings([pchk.warning, `El vuelto sería ${fmtMoney(pay.change)}.`]))) return;
        const btn = $('#p-go', w);
        btn.disabled = true; btn.textContent = 'Guardando…';
        try {
          const wantFactura = w.querySelector('[name=doc]:checked').value === 'factura';
          // Cheques recibidos: entran a la cartera en la misma transacción que la venta
          const extraOps = [];
          const s = openSession();
          for (const l of m.lines()) {
            if (l.m !== 'cheque') continue;
            const p = pays.find(x => x.cheque_id === l.chId);
            if (!p || !(p.amount > 0)) continue;
            const now = Date.now();
            extraOps.push({ coll: 'cheques', rec: { id: l.chId, kind: 'tercero', status: 'en_cartera', bank_id: l.ch.bank_id || null, number: String(l.ch.number).trim(), amount: round2(p.amount), issue_date: toISODate(now), due_date: l.ch.due || null, received_from: customer ? customer.id : '', ref: 'sale:' + saleId, created_at: now, user_id: ctx.user.id, branch_id: ctx.branchId || mainBranchId(), session_id: s ? s.id : null, status_at: now, history: [{ at: now, status: 'en_cartera', user_id: ctx.user.id, note: 'Recibido en una venta' }] } });
          }
          const sale = await onConfirm({ payments: pays.map(({ _i, ...p }) => p), wantFactura, extraOps });
          close(sale);
        } catch (e) {
          $('#p-err', w).textContent = e.message;
          btn.disabled = false; btn.textContent = 'Confirmar venta';
        }
      },
    }],
  });
}
