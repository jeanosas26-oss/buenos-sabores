// =====================================================================
// nota-debito.js — Nota de Débito a un cliente (como SGI): un recargo posterior (interés por pago fuera de término,
// diferencia de precio, flete…). Sale como comprobante interno X (la nube todavía no factura ND en ARCA) y, a cuenta
// corriente, suma a lo que debe el cliente. Se imprime como ticket.
// =====================================================================
import * as db from '../db.js';
import { html, $, ic, modal, toast, fieldError } from '../ui.js';
import { fmtMoney, parseNum, IVA_RATES, round2 } from '../logic.js';
import { createDebitNote } from '../comercial-ops.js';
import { pickCustomer } from './clientes.js';
import { printSale, ticketHTML } from '../print.js';
import { openSession } from '../ops.js';

/** sale: venta sobre la que se hace el recargo (opcional) */
export async function debitNoteDialog(sale = null) {
  let cust = sale ? sale.customer_id : null;
  const custTxt = () => { const c = cust ? db.get('customers', cust) : null; return c ? `${c.name}${Number(c.balance) ? ` · saldo ${fmtMoney(c.balance)}` : ''}` : 'Elegí el cliente'; };
  const nd = await modal({
    title: sale ? `Nota de débito sobre la venta N° ${sale.number}` : 'Nota de débito',
    body: html`<form id="nd" novalidate>
      <div class="field"><span class="label">Cliente</span><button type="button" class="btn ghost block" id="nd-cust">${ic('user')} <span id="nd-cn">${custTxt()}</span></button></div>
      <div class="field"><label for="nd-c">Concepto</label><input id="nd-c" value="Recargo por pago fuera de término" autocomplete="off"></div>
      <div class="grid2"><div class="field"><label for="nd-a">Importe (con IVA)</label><input id="nd-a" class="money-input" inputmode="decimal" placeholder="0,00" autocomplete="off"></div>
        <div class="field"><label for="nd-i">IVA</label><select id="nd-i">${IVA_RATES.map(r => html`<option value="${r}" ${r === 21 ? 'selected' : ''}>${String(r).replace('.', ',')}%</option>`)}</select></div></div>
      <fieldset class="seg"><legend>Cómo se cobra</legend>
        <label><input type="radio" name="m" value="cuenta_corriente" checked><span>A su cuenta corriente</span></label>
        <label><input type="radio" name="m" value="efectivo" ${openSession() ? '' : 'disabled'}><span>Efectivo ahora</span></label></fieldset>
      <div class="field"><label for="nd-o">Observaciones</label><input id="nd-o" autocomplete="off"></div>
      <p class="small muted">Sale como <b>Nota de débito X</b> (comprobante interno). Suma en ventas e informes.</p></form>`,
    onMount(m) { $('#nd-cust', m).onclick = async () => { const id = await pickCustomer(cust); if (id !== undefined) { cust = id; $('#nd-cn', m).textContent = custTxt(); } }; },
    actions: [{ label: 'Cancelar', value: null }, { label: 'Hacer nota de débito', kind: 'primary', id: 'nd-go', onClick: async (close, w) => {
      const a = parseNum($('#nd-a', w).value);
      if (!(a > 0)) return fieldError($('#nd-a', w), 'Poné el importe.');
      if (a >= 1e9) return fieldError($('#nd-a', w), 'Ese importe es demasiado alto: revisalo.');
      const method = w.querySelector('[name=m]:checked').value;
      if (method === 'cuenta_corriente' && !cust) { toast('Elegí el cliente.', 'warn'); return; }
      try {
        const r = await createDebitNote({ customer_id: cust, concept: $('#nd-c', w).value, amount: round2(a), iva_rate: Number($('#nd-i', w).value), method, observations: $('#nd-o', w).value, ref_sale: sale });
        close(r);
      } catch (e) { toast(e.message, 'error', 5000); }
    } }],
  });
  if (!nd) return null;
  await modal({
    title: `Nota de débito N° ${nd.number}`,
    body: html`<div class="notice notice-ok"><p>Nota de débito por <b>${fmtMoney(nd.total)}</b> guardada.</p></div>${ticketHTML(nd)}`,
    actions: [{ label: 'Imprimir', onClick: () => printSale(nd) }, { label: 'Listo', kind: 'primary', value: true }],
  });
  return nd;
}
