// =====================================================================
// vencimientos.js — Lotes con fecha de vencimiento por sucursal e informe "Artículos por vencer" (7/15/30 días).
// Los lotes se cargan acá, al recibir un pedido a proveedor o en el producto (vencimiento simple).
// Al vender, se descuentan del lote que vence primero.
// Con IA (v31): "Leer vencimiento con foto" (la fecha y el lote salen de una foto del envase) y el modo seguido para la
// góndola: escanear el código → foto de la fecha → cantidad → siguiente. Crea el lote en la sucursal del equipo.
// =====================================================================
import * as db from '../db.js';
import { ctx, stockOf, multiBranch, branches, branchName } from '../ops.js';
import { html, $, on, ic, modal, toast, exportTable, confirm } from '../ui.js';
import { fmtQty, fmtMoney, parseNum, searchProducts, toISODate } from '../logic.js';
import { expiringLots } from '../comercial.js';
import { saveLot } from '../comercial-ops.js';
import { printA4, printHead } from './ctacte.js';
import { openScanner, canScan, scanButton, playError } from '../scanner.js';

let days = 30, br = null;
const dmy = iso => String(iso || '').slice(0, 10).split('-').reverse().join('/');
const cls = d => (d < 0 ? 'exp-0' : d <= 7 ? 'exp-7' : '');
const left = d => (d < 0 ? `vencido hace ${-d} ${d === -1 ? 'día' : 'días'}` : d === 0 ? 'vence HOY' : `faltan ${d} ${d === 1 ? 'día' : 'días'}`);

/** Lista para el tablero "Hoy" y la tira de aviso */
export function expiringSoon(n = 7, branchId = ctx.branchId) {
  if (!db.COLLECTIONS.includes('product_lots')) return [];
  return expiringLots(db.all('product_lots'), db.all('products'), { days: n, branchId, productOf: id => db.get('products', id) });
}

export function render(main) {
  if (br === null) br = ctx.branchId;
  const rows = () => expiringLots(db.all('product_lots'), db.all('products'), { days, branchId: br || null, productOf: id => db.get('products', id) });
  const paint = () => {
    const list = rows();
    const exp = list.filter(r => r.expired).length;
    main.innerHTML = String(html`
      <div class="page-head"><h1>Artículos por vencer</h1><button type="button" class="btn primary" data-act="new" id="vt-new">${ic('plus')} Cargar vencimiento</button></div>
      <div class="btn-row" style="margin-bottom:1rem"><button type="button" class="btn soft" data-act="photo" id="vt-photo">${ic('camera')} Leer vencimiento con foto</button>
        <button type="button" class="btn ghost" data-act="seguido" id="vt-seguido">${ic('camera')} Góndola: varios seguidos</button></div>
      <div class="chips" role="group" aria-label="Días">${[7, 15, 30, 60].map(d => html`<button type="button" class="chip" data-days="${d}" aria-pressed="${days === d}">${d} días</button>`)}</div>
      ${multiBranch() ? html`<div class="chips" role="group" aria-label="Sucursal"><button type="button" class="chip" data-br="" aria-pressed="${!br}">Todas</button>${branches().map(b => html`<button type="button" class="chip" data-br="${b.id}" aria-pressed="${br === b.id}">${b.name}</button>`)}</div>` : ''}
      <div class="stats"><div class="stat"><div class="k">Por vencer en ${days} días</div><div class="v" id="vt-count">${list.length - exp}</div></div>
        <div class="stat"><div class="k">Vencidos con stock</div><div class="v ${exp ? 'neg' : ''}" id="vt-exp">${exp}</div></div>
        <div class="stat"><div class="k">Valor a costo</div><div class="v money">${fmtMoney(list.reduce((a, r) => a + (Number(r.product.cost) || 0) * (r.qty ?? Math.max(0, stockOf(r.product, br || ctx.branchId))), 0))}</div></div></div>
      <div class="rep-tools"><button type="button" class="btn ghost" data-act="print">${ic('print')} Imprimir</button><button type="button" class="btn ghost" data-act="xls">${ic('download')} Excel</button>
        <a class="btn ghost" href="#/etiquetas">${ic('tag')} Carteles de oferta</a></div>
      <ul class="list" id="vt-list">${list.map(r => html`<li><button type="button" class="row" ${r.lot ? html`data-lot="${r.lot.id}"` : html`data-prod="${r.product.id}"`}>
        <span class="grow"><span class="title">${r.product.name}</span><span class="sub" style="display:block">Vence ${dmy(r.expires_at)}${r.lot && r.lot.lot ? ` · lote ${r.lot.lot}` : ''}${!br && multiBranch() && r.branch_id ? ` · ${branchName(r.branch_id)}` : ''} · ${r.qty !== null ? `${fmtQty(r.qty)} del lote` : 'vencimiento del producto'} · stock ${fmtQty(stockOf(r.product, r.branch_id || br || ctx.branchId))}</span></span>
        <span class="${cls(r.days)}" style="text-align:right;white-space:nowrap">${left(r.days)}</span></button></li>`)}
        ${!list.length ? html`<li class="empty">No hay artículos que venzan en los próximos ${days} días.</li>` : ''}</ul>`);
  };
  paint();
  const table = () => [['Producto', 'Código', 'Sucursal', 'Lote', 'Vence', 'Días', 'Cantidad lote', 'Stock'], ...rows().map(r => [r.product.name, r.product.barcode || r.product.sku || '', r.branch_id ? branchName(r.branch_id) : '', r.lot ? r.lot.lot || '' : '', dmy(r.expires_at), r.days, r.qty ?? '', stockOf(r.product, r.branch_id || br || ctx.branchId)])];
  const offs = [
    on(main, 'click', '[data-days]', (e, el) => { days = Number(el.dataset.days); paint(); }),
    on(main, 'click', '[data-br]', (e, el) => { br = el.dataset.br || ''; paint(); }),
    on(main, 'click', '[data-lot]', async (e, el) => { if (await lotForm(db.get('product_lots', el.dataset.lot))) paint(); }),
    on(main, 'click', '[data-prod]', async (e, el) => { const { productForm } = await import('./productos.js'); if (await productForm(db.get('products', el.dataset.prod))) paint(); }),
    on(main, 'click', '[data-act]', async (e, el) => {
      const a = el.dataset.act;
      if (a === 'new') { if (await lotForm(null)) paint(); }
      if (a === 'photo') { if (await lotForm(null, { photo: true })) paint(); }
      if (a === 'seguido') { await gondola(); paint(); }
      if (a === 'xls') exportTable(`por-vencer-${days}-dias`, 'Por vencer', table());
      if (a === 'print') { const t = table(); printA4(html`<div class="ticket rep">${printHead(`Artículos por vencer (${days} días)${br ? ' · ' + branchName(br) : ''}`)}<table class="ptable"><thead><tr>${t[0].map(h => html`<th>${h}</th>`)}</tr></thead><tbody>${t.slice(1).map(r => html`<tr>${r.map(c => html`<td>${c}</td>`)}</tr>`)}</tbody></table></div>`); }
    }),
  ];
  return () => offs.forEach(f => f());
}

/** Foto de la fecha (durante el toque) → IA → {fecha_vencimiento, lote, ean}. null si se canceló o falló (ya avisó). */
async function readExpiryPhoto(root, ean = '', onStatus = () => {}) {
  const ia = await import('../ia.js');
  const [file] = await ia.pickImages({ capture: true, root });
  if (!file) return null;
  onStatus('Leyendo la fecha con IA…');
  try {
    const img = await ia.compressImage(file, { maxPx: 1400 });
    const r = await ia.readExpiry(img, ean);
    onStatus('');
    return r;
  } catch (e) {
    onStatus(e.code === 'AI_UNREADABLE' ? e.message : '');
    if (e.code !== 'AI_UNREADABLE') await ia.showAiError(e);
    return null;
  }
}

async function lotForm(l, { photo = false } = {}) {
  let product = l ? db.get('products', l.product_id) : null;
  return modal({
    title: l ? `Lote de ${product ? product.name : ''}` : photo ? 'Leer vencimiento con foto' : 'Cargar vencimiento',
    body: html`<form id="lf" novalidate>
      ${l ? '' : html`<div class="field searchbox">${ic('search')}<label class="sr-only" for="lf-q">Producto</label><input id="lf-q" type="search" placeholder="Buscar producto o escanear" autocomplete="off"></div><div id="lf-res" class="results"></div><p id="lf-p" class="lead"></p>`}
      ${l ? '' : html`<div class="btn-row"><button type="button" class="btn ${photo ? 'primary' : 'soft'}" data-vphoto id="lf-photo">${ic('camera')} Sacar foto de la fecha</button></div>
        <p id="lf-read" class="small" aria-live="polite">${photo ? 'Elegí el producto (o sacá la foto: si se ve el código de barras, la app lo busca) y sacale una foto a la fecha de vencimiento.' : ''}</p>`}
      <div class="grid2"><div class="field"><label for="lf-e">Vence</label><input type="date" id="lf-e" value="${l ? l.expires_at : toISODate(Date.now() + 30 * 86400000)}"></div>
        <div class="field"><label for="lf-c">Cantidad</label><input id="lf-c" inputmode="decimal" value="${l ? fmtQty(l.qty) : ''}"></div></div>
      <div class="field"><label for="lf-l">Lote (opcional)</label><input id="lf-l" value="${l ? l.lot || '' : ''}" autocomplete="off"></div>
      ${multiBranch() && !l ? html`<div class="field"><label for="lf-b">Sucursal</label><select id="lf-b">${branches().map(b => html`<option value="${b.id}" ${b.id === ctx.branchId ? 'selected' : ''}>${b.name}</option>`)}</select></div>` : ''}</form>`,
    onMount(m) {
      const q = $('#lf-q', m);
      if (!q) return;
      const pick = p => { product = p; $('#lf-p', m).textContent = p.name; $('#lf-res', m).innerHTML = ''; q.value = ''; if (!$('#lf-c', m).value) $('#lf-c', m).value = fmtQty(Math.max(0, stockOf(p))); };
      q.addEventListener('input', () => { $('#lf-res', m).innerHTML = q.value.trim() ? String(html`${searchProducts(db.all('products'), q.value, 6).map(p => html`<button type="button" class="result" data-lp="${p.id}"><span class="grow">${p.name}</span></button>`)}`) : ''; });
      q.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); const r = searchProducts(db.all('products'), q.value, 1)[0]; if (r) pick(r); } });
      m.addEventListener('click', async e => {
        const b = e.target.closest('[data-lp]'); if (b) pick(db.get('products', b.dataset.lp));
        if (e.target.closest('[data-vphoto]')) {
          const out = $('#lf-read', m);
          const r = await readExpiryPhoto(m, product ? product.barcode : '', t => { out.textContent = t; });
          if (!r) return;
          $('#lf-e', m).value = r.fecha_vencimiento;
          if (r.lote) $('#lf-l', m).value = r.lote;
          if (!product && r.ean) { const { productByCode } = await import('./productos.js'); const p = productByCode(r.ean); if (p) pick(p); }
          out.innerHTML = String(html`${ic('check')} Leído: vence <b>${dmy(r.fecha_vencimiento)}</b>${r.lote ? ` · lote ${r.lote}` : ''}. Revisalo y guardá.`);
          $('#lf-c', m).focus();
        }
      });
    },
    actions: [
      ...(l ? [{ label: 'Dar de baja', onClick: async close => { if (await confirm('¿Das de baja el lote (cantidad 0)? Para sacar la mercadería del stock usá “Ajustar stock”.', { ok: 'Dar de baja' })) { await saveLot({ ...l, qty: 0 }); toast('Lote dado de baja.'); close(true); } } }] : []),
      { label: 'Cancelar', value: null },
      { label: 'Guardar', kind: 'primary', id: 'lf-go', onClick: async (close, w) => {
        if (!product) { toast('Elegí el producto.', 'warn'); return; }
        try {
          const r = await saveLot({ id: l && l.id, product_id: product.id, branch_id: $('#lf-b', w) ? $('#lf-b', w).value : ctx.branchId, lot: $('#lf-l', w).value, expires_at: $('#lf-e', w).value, qty: parseNum($('#lf-c', w).value), notes: photo ? 'Leído con foto' : '' });
          toast('Vencimiento guardado.'); close(r);
        } catch (e) { toast(e.message, 'error'); }
      } },
    ],
  });
}

/**
 * Modo seguido para la góndola: escanear el código (cámara o lector) → foto de la fecha → cantidad → "Guardar y seguir".
 * Cada uno crea un lote en la sucursal de este equipo.
 */
async function gondola() {
  const { productByCode } = await import('./productos.js');
  let product = null, saved = 0;
  return modal({
    title: 'Vencimientos en la góndola',
    size: 'wide',
    body: html`<div class="venc-seguido" id="vs">
      <p class="muted small">Por cada producto: 1) escaneá el código, 2) sacale una foto a la fecha, 3) poné la cantidad y “Guardar y seguir”.${multiBranch() ? ` Se carga en ${branchName(ctx.branchId)}.` : ''}</p>
      <div class="venc-step"><span class="n">1</span> Producto: <span id="vs-prod" class="grow">—</span></div>
      <div class="field searchbox${canScan() ? ' has-scan' : ''}">${ic('search')}<label class="sr-only" for="vs-q">Código o nombre</label>
        <input id="vs-q" type="search" placeholder="Código (lector), nombre o escanear" autocomplete="off">${scanButton('data-vscan id="vs-scan"', 'Escanear con la cámara')}</div>
      <div id="vs-res" class="results"></div>
      <div class="venc-step off" id="vs-s2"><span class="n">2</span> Vencimiento</div>
      <div class="btn-row"><button type="button" class="btn primary" data-vsphoto id="vs-photo" disabled>${ic('camera')} Sacar foto de la fecha</button></div>
      <p id="vs-read" class="small" aria-live="polite"></p>
      <div class="grid2"><div class="field"><label for="vs-e">Vence</label><input type="date" id="vs-e"></div>
        <div class="field"><label for="vs-l">Lote (opcional)</label><input id="vs-l" autocomplete="off"></div></div>
      <div class="venc-step off" id="vs-s3"><span class="n">3</span> Cantidad</div>
      <div class="grid2"><div class="field"><label for="vs-c">Cantidad de este vencimiento</label><input id="vs-c" inputmode="decimal" autocomplete="off"></div>
        <div class="field" style="align-self:end"><button type="button" class="btn primary big block" data-vssave id="vs-save" disabled>Guardar y seguir</button></div></div>
      <p id="vs-done" class="lead" aria-live="polite"></p>
    </div>`,
    onMount(m) {
      const q = $('#vs-q', m);
      const step = () => {
        $('#vs-s2', m).classList.toggle('off', !product);
        $('#vs-photo', m).disabled = !product;
        const ok = product && $('#vs-e', m).value;
        $('#vs-s3', m).classList.toggle('off', !ok);
        $('#vs-save', m).disabled = !ok;
      };
      const pick = p => {
        product = p;
        $('#vs-prod', m).innerHTML = String(html`<b>${p.name}</b> <span class="muted small">stock ${fmtQty(Math.max(0, stockOf(p)))}</span>`);
        $('#vs-res', m).innerHTML = ''; q.value = '';
        $('#vs-e', m).value = ''; $('#vs-l', m).value = ''; $('#vs-c', m).value = ''; $('#vs-read', m).textContent = '';
        step();
        $('#vs-photo', m).focus();
      };
      const byText = () => {
        const t = q.value.trim();
        if (!t) return;
        const p = productByCode(t) || (searchProducts(db.all('products'), t, 2).length === 1 ? searchProducts(db.all('products'), t, 1)[0] : null);
        if (p) pick(p); else if (/^\d{6,}$/.test(t)) { playError(); toast(`No hay ningún producto con el código ${t}.`, 'warn'); }
      };
      q.addEventListener('input', () => { $('#vs-res', m).innerHTML = q.value.trim() && !/^\d+$/.test(q.value.trim()) ? String(html`${searchProducts(db.all('products'), q.value, 6).map(p => html`<button type="button" class="result" data-vsp="${p.id}"><span class="grow">${p.name}</span></button>`)}`) : ''; });
      q.addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); byText(); } });
      $('#vs-e', m).addEventListener('input', step);
      $('#vs-c', m).addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); $('#vs-save', m).click(); } });
      m.addEventListener('click', async e => {
        const b = e.target.closest('[data-vsp]'); if (b) pick(db.get('products', b.dataset.vsp));
        if (e.target.closest('[data-vscan]')) {
          await openScanner({ title: 'Escanear el producto', onCode: async code => { const p = productByCode(code); if (!p) { playError(); toast(`No hay ningún producto con el código ${code}.`, 'warn'); return 'continue'; } pick(p); return 'close'; } });
        }
        if (e.target.closest('[data-vsphoto]') && product) {
          const out = $('#vs-read', m);
          const r = await readExpiryPhoto(m, product.barcode || '', t => { out.textContent = t; });
          if (!r) { $('#vs-e', m).focus(); return; }
          $('#vs-e', m).value = r.fecha_vencimiento;
          if (r.lote) $('#vs-l', m).value = r.lote;
          out.innerHTML = String(html`${ic('check')} Vence <b>${dmy(r.fecha_vencimiento)}</b>${r.lote ? ` · lote ${r.lote}` : ''}${r.ean_distinto ? ' · ojo: el código de la foto es de otro producto' : ''}.`);
          step();
          $('#vs-c', m).focus();
        }
        if (e.target.closest('[data-vssave]') && product) {
          try {
            await saveLot({ product_id: product.id, branch_id: ctx.branchId, lot: $('#vs-l', m).value, expires_at: $('#vs-e', m).value, qty: parseNum($('#vs-c', m).value), notes: 'Góndola' });
            saved += 1;
            $('#vs-done', m).innerHTML = String(html`${ic('check')} ${product.name}: guardado. Van <b id="vs-count">${saved}</b> ${saved === 1 ? 'cargado' : 'cargados'}.`);
            product = null;
            $('#vs-prod', m).textContent = '—';
            $('#vs-e', m).value = ''; $('#vs-l', m).value = ''; $('#vs-c', m).value = ''; $('#vs-read', m).textContent = '';
            step();
            q.focus();
          } catch (er) { toast(er.message, 'error'); $('#vs-c', m).focus(); }
        }
      });
      step();
    },
    actions: [{ label: 'Terminar', kind: 'primary', value: true }],
  });
}
