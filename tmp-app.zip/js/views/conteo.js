// =====================================================================
// conteo.js — Contar stock en góndola con la cámara del celu.
// Se escanea cada producto, se escribe cuántos hay y al final se aplica: el stock de la
// sucursal de ESTE equipo queda igual a lo contado (stock_moves "conteo"). Las otras
// sucursales no se tocan. El borrador se guarda en IndexedDB (meta) a cada paso, así no se
// pierde si el celu se bloquea o se cierra la app.
// =====================================================================
import * as db from '../db.js';
import { ctx, stockOf, currentBranch, multiBranch, applyStockCount } from '../ops.js';
import { html, $, on, ic, modal, toast, fieldError, confirm, exportTable } from '../ui.js';
import { fmtMoney, fmtQty, fmtDateTime, parseNum, round3, searchProducts, countMerge, countSummary, can } from '../logic.js';
import { openScanner, canScan, playError } from '../scanner.js';
import { productForm, productByCode } from './productos.js';
import { audit } from '../seguridad.js';

let main;
let asking = false; // hay un conteo guardado y todavía no se eligió seguirlo o empezar otro
// Conteo que ya se eligió seguir (o se empezó) en esta sesión: si la pantalla se vuelve a dibujar (por ejemplo, llegan
// datos de la nube mientras se cuenta) no se vuelve a preguntar "¿Seguir conteo?" ni se pierde lo que se estaba buscando.
let resumed = null;
let draft = null; // {branch_id, mode: 'replace'|'add', started_at, user_id, lines: [{product_id, name, unit, counted, updated_at}]}

const draftKey = () => 'count_draft:' + ctx.branchId;
const branchLabel = () => (currentBranch() || {}).name || '';
const unitTxt = u => (u === 'kg' ? ' kg' : '');
const MODES = {
  replace: { label: 'Reemplazar por lo contado', hint: 'Si escaneás otra vez el mismo producto, vale el último número que escribas.' },
  add: { label: 'Sumar conteos', hint: 'Si el mismo producto está en dos lugares de la góndola, el segundo conteo se suma al primero de este conteo (no al stock viejo).' },
};

async function loadDraft() {
  const d = await db.getMeta(draftKey(), null);
  draft = d && d.branch_id === ctx.branchId && Array.isArray(d.lines) ? d : null;
}
async function saveDraft() {
  if (draft) draft.updated_at = Date.now();
  await db.setMeta(draftKey(), draft);
}

export async function render(m) {
  main = m;
  await loadDraft();
  asking = !!draft && draft.started_at !== resumed;
  paint();
  return on(main, 'click', '[data-act], [data-line], [data-pick]', (e, el) => {
    if (el.dataset.line) return editLine(el.dataset.line);
    if (el.dataset.pick) return pickFromSearch(el.dataset.pick);
    act(el.dataset.act);
  });
}

// ---------- Pantalla ----------

/** Líneas con el stock actual del sistema (de esta sucursal) y el costo */
function enriched() {
  return draft.lines.map(l => {
    const p = db.get('products', l.product_id);
    return { ...l, system: p ? stockOf(p) : 0, cost: p ? Number(p.cost) || 0 : 0, code: p ? (p.barcode || p.sku || '') : '', name: p ? p.name : l.name };
  });
}

function paint() {
  if (!main || !main.isConnected) return;
  if (!draft || asking) { paintStart(); return; }
  const prevQ = ($('#ct-q', main) || {}).value || '';
  const sum = countSummary(enriched());
  const showCost = can(ctx.user, 'ver_costos');
  main.innerHTML = String(html`
    <div class="page-head"><h1>Contar stock</h1><a class="btn ghost sm" href="#/productos">${ic('back')} Productos</a></div>
    <p class="muted" id="ct-info">${multiBranch() ? html`${ic('store')} Sucursal <b>${branchLabel()}</b> · ` : ''}Modo: <b>${MODES[draft.mode].label}</b> · Empezado ${fmtDateTime(draft.started_at)}</p>
    ${canScan() ? html`<button type="button" class="btn primary big block" data-act="scan" id="ct-scan">${ic('camera')} Escanear producto</button>` : ''}
    <form class="field searchbox" id="ct-sform" role="search" style="margin-top:.75rem">${ic('search')}
      <label class="sr-only" for="ct-q">Buscar por nombre o escribir el código</label>
      <input id="ct-q" type="search" autocomplete="off" enterkeyhint="go" placeholder="Buscar por nombre o escribir el código"></form>
    <div id="ct-res" class="results hidden"></div>
    <section class="card" style="margin-top:1rem" aria-labelledby="ct-h">
      <div class="card-head"><h2 id="ct-h">Conteo ${sum.counted ? html`<span class="badge">${sum.counted}</span>` : ''}</h2></div>
      <div class="stats" id="ct-stats">
        <div class="stat"><div class="k">Contados</div><div class="v" id="ct-n">${sum.counted}</div></div>
        <div class="stat"><div class="k">Faltantes</div><div class="v" style="color:var(--danger)" id="ct-falt">${sum.faltantes}</div></div>
        <div class="stat"><div class="k">Sobrantes</div><div class="v" style="color:var(--brand)" id="ct-sobr">${sum.sobrantes}</div></div>
        ${showCost ? html`<div class="stat"><div class="k">Diferencia a costo</div><div class="v money" id="ct-val">${fmtMoney(sum.value)}</div></div>` : ''}
      </div>
      ${sum.counted ? html`<ul class="list" id="ct-list">${sum.lines.map(l => html`<li>
        <button type="button" class="row" data-line="${l.product_id}" aria-label="${l.name}: sistema ${fmtQty(l.system)}, contado ${fmtQty(l.counted)}, diferencia ${fmtQty(l.diff)}. Tocá para corregir">
          <span class="grow"><span class="title">${l.name}</span>
            <span class="sub" style="display:block">Sistema ${fmtQty(l.system)}${unitTxt(l.unit)} · Contado <b>${fmtQty(l.counted)}${unitTxt(l.unit)}</b></span></span>
          <span class="ct-diff ${l.diff < 0 ? 'down' : l.diff > 0 ? 'up' : ''}" data-diff="${l.product_id}">${l.diff > 0 ? '+' : l.diff < 0 ? '−' : ''}${fmtQty(Math.abs(l.diff))}</span>
        </button></li>`)}</ul>`
        : html`<p class="empty">Todavía no contaste nada. Tocá <b>Escanear producto</b> o buscalo por nombre.</p>`}
    </section>
    <div class="btn-row" style="margin-top:1rem">
      <button type="button" class="btn primary big" data-act="finish" id="ct-finish" ${sum.counted ? '' : 'disabled'}>${ic('check')} Terminar y aplicar</button>
      <button type="button" class="btn ghost" data-act="sheet" ${sum.counted ? '' : 'disabled'}>${ic('download')} Descargar planilla</button>
      <button type="button" class="btn outline-danger" data-act="discard">${ic('trash')} Descartar conteo</button>
    </div>`);
  const q = $('#ct-q', main);
  if (prevQ) { q.value = prevQ; paintResults(prevQ); }
  let t;
  q.addEventListener('input', () => { clearTimeout(t); t = setTimeout(() => paintResults(q.value), 120); });
  $('#ct-sform', main).addEventListener('submit', e => { e.preventDefault(); onEnter(q.value); });
}

function paintStart() {
  main.innerHTML = String(html`
    <div class="page-head"><h1>Contar stock en góndola</h1><a class="btn ghost sm" href="#/productos">${ic('back')} Productos</a></div>
    <section class="card">
      ${draft ? html`<div class="notice notice-info ct-resume"><p>Tenés un conteo sin terminar del <b>${fmtDateTime(draft.started_at)}</b>
          (${draft.lines.length} ${draft.lines.length === 1 ? 'producto' : 'productos'} · ${MODES[draft.mode].label}).</p>
        <button type="button" class="btn primary big block" data-act="resume" id="ct-resume">${ic('check')} Seguir conteo del ${fmtDateTime(draft.started_at)}</button></div>
        <h2>O empezar uno nuevo</h2>` : ''}
      <p class="lead">Escaneá cada producto de la góndola y escribí cuántos hay.</p>
      <p>Al terminar, el stock${multiBranch() ? html` de <b>${branchLabel()}</b>` : ''} queda igual a lo contado. Los productos que no contás no cambian${multiBranch() ? ' y las otras sucursales no se tocan' : ''}.
        Si se bloquea el celu o se cierra la app, el conteo queda guardado.</p>
      <fieldset class="seg" id="ct-mode"><legend>Si el mismo producto se cuenta dos veces…</legend>
        <label><input type="radio" name="ct-mode" value="replace" checked><span>Reemplazar por lo contado</span></label>
        <label><input type="radio" name="ct-mode" value="add"><span>Sumar conteos</span></label></fieldset>
      <p class="hint muted" id="ct-mode-hint">${MODES.replace.hint}</p>
      <button type="button" class="btn primary big block" data-act="start" id="ct-start">${ic('camera')} ${draft ? 'Empezar un conteo nuevo' : 'Empezar a contar'}</button>
    </section>`);
  $('#ct-mode', main).addEventListener('change', e => { $('#ct-mode-hint', main).textContent = MODES[e.target.value].hint; });
}

function paintResults(v) {
  const box = $('#ct-res', main);
  if (!box) return;
  if (!v.trim()) { box.classList.add('hidden'); box.innerHTML = ''; return; }
  const list = searchProducts(db.all('products'), v, 20);
  box.classList.remove('hidden');
  box.innerHTML = list.length ? String(html`${list.map(p => html`<button type="button" class="result" data-pick="${p.id}">
      <span class="grow"><span class="title">${p.name}</span><span class="sub small muted" style="display:block">${p.barcode || p.sku || p.category || ''} · Stock ${fmtQty(stockOf(p))}${unitTxt(p.unit)}</span></span></button>`)}`)
    : String(html`<div class="empty">No encontramos “${v}”.</div>`);
}

function clearSearch() {
  const q = $('#ct-q', main);
  if (q) { q.value = ''; paintResults(''); }
}

// ---------- Acciones ----------

async function act(name) {
  if (name === 'resume') { asking = false; resumed = draft && draft.started_at; paint(); return; }
  if (name === 'start') {
    if (draft && draft.lines.length && !(await confirm(`Se descarta el conteo del ${fmtDateTime(draft.started_at)} (${draft.lines.length} productos) sin cambiar ningún stock. ¿Empezamos uno nuevo?`, { danger: true, ok: 'Empezar nuevo' }))) return;
    asking = false;
    const mode = main.querySelector('[name=ct-mode]:checked').value;
    draft = { branch_id: ctx.branchId, mode, started_at: Date.now(), user_id: ctx.user.id, lines: [] };
    resumed = draft.started_at;
    await saveDraft();
    paint();
    if (canScan()) scanLoop();
    return;
  }
  if (name === 'scan') return scanLoop();
  if (name === 'finish') return finish();
  if (name === 'sheet') return downloadSheet();
  if (name === 'discard') {
    if (!(await confirm('¿Descartar este conteo? No se cambia ningún stock.', { danger: true, ok: 'Descartar' }))) return;
    draft = null;
    await saveDraft();
    paint();
  }
}

async function onEnter(v) {
  v = v.trim();
  if (!v) return;
  const p = productByCode(v);
  if (p) { clearSearch(); await countProduct(p, false); return; }
  const list = searchProducts(db.all('products'), v, 2);
  if (list.length === 1) { clearSearch(); await countProduct(list[0], false); return; }
  if (/^\d{6,14}$/.test(v)) { clearSearch(); await unknownCode(v, false); }
}

async function pickFromSearch(id) {
  const p = db.get('products', id);
  clearSearch();
  if (p) await countProduct(p, false);
}

/**
 * Cámara: lee un código → pide la cantidad → vuelve a abrir la cámara sola,
 * hasta que se cancela la cámara o se toca "Guardar" (sin "escanear otro").
 */
async function scanLoop() {
  for (;;) {
    let code = null;
    await openScanner({
      title: 'Contar stock',
      hint: 'Escaneá un producto de la góndola. Después escribís cuántos hay.',
      onCode: c => { code = c; return 'close'; },
    });
    if (!code || !main.isConnected || !draft) return;
    const p = productByCode(code);
    const r = p ? await countProduct(p, true) : await unknownCode(code, true);
    if (r !== 'next') return;
  }
}

/** Código que no está cargado: crear el producto o seguir. Devuelve 'next' para seguir escaneando. */
async function unknownCode(code, fromScan) {
  playError();
  const r = await modal({
    title: 'Código no encontrado',
    body: html`<p class="lead">No encontramos el código <b id="ct-nf">${code}</b>.</p><p class="muted">Podés crear el producto ahora (con el código ya cargado) y contarlo.</p>`,
    actions: [
      { label: fromScan ? 'Terminar' : 'Cerrar', value: 'stop' },
      ...(fromScan ? [{ label: 'Seguir', value: 'next', id: 'ct-nf-next' }] : []),
      { label: 'Crear producto', kind: 'primary', value: 'create', id: 'ct-nf-create' },
    ],
  });
  if (r !== 'create') return r;
  const p = await productForm({ barcode: code });
  if (!p || !p.id || p.deleted) return fromScan ? 'next' : null;
  return countProduct(p, fromScan);
}

/** Pide la cantidad de un producto y la anota en el conteo. Devuelve 'next' | 'stop' | null. */
async function countProduct(p, fromScan) {
  if (!draft) return null;
  const ex = draft.lines.find(l => l.product_id === p.id);
  const r = await qtyDialog(p, { ex, fromScan });
  if (!r) return null;
  const now = Date.now();
  const counted = countMerge(ex ? ex.counted : null, r.qty, draft.mode);
  if (ex) { ex.counted = counted; ex.updated_at = now; draft.lines = [ex, ...draft.lines.filter(l => l !== ex)]; }
  else draft.lines.unshift({ product_id: p.id, name: p.name, unit: p.unit || 'u', counted, updated_at: now });
  await saveDraft();
  paint();
  toast(`${p.name.slice(0, 36)}: ${fmtQty(counted)}${unitTxt(p.unit)} contados`, 'ok', 1500);
  return r.then;
}

/** Corregir o borrar una línea del conteo (siempre reemplaza lo contado) */
async function editLine(id) {
  const ex = draft && draft.lines.find(l => l.product_id === id);
  if (!ex) return;
  const p = db.get('products', id) || { id, name: ex.name, unit: ex.unit, stock: 0 };
  const r = await qtyDialog(p, { ex, editing: true });
  if (!r) return;
  if (r.then === 'delete') draft.lines = draft.lines.filter(l => l !== ex);
  else { ex.counted = round3(r.qty); ex.updated_at = Date.now(); }
  await saveDraft();
  paint();
}

/** Ventana con la cantidad: número grande y teclado numérico grande */
function qtyDialog(p, { ex = null, fromScan = false, editing = false } = {}) {
  const kg = p.unit === 'kg';
  const coarse = window.matchMedia('(pointer: coarse)').matches;
  const keys = ['7', '8', '9', '4', '5', '6', '1', '2', '3', kg ? ',' : '', '0', 'del'];
  const read = (close, w, then) => {
    const inp = $('#ct-qty', w);
    const q = parseNum(inp.value);
    if (inp.value.trim() === '' || !isFinite(q) || q < 0) return fieldError(inp, 'Escribí cuántos hay (puede ser 0).');
    if (!kg && Math.round(q) !== q) return fieldError(inp, 'Este producto va por unidad: escribí un número entero.');
    close({ qty: round3(q), then });
  };
  const actions = editing
    ? [{ label: 'Borrar del conteo', kind: 'outline-danger', value: { then: 'delete' }, id: 'ct-del' },
      { label: 'Guardar', kind: 'primary', id: 'ct-ok', onClick: (c, w) => read(c, w, 'stop') }]
    : fromScan
      ? [{ label: 'Guardar y terminar', id: 'ct-save', onClick: (c, w) => read(c, w, 'stop') },
        { label: 'Guardar y escanear otro', kind: 'primary', id: 'ct-ok', onClick: (c, w) => read(c, w, 'next') }]
      : [{ label: 'Cancelar', value: null }, { label: 'Guardar', kind: 'primary', id: 'ct-ok', onClick: (c, w) => read(c, w, 'stop') }];
  const already = ex && !editing
    ? html`<p class="ct-already" id="ct-already">Ya contaste <b>${fmtQty(ex.counted)}${unitTxt(p.unit)}</b>: ${draft.mode === 'add' ? 'lo que escribas se SUMA.' : 'lo que escribas lo REEMPLAZA.'}</p>` : '';
  return modal({
    title: p.name,
    body: html`
      <div class="ct-sys"><span>Stock en el sistema${multiBranch() ? ` (${branchLabel()})` : ''}</span><b id="ct-sys">${fmtQty(stockOf(p))}${unitTxt(p.unit)}</b></div>
      ${already}
      <form id="ct-form" novalidate>
        <label for="ct-qty" class="ct-qty-label">${editing ? 'Cantidad contada' : 'Cantidad que hay'}${kg ? ' (kilos)' : ''}</label>
        <input id="ct-qty" class="ct-qty" inputmode="${coarse ? 'none' : 'decimal'}" autocomplete="off" value="${editing ? fmtQty(ex.counted) : ''}" placeholder="0">
        <div class="keypad" role="group" aria-label="Teclado numérico">${keys.map(k => k === ''
          ? html`<span></span>`
          : html`<button type="button" class="key" data-k="${k}" aria-label="${k === 'del' ? 'Borrar' : k}">${k === 'del' ? '⌫' : k}</button>`)}</div>
      </form>`,
    actions,
    onMount(m) {
      const inp = $('#ct-qty', m);
      m.addEventListener('click', e => {
        const b = e.target.closest('[data-k]');
        if (!b) return;
        const k = b.dataset.k;
        if (k === 'del') inp.value = inp.value.slice(0, -1);
        else if (k === ',') { if (!inp.value.includes(',')) inp.value = (inp.value || '0') + ','; }
        else inp.value += k;
        inp.dispatchEvent(new Event('input', { bubbles: true }));
        inp.focus({ preventScroll: true });
      });
      $('#ct-form', m).addEventListener('submit', e => { e.preventDefault(); $('#ct-ok', m.parentElement).click(); });
      if (editing) setTimeout(() => inp.select(), 40);
    },
  });
}

// ---------- Terminar ----------

async function finish() {
  if (!draft || !draft.lines.length) { toast('Todavía no contaste ningún producto.', 'warn'); return; }
  const sum = countSummary(enriched());
  const changes = sum.lines.filter(l => l.diff !== 0);
  const showCost = can(ctx.user, 'ver_costos');
  const ok = await modal({
    title: 'Terminar y aplicar',
    size: 'wide',
    body: html`
      <div class="stats" id="ct-sum">
        <div class="stat"><div class="k">Productos contados</div><div class="v" id="cs-n">${sum.counted}</div></div>
        <div class="stat"><div class="k">Faltantes</div><div class="v" style="color:var(--danger)" id="cs-falt">${sum.faltantes}</div></div>
        <div class="stat"><div class="k">Sobrantes</div><div class="v" style="color:var(--brand)" id="cs-sobr">${sum.sobrantes}</div></div>
        ${showCost ? html`<div class="stat"><div class="k">Diferencia a costo</div><div class="v money" id="cs-val">${fmtMoney(sum.value)}</div></div>` : ''}
      </div>
      ${changes.length ? html`<div class="table-wrap"><table><thead><tr><th>Producto</th><th class="r">Sistema</th><th class="r">Contado</th><th class="r">Dif.</th></tr></thead><tbody>
        ${changes.map(l => html`<tr><td style="white-space:normal">${l.name}</td><td class="r">${fmtQty(l.system)}</td><td class="r">${fmtQty(l.counted)}</td>
          <td class="r" style="font-weight:800;color:${l.diff < 0 ? 'var(--danger)' : 'var(--brand)'}">${l.diff > 0 ? '+' : '−'}${fmtQty(Math.abs(l.diff))}</td></tr>`)}</tbody></table></div>`
        : html`<p>Todo lo contado coincide con el sistema.</p>`}
      <div class="notice notice-info" style="margin-top:1rem"><p>Se van a cambiar <b>${changes.length}</b> productos: su stock${multiBranch() ? html` en <b>${branchLabel()}</b>` : ''} queda igual a lo contado.
        Los productos que no contaste no cambian${multiBranch() ? '. Las otras sucursales no se tocan' : ''}.</p></div>`,
    actions: [
      { label: 'Volver', value: false },
      { label: 'Descargar planilla', onClick: () => downloadSheet() },
      { label: 'Aplicar conteo', kind: 'primary', id: 'ct-apply', onClick: async (close, w) => {
        const b = $('#ct-apply', w);
        b.disabled = true; b.textContent = 'Aplicando…';
        try {
          const res = await applyStockCount(draft.lines);
          await audit('conteo_stock', 'stock_moves', res.ref_id, { lines: draft.lines.length, changed: res.changed });
          close(res);
        } catch (e) { toast(e.message, 'error'); b.disabled = false; b.textContent = 'Aplicar conteo'; }
      } },
    ],
  });
  if (!ok) return;
  draft = null;
  await saveDraft();
  toast(`Conteo aplicado: ${ok.changed} ${ok.changed === 1 ? 'producto cambió' : 'productos cambiaron'} de stock.`, 'ok', 4000);
  if (main.isConnected) location.hash = '#/productos';
}

async function downloadSheet() {
  if (!draft || !draft.lines.length) return;
  const sum = countSummary(enriched());
  const rows = [['codigo', 'producto', 'unidad', 'sistema', 'contado', 'diferencia', 'costo', 'diferencia_a_costo']];
  for (const l of sum.lines) rows.push([l.code, l.name, l.unit, l.system, l.counted, l.diff, l.cost, Math.round(l.diff * l.cost * 100) / 100]);
  const day = new Date().toISOString().slice(0, 10);
  const br = multiBranch() ? '-' + branchLabel().replace(/[^\w-]+/g, '_') : '';
  await exportTable(`conteo${br}-${day}`, 'Conteo', rows);
}
