// =====================================================================
// ajustes.js — Comercio, facturación ARCA, usuarios, nube, copias, impresora.
// =====================================================================
import * as db from '../db.js';
import * as sync from '../sync.js';
import { ctx, settings, saveSettings, saveUser, branches, saveBranch, currentBranch, multiBranch, mainBranchId, resetPreview, resetAll } from '../ops.js';
import { html, $, on, ic, modal, toast, formData, fieldError, confirm, pickFile, alertBox, download } from '../ui.js';
import { generateCsr, cleanAlias } from '../csr.js';
import { can, ROLES, validCuit, validPin, pinMin, fmtDateTime, parseNum, PERMS, PERM_GROUPS, roleCan, permsDiff, permsChanges, discountMax } from '../logic.js';
import * as backup from '../backup.js';
import { cloudDialog } from './login.js';
import { soundSettings, setSoundSettings, unlockAudio, playBeep, playError } from '../scanner.js';
import { storageState, storageText } from '../durability.js';
import { audit } from '../seguridad.js';

let main, app;

export async function render(m, a) {
  main = m; app = a;
  await paint();
  return on(main, 'click', '[data-act]', (e, el) => act(el.dataset.act, el));
}

const ENV_INFO = {
  off: 'Desactivada: solo tickets no fiscales. La app nunca inventa un CAE.',
  homo: 'Homologación (pruebas): las facturas van al ambiente de pruebas de ARCA y NO tienen validez. Ideal para probar antes de arrancar.',
  prod: 'Producción: facturas reales con CAE válido ante ARCA. Necesita el certificado de producción cargado.',
};

/** Recordatorio de copia para el modo "solo en este dispositivo" */
export async function backupNotice() {
  if (sync.isConfigured()) return '';
  const last = await db.getMeta('last_backup', 0);
  return html`<div class="notice notice-warn"><p><b>Solo en este dispositivo — hacé copias.</b> Si se rompe o se borra el navegador, se pierden los datos.
    ${last ? `Última copia: ${fmtDateTime(last)}.` : 'Todavía no hiciste ninguna copia.'}</p>
    <p><button type="button" class="btn primary sm" data-act="backup">${ic('download')} Hacer copia de seguridad</button></p></div>`;
}

/** Descarga la copia de seguridad completa en JSON */
export async function doBackup() {
  await backup.downloadBackup();
  toast('Copia descargada. Guardala en un lugar seguro.');
}

/** Sección "Copia de seguridad": descarga manual y, para el dueño, copia automática diaria a una carpeta */
async function backupSection(owner) {
  const bi = await backup.info();
  const last = bi.lastBackup ? fmtDateTime(bi.lastBackup) : 'nunca';
  let auto = '';
  if (owner && bi.supported) {
    const la = bi.lastAuto;
    auto = html`<h3 style="margin-top:1.25rem">Copia automática diaria</h3>
      <p>La app guarda sola, una vez por día, una copia completa en una carpeta de esta PC (por ejemplo <b>OneDrive\\Respaldo JEANO Gestión</b>, así también queda en la nube de Microsoft).
        Se guardan las últimas ${bi.keep} copias y las más viejas se borran solas.</p>
      ${bi.configured ? html`<ul class="list" id="bk-auto">
          <li class="row"><span class="grow">Carpeta</span><b id="bk-folder">${bi.folder}</b></li>
          <li class="row"><span class="grow">Última copia automática</span><b id="bk-last-auto">${la ? fmtDateTime(la.at) : 'Todavía ninguna'}</b></li>
          ${la ? html`<li class="row"><span class="grow">Archivo</span><span class="small" id="bk-file">${la.file}</span></li>` : ''}
        </ul>
        ${bi.permission !== 'granted' || bi.status === 'needs-permission' ? html`<div class="notice notice-warn"><p><b>La copia automática está en pausa.</b> El navegador pide permiso otra vez para guardar en esa carpeta. Es un clic.</p>
          <p><button type="button" class="btn primary sm" data-act="bk-regrant">${ic('check')} Volver a permitir</button></p></div>` : ''}
        ${bi.status === 'error' ? html`<div class="notice notice-error"><p>No se pudo guardar la última copia: ${bi.error}</p></div>` : ''}
        <div class="btn-row"><button type="button" class="btn ghost" data-act="bk-now">${ic('download')} Hacer copia ahora</button>
          <button type="button" class="btn ghost" data-act="bk-folder">Cambiar carpeta</button>
          <button type="button" class="btn outline-danger" data-act="bk-forget">Dejar de copiar</button></div>`
      : html`<p class="muted">Elegí la carpeta una sola vez. Si el navegador vuelve a pedir permiso, la app te avisa con un botón.</p>
        <button type="button" class="btn primary" data-act="bk-folder">${ic('download')} Elegir carpeta</button>`}`;
  } else if (owner) {
    auto = html`<div class="notice notice-info" style="margin-top:1rem"><p><b>Copia automática:</b> este navegador no permite guardar copias solas en una carpeta (pasa en el celular, Firefox y Safari).
      Para eso abrí la app en <b>Chrome o Edge en la PC</b>. Mientras tanto, usá “Descargar copia” al menos una vez por semana: la app te lo recuerda.</p></div>`;
  }
  return html`<section class="card" id="aj-backup" aria-labelledby="h-bk"><h2 id="h-bk">Copia de seguridad</h2>
      <p>Bajá un archivo con todos los datos (productos, ventas, caja, clientes…). Guardalo en el mail, Drive o un pendrive.</p>
      <p>Última copia: <b id="bk-last">${last}</b></p>
      <div class="btn-row"><button type="button" class="btn primary" data-act="backup">${ic('download')} Descargar copia</button>
        ${owner ? html`<button type="button" class="btn ghost" data-act="restore">${ic('upload')} Restaurar una copia</button>` : ''}</div>
      ${auto}
    </section>`;
}

/** Sección "Empezar de cero" (solo dueño) */
function resetSection() {
  return html`<section class="card" id="aj-reset" aria-labelledby="h-rs"><h2 id="h-rs">Empezar de cero</h2>
    <p>Para cuando termina la prueba en paralelo con el sistema anterior: borra las <b>ventas, cajas, movimientos de caja, compras y movimientos de stock</b>, y deja en $ 0 las cuentas corrientes de los clientes.</p>
    <p>Quedan <b>productos, precios, costos, categorías, proveedores, clientes, usuarios, sucursales, datos del comercio y facturación ARCA</b>. Antes de borrar se descarga una copia completa.</p>
    <button type="button" class="btn outline-danger" data-act="reset">${ic('trash')} Empezar de cero…</button>
  </section>`;
}

async function resetDialog() {
  const cloud = sync.isConfigured();
  const pv = resetPreview();
  const n = (x, one, many) => `${x} ${x === 1 ? one : many}`;
  const total = Object.values(pv.counts).reduce((a, b) => a + b, 0);
  await modal({
    title: 'Empezar de cero',
    body: html`<div id="rs-body">
      <p class="lead">Se van a borrar${cloud ? ' en todos los equipos y en la nube' : ''}:</p>
      <ul id="rs-list">
        <li>${n(pv.counts.sales, 'venta', 'ventas')}</li>
        <li>${n(pv.counts.cash_sessions, 'caja', 'cajas')} y ${n(pv.counts.cash_movements, 'movimiento de caja', 'movimientos de caja')}</li>
        <li>${n(pv.counts.purchases, 'compra', 'compras')} y ${n(pv.counts.stock_moves, 'movimiento de stock', 'movimientos de stock')}</li>
        ${pv.counts.returns || pv.counts.transfers ? html`<li>${n(pv.counts.returns || 0, 'devolución', 'devoluciones')} y ${n(pv.counts.transfers || 0, 'remito', 'remitos')}</li>` : ''}
        <li>${pv.customers ? `Saldo de cuenta corriente de ${n(pv.customers, 'cliente', 'clientes')} (queda en $ 0)` : 'Saldos de cuenta corriente (ya están en $ 0)'}</li>
        ${pv.counts.customer_payments || pv.counts.supplier_payments ? html`<li>${n(pv.counts.customer_payments || 0, 'cobro', 'cobros')} de clientes y ${n(pv.counts.supplier_payments || 0, 'pago', 'pagos')} a proveedores</li>` : ''}
        ${pv.suppliers ? html`<li>Cuenta corriente de ${n(pv.suppliers, 'proveedor', 'proveedores')}: queda en su saldo inicial (el traído de SGI), o en $ 0 si no tiene</li>` : ''}
      </ul>
      ${cloud ? html`<p class="small muted">Los números son de este equipo; en la nube se borra lo de todo el comercio.</p>` : ''}
      ${pv.keptInvoices ? html`<div class="notice notice-warn" id="rs-cae"><p><b>${pv.keptInvoices === 1 ? 'Hay 1 factura autorizada' : `Hay ${pv.keptInvoices} facturas autorizadas`} por ARCA (con CAE).</b>
        Las facturas con CAE no se pueden borrar: quedan como registro, marcadas “de prueba”, y no suman en los reportes ni en los totales de ventas.
        Si eran reales, anulalas con nota de crédito desde Ventas.</p></div>` : ''}
      <p>Quedan: productos, precios, costos, categorías, proveedores, clientes, usuarios, sucursales, datos del comercio y facturación ARCA.</p>
      <label class="check"><input type="checkbox" id="rs-stock" name="zero_stock"> Poner en 0 el stock de todos los productos, en todas las sucursales</label>
      <div class="notice notice-info"><p>${ic('download')} Antes de borrar se descarga sola una <b>copia de seguridad completa</b>. Guardala por si necesitás consultar algo de la etapa de prueba.</p>
        ${cloud ? html`<p>Hace falta internet: se borra en la nube y los otros equipos lo reciben cuando se sincronizan.</p>` : ''}</div>
      <div class="field"><label for="rs-word">Para confirmar, escribí <b>BORRAR</b></label>
        <input id="rs-word" autocomplete="off" autocapitalize="characters" spellcheck="false" style="max-width:240px"></div>
      ${sync.isDevice() ? html`<div class="field"><label for="rs-pass">Contraseña de la nube</label>
        <input id="rs-pass" type="password" autocomplete="current-password" autocapitalize="off" autocorrect="off" spellcheck="false" style="max-width:320px">
        <div class="hint">Para borrar todo en la nube se pide la contraseña del dueño (no alcanza con el PIN).</div></div>` : ''}
      <p id="rs-status" class="muted" aria-live="polite"></p>
    </div>`,
    actions: [{ label: 'Cancelar', value: null }, {
      label: 'Borrar todo', kind: 'danger', id: 'rs-go', onClick: async (close, w) => {
        const word = $('#rs-word', w);
        if (word.value.trim() !== 'BORRAR') return fieldError(word, 'Escribí BORRAR (en mayúsculas) para confirmar.');
        const zeroStock = $('#rs-stock', w).checked;
        const passIn = $('#rs-pass', w);
        if (passIn && !passIn.value) return fieldError(passIn, 'Escribí la contraseña de la nube.');
        const status = $('#rs-status', w);
        w.querySelectorAll('.modal-foot button, [data-close]').forEach(b => { b.disabled = true; });
        try {
          status.textContent = 'Descargando la copia de seguridad…';
          await backup.downloadBackup();
          const r = await resetAll({ zeroStock, password: passIn ? passIn.value : undefined, onProgress: t => { status.textContent = t; } });
          await audit('empezar_de_cero', '', '', { zero_stock: !!zeroStock }).catch(e => console.warn(e));
          close(true);
          const d = r.server ? r.server.deleted : r.local.counts;
          const kept = r.server ? r.server.kept_invoices : r.local.keptInvoices;
          const zeroed = r.server ? r.server.products_zeroed : r.local.products;
          await alertBox(html`<p><b>Listo, empezaste de cero.</b></p>
            <p>Se borraron ${n(d.sales || 0, 'venta', 'ventas')}, ${n(d.cash_sessions || 0, 'caja', 'cajas')}, ${n(d.purchases || 0, 'compra', 'compras')} y los movimientos de caja y de stock.${zeroStock ? ` El stock quedó en 0 (${n(zeroed || 0, 'producto', 'productos')}).` : ''}</p>
            ${kept ? html`<p>${kept === 1 ? 'Queda 1 factura con CAE' : `Quedan ${kept} facturas con CAE`} como registro, marcada${kept === 1 ? '' : 's'} “de prueba”.</p>` : ''}
            <p>La copia de seguridad se descargó antes de borrar.</p>`, { title: 'Empezar de cero', kind: 'ok' });
          app.rerender();
        } catch (e) {
          status.textContent = '';
          w.querySelectorAll('.modal-foot button, [data-close]').forEach(b => { b.disabled = false; });
          fieldError(null, 'No se pudo empezar de cero: ' + e.message);
        }
      },
    }],
  });
  return total;
}

async function paint() {
  const st = settings();
  const owner = can(ctx.user, 'comercio');
  const brs = branches({ includeInactive: true });
  const activeBrs = brs.filter(b => b.active !== 0);
  const multi = multiBranch();
  const cur = currentBranch();
  const width = await db.getMeta('ticket_width', '80');
  const cfg = sync.config();
  const s = sync.status;
  main.innerHTML = String(html`
    <div class="page-head"><h1>Ajustes</h1></div>
    ${await backupNotice()}
    <nav class="chips" aria-label="Secciones">
      ${owner ? html`<a class="chip" href="#aj-comercio">Comercio</a>
      <a class="chip" href="#aj-arca">Facturación</a>
      <a class="chip" href="#aj-branches">Sucursales</a>
      <a class="chip" href="#aj-users">Usuarios</a>
      <a class="chip" href="#aj-cloud">Nube</a>
      ${sync.isDevice() ? html`<a class="chip" href="#aj-devices">Equipos</a>` : ''}
      <a class="chip" href="#aj-ia">IA</a>` : multi ? html`<a class="chip" href="#aj-branches">Sucursal</a>` : ''}
      ${can(ctx.user, 'editar_productos') ? html`<a class="chip" href="#aj-precios">Precios</a>` : ''}
      <a class="chip" href="#aj-backup">Copias</a>
      <a class="chip" href="#aj-print">Impresora</a>
      ${owner ? html`<a class="chip" href="#aj-reset">Empezar de cero</a>` : ''}
    </nav>

    ${owner ? html`
    <section class="card" id="aj-comercio" aria-labelledby="h-com"><h2 id="h-com">Datos del comercio</h2>
      <form id="f-com" novalidate>
        <div class="grid2">
          <div class="field"><label for="s-bn">Nombre de fantasía</label><input id="s-bn" name="business_name" value="${st.business_name}"></div>
          <div class="field"><label for="s-ln">Razón social</label><input id="s-ln" name="legal_name" value="${st.legal_name}"></div>
          <div class="field"><label for="s-cuit">CUIT</label><input id="s-cuit" name="cuit" inputmode="numeric" value="${st.cuit}" placeholder="20-12345678-9"></div>
          <div class="field"><label for="s-iva">Condición IVA</label><select id="s-iva" name="iva_condition">
            ${[['MT', 'Monotributo'], ['RI', 'Responsable inscripto'], ['EX', 'Exento']].map(([v, l]) => html`<option value="${v}" ${st.iva_condition === v ? 'selected' : ''}>${l}</option>`)}</select></div>
          <div class="field"><label for="s-iibb">Ingresos Brutos</label><input id="s-iibb" name="iibb" value="${st.iibb}"></div>
          <div class="field"><label for="s-sd">Inicio de actividades</label><input id="s-sd" name="start_date" type="date" value="${st.start_date}"></div>
          <div class="field"><label for="s-ad">Dirección</label><input id="s-ad" name="address" value="${st.address}"></div>
          <div class="field"><label for="s-ph">Teléfono</label><input id="s-ph" name="phone" type="tel" value="${st.phone}"></div>
        </div>
        <div class="field"><label for="s-ft">Pie del ticket</label><input id="s-ft" name="ticket_footer" value="${st.ticket_footer}"></div>
        <button class="btn primary">Guardar datos</button>
      </form></section>

    <section class="card" id="aj-arca" aria-labelledby="h-arca"><h2 id="h-arca">Facturación electrónica ARCA</h2>
      <form id="f-arca" novalidate>
        <fieldset class="seg"><legend>Ambiente</legend>
          ${[['off', 'Desactivada'], ['homo', 'Pruebas'], ['prod', 'Producción']].map(([v, l]) => html`<label><input type="radio" name="arca_env" value="${v}" ${st.arca_env === v ? 'checked' : ''}><span>${l}</span></label>`)}
        </fieldset>
        <p class="notice notice-info" id="env-info">${ENV_INFO[st.arca_env] || ''}</p>
        ${activeBrs.length > 1 ? html`<p><b>Punto de venta:</b> cada sucursal factura con el suyo (los que diste de alta en ARCA para “Web services”).</p>
          <ul class="list">${activeBrs.map(b => html`<li class="row"><span class="grow">${b.name}</span><b>Pto. vta. ${b.pos_number}</b></li>`)}</ul>
          <p class="small muted">Se cambian en <a href="#aj-branches" data-jump>Sucursales</a>.</p>`
        : html`<div class="field"><label for="s-pos">Punto de venta (el que diste de alta en ARCA para “Web services”)</label><input id="s-pos" name="pos_number" inputmode="numeric" value="${activeBrs[0] ? activeBrs[0].pos_number : st.pos_number}" style="max-width:160px"></div>`}
        <p class="small muted">Tipo de comprobante automático: si sos Monotributo o Exento → Factura C. Si sos Responsable inscripto → Factura A a otro inscripto y Factura B al resto.</p>
        <button class="btn primary">Guardar facturación</button>
      </form>
      <h3 style="margin-top:1.25rem">Certificado digital</h3>
      <p class="muted">1) Tocá <b>Generar pedido</b>: baja un archivo <b>.csr</b> (y una copia de la clave <b>.key</b>). 2) En ARCA → Administración de Certificados Digitales → Agregar alias, subí el .csr y descargá el <b>.crt</b>. 3) Tocá <b>Cargar certificado</b> y elegí el .crt. Se guarda cifrado en la nube.</p>
      ${sync.isConfigured() ? html`<div class="btn-row">${owner ? html`<button type="button" class="btn ghost" data-act="csr">${ic('download')} Generar pedido de certificado</button>` : ''}<button type="button" class="btn ghost" data-act="cert">${ic('upload')} Cargar certificado</button>
        <button type="button" class="btn ghost" data-act="arca-status">Ver estado</button></div><div id="arca-st" aria-live="polite" style="margin-top:.75rem"></div>`
        : html`<div class="notice notice-warn"><p>Para facturar hace falta conectar la nube (abajo). Sin nube, la app emite solo comprobantes no fiscales.</p></div>`}
    </section>

    ${branchesSection(brs, cur)}

    <section class="card" id="aj-medios" aria-labelledby="h-md"><h2 id="h-md">Tarjetas y medios de pago</h2>
      <p class="small muted">Tarjetas de crédito y débito con su % de recargo y cuotas (como en SGI), y medios propios como “Coca Cola”.</p>
      <a class="btn ghost" href="#/medios" id="aj-medios-go">${ic('cash')} Tarjetas y medios de pago</a></section>

    <section class="card" id="aj-users" aria-labelledby="h-us"><div class="card-head"><h2 id="h-us">Usuarios</h2>
      <button type="button" class="btn primary sm" data-act="user-new">${ic('plus')} Nuevo usuario</button></div>
      <p class="small muted">Dueño: ve y cambia todo. Encargado: todo menos usuarios, nube y datos fiscales. Cajero: vende, caja y clientes; no ve costos, reportes ni ajustes. Vendedor: como el cajero, y sus ventas y cobros cuentan para su comisión.</p>
      <ul class="list" id="users-list">${db.all('users').sort((a, b) => String(a.name || '').localeCompare(String(b.name || ''), 'es')).map(u => html`<li class="user-li" style="display:flex;align-items:center;gap:.5rem" data-uid="${u.id}"><button type="button" class="row" style="flex:1;min-width:0" data-act="user-edit" data-id="${u.id}">
        <span class="avatar" aria-hidden="true">${u.name[0].toUpperCase()}</span>
        <span class="grow" style="min-width:0"><span class="title">${u.name}${u.id === ctx.user.id ? ' (vos)' : ''}</span><span class="sub" style="display:block">${ROLES[u.role] || u.role}${u.perms && Object.keys(u.perms).length ? ' · permisos cambiados' : ''}${u.active && pinMin(u.role) > 4 && (Number(u.pin_len) || 4) < pinMin(u.role) ? ' · PIN de 4 números: cambialo por uno de 6' : ''}${u.commission_base ? ` · comisión ${String(u.commission_pct || 0).replace('.', ',')}% ${u.commission_base === 'venta' ? 'por venta' : 'por cobranza'}` : ''}${u.email ? ` · ${u.email}` : ''}</span></span>
        ${u.active ? '' : html`<span class="badge">Inactivo</span>`}</button>
        ${u.role !== 'dueno' ? html`<button type="button" class="btn ghost sm" data-act="user-perms" data-id="${u.id}" aria-label="Permisos de ${u.name}">${ic('lock')} Permisos</button>` : ''}</li>`)}</ul>
    </section>

    <section class="card" id="aj-cloud" aria-labelledby="h-cl"><h2 id="h-cl">Nube y sincronización</h2>
      ${sync.isConfigured() ? html`
        <p>Conectado a <b>${cfg.url}</b>${cfg.user && cfg.user.email ? html` (cuenta de <b>${cfg.user.email}</b>)` : ''}.</p>
        ${sync.isDevice() ? html`<p class="small" id="aj-device-info">${ic('check')} Equipo autorizado: <b>${cfg.device.name}</b>. Cada usuario entra con su PIN y la nube aplica sus permisos.
          ${sync.sessionInfo() ? html`Sesión de la nube: <b>${(db.get('users', sync.sessionInfo().uid) || {}).name || '—'}</b>, hasta las ${fmtDateTime(sync.sessionInfo().exp).split(' ').pop()}.` : 'Sin sesión de la nube: ingresá tu PIN para sincronizar.'}</p>`
          : html`<div class="notice notice-info" id="aj-legacy"><p>Este equipo usa el acceso de antes (la sesión del dueño). La próxima vez que alguien entre con su PIN con internet, se convierte solo en <b>equipo autorizado</b>.</p></div>`}
        ${s.waiting ? html`<div class="notice notice-warn"><p><b>${s.waiting} ${s.waiting === 1 ? 'cambio' : 'cambios'} de otros usuarios esperan en este equipo.</b> Se suben cuando entre su autor o vos (dueño o encargado) con internet.</p></div>` : ''}
        <ul class="list">
          <li class="row"><span class="grow">Estado</span><b>${sync.statusText(s)}</b></li>
          <li class="row"><span class="grow">Cambios por subir</span><b>${s.pending}</b></li>
          <li class="row"><span class="grow">Última sincronización</span><b>${s.lastSync ? fmtDateTime(s.lastSync) : 'Nunca'}</b></li>
        </ul>
        ${s.error ? html`<div class="notice notice-error"><p>${s.error}</p></div>` : ''}
        <div class="btn-row"><button type="button" class="btn primary" data-act="sync">Sincronizar ahora</button>
          ${s.authError || s.revoked || (s.needPin && /PIN en la nube/.test(s.pinError || '')) ? html`<button type="button" class="btn ghost" data-act="cloud">Volver a conectar</button>` : ''}
          <button type="button" class="btn ghost" data-act="cloud-pass">${ic('lock')} Cambiar contraseña de la nube</button>
          <button type="button" class="btn outline-danger" data-act="cloud-off">Desconectar</button></div>`
      : html`<p>Ahora los datos se guardan <b>solo en este dispositivo</b>. Con la nube se guardan también en internet, se sincronizan cada 30 segundos y podés usar varios equipos (celu y PC).</p>
        <button type="button" class="btn primary" data-act="cloud">${ic('cloud')} Conectar a la nube</button>`}
    </section>
    ${sync.isDevice() ? html`<section class="card" id="aj-devices" aria-labelledby="h-dv"><h2 id="h-dv">Equipos</h2>
      <p class="small muted">Los equipos (PC de caja, celulares) que autorizaste con tu email y contraseña. En cada uno, cada persona entra con su PIN.
        Si perdiste un celu o un equipo ya no se usa, quitale el acceso: deja de sincronizar enseguida.</p>
      <div id="dv-list" aria-live="polite"><p class="muted">Consultando…</p></div></section>` : ''}
    ${iaSection()}` : multi ? branchesSection(brs, cur) : ''}

    ${can(ctx.user, 'editar_productos') ? pricesSection(st) : ''}

    ${await backupSection(owner)}

    <section class="card" id="aj-print" aria-labelledby="h-pr"><h2 id="h-pr">Impresora de tickets</h2>
      <fieldset class="seg"><legend>Ancho del papel</legend>
        ${[['58', '58 mm'], ['80', '80 mm'], ['a4', 'Hoja A4']].map(([v, l]) => html`<label><input type="radio" name="tw" value="${v}" ${width === v ? 'checked' : ''}><span>${l}</span></label>`)}
      </fieldset>
      <p class="small muted">En el diálogo de impresión elegí tu impresora térmica y márgenes “Ninguno”.</p>
      ${owner || can(ctx.user, 'ajustes') ? html`<div class="field" id="tk-logo-field"><span class="label">Logo del ticket</span>
        <div id="tk-logo-prev">${settings().ticket_logo ? html`<img src="${settings().ticket_logo}" alt="Logo del ticket" style="max-width:220px;background:#fff;border:1px dashed var(--line-strong);padding:6px">` : html`<p class="muted small">Sin logo.</p>`}</div>
        <div class="btn-row" style="margin-top:.5rem"><label class="btn ghost">Elegir imagen<input type="file" accept="image/*" id="tk-logo-file" hidden></label>
        ${settings().ticket_logo ? html`<button type="button" class="btn ghost" id="tk-logo-del">Quitar logo</button>` : ''}</div>
        <p class="small muted">Se pasa a blanco y negro para la impresora térmica. Sale arriba de cada ticket, en todos los equipos.</p></div>` : ''}
    </section>

    ${owner ? catalogSection() : ''}

    ${soundSection()}

    ${owner ? resetSection() : ''}

    <section class="card" aria-labelledby="h-app"><h2 id="h-app">Aplicación</h2>
      <p class="muted">JEANO Gestión · JEANO DIGITAL (Mendoza). Funciona sin internet una vez abierta.</p>
      <p id="aj-storage" class="small ${storageText(storageState).ok ? '' : 'muted'}" data-persisted="${String(storageState.persisted)}">${storageText(storageState).ok ? ic('check') : ic('alert')} ${storageText(storageState).text}
        Cada venta se guarda en el equipo antes de decir “listo”, y lo que falta subir a la nube espera acá aunque se corte la luz.</p>
      <div class="btn-row"><button type="button" class="btn ghost ${app.isStandalone() || !(app.canInstall() || app.isIOS) ? 'hidden' : ''}" data-act="install">${ic('install')} Instalar app</button>
        <button type="button" class="btn ghost" data-act="logout">${ic('lock')} Cambiar usuario</button></div>
    </section>`);

  const fc = $('#f-com', main);
  if (fc) fc.addEventListener('submit', async e => {
    e.preventDefault();
    const f = formData(fc);
    if (!f.business_name.trim()) return fieldError($('#s-bn', main), 'El nombre no puede quedar vacío.');
    if (f.cuit.trim() && !validCuit(f.cuit)) return fieldError($('#s-cuit', main), 'El CUIT no es válido.');
    await saveSettings({ ...f, cuit: f.cuit.trim() });
    toast('Datos guardados.');
  });
  const fa = $('#f-arca', main);
  if (fa) {
    fa.addEventListener('change', () => { $('#env-info', main).textContent = ENV_INFO[formData(fa).arca_env]; });
    fa.addEventListener('submit', async e => {
      e.preventDefault();
      const f = formData(fa);
      const posIn = $('#s-pos', main);
      const pos = posIn ? Number(f.pos_number) : null;
      if (posIn && (!Number.isInteger(pos) || pos < 1 || pos > 99998)) return fieldError(posIn, 'Número de punto de venta inválido.');
      if (f.arca_env !== 'off') {
        const cur = settings();
        if (!cur.cuit || !validCuit(cur.cuit)) { toast('Primero cargá un CUIT válido en Datos del comercio.', 'warn', 5000); return; }
        if (f.arca_env === 'prod' && !(await confirm('En Producción las facturas son reales ante ARCA. ¿Confirmás?', { ok: 'Sí, producción' }))) return;
      }
      await saveSettings({ arca_env: f.arca_env });
      // Con una sola sucursal, el punto de venta se edita acá y queda en esa sucursal
      if (posIn) {
        const b = activeBrs[0];
        try {
          if (b) await saveBranch({ ...b, pos_number: pos });
          else await saveSettings({ pos_number: pos });
        } catch (err) { return fieldError(posIn, err.message); }
      }
      toast('Facturación guardada.');
    });
  }
  wireSound();
  if (owner && sync.isDevice()) loadDevices();
  if (owner && sync.isConfigured()) loadIaStatus();
  const fp = $('#f-precios', main);
  if (fp) fp.addEventListener('submit', async e => { e.preventDefault(); await savePrices(fp); });
  main.querySelectorAll('[name=tw]').forEach(r => r.addEventListener('change', async () => { await db.setMeta('ticket_width', r.value); toast('Impresora guardada.'); }));
  // Logo del ticket: se achica a 480 px de ancho y se pasa a blanco y negro puro (impresora térmica)
  const lf = main.querySelector('#tk-logo-file');
  if (lf) lf.addEventListener('change', async () => {
    const f = lf.files && lf.files[0]; if (!f) return;
    try {
      const url = await ticketLogoFrom(f);
      await saveSettings({ ticket_logo: url });
      toast('Logo del ticket guardado.'); await paint();
    } catch (e) { toast(e.message || 'No se pudo leer la imagen.', 'error', 5000); }
  });
  const ld = main.querySelector('#tk-logo-del');
  if (ld) ld.addEventListener('click', async () => { await saveSettings({ ticket_logo: null }); toast('Logo quitado.'); await paint(); });
  // Catálogo público para la web y el WhatsApp
  const ca = main.querySelector('#cat-pub-on');
  if (ca) ca.addEventListener('click', async () => {
    const r = new Uint8Array(18); crypto.getRandomValues(r);
    const key = 'bs' + btoa(String.fromCharCode(...r)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
    await saveSettings({ public_catalog_key: key }); await audit('catalogo_publico', 'settings', 'business').catch(() => {});
    toast('Catálogo activado. Se publica cuando el equipo sincroniza.'); await paint();
  });
  const cx = main.querySelector('#cat-pub-off');
  if (cx) cx.addEventListener('click', async () => {
    if (!await confirm('¿Dejar de publicar los precios en la web y WhatsApp?')) return;
    await saveSettings({ public_catalog_key: null }); toast('Catálogo desactivado.'); await paint();
  });
  const cc = main.querySelector('#cat-pub-copy');
  if (cc) cc.addEventListener('click', async () => { try { await navigator.clipboard.writeText(catalogUrl()); toast('Dirección copiada.'); } catch (e) { toast('No se pudo copiar.', 'error'); } });
  // Saltos a secciones sin cambiar la ruta
  main.querySelectorAll('nav.chips a, a[data-jump]').forEach(a => a.addEventListener('click', e => {
    e.preventDefault();
    const t = main.querySelector(a.getAttribute('href'));
    if (t) { t.scrollIntoView({ behavior: 'smooth', block: 'start' }); t.setAttribute('tabindex', '-1'); t.focus({ preventScroll: true }); }
  }));
}

// ---------- IA (solo el dueño) ----------

function iaSection() {
  return html`<section class="card" id="aj-ia" aria-labelledby="h-ia"><h2 id="h-ia">IA: leer comprobantes y vencimientos, asistente</h2>
    ${sync.isConfigured() ? html`<div id="ia-st-box" aria-live="polite"><p class="muted">Consultando…</p></div>
      <h3 style="margin-top:1rem">Claude (lectura avanzada, sin límite diario)</h3>
      <p>Con una <b>clave de API de Anthropic</b> la IA lee mejor (letra chica, fotos torcidas, facturas largas) y no tiene límite por día.
        La clave se crea en <b>console.anthropic.com</b> → <i>API Keys</i>; ahí cargás una tarjeta y Anthropic <b>cobra por uso</b> (unos pocos pesos por comprobante leído).</p>
      <div class="notice notice-warn"><p><b>El plan de claude.ai (Pro o Max) NO sirve para esto:</b> es una suscripción para chatear; la clave de API es otra cuenta, en console.anthropic.com.</p></div>
      <p class="small muted">La clave se guarda cifrada en la nube. Nunca vuelve a este equipo ni a los otros, y no se muestra entera.</p>
      <div class="field"><label for="ia-key">Clave de API de Anthropic</label>
        <input id="ia-key" type="password" autocomplete="off" autocapitalize="off" autocorrect="off" spellcheck="false" placeholder="sk-ant-api03-…"></div>
      <div class="btn-row"><button type="button" class="btn primary" data-act="ia-save" id="ia-save">Probar y guardar</button>
        <button type="button" class="btn ghost hidden" data-act="ia-test" id="ia-test">Probar la guardada</button>
        <button type="button" class="btn outline-danger hidden" data-act="ia-del" id="ia-del">Quitar</button></div>`
    : html`<p>La IA funciona en la nube: primero conectala (arriba, en Nube).</p>`}
  </section>`;
}

async function loadIaStatus() {
  const box = $('#ia-st-box', main);
  if (!box) return;
  const { aiStatus } = await import('../ia.js');
  const s = await aiStatus({ fresh: true });
  if (!$('#ia-st-box', main)) return;
  if (!s) { box.innerHTML = String(html`<p class="muted">No se pudo consultar el estado de la IA (¿sin internet?).</p>`); return; }
  const c = s.claude || {};
  const day = c.used_today || {};
  box.innerHTML = String(html`<ul class="list">
    <li class="row"><span class="grow">Motor</span><b id="ia-engine">${s.engine === 'claude' ? 'Claude activado' : s.engine === 'free' ? 'Gratis (Workers AI)' : 'Desactivada'}</b></li>
    ${s.engine === 'claude' ? html`<li class="row"><span class="grow">Clave</span><b id="ia-hint">${c.hint || ''}</b></li>
      <li class="row"><span class="grow">Uso de hoy con Claude</span><b id="ia-used">${day.image || 0} lecturas · ${day.text || 0} consultas</b></li>`
      : s.engine === 'free' ? html`<li class="row"><span class="grow">Uso gratis de hoy</span><b id="ia-used">${s.used.image} de ${s.limits.image} lecturas · ${s.used.text} de ${s.limits.text} consultas</b></li>` : ''}
    </ul>
    ${!s.free_available ? html`<div class="notice notice-info" id="ia-nofree"><p><b>La IA gratis no está activada en el Worker.</b> El que administra la nube la activa en Cloudflare: Workers → jeano-gestion → Configuración → Enlaces → Agregar → Workers AI → nombre <b>AI</b>. Mientras tanto, se puede usar Claude con la clave de API.</p></div>` : ''}
    ${s.engine === 'claude' && c.last_message ? html`<p class="small muted">Última prueba: ${c.last_message}</p>` : ''}`);
  $('#ia-test', main).classList.toggle('hidden', s.engine !== 'claude');
  $('#ia-del', main).classList.toggle('hidden', s.engine !== 'claude');
}

async function iaKeyAct(name, el) {
  const busy = (on, txt) => { el.disabled = on; if (txt) el.textContent = txt; };
  try {
    if (name === 'ia-save') {
      const inp = $('#ia-key', main);
      const key = inp.value.trim();
      if (!key) return fieldError(inp, 'Pegá la clave de API (empieza con sk-ant-).');
      busy(true, 'Probando…');
      const r = await sync.cloudApi('/api/ai/key', { method: 'POST', body: { api_key: key }, timeout: 45000 });
      inp.value = '';
      toast(r.message || 'Claude activado.', 'ok', 5000);
      await audit('ia_clave', 'settings', 'business', { action: 'guardar', hint: r.hint }).catch(() => {});
    } else if (name === 'ia-test') {
      busy(true, 'Probando…');
      const r = await sync.cloudApi('/api/ai/key/test', { method: 'POST', body: {}, timeout: 45000 });
      toast(r.message, r.ok ? 'ok' : 'error', 6000);
    } else if (name === 'ia-del') {
      if (!(await confirm('¿Quitar la clave de Claude? La IA vuelve a la versión gratis (con límite diario). La clave no se borra en Anthropic: si no la vas a usar más, borrala también en console.anthropic.com.', { ok: 'Quitar', danger: true }))) return;
      busy(true);
      await sync.cloudApi('/api/ai/key/delete', { method: 'POST', body: {} });
      toast('Clave quitada. La IA usa la versión gratis.', 'ok', 4000);
      await audit('ia_clave', 'settings', 'business', { action: 'quitar' }).catch(() => {});
    }
  } catch (e) {
    if (name === 'ia-save') fieldError($('#ia-key', main), e.message); else toast(e.message, 'error', 6000);
  } finally {
    el.disabled = false;
    if (name === 'ia-save') el.textContent = 'Probar y guardar';
    if (name === 'ia-test') el.textContent = 'Probar la guardada';
  }
  loadIaStatus();
}

// ---------- Precios (margen y redondeo para la carga de compras) ----------

const ROUNDS = [[0, 'Sin redondeo (centavos)'], [1, 'A $ 1'], [10, 'A $ 10'], [50, 'A $ 50'], [100, 'A $ 100']];
function pricesSection(st) {
  const cats = [...new Set([...db.all('products').map(p => String(p.category || '').trim()), ...db.all('categories').map(c => String(c.name || '').trim())].filter(Boolean))]
    .sort((a, b) => a.localeCompare(b, 'es'));
  const cm = Array.isArray(st.category_margins) ? st.category_margins : [];
  const pctOf = c => { const x = cm.find(y => y && String(y.category).toLowerCase() === c.toLowerCase()); return x && x.pct !== null && x.pct !== undefined ? String(x.pct).replace('.', ',') : ''; };
  const num = v => (v === null || v === undefined || v === '' ? '' : String(v).replace('.', ','));
  return html`<section class="card" id="aj-precios" aria-labelledby="h-prc"><h2 id="h-prc">Precios</h2>
    <p class="muted">Cuando una compra cambia el costo, la app sugiere el precio de venta nuevo: <b>costo nuevo × (1 + margen)</b>, redondeado. Vos decidís en cada renglón si se aplica.</p>
    <form id="f-precios" novalidate>
      <div class="field"><label for="pr-mode">Margen a usar</label><select id="pr-mode">
        <option value="producto" ${st.price_margin_mode !== 'rubro' ? 'selected' : ''}>El que ya tiene cada producto (precio ÷ costo); si no tiene, el del rubro o el general</option>
        <option value="rubro" ${st.price_margin_mode === 'rubro' ? 'selected' : ''}>Siempre el del rubro (o el general)</option></select></div>
      <div class="grid2">
        <div class="field"><label for="pr-gen">Margen general %</label><input id="pr-gen" inputmode="decimal" autocomplete="off" placeholder="Ej: 35" value="${num(st.price_margin)}"></div>
        <div class="field"><label for="pr-round">Redondeo del precio</label><select id="pr-round">${ROUNDS.map(([v, l]) => html`<option value="${v}" ${Number(st.price_round || 0) === v ? 'selected' : ''}>${l}</option>`)}</select>
          <div class="hint">Siempre hacia arriba: $ 1.234 → $ 1.240 con “A $ 10”.</div></div>
      </div>
      ${cats.length ? html`<details class="pr-cats"><summary>Margen por rubro (${cats.length})</summary>
        <p class="small muted">Vacío = el margen general. Comercio responsable inscripto: el margen va sobre el costo sin IVA y la app le suma el IVA del producto.</p>
        <div class="grid3">${cats.map((c, i) => html`<div class="field"><label for="pr-c${i}">${c}</label><input id="pr-c${i}" data-cat="${c}" inputmode="decimal" autocomplete="off" placeholder="%" value="${pctOf(c)}"></div>`)}</div></details>` : ''}
      <button class="btn primary" id="pr-save">Guardar precios</button>
    </form></section>`;
}

async function savePrices(f) {
  const read = el => { const t = el.value.trim(); if (!t) return null; const n = parseNum(t); return Number.isFinite(n) && n >= 0 && n <= 1000 ? n : NaN; };
  const gen = read($('#pr-gen', f));
  if (Number.isNaN(gen)) return fieldError($('#pr-gen', f), 'Margen inválido (0 a 1000 %).');
  const cats = [];
  for (const el of f.querySelectorAll('[data-cat]')) {
    const v = read(el);
    if (Number.isNaN(v)) return fieldError(el, 'Margen inválido.');
    if (v !== null) cats.push({ category: el.dataset.cat, pct: v });
  }
  await saveSettings({ price_margin: gen, price_round: Number($('#pr-round', f).value) || 0, category_margins: cats, price_margin_mode: $('#pr-mode', f).value === 'rubro' ? 'rubro' : 'producto' });
  toast('Precios guardados.');
}

/** Sonido del lector (bip al leer con la cámara): de cada equipo */
function soundSection() {
  const s = soundSettings();
  return html`<section class="card" id="aj-sound" aria-labelledby="h-snd"><h2 id="h-snd">Sonido del lector</h2>
    <p class="muted">El bip al leer un código con la cámara, y el doble zumbido cuando el código no está cargado. Se guarda en este equipo.</p>
    <label class="check"><input type="checkbox" id="snd-on" ${s.on ? 'checked' : ''}> Sonido al leer</label>
    <div class="field"><label for="snd-vol">Volumen: <b id="snd-vol-txt">${s.volume}%</b></label>
      <input type="range" id="snd-vol" min="5" max="100" step="5" value="${s.volume}" ${s.on ? '' : 'disabled'} style="min-height:44px;padding:0;border:0"></div>
    <div class="btn-row"><button type="button" class="btn ghost" id="snd-test">Probar bip</button>
      <button type="button" class="btn ghost" id="snd-test-err">Probar código no encontrado</button></div>
  </section>`;
}
function wireSound() {
  const on = $('#snd-on', main), vol = $('#snd-vol', main);
  if (!on) return;
  on.addEventListener('change', () => { setSoundSettings({ on: on.checked }); vol.disabled = !on.checked; toast(on.checked ? 'Sonido del lector activado.' : 'Sonido del lector apagado.'); });
  vol.addEventListener('input', () => { $('#snd-vol-txt', main).textContent = vol.value + '%'; });
  vol.addEventListener('change', () => { setSoundSettings({ volume: Number(vol.value) }); unlockAudio(); playBeep(); });
  $('#snd-test', main).addEventListener('click', () => { unlockAudio(); playBeep(); });
  $('#snd-test-err', main).addEventListener('click', () => { unlockAudio(); playError(); });
}

async function act(name, el) {
  switch (name) {
    case 'backup':
      await doBackup();
      return paint();
    case 'restore': {
      if (!(await confirm('Se van a mezclar los datos de la copia con los actuales (gana el dato más nuevo). ¿Seguimos?', { ok: 'Elegir archivo' }))) return;
      const file = await pickFile('.json,application/json');
      if (!file) return;
      try {
        const n = await db.importAll(JSON.parse(await file.text()));
        toast(`Copia restaurada: ${n} registros.`);
        sync.refreshPending();
        app.rerender();
      } catch (e) { toast('No se pudo restaurar: ' + e.message, 'error', 6000); }
      return;
    }
    case 'reset': return resetDialog();
    case 'bk-folder': {
      try {
        const r = await backup.chooseFolder();
        if (r && r.status === 'done') toast(`Listo: la copia se guarda todos los días en “${backup.state.folder}”.`, 'ok', 4500);
        else if (r && r.status === 'error') toast('No se pudo guardar la copia: ' + r.error, 'error', 6000);
        else if (r && r.status === 'needs-permission') toast('El navegador no dio permiso para esa carpeta.', 'warn', 5000);
      } catch (e) { toast(e.message, 'error', 6000); }
      return paint();
    }
    case 'bk-now': case 'bk-regrant': {
      // "Hacer copia ahora" es un clic: si el permiso venció, se aprovecha para pedirlo de nuevo
      const perm = name === 'bk-now' ? (await backup.info()).permission : null;
      const r = name === 'bk-regrant' ? await backup.regrant() : perm !== 'granted' ? await backup.regrant({ force: true }) : await backup.runDaily({ force: true });
      if (r.status === 'done') toast(`Copia guardada: ${r.file}`);
      else if (r.status === 'needs-permission') toast('Hace falta volver a dar permiso a la carpeta.', 'warn', 5000);
      else if (r.status === 'error') toast('No se pudo guardar la copia: ' + r.error, 'error', 6000);
      return paint();
    }
    case 'bk-forget':
      if (await confirm('¿Dejar de guardar la copia diaria en esa carpeta? Las copias que ya están ahí no se borran.', { ok: 'Dejar de copiar', danger: true })) { await backup.forgetFolder(); paint(); }
      return;
    case 'branch-new': return branchForm();
    case 'branch-edit': return branchForm(db.get('branches', el.dataset.id));
    case 'branch-device': return app.changeBranch();
    case 'user-new': return userForm();
    case 'user-edit': return userForm(db.get('users', el.dataset.id));
    case 'user-perms': return permsDialog(db.get('users', el.dataset.id));
    case 'cloud': return cloudDialog({ currentUser: ctx.user, onDone: u => { if (u) app.switchUser(db.get('users', u.id) || ctx.user); app.rerender(); } });
    case 'cloud-pass': return cloudPasswordDialog();
    case 'cloud-off':
      if (await confirm('¿Desconectar la nube? Los datos quedan en este equipo, pero dejan de sincronizarse.', { ok: 'Desconectar', danger: true })) { await sync.disconnect(); paint(); }
      return;
    case 'sync': {
      el.disabled = true; el.textContent = 'Sincronizando…';
      const ok = await sync.syncNow();
      toast(ok ? 'Sincronizado.' : (sync.status.error || 'No se pudo sincronizar.'), ok ? 'ok' : 'error');
      return paint();
    }
    case 'dev-revoke': return revokeDevice(el.dataset.id, el.dataset.name);
    case 'legacy-off': return legacyOff();
    case 'cert': return certDialog();
    case 'csr': return csrDialog();
    case 'ia-save': case 'ia-test': case 'ia-del': return iaKeyAct(name, el);
    case 'arca-status': return arcaStatus();
    case 'install': return app.install();
    case 'logout': return app.logout();
    default:
  }
}

/** Sección Sucursales: la lista y el alta/edición son del dueño; el cambio de sucursal del equipo, del dueño o encargado */
function branchesSection(brs, cur) {
  const owner = can(ctx.user, 'sucursales');
  return html`<section class="card" id="aj-branches" aria-labelledby="h-br"><div class="card-head"><h2 id="h-br">Sucursales</h2>
      ${owner ? html`<button type="button" class="btn primary sm" data-act="branch-new">${ic('plus')} Nueva sucursal</button>` : ''}</div>
    <p class="small muted">Los productos y los precios son los mismos en todas las sucursales. El stock, la caja, las ventas y las compras son de cada una, y cada una factura con su propio punto de venta de ARCA. En las sucursales nuevas el stock arranca en 0.</p>
    <div class="notice notice-info" style="display:flex;align-items:center;gap:.75rem;flex-wrap:wrap">
      <p style="flex:1;margin:0">${ic('store')} Este equipo trabaja en <b id="aj-cur-branch">${cur ? cur.name : '—'}</b>.</p>
      ${brs.filter(b => b.active !== 0).length > 1 ? html`<button type="button" class="btn ghost sm" data-act="branch-device">Cambiar</button>` : ''}</div>
    ${owner ? html`<ul class="list" id="branch-list">${brs.map(b => html`<li><button type="button" class="row" data-act="branch-edit" data-id="${b.id}">
      <span class="avatar" aria-hidden="true">${ic('store')}</span>
      <span class="grow"><span class="title">${b.name}${cur && b.id === cur.id ? html` <span class="branch-tag">este equipo</span>` : ''}</span>
        <span class="sub" style="display:block">Punto de venta ${b.pos_number}${b.address ? ` · ${b.address}` : ''}${b.id === mainBranchId() ? ' · Principal' : ''}</span></span>
      ${b.active === 0 ? html`<span class="badge">Inactiva</span>` : ''}</button></li>`)}</ul>` : ''}
  </section>`;
}

async function branchForm(b = null) {
  const used = branches().filter(x => !b || x.id !== b.id).map(x => Number(x.pos_number) || 0);
  const nextPos = b ? b.pos_number : Math.max(0, ...used) + 1;
  await modal({
    title: b ? 'Editar sucursal' : 'Nueva sucursal',
    body: html`<form id="bf" novalidate>
      <div class="field"><label for="bf-n">Nombre</label><input id="bf-n" name="name" value="${b ? b.name : ''}" autocomplete="off" placeholder="Ej: Sucursal Centro"></div>
      <div class="field"><label for="bf-a">Dirección <span class="muted">(sale en el ticket)</span></label><input id="bf-a" name="address" value="${b ? b.address || '' : ''}" autocomplete="off"></div>
      <div class="field"><label for="bf-p">Punto de venta ARCA</label><input id="bf-p" name="pos_number" inputmode="numeric" value="${nextPos}" style="max-width:160px">
        <div class="hint">El número que diste de alta en ARCA para “Web services” en esta sucursal.</div></div>
      ${b ? html`<label class="check"><input type="checkbox" name="active" ${b.active !== 0 ? 'checked' : ''}> Activa (se puede elegir en los equipos)</label>` : ''}
      ${b ? '' : html`<div class="notice notice-info"><p>Los productos y precios ya están en todas las sucursales. En esta, el stock arranca en 0: cargalo con una compra o con “Ajustar stock”.</p></div>`}
    </form>`,
    onMount(m) { $('#bf', m).addEventListener('submit', e => { e.preventDefault(); m.querySelector('.modal-foot .primary').click(); }); },
    actions: [{ label: 'Cancelar', value: null }, {
      label: 'Guardar', kind: 'primary', onClick: async (close, w) => {
        const f = formData($('#bf', w));
        if (!f.name.trim()) return fieldError($('#bf-n', w), 'Escribí el nombre.');
        const pos = Number(String(f.pos_number).trim());
        if (!Number.isInteger(pos) || pos < 1 || pos > 99998) return fieldError($('#bf-p', w), 'Escribí un número de punto de venta (1 a 99998).');
        try {
          await saveBranch({ id: b ? b.id : null, name: f.name, address: f.address, pos_number: pos, active: b ? (f.active ? 1 : 0) : 1 });
        } catch (e) {
          return fieldError(/punto de venta/i.test(e.message) ? $('#bf-p', w) : /nombre|llama/i.test(e.message) ? $('#bf-n', w) : null, e.message);
        }
        toast('Sucursal guardada.');
        close(true);
        paint();
      },
    }],
  });
}

async function userForm(u = null) {
  const isMe = u && u.id === ctx.user.id;
  const owners = db.all('users').filter(x => x.role === 'dueno' && x.active);
  await modal({
    title: u ? 'Editar usuario' : 'Nuevo usuario',
    body: html`<form id="uf" novalidate>
      <div class="field"><label for="uf-n">Nombre</label><input id="uf-n" name="name" value="${u ? u.name : ''}" autocomplete="off"></div>
      <fieldset class="seg"><legend>Rol</legend>
        ${Object.entries(ROLES).map(([k, l]) => html`<label><input type="radio" name="role" value="${k}" ${(u ? u.role : 'cajero') === k ? 'checked' : ''} ${isMe ? 'disabled' : ''}><span>${l}</span></label>`)}
      </fieldset>
      <div class="grid2">
        <div class="field"><label for="uf-p">${u ? 'Nuevo PIN (dejalo vacío para no cambiarlo)' : 'PIN'}</label><input id="uf-p" name="pin" type="password" inputmode="numeric" maxlength="8" autocomplete="new-password">
          <div class="hint" id="uf-pin-hint">De 4 a 8 números. Dueño y encargado: de 6 a 8.${sync.isConfigured() ? ' Se carga en la nube: hace falta internet.' : ''}</div></div>
        <div class="field"><label for="uf-p2">Repetir PIN</label><input id="uf-p2" name="pin2" type="password" inputmode="numeric" maxlength="8" autocomplete="new-password"></div>
      </div>
      <div class="field"><label for="uf-e">Email <span class="muted">(solo si entra a la nube)</span></label><input id="uf-e" name="email" type="email" value="${u ? u.email || '' : ''}"></div>
      <fieldset class="seg" id="uf-cb"><legend>Comisión</legend>
        ${[['', 'Sin comisión'], ['venta', 'Por venta'], ['cobranza', 'Por cobranza']].map(([k, l]) => html`<label><input type="radio" name="commission_base" value="${k}" ${((u && u.commission_base) || '') === k ? 'checked' : ''}><span>${l}</span></label>`)}
      </fieldset>
      <div class="field" id="uf-pct-f"><label for="uf-pct">Porcentaje de comisión</label><input id="uf-pct" name="commission_pct" inputmode="decimal" value="${u && u.commission_pct ? String(u.commission_pct).replace('.', ',') : ''}" placeholder="Ej: 2,5" style="max-width:160px">
        <div class="hint">Por venta: sobre lo vendido menos devoluciones y anuladas. Por cobranza: sobre lo cobrado de contado de sus ventas y los cobros de cuenta corriente de sus clientes.</div></div>
      ${u && !isMe ? html`<label class="check"><input type="checkbox" name="active" ${u.active ? 'checked' : ''}> Activo (puede entrar)</label>` : ''}
    </form>`,
    onMount(m) { $('#uf', m).addEventListener('submit', e => { e.preventDefault(); m.querySelector('.modal-foot .primary').click(); }); },
    actions: [{ label: 'Cancelar', value: null }, {
      label: 'Guardar', kind: 'primary', onClick: async (close, w) => {
        const f = formData($('#uf', w));
        if (!f.name.trim()) return fieldError($('#uf-n', w), 'Escribí el nombre.');
        const role = isMe ? u.role : f.role;
        const min = pinMin(role);
        if ((!u || f.pin) && (!validPin(f.pin) || f.pin.length < min)) return fieldError($('#uf-p', w), `El PIN tiene que tener de ${min} a 8 números${min > 4 ? ' (dueño y encargado)' : ''}.`);
        if (f.pin && f.pin !== f.pin2) return fieldError($('#uf-p2', w), 'Los PIN no coinciden.');
        if (f.pin && sync.isConfigured() && navigator.onLine === false) return fieldError($('#uf-p', w), 'Para cargar o cambiar un PIN hace falta internet (se guarda en la nube).');
        const base = f.commission_base || null;
        const pct = base ? parseNum(f.commission_pct || '') : 0;
        if (base && !(isFinite(pct) && pct > 0 && pct <= 100)) return fieldError($('#uf-pct', w), 'Escribí el porcentaje (entre 0 y 100).');
        const active = isMe ? 1 : (u ? (f.active ? 1 : 0) : 1);
        // Siempre tiene que quedar al menos un dueño activo
        if (u && u.role === 'dueno' && (role !== 'dueno' || !active) && owners.length <= 1) return toast('Tiene que quedar al menos un dueño activo.', 'warn');
        // Si cambia el rol, los permisos vuelven a los de su nuevo rol
        const roleChanged = !!u && u.role !== role && u.perms && Object.keys(u.perms).length;
        let saved;
        try {
          saved = await saveUser({ id: u ? u.id : null, name: f.name, role, pin: f.pin || null, email: f.email, active, commission_base: base, commission_pct: pct, ...(roleChanged ? { perms: null } : {}) });
        } catch (e) { return fieldError(f.pin ? $('#uf-p', w) : null, e.message); }
        if (roleChanged) await audit('permisos_cambiados', 'users', saved.id, { name: saved.name, role, reset: true, reason: 'cambio de rol', before: u.perms });
        await audit('usuario_guardado', 'users', saved.id, { name: saved.name, role, active, new: !u, role_before: u ? u.role : null, pin_changed: !!f.pin });
        if (isMe) { ctx.user = saved; if (f.pin) sync.rememberPin(saved.id, f.pin); }
        toast('Usuario guardado.');
        close(true);
        paint();
      },
    }],
  });
}

/** Genera la clave y el pedido de certificado (.csr) en este equipo; la clave queda guardada acá para cuando llegue el .crt */
async function csrDialog() {
  const st = settings();
  const org = st.legal_name || st.business_name || '';
  await modal({
    title: 'Generar pedido de certificado',
    body: html`<p>Se arma acá, en este equipo. Va a pedir el CUIT <b>${st.cuit || '(falta)'}</b> a nombre de <b>${org || '(falta)'}</b>.</p>
      <div class="field"><label for="csr-a">Nombre del certificado (alias en ARCA)</label><input id="csr-a" value="jeanogestion" autocomplete="off"><p class="small muted">Solo letras y números. Es el mismo nombre que vas a escribir en ARCA al “Agregar alias”.</p></div>
      <div class="notice notice-info"><p>Bajan dos archivos: el <b>.csr</b> (se sube a ARCA) y el <b>.key</b> (la clave privada: guardalo en un lugar seguro, no lo compartas). La clave también queda guardada en este equipo para cuando cargues el certificado.</p></div>
      <p id="csr-err" class="field-err" role="alert"></p>`,
    actions: [{ label: 'Cancelar', value: null }, {
      label: 'Generar', kind: 'primary', onClick: async (close, w) => {
        const err = $('#csr-err', w);
        err.textContent = '';
        try {
          const r = await generateCsr({ cuit: st.cuit, org, alias: $('#csr-a', w).value });
          download(`pedido-${r.alias}.csr`, r.csrPem, 'application/pkcs10');
          download(`clave-${r.alias}.key`, r.keyPem, 'application/x-pem-file');
          await db.setMeta('arca_key_pending', { keyPem: r.keyPem, alias: r.alias, at: Date.now() });
          await audit('arca_csr', 'settings', 'business').catch(() => {});
          toast('Pedido generado. Ahora subí el .csr en ARCA.');
          close(true);
        } catch (e) { err.textContent = e.message; }
      },
    }],
  });
}

async function certDialog() {
  const st = settings();
  const pending = await db.getMeta('arca_key_pending', null);
  await modal({
    title: 'Cargar certificado ARCA',
    body: html`<p>Ambiente: <b>${st.arca_env === 'prod' ? 'Producción' : st.arca_env === 'homo' ? 'Homologación (pruebas)' : 'Desactivado'}</b></p>
      ${st.arca_env === 'off' ? html`<div class="notice notice-warn"><p>Elegí primero el ambiente (Pruebas o Producción) y guardá.</p></div>` : ''}
      <div class="field"><label for="ct-c">Certificado (.crt / .pem)</label><input id="ct-c" type="file" accept=".crt,.pem,.cer"></div>
      <div class="field"><label for="ct-k">Clave privada (.key)</label><input id="ct-k" type="file" accept=".key,.pem">
        ${pending ? html`<p class="small muted">Si no elegís ninguna, se usa la clave del pedido “${pending.alias}” generado en este equipo el ${new Date(pending.at).toLocaleDateString('es-AR')}.</p>` : ''}</div>
      <p id="ct-err" class="field-err" role="alert"></p>`,
    actions: [{ label: 'Cancelar', value: null }, {
      label: 'Subir', kind: 'primary', onClick: async (close, w) => {
        const c = $('#ct-c', w).files[0], k = $('#ct-k', w).files[0];
        const err = $('#ct-err', w);
        if (st.arca_env === 'off') { err.textContent = 'Elegí el ambiente primero.'; return; }
        if (!c || (!k && !pending)) { err.textContent = k || pending ? 'Elegí el certificado (.crt).' : 'Elegí los dos archivos.'; return; }
        const cert_pem = await c.text(), key_pem = k ? await k.text() : pending.keyPem;
        if (!/BEGIN CERTIFICATE/.test(cert_pem)) { err.textContent = 'El certificado no tiene el formato esperado (PEM).'; return; }
        if (!/BEGIN (RSA |EC )?PRIVATE KEY/.test(key_pem)) { err.textContent = 'La clave privada no tiene el formato esperado (PEM).'; return; }
        try {
          await sync.api('/api/arca/cert', { method: 'POST', body: { cert_pem, key_pem, env: st.arca_env } });
          toast('Certificado guardado en la nube.');
          if (pending && !k) await db.setMeta('arca_key_pending', null);
          close(true);
          arcaStatus();
        } catch (e) { err.textContent = e.message; }
      },
    }],
  });
}

async function arcaStatus() {
  const box = $('#arca-st', main);
  if (!box) return;
  box.innerHTML = '<p class="muted">Consultando…</p>';
  try {
    const r = await sync.api('/api/arca/status');
    box.innerHTML = String(html`<div class="notice ${r.ok ? 'notice-ok' : 'notice-warn'}">
      <p><b>${r.has_cert ? 'Certificado cargado' : 'Sin certificado'}</b> · Ambiente ${r.env || '—'}${r.cert_expires ? ` · vence ${r.cert_expires}` : ''}</p>
      ${r.message ? html`<p>${r.message}</p>` : ''}</div>`);
  } catch (e) {
    box.innerHTML = String(html`<div class="notice notice-error"><p>${e.message}</p></div>`);
  }
}


/** Cambiar la contraseña de la cuenta de la nube (la que se usa para entrar desde otro equipo o el celu) */
async function cloudPasswordDialog() {
  const cfg = sync.config();
  return modal({
    title: 'Cambiar contraseña de la nube',
    body: html`<p class="muted">Es la contraseña para entrar desde otro equipo o el celu${cfg.user && cfg.user.email ? html` con <b>${cfg.user.email}</b>` : ''}. Mínimo 8 letras o números.</p>
      <form id="cp" novalidate>
        <div class="field"><label for="cp-1">Contraseña nueva</label><input id="cp-1" name="p1" type="password" autocomplete="new-password" autocapitalize="off" autocorrect="off" spellcheck="false"></div>
        <div class="field"><label for="cp-2">Repetila</label><input id="cp-2" name="p2" type="password" autocomplete="new-password" autocapitalize="off" autocorrect="off" spellcheck="false"></div>
        <label class="check"><input type="checkbox" id="cp-show"> Mostrar contraseña</label>
        <p id="cp-msg" role="alert" class="field-err"></p>
      </form>`,
    onMount(m) {
      $('#cp-show', m).addEventListener('change', e => m.querySelectorAll('#cp-1,#cp-2').forEach(i => { i.type = e.target.checked ? 'text' : 'password'; }));
      $('#cp', m).addEventListener('submit', e => e.preventDefault());
    },
    actions: [{ label: 'Cancelar', value: false }, {
      label: 'Guardar', kind: 'primary', id: 'cp-go', onClick: async (close, w) => {
        const f = formData($('#cp', w));
        if (f.p1.length < 8) return fieldError($('#cp-1', w), 'Tiene que tener al menos 8 letras o números.');
        if (f.p1 !== f.p2) return fieldError($('#cp-2', w), 'Las dos no son iguales.');
        const btn = $('#cp-go', w); btn.disabled = true; btn.textContent = 'Guardando…';
        try {
          await sync.api('/api/auth/password', { method: 'POST', body: { new_password: f.p1 } });
          close(true);
          toast('Listo: usá la contraseña nueva para entrar desde el celu u otro equipo.', 'ok', 6000);
        } catch (err) {
          $('#cp-msg', w).textContent = err.message;
          btn.disabled = false; btn.textContent = 'Guardar';
        }
      },
    }],
  });
}


// ---------- Equipos autorizados (solo dueño) ----------

async function loadDevices() {
  const box = $('#dv-list', main);
  if (!box) return;
  // Recién entrado: la sesión de la nube se pide en segundo plano; se espera (sin sesión, la lista no se puede ver)
  if (!sync.sessionInfo() && navigator.onLine !== false) await sync.syncNow();
  if (!sync.sessionInfo()) { box.innerHTML = String(html`<p class="muted">${navigator.onLine === false ? 'Sin internet: la lista de equipos se ve con conexión.' : 'Ingresá tu PIN para sincronizar y ver los equipos.'}</p>`); return; }
  let r;
  try { r = await sync.api('/api/devices', { timeout: 10000 }); } catch (e) {
    box.innerHTML = String(html`<p class="muted">${e.offline || e.network ? 'Sin internet: la lista de equipos se ve con conexión.' : e.message}</p>`);
    return;
  }
  if (!$('#dv-list', main)) return;
  const brName = id => { const b = id && db.get('branches', id); return b ? b.name : ''; };
  const devs = r.devices || [];
  box.innerHTML = String(html`<ul class="list" id="dv-ul">${devs.map(d => html`<li class="row" data-device="${d.id}">
      <span class="avatar" aria-hidden="true">${ic(/celu|tel|tablet/i.test(d.name || '') ? 'device' : 'store')}</span>
      <span class="grow"><span class="title">${d.name || 'Equipo'}${d.this_device ? html` <span class="branch-tag">este equipo</span>` : ''}</span>
        <span class="sub" style="display:block">${[brName(d.branch_id), d.revoked_at ? `Sin acceso desde ${fmtDateTime(d.revoked_at)}` : d.last_seen_at ? `Último uso: ${fmtDateTime(d.last_seen_at)}` : 'Sin uso todavía',
          d.revoked_at ? '' : d.current_user_name ? `Ahora: ${d.current_user_name}` : d.last_user_name ? `Último usuario: ${d.last_user_name}` : ''].filter(Boolean).join(' · ')}</span></span>
      ${d.revoked_at ? html`<span class="badge">Sin acceso</span>` : d.this_device ? '' : html`<button type="button" class="btn outline-danger sm" data-act="dev-revoke" data-id="${d.id}" data-name="${d.name || 'Equipo'}">Quitar acceso</button>`}
    </li>`)}</ul>
    ${r.legacy_seen_at ? html`<div class="notice notice-warn" id="dv-legacy" style="margin-top:1rem"><p><b>Todavía hay equipos con el acceso de antes</b> (la sesión del dueño guardada en el equipo). Último uso: ${fmtDateTime(r.legacy_seen_at)}.</p>
      <p class="small">Se convierten solos cuando alguien entra con su PIN con internet. Cuando todos los equipos estén en esta lista, cortá los accesos viejos: el que no se haya convertido va a pedir que lo vuelvas a conectar con tu email y contraseña.</p>
      <p><button type="button" class="btn ghost sm" data-act="legacy-off">${ic('lock')} Cortar accesos viejos</button></p></div>` : ''}`);
}

async function revokeDevice(id, name) {
  if (!(await confirm(`¿Quitarle el acceso a la nube a “${name}”? Deja de sincronizar enseguida. Lo que tenga guardado sin subir queda en ese equipo; para volver a usarlo lo tenés que conectar de nuevo con tu email y contraseña.`, { ok: 'Quitar acceso', danger: true }))) return;
  try {
    await sync.api('/api/devices/revoke', { method: 'POST', body: { device_id: id } });
    await audit('equipo_quitado', 'devices', id, { name });
    toast(`Listo: “${name}” ya no tiene acceso a la nube.`);
  } catch (e) { toast(e.message, 'error', 6000); }
  loadDevices();
}

async function legacyOff() {
  if (!(await confirm('¿Cortar los accesos de antes? Los equipos autorizados de la lista siguen andando. Un equipo que todavía no se convirtió deja de sincronizar hasta que lo vuelvas a conectar con tu email y contraseña (lo que tenga guardado no se pierde).', { ok: 'Cortar accesos viejos', danger: true }))) return;
  try {
    await sync.api('/api/devices/legacy-off', { method: 'POST', body: {} });
    await audit('accesos_viejos_cortados', '', '', {});
    toast('Listo: solo quedan los equipos autorizados.');
  } catch (e) { toast(e.message, 'error', 6000); }
  loadDevices();
}


// ---------- Permisos por usuario (solo dueño) ----------

/** Ajustes → Usuarios → Permisos: interruptores agrupados; arranca con lo de su rol y guarda solo las diferencias */
async function permsDialog(u) {
  if (!u || u.role === 'dueno' || !can(ctx.user, 'permisos')) return;
  const cur = u.perms || {};
  const eff = { role: u.role, perms: cur };
  const maxNow = cur.descuento_max !== undefined ? String(cur.descuento_max).replace('.', ',') : '';
  const row = p => html`<label class="perm-row" data-perm="${p.key}">
      <span class="perm-txt"><b>${p.label}</b>${p.hint ? html`<small>${p.hint}</small>` : ''}<span class="badge info perm-diff hidden"></span></span>
      <span class="switch"><input type="checkbox" role="switch" name="${p.key}" ${can(eff, p.key) ? 'checked' : ''}><i aria-hidden="true"></i></span></label>
    ${p.key === 'descuentos' ? html`<div class="perm-max" id="pm-max-row"><label for="pm-max" class="small">% máximo sin autorización</label>
      <input id="pm-max" inputmode="decimal" value="${maxNow}" placeholder="Sin límite" autocomplete="off"></div>` : ''}`;
  const saved = await modal({
    title: `Permisos de ${u.name}`,
    size: 'wide',
    body: html`<p class="muted" id="pm-intro">${ROLES[u.role]}: arranca con lo de su rol. Lo que cambies queda marcado y se aplica en todos los equipos al sincronizar (y en la nube enseguida).</p>
      <form id="pm-f" novalidate>${PERM_GROUPS.map(([g, title]) => html`<fieldset class="perm-group"><legend>${title}</legend>${PERMS.filter(p => p.group === g).map(row)}</fieldset>`)}</form>
      <div class="notice notice-info"><p class="small"><b>Solo del dueño</b> (no se pueden dar): usuarios y permisos, equipos, datos del comercio, nube, certificado ARCA, auditoría, sucursales y empezar de cero.</p></div>
      <p id="pm-err" class="field-err" role="alert"></p>`,
    onMount(m) {
      const paintDiff = () => {
        for (const p of PERMS) {
          const inp = m.querySelector(`[name="${p.key}"]`);
          const b = m.querySelector(`[data-perm="${p.key}"] .perm-diff`);
          const diff = inp.checked !== roleCan(u.role, p.key);
          b.classList.toggle('hidden', !diff);
          b.textContent = diff ? `Cambiado · su rol: ${roleCan(u.role, p.key) ? 'Sí' : 'No'}` : '';
        }
        $('#pm-max-row', m).classList.toggle('hidden', !m.querySelector('[name=descuentos]').checked);
      };
      m.addEventListener('change', paintDiff);
      $('#pm-f', m).addEventListener('submit', e => e.preventDefault());
      paintDiff();
    },
    actions: [{ label: 'Volver a los de su rol', id: 'pm-reset', kind: 'ghost', onClick: (close, w) => {
      for (const p of PERMS) w.querySelector(`[name="${p.key}"]`).checked = roleCan(u.role, p.key);
      $('#pm-max', w).value = '';
      w.querySelector('#pm-f').dispatchEvent(new Event('change', { bubbles: true }));
    } }, { label: 'Cancelar', value: null }, {
      label: 'Guardar permisos', kind: 'primary', id: 'pm-go', onClick: async (close, w) => {
        const wanted = {};
        for (const p of PERMS) wanted[p.key] = w.querySelector(`[name="${p.key}"]`).checked;
        const mx = $('#pm-max', w).value.trim();
        if (mx) {
          const v = parseNum(mx);
          if (!(isFinite(v) && v >= 0 && v <= 100)) return fieldError($('#pm-max', w), 'Escribí un porcentaje entre 0 y 100 (o dejalo vacío: sin límite).');
          wanted.descuento_max = v;
        }
        const perms = permsDiff(u.role, wanted);
        const changes = permsChanges(u.role, cur, perms);
        if (!changes.length && JSON.stringify(perms) === JSON.stringify(cur)) { close(false); return; }
        const fresh = db.get('users', u.id);
        await saveUser({ ...fresh, pin: null, perms });
        await audit('permisos_cambiados', 'users', u.id, { name: u.name, role: u.role, changes, perms, max_discount: can({ role: u.role, perms }, 'descuentos') ? discountMax({ role: u.role, perms }) : 0 });
        close(true);
      },
    }],
  });
  if (saved) { toast(`Permisos de ${u.name} guardados.`); paint(); }
}


/** Imagen → PNG blanco y negro de hasta 480 px de ancho (fondo transparente = blanco), para el ticket */
export async function ticketLogoFrom(file) {
  if (!/^image\//.test(file.type || '')) throw new Error('Elegí una imagen (PNG o JPG).');
  const bmp = await createImageBitmap(file);
  const W = Math.min(480, bmp.width), H = Math.max(1, Math.round(bmp.height * W / bmp.width));
  const c = document.createElement('canvas'); c.width = W; c.height = H;
  const g = c.getContext('2d'); g.fillStyle = '#fff'; g.fillRect(0, 0, W, H); g.drawImage(bmp, 0, 0, W, H);
  const im = g.getImageData(0, 0, W, H), d = im.data;
  let minY = H, maxY = -1;
  for (let i = 0; i < d.length; i += 4) {
    const v = (0.299 * d[i] + 0.587 * d[i + 1] + 0.114 * d[i + 2]) < 150 ? 0 : 255;
    d[i] = d[i + 1] = d[i + 2] = v; d[i + 3] = 255;
    if (!v) { const y = Math.floor(i / 4 / W); if (y < minY) minY = y; if (y > maxY) maxY = y; }
  }
  if (maxY < 0) throw new Error('La imagen quedó en blanco: probá con una versión del logo en negro o más oscura.');
  g.putImageData(im, 0, 0);
  // Recorta el blanco de arriba y abajo
  const h2 = maxY - minY + 1, c2 = document.createElement('canvas'); c2.width = W; c2.height = h2;
  c2.getContext('2d').drawImage(c, 0, minY, W, h2, 0, 0, W, h2);
  const url = c2.toDataURL('image/png');
  if (url.length > 190000) throw new Error('El logo es muy pesado: usá una imagen más simple.');
  return url;
}

function catalogUrl() {
  const k = settings().public_catalog_key;
  const base = sync.cleanUrl(sync.config().url || (globalThis.JG_CONFIG && globalThis.JG_CONFIG.cloudUrl) || '');
  return k && base ? `${base}/api/public/catalogo?k=${k}` : '';
}

/** Catálogo público: la web del comercio y el bot de WhatsApp leen de acá productos, precios, stock y fotos (nunca costos). */
function catalogSection() {
  const url = catalogUrl();
  return html`<section class="card" id="aj-catalogo" aria-labelledby="h-cat"><h2 id="h-cat">Catálogo para la web y WhatsApp</h2>
    <p class="small muted">Publica los productos activos con precio, stock y foto para que la página web y el bot de WhatsApp muestren siempre los precios de este sistema. No publica costos, proveedores ni clientes.</p>
    ${settings().public_catalog_key ? html`<div class="notice notice-ok"><p><b>Activado.</b> Dirección del catálogo:</p><p class="small" style="word-break:break-all"><code>${url || '(conectá la nube para ver la dirección)'}</code></p></div>
      <div class="btn-row"><button type="button" class="btn ghost" id="cat-pub-copy">Copiar dirección</button><button type="button" class="btn ghost" id="cat-pub-off">Desactivar</button></div>`
    : html`<div class="btn-row"><button type="button" class="btn primary" id="cat-pub-on">Activar catálogo</button></div>`}
  </section>`;
}
