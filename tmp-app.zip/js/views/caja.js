// =====================================================================
// caja.js — Abrir caja, ingresos/egresos, cierre con arqueo (ciego para
// cajero y vendedor), informe de cierre, stock para revisar e historial.
// =====================================================================
import * as db from '../db.js';
import { ctx, openSession, sessionArqueo, addCashMovement, userName, sessionData, multiBranch, branches, currentBranch, inBranch, branchName, mainBranchId } from '../ops.js';
import { html, $, on, ic, modal, toast, fieldError } from '../ui.js';
import { fmtMoney, fmtDateTime, fmtTime, parseNum, payLabel, round2, toISODate, dayStart, dayEnd, branchOf, can } from '../logic.js';
import { isManager, filterSessions, shortageStatus } from '../control.js';
import { askOpenCash } from './vender.js';
import { printHTML } from '../print.js';
import { backupNotice, doBackup } from './ajustes.js';
import { auditOps, closeCashSession, sessionReport, reopenCash, auditEntries } from '../seguridad.js';
import { authorize, guardClock, confirmWarnings } from '../autoriza.js';
import { billsHTML, readBills, paintBills, closingReportHTML, sessionStockIssues, stockIssuesHTML, bindStockFix } from '../cierre.js';
import { saveCashMovement } from '../tesoreria-ops.js';
import { chequeFieldsHTML, readCheque, walletPickerHTML, pickedCheques } from './cheque-ui.js';
import { expenseDialog } from './gastos.js';

let main;
// Filtros del historial (se recuerdan en este equipo). branch: '' = la de este equipo, 'all' = todas, o un id
const HKEY = 'jg-filtros-caja';
const hf = { branch: '', user: '', diff: '', from: '', to: '' };
try { Object.assign(hf, JSON.parse(localStorage.getItem(HKEY) || '{}')); } catch (e) { /* sin almacenamiento */ }
const saveHf = () => { try { localStorage.setItem(HKEY, JSON.stringify({ branch: hf.branch, user: hf.user, diff: hf.diff })); } catch (e) { /* nada */ } };

// Ver lo esperado (sin esto, arqueo ciego) y movimientos con cheques: según los permisos del usuario
const manager = () => !!ctx.user && can(ctx.user, 'ver_esperado');

export async function render(m) {
  main = m;
  await paint();
  const off = on(main, 'click', '[data-act]', (e, el) => act(el.dataset.act, el));
  const onSel = e => {
    const t = e.target;
    if (!t.closest('#cj-hf')) return;
    hf.branch = ($('#cj-branch', main) || {}).value || '';
    if (hf.branch === ctx.branchId) hf.branch = '';
    hf.user = $('#cj-user', main).value; hf.diff = $('#cj-diff', main).value;
    hf.from = $('#cj-from', main).value; hf.to = $('#cj-to', main).value;
    saveHf();
    paintHistory();
  };
  main.addEventListener('change', onSel);
  return () => { off(); main.removeEventListener('change', onSel); };
}

async function paint() {
  const s = openSession();
  const notice = s ? '' : await backupNotice();
  const multi = multiBranch();
  const cur = currentBranch();
  const hb = hf.branch || ctx.branchId;
  const users = db.all('users', { includeDeleted: true }).filter(u => u.name).sort((a, b) => String(a.name).localeCompare(String(b.name), 'es'));
  main.innerHTML = String(html`
    <div class="page-head"><h1>Caja${multi && cur ? html` <span class="branch-tag" style="font-size:.9rem;vertical-align:middle">${cur.name}</span>` : ''}</h1></div>
    ${notice}
    ${s ? openView(s) : html`<div class="card" style="text-align:center">
        <p class="lead"><b>La caja${multi && cur ? ` de ${cur.name}` : ''} está cerrada.</b></p>
        <p class="muted">Abrila al empezar el día con el efectivo que hay en el cajón.</p>
        <button type="button" class="btn primary big" data-act="open">Abrir caja</button></div>`}
    <div class="card"><div class="card-head"><h2>Cierres anteriores</h2></div>
      <form id="cj-hf" class="filters" aria-label="Filtros del historial">
        ${multi ? html`<div class="field"><label for="cj-branch">Sucursal</label><select id="cj-branch">
          ${branches({ includeInactive: true }).map(b => html`<option value="${b.id}" ${hb === b.id ? 'selected' : ''}>${b.name}</option>`)}
          <option value="all" ${hb === 'all' ? 'selected' : ''}>Todas las sucursales</option></select></div>` : ''}
        <div class="field"><label for="cj-from">Desde</label><input id="cj-from" type="date" value="${hf.from}"></div>
        <div class="field"><label for="cj-to">Hasta</label><input id="cj-to" type="date" value="${hf.to}"></div>
        <div class="field"><label for="cj-user">Usuario</label><select id="cj-user"><option value="">Todos</option>${users.map(u => html`<option value="${u.id}" ${hf.user === u.id ? 'selected' : ''}>${u.name}</option>`)}</select></div>
        <div class="field"><label for="cj-diff">Diferencia</label><select id="cj-diff">
          ${[['', 'Todas'], ['con', 'Con diferencia'], ['faltante', 'Con faltante'], ['sobrante', 'Con sobrante']].map(([v, l]) => html`<option value="${v}" ${hf.diff === v ? 'selected' : ''}>${l}</option>`)}</select></div>
      </form>
      <p class="muted small" id="cj-count" aria-live="polite"></p>
      <div id="cj-hist"></div>
    </div>`);
  $('#cj-hf', main).addEventListener('submit', e => e.preventDefault());
  paintHistory();
}

function historyList() {
  const multi = multiBranch();
  const hb = hf.branch || ctx.branchId;
  const base = db.all('cash_sessions').filter(x => !multi || hb === 'all' || inBranch(x, hb));
  return filterSessions(base, { from: hf.from ? dayStart(hf.from) : 0, to: hf.to ? dayEnd(hf.to) : 0, user: hf.user, diff: hf.diff });
}

function paintHistory() {
  const box = $('#cj-hist', main);
  if (!box) return;
  const multi = multiBranch();
  const hb = hf.branch || ctx.branchId;
  const all = historyList();
  const list = all.slice(0, 60);
  const filtering = hf.user || hf.diff || hf.from || hf.to;
  $('#cj-count', main).textContent = all.length ? `${all.length} ${all.length === 1 ? 'cierre' : 'cierres'}${all.length > list.length ? ` (se muestran los ${list.length} más recientes)` : ''}` : '';
  box.innerHTML = String(list.length ? html`<ul class="list" id="cj-list">${list.map(h => html`<li><button type="button" class="row" data-act="hist" data-id="${h.id}">
      <span class="grow"><span class="title">${fmtDateTime(h.opened_at)} → ${toISODate(h.opened_at) === toISODate(h.closed_at) ? fmtTime(h.closed_at) : fmtDateTime(h.closed_at)}</span>
      <span class="sub" style="display:block">${multi && hb === 'all' ? html`<span class="branch-tag">${branchName(h.branch_id)}</span> ` : ''}Abrió ${userName(h.opened_by)} · Cerró ${userName(h.closed_by)}${h.blind ? ' · ciego' : ''}${manager() ? ` · Esperado ${fmtMoney(h.expected_amount)}` : ''}</span></span>
      ${diffBadge(h.difference)}</button></li>`)}</ul>`
    : html`<p class="empty">${filtering ? 'No hay cierres con esos filtros.' : multi ? 'No hay cierres de caja en esa sucursal.' : 'Todavía no cerraste ninguna caja.'}</p>`);
}

function diffBadge(d) {
  if (d === null || d === undefined) return '';
  if (Math.abs(d) < 0.005) return html`<span class="badge ok">Justo</span>`;
  return d > 0 ? html`<span class="badge warn money">Sobra ${fmtMoney(d)}</span>` : html`<span class="badge err money">Falta ${fmtMoney(-d)}</span>`;
}

function movementsList(movs) {
  const MED = { mercadopago: 'Mercado Pago', cheque: 'Cheque' };
  return movs.length ? html`<ul class="list" id="cj-movs">${movs.map(x => html`<li class="row"><span class="grow"><span class="title">${x.reason || (x.type === 'ingreso' ? 'Ingreso' : 'Egreso')}</span>
      <span class="sub" style="display:block">${x.number ? html`<span class="mv-num">N° ${x.number}</span> · ` : ''}${fmtTime(x.created_at)} · ${userName(x.user_id)}${MED[x.method] ? html` · <span class="badge info">${MED[x.method]}</span>` : ''}</span></span>
      <b class="money" style="color:${x.type === 'egreso' ? 'var(--danger)' : 'var(--brand-dark)'}">${x.type === 'egreso' ? '-' : '+'}${fmtMoney(x.amount)}</b></li>`)}</ul>`
    : html`<p class="muted">Sin movimientos. Usá “Egreso” para pagos a proveedores o gastos en efectivo.</p>`;
}

function openView(s) {
  const a = sessionArqueo(s);
  const { movements, sales } = sessionData(s);
  const movs = movements.filter(x => x.type === 'ingreso' || x.type === 'egreso').sort((x, y) => y.created_at - x.created_at);
  const voided = sales.filter(x => x.status === 'anulada').length;
  const buttons = html`<div class="btn-row" style="margin-bottom:1rem">
      <button type="button" class="btn ghost big" data-act="ingreso">${ic('plus')} Ingreso</button>
      <button type="button" class="btn ghost big" data-act="egreso">${ic('minus')} Egreso / gasto</button>
      <button type="button" class="btn ghost big" data-act="gasto">${ic('receipt')} Cargar gasto</button>
      <button type="button" class="btn primary big" data-act="close">Cerrar caja</button>
    </div>`;
  const head = html`<div class="notice notice-ok"><p><b>Caja abierta${multiBranch() ? ` en ${branchName(s.branch_id)}` : ''}</b> desde ${fmtDateTime(s.opened_at)} por ${userName(s.opened_by)}.</p></div>`;
  if (!manager()) {
    // Arqueo ciego: el cajero / vendedor no ve el efectivo esperado ni los totales (se ven al cerrar)
    return html`${head}
      <div class="stats"><div class="stat"><div class="k">Ventas</div><div class="v" id="cj-count-sales">${a.count}</div></div>
        <div class="stat"><div class="k">Inicial</div><div class="v money">${fmtMoney(a.opening)}</div></div></div>
      <div class="notice notice-info" id="cj-blind"><p>Al cerrar, contás los billetes del cajón <b>sin ver cuánto debería haber</b>. La diferencia se ve después de cerrar y queda registrada.</p></div>
      ${buttons}
      <div class="card"><div class="card-head"><h2>Ingresos y egresos</h2></div>${movementsList(movs)}
        <p class="small muted" style="margin-top:.5rem">Los movimientos quedan registrados con tu usuario y no se pueden modificar.</p></div>`;
  }
  return html`${head}
    <div class="stats">
      <div class="stat hero"><div class="k">Efectivo que debería haber</div><div class="v money" id="cj-expected">${fmtMoney(a.expected)}</div></div>
      <div class="stat"><div class="k">Vendido hoy</div><div class="v money">${fmtMoney(a.salesTotal)}</div></div>
      <div class="stat"><div class="k">Ventas</div><div class="v">${a.count}</div></div>
      <div class="stat"><div class="k">Inicial</div><div class="v money">${fmtMoney(a.opening)}</div></div>
      <div class="stat"><div class="k">Efectivo ventas</div><div class="v money">${fmtMoney(a.cashSales)}</div></div>
      ${a.returnsCount ? html`<div class="stat"><div class="k">Devoluciones (${a.returnsCount})</div><div class="v money" id="cj-devs">-${fmtMoney(a.returnsTotal)}</div></div>
        <div class="stat"><div class="k">Efectivo devuelto</div><div class="v money">-${fmtMoney(a.devoluciones)}</div></div>` : ''}
    </div>
    ${buttons}
    <div class="card"><div class="card-head"><h2>Por medio de pago</h2></div>
      ${Object.keys(a.byMethod).length ? html`<ul class="list">${Object.entries(a.byMethod).map(([k, v]) => html`<li class="row"><span class="grow">${payLabel(k)}</span><b class="money">${fmtMoney(v)}</b></li>`)}</ul>`
        : html`<p class="muted">Sin ventas todavía.</p>`}</div>
    <div class="card"><div class="card-head"><h2>Ingresos y egresos</h2></div>${movementsList(movs)}</div>
    ${voided ? html`<p class="muted small">Ventas anuladas en esta caja: ${voided}</p>` : ''}`;
}

async function act(name, el) {
  if (name === 'backup') { await doBackup(); return paint(); }
  if (name === 'open') { if (await askOpenCash()) paint(); return; }
  if (name === 'ingreso' || name === 'egreso') { if (await movementDialog(name)) paint(); return; }
  if (name === 'gasto') { if (await expenseDialog({ toCash: true })) paint(); return; }
  if (name === 'close') { if (await closeDialog()) paint(); return; }
  if (name === 'hist') { await historyDetail(db.get('cash_sessions', el.dataset.id)); paint(); }
}

async function movementDialog(type) {
  // Movimiento como SGI: efectivo, Mercado Pago y cheques de terceros, con número correlativo. Solo el efectivo cambia el arqueo.
  const mgr = manager();
  return modal({
    title: type === 'ingreso' ? 'Entrada de caja' : 'Salida de caja',
    body: html`<form id="mv" novalidate>
      <div class="mv-media">
        <div class="field"><label for="mv-a">Efectivo</label><input id="mv-a" class="money-input" inputmode="decimal" placeholder="0,00" autocomplete="off"></div>
        <div class="field"><label for="mv-mp">Mercado Pago <span class="muted">(no cambia el efectivo)</span></label><input id="mv-mp" class="money-input" inputmode="decimal" placeholder="0,00" autocomplete="off"></div>
      </div>
      ${type === 'ingreso' ? html`<details id="mv-chq"><summary>Entra un cheque de terceros</summary>${chequeFieldsHTML('mvc')}</details>`
        : mgr ? html`<details id="mv-chq"><summary>Sale con cheques de la cartera</summary>${walletPickerHTML('mvw')}</details>` : ''}
      <div class="field"><label for="mv-r">Detalle</label><input id="mv-r" list="mv-sug" placeholder="${type === 'ingreso' ? 'Ej: cambio, aporte' : 'Ej: pago proveedor, flete, retiro'}">
      <datalist id="mv-sug">${(type === 'ingreso' ? ['Cambio', 'Aporte del dueño', 'Cobro de cheque'] : ['Pago a proveedor', 'Retiro del dueño', 'Gastos varios', 'Flete', 'Limpieza', 'Depósito en banco']).map(x => html`<option value="${x}"></option>`)}</datalist></div>
      <p class="small muted">Queda registrado con tu usuario, la hora y un número de movimiento. Después no se puede modificar ni borrar. Para un gasto con tipo (flete, limpieza…) usá “Cargar gasto”.</p></form>`,
    onMount(m) { $('#mv', m).addEventListener('submit', e => { e.preventDefault(); m.parentElement.querySelector('.modal-foot .primary').click(); }); },
    actions: [{ label: 'Cancelar', value: false }, {
      label: 'Guardar', kind: 'primary', id: 'mv-go', onClick: async (close, w) => {
        const inp = $('#mv-a', w), mpInp = $('#mv-mp', w);
        const v = inp.value.trim() === '' ? 0 : parseNum(inp.value);
        const mp = mpInp.value.trim() === '' ? 0 : parseNum(mpInp.value);
        if (!isFinite(v) || v < 0) return fieldError(inp, 'Escribí un importe válido.');
        if (!isFinite(mp) || mp < 0) return fieldError(mpInp, 'Escribí un importe válido.');
        const chqOpen = $('#mv-chq', w) && $('#mv-chq', w).open;
        const newCheques = type === 'ingreso' && chqOpen && $('#mvc-num', w).value.trim() ? [readCheque(w, 'mvc')] : [];
        if (newCheques.length && !(newCheques[0].amount > 0)) return fieldError($('#mvc-amt', w), 'Escribí el importe del cheque.');
        const chequeIds = type === 'egreso' && chqOpen ? pickedCheques(w, 'mvw').ids : [];
        if (!(v > 0) && !(mp > 0) && !newCheques.length && !chequeIds.length) return fieldError(inp, 'Escribí un importe mayor a cero.');
        if (v >= 1e9 || mp >= 1e9) return fieldError(inp, 'Ese importe es demasiado alto: revisalo.');
        const r = $('#mv-r', w);
        if (!r.value.trim()) return fieldError(r, 'Escribí el motivo.');
        const s = openSession();
        const big = s && v > 10 * Math.max(sessionArqueo(s).expected, Number(s.opening_amount) || 0, 10000);
        if (big && !(await confirmWarnings([`¿Seguro que el ${type} es de ${fmtMoney(v)}? Es un importe muy alto.`]))) return;
        try {
          const res = await saveCashMovement({ type, cash: v, mp, newCheques, chequeIds, detail: r.value });
          toast(`Movimiento N° ${res.number} guardado.`); close(true);
        } catch (e) { toast(e.message, 'error'); }
      },
    }],
  });
}

async function closeDialog() {
  if (!(await guardClock('cerrar la caja'))) return false;
  const s = openSession();
  if (!s) return false;
  const blind = !manager();
  const a = sessionArqueo(s);
  const closed = await modal({
    title: 'Cerrar caja',
    size: 'wide',
    body: html`
      ${blind ? html`<div class="notice notice-info"><p><b>Contá el efectivo del cajón</b> y anotá cuántos billetes hay de cada uno. La diferencia la vas a ver después de cerrar.</p></div>`
        : html`<div class="stats" style="grid-template-columns:1fr 1fr">
        <div class="stat"><div class="k">Inicial</div><div class="v money">${fmtMoney(a.opening)}</div></div>
        <div class="stat"><div class="k">+ Efectivo ventas</div><div class="v money">${fmtMoney(a.cashSales)}</div></div>
        <div class="stat"><div class="k">+ Ingresos</div><div class="v money">${fmtMoney(a.ingresos)}</div></div>
        <div class="stat"><div class="k">− Egresos</div><div class="v money">${fmtMoney(a.egresos)}</div></div>
        ${a.devoluciones ? html`<div class="stat"><div class="k">− Devoluciones en efectivo</div><div class="v money">${fmtMoney(a.devoluciones)}</div></div>` : ''}
        <div class="stat hero"><div class="k">Esperado en efectivo</div><div class="v money">${fmtMoney(a.expected)}</div></div>
      </div>`}
      <form id="cc" novalidate>
        ${billsHTML()}
        <div class="change-box" id="cc-total-box"><div class="k">Total contado</div><div class="v money" id="cc-total">$ 0,00</div></div>
        ${blind ? '' : html`<div class="change-box" id="cc-diff" aria-live="polite"><div class="k">Diferencia</div><div class="v">—</div></div>`}
        <div class="field"><label for="cc-n">Notas <span class="muted">(opcional)</span></label><input id="cc-n"></div>
        <p id="cc-err" class="field-err" role="alert"></p>
      </form>`,
    onMount(m) {
      const upd = () => {
        paintBills(m);
        const r = readBills(m);
        $('#cc-err', m).textContent = r.error || '';
        $('#cc-total', m).textContent = fmtMoney(r.error ? 0 : r.total);
        const box = $('#cc-diff', m);
        if (!box) return;
        if (r.error) { box.className = 'change-box'; box.innerHTML = '<div class="k">Diferencia</div><div class="v">—</div>'; return; }
        const d = round2(r.total - a.expected); // misma cuenta que computeArqueo
        box.className = 'change-box ' + (Math.abs(d) < 0.005 ? 'ok' : 'miss');
        box.innerHTML = String(html`<div class="k">${Math.abs(d) < 0.005 ? 'Está justo' : d > 0 ? 'Sobra' : 'Falta'}</div><div class="v money" id="cc-dv">${fmtMoney(Math.abs(d))}</div>`);
      };
      m.addEventListener('input', upd);
      $('#cc', m).addEventListener('submit', e => { e.preventDefault(); m.parentElement.querySelector('#cc-go').click(); });
      // Enter en un billete pasa al siguiente (como en una planilla)
      m.addEventListener('keydown', e => {
        if (e.key !== 'Enter' || !e.target.matches('[data-bill], [data-bill-other]')) return;
        e.preventDefault();
        const all = [...m.querySelectorAll('[data-bill], [data-bill-other], #cc-n')];
        const i = all.indexOf(e.target);
        if (all[i + 1]) all[i + 1].focus();
      });
      upd();
    },
    actions: [{ label: 'Cancelar', value: false }, {
      label: 'Cerrar caja', kind: 'primary', id: 'cc-go', onClick: async (close, w) => {
        const r = readBills(w);
        if (r.error) return fieldError(r.input, r.error);
        const msg = blind
          ? `Vas a cerrar la caja con ${fmtMoney(r.total)} contados. Después no se puede cambiar.`
          : `Vas a cerrar la caja con ${fmtMoney(r.total)} contados (esperado ${fmtMoney(a.expected)}).`;
        if (!(await confirmWarnings([msg], { title: 'Confirmar cierre', ok: 'Sí, cerrar la caja' }))) return;
        try { close(await closeCashSession(r.total, $('#cc-n', w).value)); } catch (e) { toast(e.message, 'error'); }
      },
    }],
  });
  if (!closed) return false;
  toast('Caja cerrada.');
  await resultDialog(closed);
  return true;
}

/** Después de cerrar: recién acá el cajero ve si sobró o faltó. Informe imprimible y stock para revisar. */
async function resultDialog(s) {
  const r = sessionReport(s);
  const d = Number(s.difference) || 0;
  const issues = sessionStockIssues(s, r);
  await modal({
    title: 'Caja cerrada',
    size: 'wide',
    body: html`
      <div class="change-box ${Math.abs(d) < 0.005 ? 'ok' : 'miss'}" id="cr-result"><div class="k">${Math.abs(d) < 0.005 ? 'Está justo' : d < 0 ? 'Faltante' : 'Sobrante'}</div><div class="v money" id="cr-diff">${fmtMoney(Math.abs(d))}</div></div>
      <p class="lead" style="text-align:center">Contado <b class="money">${fmtMoney(s.counted_amount)}</b> · Esperado <b class="money">${fmtMoney(s.expected_amount)}</b></p>
      ${s.shortage_amount > 0 ? html`<div class="notice notice-warn" id="cr-shortage"><p>El faltante de <b>${fmtMoney(s.shortage_amount)}</b> queda registrado a cargo de <b>${userName(s.shortage_user_id)}</b>. El dueño lo revisa en Auditoría → Faltantes.</p></div>` : ''}
      <div class="card" style="padding:.7rem .9rem"><div class="card-head"><h2>Stock para revisar</h2></div><div id="cr-stock">${stockIssuesHTML(issues)}</div></div>
      <details><summary>Ver el informe de cierre</summary><div style="margin-top:.6rem">${closingReportHTML(s, r)}</div></details>`,
    onMount(m) { bindStockFix(m, () => { const box = $('#cr-stock', m); if (box) box.innerHTML = String(stockIssuesHTML(sessionStockIssues(s, r))); }); },
    actions: [{ label: 'Listo', value: true }, { label: html`${ic('print')} Imprimir informe`, kind: 'primary', id: 'cr-print', onClick: () => printHTML(closingReportHTML(s, r)) }],
  });
}

async function historyDetail(s) {
  if (!s) return;
  const r = sessionReport(s);
  const audits = await auditEntries();
  const st = s.shortage_amount > 0 || Number(s.difference) < -0.004 ? shortageStatus(s.id, audits) : '';
  const br = branchOf(s, mainBranchId());
  const isLast = !db.all('cash_sessions').some(x => x.id !== s.id && inBranch(x, br) && x.opened_at > s.opened_at);
  const canReopen = isLast && br === ctx.branchId && !openSession();
  const issues = ctx.user && can(ctx.user, 'ajustar_stock') ? sessionStockIssues(s, r) : [];
  await modal({
    title: `Caja del ${fmtDateTime(s.opened_at)}${multiBranch() ? ` · ${branchName(s.branch_id)}` : ''}`,
    size: 'wide',
    body: html`${diffBadge(s.difference)} ${s.blind ? html`<span class="badge info">Arqueo ciego</span>` : ''}
      ${st ? html` <span class="badge ${st === 'pendiente' ? 'err' : 'ok'}" id="hd-shortage">Faltante ${st}</span>` : ''}
      ${issues.length ? html`<div class="card" style="padding:.7rem .9rem;margin-top:.75rem"><div class="card-head"><h2>Stock para revisar (stock actual)</h2></div><div id="hd-stock">${stockIssuesHTML(issues)}</div></div>` : ''}
      <div style="margin-top:.75rem">${closingReportHTML(s, r)}</div>`,
    onMount(m) { bindStockFix(m, () => { const box = $('#hd-stock', m); if (box) box.innerHTML = String(stockIssuesHTML(sessionStockIssues(s, r))); }); },
    actions: [
      { label: 'Cerrar', value: true },
      ...(canReopen ? [{ label: 'Reabrir caja', id: 'hd-reopen', onClick: async close => { if (await reopenDialog(s)) close(true); } }] : []),
      { label: html`${ic('print')} Imprimir`, kind: 'primary', onClick: () => printHTML(closingReportHTML(s, r)) },
    ],
  });
}

async function reopenDialog(s) {
  const reason = await modal({
    title: 'Reabrir caja',
    body: html`<p>Se vuelve a abrir la caja del ${fmtDateTime(s.opened_at)}: se borra el cierre (contado, diferencia y faltante) y se va a tener que cerrar de nuevo. Queda registrado en la auditoría.</p>
      <div class="field"><label for="ro-r">Motivo</label><input id="ro-r" placeholder="Ej: se cerró por error"></div>`,
    actions: [{ label: 'Cancelar', value: null }, { label: 'Reabrir', kind: 'danger', id: 'ro-go', onClick: (close, w) => { const v = $('#ro-r', w).value.trim(); if (!v) return fieldError($('#ro-r', w), 'Escribí el motivo.'); close(v); } }],
  });
  if (!reason) return false;
  const auth = await authorize('reabrir una caja cerrada', { action: 'caja_reabierta', entity: 'cash_sessions', entityId: s.id, perm: 'reabrir_caja' });
  if (!auth) return false;
  try { await reopenCash(s.id, { auth, reason }); toast('Caja reabierta.'); return true; } catch (e) { toast(e.message, 'error', 5000); return false; }
}
