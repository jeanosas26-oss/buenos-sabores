// =====================================================================
// tesoreria.js — Tesorería y Balance (saldos por medio, cajas abiertas, cheques en cartera, cuentas por cobrar y por
// pagar, resultado del período), cartera de cheques y bancos, informes "Cajas cerradas" y "Caja diaria"
// (imprimibles y Excel) y "Recalcular stock y saldos" (solo el dueño).
// =====================================================================
import * as db from '../db.js';
import { ctx, userName, multiBranch, branches, branchName, mainBranchId, settings } from '../ops.js';
import { html, $, on, ic, modal, toast, fieldError, confirm, exportTable } from '../ui.js';
import { fmtMoney, fmtDate, fmtTime, fmtDateTime, fmtQty, parseNum, round2, toISODate, dayStart, dayEnd, payLabel, branchOf, can } from '../logic.js';
import {
  treasury, MEDIA_LABEL, chequesDueSoon, chequesSummary, chequeStatusLabel, CHEQUE_NEXT, daysToDue, sessionSummary, recalcStock, recalcBalances, liveExpense,
  expenseMethodLabel,
} from '../tesoreria-calc.js';
import { banks, bankName, seedBanks, saveBank, saveCheque, moveCheque, applyRecalc, expenseTypeName } from '../tesoreria-ops.js';
import { chequeFieldsHTML, readCheque } from './cheque-ui.js';
import { printA4, printHead } from './ctacte.js';
import { purchaseDocLabel, paymentLabel, isVoidPurchase, purchaseSign } from '../compras-calc.js';

let main;
let tab = 'balance';
const owner = () => !!ctx.user && ctx.user.role === 'dueno';
const monthStart = () => { const d = new Date(); return toISODate(new Date(d.getFullYear(), d.getMonth(), 1).getTime()); };
const f = { from: monthStart(), to: toISODate(Date.now()), branch: '', day: toISODate(Date.now()), chq: 'en_cartera' };
let recalc = null; // resultado de "Revisar" (recalcular)

const TABS = () => [['balance', 'Tesorería y balance'], ['cheques', 'Cheques'], ['cajas', 'Cajas cerradas'], ['diaria', 'Caja diaria'], ['bancos', 'Bancos'],
  ...(owner() ? [['recalcular', 'Recalcular']] : [])];

export async function render(m) {
  main = m;
  const qt = new URLSearchParams(location.hash.split('?')[1] || '').get('tab');
  if (qt && TABS().some(t => t[0] === qt)) tab = qt;
  await seedBanks().catch(e => console.warn('bancos', e));
  paint();
  const off = on(main, 'click', '[data-act], [data-tab], [data-chq], [data-bank]', async (e, el) => {
    if (el.dataset.tab) { tab = el.dataset.tab; paint(); return; }
    if (el.dataset.chq) { await chequeDetail(db.get('cheques', el.dataset.chq)); paint(); return; }
    if (el.dataset.bank) { await bankDialog(db.get('banks', el.dataset.bank)); paint(); return; }
    const a = el.dataset.act;
    if (a === 'print') doPrint();
    if (a === 'excel') doExcel();
    if (a === 'new-cheque') { if (await newChequeDialog()) paint(); }
    if (a === 'new-bank') { await bankDialog(); paint(); }
    if (a === 'rc-check') { recalc = computeRecalc(); paint(); }
    if (a === 'rc-all') { main.querySelectorAll('[data-rc]').forEach(x => { x.checked = true; }); }
    if (a === 'rc-none') { main.querySelectorAll('[data-rc]').forEach(x => { x.checked = false; }); }
    if (a === 'rc-apply') { await applyRecalcUI(); }
  });
  const onCh = e => {
    const t = e.target;
    if (!t.closest('#ts-f')) return;
    for (const [k, id] of [['from', 'ts-from'], ['to', 'ts-to'], ['branch', 'ts-branch'], ['day', 'ts-day'], ['chq', 'ts-chq']]) { const x = $('#' + id, main); if (x) f[k] = x.value; }
    paint();
  };
  main.addEventListener('change', onCh);
  return () => { off(); main.removeEventListener('change', onCh); };
}

function rangeMs() { return { from: f.from ? dayStart(f.from) : -Infinity, to: f.to ? dayEnd(f.to) : Infinity }; }
const branchSel = () => (multiBranch() ? html`<div class="field"><label for="ts-branch">Sucursal</label><select id="ts-branch"><option value="">Todas</option>${branches({ includeInactive: true }).map(b => html`<option value="${b.id}" ${f.branch === b.id ? 'selected' : ''}>${b.name}</option>`)}</select></div>` : '');
const periodSel = () => html`<div class="field"><label for="ts-from">Desde</label><input id="ts-from" type="date" value="${f.from}"></div><div class="field"><label for="ts-to">Hasta</label><input id="ts-to" type="date" value="${f.to}"></div>`;
const tools = () => html`<div class="btn-row" style="margin-bottom:1rem"><button type="button" class="btn ghost" data-act="print">${ic('print')} Imprimir</button><button type="button" class="btn ghost" data-act="excel">${ic('download')} Excel</button></div>`;
const inBranch = r => !f.branch || branchOf(r, mainBranchId()) === f.branch;

function paint() {
  if (!TABS().some(t => t[0] === tab)) tab = 'balance';
  const due = chequesDueSoon(db.all('cheques'));
  main.innerHTML = String(html`<div class="page-head"><h1>Tesorería</h1></div>
    ${due.length ? html`<div class="notice notice-warn" id="ts-due"><p><b>${due.length === 1 ? 'Hay 1 cheque' : `Hay ${due.length} cheques`} en cartera por vencer o vencidos</b> (próximos 7 días): ${due.slice(0, 3).map(c => `${bankName(c.bank_id) || 'cheque'} N° ${c.number} ${fmtMoney(c.amount)} (${c.days < 0 ? 'vencido' : c.days === 0 ? 'hoy' : `en ${c.days} días`})`).join(' · ')}${due.length > 3 ? '…' : ''}</p></div>` : ''}
    <div class="chips" role="tablist">${TABS().map(([k, l]) => html`<button type="button" class="chip" role="tab" data-tab="${k}" aria-pressed="${tab === k}" aria-selected="${tab === k}">${l}</button>`)}</div>
    ${tab === 'balance' ? balanceView() : tab === 'cheques' ? chequesView() : tab === 'cajas' ? closedView() : tab === 'diaria' ? dailyView() : tab === 'bancos' ? banksView() : recalcView()}`);
}

// ---------- Tesorería y balance ----------

function treasuryData() {
  const all = c => db.all(c).filter(inBranch);
  const products = new Map(db.all('products', { includeDeleted: true }).map(p => [p.id, p]));
  const { from, to } = rangeMs();
  return treasury({
    sales: all('sales'), returns: all('returns'), cash_movements: all('cash_movements'), cash_sessions: all('cash_sessions'), purchases: all('purchases'),
    expenses: all('expenses'), supplier_payments: all('supplier_payments'), customer_payments: all('customer_payments'), cheques: db.all('cheques'),
    customers: db.all('customers'), suppliers: db.all('suppliers'), expense_types: db.all('expense_types'),
  }, { from, to, costOf: id => (products.get(id) || {}).cost || 0, mainId: mainBranchId() });
}

function balanceView() {
  const t = treasuryData();
  const r = t.result;
  const v = (k, val, id = '') => html`<div class="stat"><div class="k">${k}</div><div class="v money ${val < 0 ? 'neg' : ''}" ${id ? html`id="${id}"` : ''}>${fmtMoney(val)}</div></div>`;
  return html`<form class="card filters" id="ts-f" onsubmit="return false">${periodSel()}${branchSel()}</form>${tools()}
    <h2>Saldos hoy</h2>
    <div class="t-grid">
      ${v('Efectivo en cajas abiertas', t.cashTotal, 'ts-cash')}
      ${v(`Cheques en cartera (${t.cheques.count})`, t.cheques.total, 'ts-chq')}
      ${v('Cuentas por cobrar (clientes)', t.receivable, 'ts-rec')}
      ${v('Cuentas por pagar (proveedores)', t.payable, 'ts-pay')}
    </div>
    ${t.cash.length ? html`<ul class="t-rows">${t.cash.map(c => html`<li><span>Caja abierta${multiBranch() ? ` · ${branchName(c.branch_id)}` : ''} desde ${fmtDateTime(c.opened_at)}</span><b class="money">${fmtMoney(c.expected)}</b></li>`)}</ul>` : html`<p class="muted small">No hay cajas abiertas.</p>`}
    ${t.customerCredit || t.supplierCredit ? html`<p class="small muted">Saldos a favor: de clientes ${fmtMoney(t.customerCredit)} · nuestro con proveedores ${fmtMoney(t.supplierCredit)}.</p>` : ''}
    <div class="card"><div class="card-head"><h2>Entradas y salidas del período por medio</h2></div>
      <ul class="t-rows" id="ts-media">${Object.entries(t.media).filter(([, m]) => m.in || m.out).map(([k, m]) => html`<li><span>${MEDIA_LABEL[k]}</span>
        <span class="nums"><span>+ ${fmtMoney(m.in)}</span><span>− ${fmtMoney(m.out)}</span><b class="money ${m.net < 0 ? 'neg' : ''}">${fmtMoney(m.net)}</b></span></li>`)}</ul>
      <p class="small muted">Efectivo: ventas, cobros e ingresos menos pagos, gastos, compras y devoluciones (lo de contado que no salió de la caja también cuenta). Bancos: transferencias y cheques depositados.</p></div>
    <div class="card"><div class="card-head"><h2>Resultado del período</h2></div>
      <ul class="t-rows" id="ts-result">
        <li><span>Ventas (con IVA, menos devoluciones) · ${r.count} ventas</span><b class="money">${fmtMoney(r.sales)}</b></li>
        <li><span>− IVA de las ventas</span><b class="money">${fmtMoney(r.iva)}</b></li>
        <li><span>Ventas netas</span><b class="money">${fmtMoney(r.netSales)}</b></li>
        <li><span>− Costo de ventas${r.costKnown ? '' : ' (hay productos sin costo cargado)'}</span><b class="money">${fmtMoney(r.cost)}</b></li>
        <li><span>Ganancia bruta</span><b class="money">${fmtMoney(r.gross)}</b></li>
        <li><span>− Gastos</span><b class="money">${fmtMoney(r.expenses)}</b></li>
        <li class="t-total"><span>Resultado</span><b class="money ${r.result < 0 ? 'neg' : ''}" id="ts-res">${fmtMoney(r.result)}</b></li></ul>
      <p class="small muted">El costo de ventas usa el costo actual de cada producto. No incluye pagos a proveedores ni retiros de efectivo (${fmtMoney(r.expensesOther)} en el período). Compras del período: ${t.purchases.count} por ${fmtMoney(t.purchases.total)}.</p></div>`;
}

// ---------- Cheques ----------

function chequesView() {
  const all = db.all('cheques');
  const s = chequesSummary(all);
  const list = all.filter(c => !f.chq || c.status === f.chq).sort((a, b) => String(a.due_date || '').localeCompare(String(b.due_date || '')));
  const mgr = can(ctx.user, 'compras');
  return html`<div class="t-grid">${Object.keys(CHEQUE_NEXT).map(k => html`<div class="stat"><div class="k">${chequeStatusLabel(k)} (${(s.byStatus[k] || {}).count || 0})</div><div class="v money">${fmtMoney((s.byStatus[k] || {}).total || 0)}</div></div>`)}</div>
    ${mgr ? html`<div class="btn-row" style="margin-bottom:1rem"><button type="button" class="btn primary" data-act="new-cheque">${ic('plus')} Cargar cheque</button></div>` : ''}
    <form class="card filters" id="ts-f" onsubmit="return false"><div class="field"><label for="ts-chq">Estado</label><select id="ts-chq"><option value="">Todos</option>${Object.keys(CHEQUE_NEXT).map(k => html`<option value="${k}" ${f.chq === k ? 'selected' : ''}>${chequeStatusLabel(k)}</option>`)}</select></div></form>
    <div class="card">${list.length ? html`<ul class="list" id="ts-chqs">${list.map(c => {
      const d = daysToDue(c.due_date);
      const warn = c.status === 'en_cartera' && d !== null && d <= 7;
      return html`<li class="${warn ? (d < 0 ? 'chq-over' : 'chq-due') : ''}"><button type="button" class="row" data-chq="${c.id}">
        <span class="grow"><span class="title">${bankName(c.bank_id) || 'Cheque'} N° ${c.number}${c.kind === 'propio' ? ' · propio' : ''}</span>
        <span class="sub" style="display:block">Cobro ${c.due_date ? fmtDate(dayStart(c.due_date)) : '—'}${warn ? (d < 0 ? ' · VENCIDO' : ` · vence en ${d} días`) : ''} · ${c.holder || 'sin librador'}${c.received_from ? ` · de ${partyName(c.received_from)}` : ''}${c.delivered_to ? ` · a ${partyName(c.delivered_to)}` : ''}</span></span>
        <b class="money">${fmtMoney(c.amount)}</b> <span class="badge ${c.status === 'rechazado' ? 'err' : c.status === 'en_cartera' ? 'ok' : ''}">${chequeStatusLabel(c.status)}</span></button></li>`;
    })}</ul>` : html`<p class="empty">No hay cheques${f.chq ? ' en ese estado' : ''}. Los cheques entran a la cartera al cobrar con cheque o con una entrada de caja.</p>`}</div>`;
}

/** Nombre de un cliente o proveedor (o el texto tal cual) */
function partyName(x) {
  const c = db.get('customers', x) || db.get('suppliers', x);
  return c ? c.name : x;
}

async function newChequeDialog() {
  return modal({
    title: 'Cargar cheque a la cartera',
    body: html`<form id="nc" novalidate>
      <fieldset class="seg"><legend>Tipo</legend><label><input type="radio" name="nc-k" value="tercero" checked><span>De terceros (recibido)</span></label><label><input type="radio" name="nc-k" value="propio"><span>Propio (emitido)</span></label></fieldset>
      ${chequeFieldsHTML('ncq')}
      <div class="field"><label for="nc-from">Recibido de / entregado a</label><input id="nc-from" autocomplete="off"></div>
      <div class="field"><label for="nc-n">Notas</label><input id="nc-n" autocomplete="off"></div></form>`,
    actions: [{ label: 'Cancelar', value: null }, { label: 'Guardar cheque', kind: 'primary', onClick: async (close, w) => {
      const kind = w.querySelector('[name=nc-k]:checked').value;
      const c = { ...readCheque(w, 'ncq'), kind, notes: $('#nc-n', w).value };
      if (kind === 'propio') c.delivered_to = $('#nc-from', w).value; else c.received_from = $('#nc-from', w).value;
      try { close(await saveCheque(c)); toast('Cheque guardado.'); } catch (e) { toast(e.message, 'error'); }
    } }],
  });
}

const ACTION_LABEL = { depositado: 'Depositar', entregado: 'Entregar', cobrado: 'Cobrado', rechazado: 'Rechazado', anulado: 'Anular', en_cartera: 'Volver a cartera' };

async function chequeDetail(c) {
  if (!c) return;
  const mgr = can(ctx.user, 'compras');
  const next = mgr ? CHEQUE_NEXT[c.status || 'en_cartera'] || [] : [];
  const r = await modal({
    title: `Cheque N° ${c.number}`,
    body: html`<ul class="t-rows">
      <li><span>Estado</span><b>${chequeStatusLabel(c.status)}</b></li>
      <li><span>Importe</span><b class="money">${fmtMoney(c.amount)}</b></li>
      <li><span>Banco</span><b>${bankName(c.bank_id) || '—'}${c.branch_name ? ` · ${c.branch_name}` : ''}</b></li>
      <li><span>Fecha de cobro</span><b>${c.due_date ? fmtDate(dayStart(c.due_date)) : '—'}</b></li>
      <li><span>Emisión</span><b>${c.issue_date ? fmtDate(dayStart(c.issue_date)) : '—'}</b></li>
      <li><span>Librador</span><b>${c.holder || '—'}${c.cuit ? ` · CUIT ${c.cuit}` : ''}</b></li>
      <li><span>Recibido de</span><b>${c.received_from ? partyName(c.received_from) : '—'}</b></li>
      <li><span>Entregado a</span><b>${c.delivered_to ? partyName(c.delivered_to) : '—'}</b></li>
      <li><span>Tipo</span><b>${c.kind === 'propio' ? 'Propio' : 'De terceros'}</b></li></ul>
      <h3>Historial</h3><ul class="t-rows">${(c.history || []).map(h => html`<li><span>${fmtDateTime(h.at)} · ${chequeStatusLabel(h.status)}${h.note ? ` · ${h.note}` : ''}</span><span class="muted">${userName(h.user_id)}</span></li>`)}</ul>
      ${next.includes('entregado') ? html`<div class="field"><label for="cq-to">Entregar a (para “Entregar”)</label><input id="cq-to" autocomplete="off"></div>` : ''}
      ${next.includes('depositado') ? html`<div class="field"><label for="cq-bank">Banco donde se deposita</label><select id="cq-bank"><option value="">—</option>${banks().map(b => html`<option value="${b.id}">${b.name}</option>`)}</select></div>` : ''}
      ${next.length ? html`<div class="field"><label for="cq-note">Nota del cambio <span class="muted">(opcional)</span></label><input id="cq-note" autocomplete="off"></div>` : ''}
      ${next.includes('rechazado') ? html`<p class="small muted">Si se rechaza: si vino de un cobro, vuelve a la cuenta del cliente; si se le dio a un proveedor, vuelve a lo que le debemos.</p>` : ''}`,
    onMount(m, close) {
      m.addEventListener('click', async e => {
        const b = e.target.closest('[data-mv]');
        if (!b) return;
        const st = b.dataset.mv;
        if (['rechazado', 'anulado'].includes(st) && !(await confirm(`¿Marcar el cheque como ${chequeStatusLabel(st).toLowerCase()}?`, { danger: true, ok: ACTION_LABEL[st] }))) return;
        try {
          await moveCheque(c.id, st, { note: ($('#cq-note', m) || { value: '' }).value, delivered_to: ($('#cq-to', m) || { value: '' }).value, bank_id: ($('#cq-bank', m) || { value: '' }).value });
          toast(`Cheque ${chequeStatusLabel(st).toLowerCase()}.`);
          close(true);
        } catch (er) { toast(er.message, 'error'); }
      });
      if (next.length) {
        const foot = m.querySelector('.modal-foot');
        foot.insertAdjacentHTML('afterbegin', String(html`${next.map(st => html`<button type="button" class="btn ${['rechazado', 'anulado'].includes(st) ? 'danger' : 'ghost'}" data-mv="${st}">${ACTION_LABEL[st]}</button>`)}`));
      }
    },
    actions: [{ label: 'Cerrar', kind: 'primary', value: null }],
  });
  return r;
}

// ---------- Bancos ----------

function banksView() {
  const list = banks({ includeInactive: true });
  const mgr = can(ctx.user, 'compras');
  return html`<div class="card"><div class="card-head"><h2>Bancos</h2>${mgr ? html`<button type="button" class="btn ghost sm" data-act="new-bank">${ic('plus')} Nuevo banco</button>` : ''}</div>
    <ul class="list" id="ts-banks">${list.map(b => {
      const n = db.all('cheques').filter(c => c.bank_id === b.id && c.status === 'en_cartera');
      return html`<li><button type="button" class="row" data-bank="${b.id}"><span class="grow">${b.name}${n.length ? html`<span class="sub" style="display:block">${n.length} cheques en cartera · ${fmtMoney(n.reduce((a, c) => a + Number(c.amount || 0), 0))}</span>` : ''}</span>${b.active === 0 ? html`<span class="badge">Inactivo</span>` : ''}</button></li>`;
    })}</ul></div>`;
}

async function bankDialog(b = null) {
  if (!can(ctx.user, 'compras')) return null;
  return modal({
    title: b ? 'Banco' : 'Nuevo banco',
    body: html`<form id="bk" novalidate><div class="field"><label for="bk-n">Nombre</label><input id="bk-n" value="${b ? b.name : ''}" autocomplete="off"></div>
      <label class="check"><input type="checkbox" id="bk-a" ${!b || b.active !== 0 ? 'checked' : ''}> Activo</label></form>`,
    actions: [{ label: 'Cancelar', value: null }, { label: 'Guardar', kind: 'primary', onClick: async (close, w) => {
      try { close(await saveBank({ id: b && b.id, name: $('#bk-n', w).value, active: $('#bk-a', w).checked })); toast('Banco guardado.'); } catch (e) { fieldError($('#bk-n', w), e.message); }
    } }],
  });
}

// ---------- Cajas cerradas ----------

function sessionData(s) {
  return {
    sales: db.all('sales').filter(x => x.session_id === s.id), movements: db.all('cash_movements').filter(x => x.session_id === s.id),
    returns: db.all('returns').filter(x => x.session_id === s.id), expenses: db.all('expenses'),
  };
}

function closedRows() {
  const { from, to } = rangeMs();
  return db.all('cash_sessions').filter(s => s.closed_at && s.closed_at >= from && s.opened_at <= to && inBranch(s))
    .sort((a, b) => b.opened_at - a.opened_at).map(s => ({ s, r: sessionSummary(s, sessionData(s)) }));
}

function closedView() {
  const rows = closedRows();
  const sum = k => round2(rows.reduce((a, x) => a + (Number(x.r[k]) || 0), 0));
  return html`<form class="card filters" id="ts-f" onsubmit="return false">${periodSel()}${branchSel()}</form>${tools()}
    <div class="card"><div class="card-head"><h2>Cajas cerradas (${rows.length})</h2></div>
    ${rows.length ? html`<div class="table-wrap"><table id="ts-closed"><thead><tr><th>Apertura</th><th>Cierre</th>${multiBranch() ? html`<th>Sucursal</th>` : ''}<th>Cerró</th><th class="r">Inicial</th><th class="r">Ventas</th><th class="r">Efectivo ventas</th><th class="r">Ingresos</th><th class="r">Egresos</th><th class="r">Esperado</th><th class="r">Contado</th><th class="r">Diferencia</th></tr></thead><tbody>
      ${rows.map(({ s, r }) => html`<tr><td>${fmtDateTime(s.opened_at)}</td><td>${fmtDateTime(s.closed_at)}</td>${multiBranch() ? html`<td>${branchName(s.branch_id)}</td>` : ''}<td>${userName(s.closed_by)}</td>
        <td class="r">${fmtMoney(r.opening)}</td><td class="r">${fmtMoney(r.salesTotal)}</td><td class="r">${fmtMoney(r.cashSales)}</td><td class="r">${fmtMoney(r.ingresos)}</td><td class="r">${fmtMoney(r.egresos)}</td>
        <td class="r">${fmtMoney(r.expected)}</td><td class="r">${r.counted === null ? '—' : fmtMoney(r.counted)}</td><td class="r ${Number(r.difference) < 0 ? 'neg' : ''}">${r.difference === null ? '—' : fmtMoney(r.difference)}</td></tr>`)}
      </tbody><tfoot><tr><td colspan="${multiBranch() ? 5 : 4}">Totales</td><td class="r">${fmtMoney(sum('salesTotal'))}</td><td class="r">${fmtMoney(sum('cashSales'))}</td><td class="r">${fmtMoney(sum('ingresos'))}</td><td class="r">${fmtMoney(sum('egresos'))}</td><td class="r">${fmtMoney(sum('expected'))}</td><td class="r">${fmtMoney(sum('counted'))}</td><td class="r">${fmtMoney(sum('difference'))}</td></tr></tfoot></table></div>`
      : html`<p class="empty">No hay cajas cerradas en ese período.</p>`}</div>`;
}

// ---------- Caja diaria ----------

function dailyData() {
  const from = dayStart(f.day), to = dayEnd(f.day);
  const inDay = t => t >= from && t <= to;
  const sessions = db.all('cash_sessions').filter(s => inBranch(s) && (inDay(s.opened_at) || (s.closed_at && inDay(s.closed_at)) || (s.opened_at < from && (!s.closed_at || s.closed_at > to))));
  const sales = db.all('sales').filter(s => inBranch(s) && inDay(s.created_at) && !s.test);
  const ok = sales.filter(s => s.status === 'ok');
  const byMethod = {};
  for (const s of ok) for (const p of s.payments || []) byMethod[p.method] = round2((byMethod[p.method] || 0) + Number(p.amount || 0));
  const returns = db.all('returns').filter(r => inBranch(r) && inDay(r.created_at) && !r.test);
  const movements = db.all('cash_movements').filter(m => inBranch(m) && inDay(m.created_at) && (m.type === 'ingreso' || m.type === 'egreso')).sort((a, b) => a.created_at - b.created_at);
  const expenses = db.all('expenses').filter(e => inBranch(e) && inDay(e.created_at)).sort((a, b) => a.created_at - b.created_at);
  const purchases = db.all('purchases').filter(p => inBranch(p) && inDay(p.created_at) && !isVoidPurchase(p)).sort((a, b) => a.created_at - b.created_at);
  const summaries = sessions.map(s => ({ s, r: sessionSummary(s, sessionData(s)) }));
  return {
    sessions: summaries, sales: ok, voided: sales.length - ok.length, total: round2(ok.reduce((a, s) => a + Number(s.total || 0), 0)), byMethod,
    returns, returnsTotal: round2(returns.reduce((a, r) => a + Number(r.total || 0), 0)), movements, expenses, purchases,
    expensesTotal: round2(expenses.filter(liveExpense).reduce((a, e) => a + Number(e.amount || 0), 0)),
  };
}

const MED = { efectivo: 'Efectivo', mercadopago: 'Mercado Pago', cheque: 'Cheque' };

function dailyView() {
  const d = dailyData();
  return html`<form class="card filters" id="ts-f" onsubmit="return false"><div class="field"><label for="ts-day">Día</label><input id="ts-day" type="date" value="${f.day}"></div>${branchSel()}</form>${tools()}
    <div class="t-grid"><div class="stat"><div class="k">Vendido (${d.sales.length})</div><div class="v money" id="ts-dsales">${fmtMoney(d.total)}</div></div>
      <div class="stat"><div class="k">Devoluciones</div><div class="v money">${fmtMoney(d.returnsTotal)}</div></div>
      <div class="stat"><div class="k">Gastos</div><div class="v money" id="ts-dexp">${fmtMoney(d.expensesTotal)}</div></div>
      <div class="stat"><div class="k">Compras</div><div class="v money">${fmtMoney(round2(d.purchases.reduce((a, p) => a + purchaseSign(p) * Number(p.total || 0), 0)))}</div></div></div>
    <div class="card"><div class="card-head"><h2>Cajas del día</h2></div>${d.sessions.length ? html`<ul class="t-rows">${d.sessions.map(({ s, r }) => html`<li><span>${multiBranch() ? `${branchName(s.branch_id)} · ` : ''}${fmtTime(s.opened_at)} → ${s.closed_at ? fmtTime(s.closed_at) : 'abierta'} · ${userName(s.opened_by)}</span>
      <span class="nums"><span>Inicial ${fmtMoney(r.opening)}</span><span>Esperado ${fmtMoney(r.expected)}</span>${s.closed_at ? html`<span>Contado ${fmtMoney(r.counted)}</span><b class="${Number(r.difference) < 0 ? 'neg' : ''}">Dif. ${fmtMoney(r.difference)}</b>` : ''}</span></li>`)}</ul>` : html`<p class="muted">Ese día no hubo caja.</p>`}</div>
    <div class="card"><div class="card-head"><h2>Ventas por medio de pago</h2></div>${Object.keys(d.byMethod).length ? html`<ul class="t-rows">${Object.entries(d.byMethod).map(([k, v]) => html`<li><span>${payLabel(k)}</span><b class="money">${fmtMoney(v)}</b></li>`)}</ul>` : html`<p class="muted">Sin ventas.</p>`}</div>
    <div class="card"><div class="card-head"><h2>Movimientos de caja</h2></div>${d.movements.length ? html`<ul class="t-rows" id="ts-dmov">${d.movements.map(m => html`<li><span><span class="mv-num">${m.number ? `N° ${m.number} · ` : ''}${fmtTime(m.created_at)}</span> ${m.reason || ''} · ${MED[m.method || 'efectivo'] || m.method}</span><b class="money ${m.type === 'egreso' ? 'neg' : ''}">${m.type === 'egreso' ? '−' : '+'} ${fmtMoney(m.amount)}</b></li>`)}</ul>` : html`<p class="muted">Sin movimientos.</p>`}</div>
    <div class="card"><div class="card-head"><h2>Gastos</h2></div>${d.expenses.length ? html`<ul class="t-rows">${d.expenses.map(e => html`<li><span>N° ${e.number || '—'} · ${fmtTime(e.created_at)} · ${expenseTypeName(e.type_id)}${e.detail ? ` · ${e.detail}` : ''} · ${expenseMethodLabel(e.method)}${e.to_cash ? ' · a caja' : ''}${liveExpense(e) ? '' : ' · ANULADO'}</span><b class="money">${fmtMoney(e.amount)}</b></li>`)}</ul>` : html`<p class="muted">Sin gastos.</p>`}</div>
    <div class="card"><div class="card-head"><h2>Compras</h2></div>${d.purchases.length ? html`<ul class="t-rows">${d.purchases.map(p => html`<li><span>${fmtTime(p.created_at)} · ${purchaseDocLabel(p) || 'Compra'} · ${(db.get('suppliers', p.supplier_id) || {}).name || 'Sin proveedor'} · ${paymentLabel(p.payment)}${p.to_cash ? ' · a caja' : ''}</span><b class="money">${fmtMoney(purchaseSign(p) * p.total)}</b></li>`)}</ul>` : html`<p class="muted">Sin compras.</p>`}</div>`;
}

// ---------- Imprimir y Excel ----------

async function doPrint() {
  if (tab === 'balance') {
    const t = treasuryData(), r = t.result;
    await printA4(html`<div class="ticket doc-a4">${printHead('Tesorería y balance', [`Del ${fmtDate(dayStart(f.from))} al ${fmtDate(dayStart(f.to))}${f.branch ? ' · ' + branchName(f.branch) : ''}`])}
      <table class="ptable"><tbody>
        <tr><td>Efectivo en cajas abiertas</td><td class="r">${fmtMoney(t.cashTotal)}</td></tr><tr><td>Cheques en cartera</td><td class="r">${fmtMoney(t.cheques.total)}</td></tr>
        <tr><td>Cuentas por cobrar</td><td class="r">${fmtMoney(t.receivable)}</td></tr><tr><td>Cuentas por pagar</td><td class="r">${fmtMoney(t.payable)}</td></tr></tbody></table>
      <table class="ptable"><thead><tr><th>Medio</th><th class="r">Entradas</th><th class="r">Salidas</th><th class="r">Neto</th></tr></thead><tbody>
        ${Object.entries(t.media).filter(([, m]) => m.in || m.out).map(([k, m]) => html`<tr><td>${MEDIA_LABEL[k]}</td><td class="r">${fmtMoney(m.in)}</td><td class="r">${fmtMoney(m.out)}</td><td class="r">${fmtMoney(m.net)}</td></tr>`)}</tbody></table>
      <table class="ptable"><tbody><tr><td>Ventas</td><td class="r">${fmtMoney(r.sales)}</td></tr><tr><td>− IVA</td><td class="r">${fmtMoney(r.iva)}</td></tr><tr><td>Ventas netas</td><td class="r">${fmtMoney(r.netSales)}</td></tr>
        <tr><td>− Costo de ventas</td><td class="r">${fmtMoney(r.cost)}</td></tr><tr><td>Ganancia bruta</td><td class="r">${fmtMoney(r.gross)}</td></tr><tr><td>− Gastos</td><td class="r">${fmtMoney(r.expenses)}</td></tr></tbody>
        <tfoot><tr><td>Resultado</td><td class="r">${fmtMoney(r.result)}</td></tr></tfoot></table></div>`);
  } else if (tab === 'cajas') {
    const rows = closedRows();
    await printA4(html`<div class="ticket doc-a4">${printHead('Cajas cerradas', [`Del ${fmtDate(dayStart(f.from))} al ${fmtDate(dayStart(f.to))}`])}
      <table class="ptable"><thead><tr><th>Apertura</th><th>Cierre</th><th>Cerró</th><th class="r">Ventas</th><th class="r">Esperado</th><th class="r">Contado</th><th class="r">Dif.</th></tr></thead><tbody>
      ${rows.map(({ s, r }) => html`<tr><td>${fmtDateTime(s.opened_at)}</td><td>${fmtDateTime(s.closed_at)}</td><td>${userName(s.closed_by)}</td><td class="r">${fmtMoney(r.salesTotal)}</td><td class="r">${fmtMoney(r.expected)}</td><td class="r">${r.counted === null ? '—' : fmtMoney(r.counted)}</td><td class="r">${r.difference === null ? '—' : fmtMoney(r.difference)}</td></tr>`)}</tbody></table></div>`);
  } else if (tab === 'diaria') {
    const d = dailyData();
    await printA4(html`<div class="ticket doc-a4">${printHead('Caja diaria', [fmtDate(dayStart(f.day)) + (f.branch ? ' · ' + branchName(f.branch) : '')])}
      <table class="ptable"><tbody><tr><td>Vendido (${d.sales.length})</td><td class="r">${fmtMoney(d.total)}</td></tr>${Object.entries(d.byMethod).map(([k, v]) => html`<tr><td>   ${payLabel(k)}</td><td class="r">${fmtMoney(v)}</td></tr>`)}
        <tr><td>Devoluciones</td><td class="r">${fmtMoney(d.returnsTotal)}</td></tr><tr><td>Gastos</td><td class="r">${fmtMoney(d.expensesTotal)}</td></tr></tbody></table>
      <table class="ptable"><thead><tr><th>Caja</th><th class="r">Inicial</th><th class="r">Esperado</th><th class="r">Contado</th><th class="r">Dif.</th></tr></thead><tbody>
      ${d.sessions.map(({ s, r }) => html`<tr><td>${fmtTime(s.opened_at)} → ${s.closed_at ? fmtTime(s.closed_at) : 'abierta'} ${userName(s.opened_by)}</td><td class="r">${fmtMoney(r.opening)}</td><td class="r">${fmtMoney(r.expected)}</td><td class="r">${r.counted === null ? '—' : fmtMoney(r.counted)}</td><td class="r">${r.difference === null ? '—' : fmtMoney(r.difference)}</td></tr>`)}</tbody></table>
      <table class="ptable"><thead><tr><th>N°</th><th>Hora</th><th>Movimiento</th><th>Medio</th><th class="r">Importe</th></tr></thead><tbody>
      ${d.movements.map(m => html`<tr><td>${m.number || ''}</td><td>${fmtTime(m.created_at)}</td><td>${m.reason || ''}</td><td>${MED[m.method || 'efectivo'] || m.method}</td><td class="r">${m.type === 'egreso' ? '-' : ''}${fmtMoney(m.amount)}</td></tr>`)}</tbody></table></div>`);
  } else toast('Elegí Tesorería, Cajas cerradas o Caja diaria para imprimir.', 'warn');
}

async function doExcel() {
  if (tab === 'balance') {
    const t = treasuryData(), r = t.result;
    const rows = [['Concepto', 'Entradas', 'Salidas', 'Importe']];
    rows.push(['Efectivo en cajas abiertas', '', '', t.cashTotal], ['Cheques en cartera', '', '', t.cheques.total], ['Cuentas por cobrar', '', '', t.receivable], ['Cuentas por pagar', '', '', t.payable]);
    for (const [k, m] of Object.entries(t.media)) if (m.in || m.out) rows.push([MEDIA_LABEL[k], m.in, m.out, m.net]);
    rows.push(['Ventas', '', '', r.sales], ['IVA', '', '', r.iva], ['Ventas netas', '', '', r.netSales], ['Costo de ventas', '', '', r.cost], ['Ganancia bruta', '', '', r.gross], ['Gastos', '', '', r.expenses], ['Resultado', '', '', r.result]);
    await exportTable(`tesoreria-${f.from}-${f.to}`, 'Tesorería', rows);
  } else if (tab === 'cajas') {
    const rows = [['Apertura', 'Cierre', 'Sucursal', 'Abrió', 'Cerró', 'Inicial', 'Ventas', 'Efectivo ventas', 'Ingresos', 'Egresos', 'Devuelto', 'Esperado', 'Contado', 'Diferencia', 'Cheques entrados', 'Mercado Pago entrado']];
    for (const { s, r } of closedRows()) rows.push([fmtDateTime(s.opened_at), fmtDateTime(s.closed_at), branchName(s.branch_id), userName(s.opened_by), userName(s.closed_by), r.opening, r.salesTotal, r.cashSales, r.ingresos, r.egresos, r.devoluciones, r.expected, r.counted ?? '', r.difference ?? '', r.cheques_in, r.mp_in]);
    await exportTable(`cajas-cerradas-${f.from}-${f.to}`, 'Cajas cerradas', rows);
  } else if (tab === 'diaria') {
    const d = dailyData();
    const rows = [['Tipo', 'N°', 'Hora', 'Detalle', 'Medio', 'Importe']];
    for (const s of d.sales) rows.push(['Venta', s.number, fmtTime(s.created_at), '', (s.payments || []).map(p => payLabel(p.method)).join(' + '), round2(s.total)]);
    for (const m of d.movements) rows.push([m.type === 'egreso' ? 'Salida de caja' : 'Entrada de caja', m.number || '', fmtTime(m.created_at), m.reason || '', MED[m.method || 'efectivo'] || m.method, (m.type === 'egreso' ? -1 : 1) * round2(m.amount)]);
    for (const e of d.expenses) rows.push(['Gasto', e.number || '', fmtTime(e.created_at), `${expenseTypeName(e.type_id)} ${e.detail || ''}`.trim(), expenseMethodLabel(e.method), -round2(e.amount)]);
    for (const p of d.purchases) rows.push(['Compra', '', fmtTime(p.created_at), purchaseDocLabel(p), paymentLabel(p.payment), -purchaseSign(p) * round2(p.total)]);
    await exportTable(`caja-diaria-${f.day}`, 'Caja diaria', rows);
  } else toast('Elegí Tesorería, Cajas cerradas o Caja diaria para exportar.', 'warn');
}

// ---------- Recalcular stock y saldos (solo dueño) ----------

function computeRecalc() {
  const stock = recalcStock(db.all('products'), db.all('stock_moves'), { mainId: mainBranchId() });
  const bal = recalcBalances({
    customers: db.all('customers'), suppliers: db.all('suppliers'), sales: db.all('sales'), returns: db.all('returns'), customer_payments: db.all('customer_payments'),
    cash_movements: db.all('cash_movements'), purchases: db.all('purchases'), supplier_payments: db.all('supplier_payments'),
  });
  return { stock, ...bal, at: Date.now() };
}

function recalcView() {
  if (!owner()) return html`<p class="muted">Solo el dueño puede recalcular.</p>`;
  const r = recalc;
  const sect = (title, kind, list, fmt) => html`<div class="card"><div class="card-head"><h2>${title} (${list.length})</h2></div>
    ${list.length ? html`<div class="table-wrap"><table class="rc-table" id="rc-${kind}"><thead><tr><th><span class="sr-only">Corregir</span></th><th>${kind === 'stock' ? 'Producto' : 'Nombre'}</th>${kind === 'stock' && multiBranch() ? html`<th>Sucursal</th>` : ''}<th class="r">Guardado</th><th class="r">Según movimientos</th><th class="r">Diferencia</th><th class="r">Movs.</th></tr></thead><tbody>
      ${list.slice(0, 500).map((x, i) => html`<tr><td><input type="checkbox" data-rc="${kind}:${i}" aria-label="Corregir ${x.name}"></td><td style="white-space:normal">${x.name}</td>${kind === 'stock' && multiBranch() ? html`<td>${branchName(x.branch_id)}</td>` : ''}
        <td class="r">${fmt(x.current)}</td><td class="r">${fmt(x.computed)}</td><td class="r">${fmt(x.diff)}</td><td class="r">${x.moves}</td></tr>`)}</tbody></table></div>${list.length > 500 ? html`<p class="small muted">Se muestran las 500 diferencias más grandes.</p>` : ''}`
      : html`<p class="muted">Sin diferencias.</p>`}</div>`;
  return html`<div class="notice notice-info"><p><b>Recalcular stock y saldos</b> reconstruye el stock de cada sucursal sumando sus movimientos de stock, y los saldos de clientes y proveedores sumando sus movimientos de cuenta corriente. Primero te muestra las diferencias; no cambia nada hasta que marques qué corregir y confirmes.</p>
    <p><b>Ojo:</b> el stock que se cargó al crear o importar un producto (o el saldo traído de SGI sin movimiento) no tiene movimiento: en esos casos el cálculo da de menos y <b>no conviene corregirlo</b>. Revisá fila por fila.</p></div>
    <div class="btn-row" style="margin-bottom:1rem"><button type="button" class="btn primary" data-act="rc-check" id="rc-check">${ic('search')} Revisar diferencias</button>
      ${r ? html`<button type="button" class="btn ghost" data-act="rc-all">Marcar todo</button><button type="button" class="btn ghost" data-act="rc-none">Desmarcar todo</button>
      <button type="button" class="btn danger" data-act="rc-apply" id="rc-apply">Corregir lo marcado</button>` : ''}</div>
    ${r ? html`<p class="muted small" id="rc-when">Revisado ${fmtDateTime(r.at)}.</p>
      ${sect('Stock', 'stock', r.stock, fmtQty)}${sect('Saldos de clientes', 'customers', r.customers, fmtMoney)}${sect('Saldos de proveedores', 'suppliers', r.suppliers, fmtMoney)}` : ''}`;
}

async function applyRecalcUI() {
  if (!recalc) return;
  const pick = { stock: [], customers: [], suppliers: [] };
  main.querySelectorAll('[data-rc]:checked').forEach(x => { const [k, i] = x.dataset.rc.split(':'); pick[k].push(recalc[k][Number(i)]); });
  const n = pick.stock.length + pick.customers.length + pick.suppliers.length;
  if (!n) { toast('Marcá las filas que querés corregir.', 'warn'); return; }
  if (!(await confirm(`Vas a corregir ${pick.stock.length} stocks, ${pick.customers.length} saldos de clientes y ${pick.suppliers.length} de proveedores para que queden como dicen sus movimientos. Queda en la auditoría. ¿Seguimos?`, { title: 'Corregir', ok: 'Corregir', danger: true }))) return;
  try {
    const done = await applyRecalc(pick);
    toast(`Listo: ${done} correcciones.`);
    recalc = computeRecalc();
    paint();
  } catch (e) { toast(e.message, 'error'); }
}

export { settings };
