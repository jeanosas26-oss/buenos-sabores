// =====================================================================
// gastos.js — Gastos como SGI: fecha, hora, tipo (los de SGI precargados), importe, condición, detalle,
// compra N°, "a Caja" (sale de la caja abierta). Listado con total y filtros, informe por tipo y período,
// tipos de gasto. Cajero y vendedor solo cargan gastos en efectivo que salen de su caja.
// =====================================================================
import * as db from '../db.js';
import { ctx, openSession, userName, multiBranch, branchName } from '../ops.js';
import { html, $, on, ic, modal, toast, fieldError, confirm, exportTable } from '../ui.js';
import { fmtMoney, fmtDate, fmtTime, parseNum, round2, toISODate, dayStart, dayEnd, can } from '../logic.js';
import { expensesReport, EXPENSE_METHODS, expenseMethodLabel, liveExpense, isResultExpense } from '../tesoreria-calc.js';
import { expenseTypes, expenseTypeName, seedExpenseTypes, saveExpense, voidExpense, saveExpenseType } from '../tesoreria-ops.js';
import { purchaseDocLabel } from '../compras-calc.js';
import { walletPickerHTML, pickedCheques } from './cheque-ui.js';
import { printA4, printHead } from './ctacte.js';

let main;
let tab = 'lista';
const manager = () => !!ctx.user && can(ctx.user, 'compras');
const monthStart = () => { const d = new Date(); return toISODate(new Date(d.getFullYear(), d.getMonth(), 1).getTime()); };
const gf = { from: monthStart(), to: toISODate(Date.now()), type: '', method: '', cash: '' };

export async function render(m) {
  main = m;
  await seedExpenseTypes().catch(e => console.warn('tipos de gasto', e));
  paint();
  const off = on(main, 'click', '[data-act], [data-tab], [data-exp], [data-et]', async (e, el) => {
    if (el.dataset.tab) { tab = el.dataset.tab; paint(); return; }
    if (el.dataset.exp) { await expenseDetail(db.get('expenses', el.dataset.exp)); paint(); return; }
    if (el.dataset.et) { await typeDialog(db.get('expense_types', el.dataset.et)); paint(); return; }
    const a = el.dataset.act;
    if (a === 'new') { if (await expenseDialog()) paint(); }
    if (a === 'new-type') { await typeDialog(); paint(); }
    if (a === 'export') exportList();
    if (a === 'print') printReport();
  });
  const onCh = e => {
    if (!e.target.closest('#gs-f')) return;
    gf.from = $('#gs-from', main).value; gf.to = $('#gs-to', main).value;
    gf.type = ($('#gs-type', main) || {}).value || ''; gf.method = ($('#gs-m', main) || {}).value || ''; gf.cash = ($('#gs-cash', main) || {}).value || '';
    paint();
  };
  main.addEventListener('change', onCh);
  return () => { off(); main.removeEventListener('change', onCh); };
}

function range() { return { from: gf.from ? dayStart(gf.from) : -Infinity, to: gf.to ? dayEnd(gf.to) : Infinity }; }

function filtered() {
  const { from, to } = range();
  const s = openSession();
  return db.all('expenses').filter(e => {
    if (!manager()) return s && e.session_id === s.id; // cajero/vendedor: los de su caja
    return e.created_at >= from && e.created_at <= to && (!gf.type || e.type_id === gf.type) && (!gf.method || e.method === gf.method)
      && (!gf.cash || String(e.to_cash ? 1 : 0) === gf.cash);
  }).sort((a, b) => b.created_at - a.created_at);
}

function paint() {
  const mgr = manager();
  const tabs = mgr ? [['lista', 'Gastos'], ['informe', 'Informe por tipo'], ['tipos', 'Tipos de gasto']] : [['lista', 'Gastos']];
  if (!tabs.some(t => t[0] === tab)) tab = 'lista';
  main.innerHTML = String(html`<div class="page-head"><h1>Gastos</h1></div>
    <div class="btn-row" style="margin-bottom:1rem"><button type="button" class="btn primary big" data-act="new" id="gs-new">${ic('plus')} Cargar gasto</button></div>
    ${tabs.length > 1 ? html`<div class="chips" role="tablist">${tabs.map(([k, l]) => html`<button type="button" class="chip" role="tab" data-tab="${k}" aria-pressed="${tab === k}" aria-selected="${tab === k}">${l}</button>`)}</div>` : ''}
    ${tab === 'tipos' ? typesView() : html`${mgr ? filtersHTML() : html`<p class="muted">Gastos que salieron de la caja abierta. Para ver otros días pedile al dueño o al encargado.</p>`}
      ${tab === 'informe' ? reportView() : listView()}`}`);
}

function filtersHTML() {
  return html`<form class="card filters" id="gs-f" aria-label="Filtros de gastos" onsubmit="return false">
    <div class="field"><label for="gs-from">Desde</label><input id="gs-from" type="date" value="${gf.from}"></div>
    <div class="field"><label for="gs-to">Hasta</label><input id="gs-to" type="date" value="${gf.to}"></div>
    ${tab === 'lista' ? html`<div class="field"><label for="gs-type">Tipo</label><select id="gs-type"><option value="">Todos</option>${expenseTypes({ includeInactive: true }).map(t => html`<option value="${t.id}" ${gf.type === t.id ? 'selected' : ''}>${t.name}</option>`)}</select></div>
    <div class="field"><label for="gs-m">Condición</label><select id="gs-m"><option value="">Todas</option>${EXPENSE_METHODS.map(([k, l]) => html`<option value="${k}" ${gf.method === k ? 'selected' : ''}>${l}</option>`)}</select></div>
    <div class="field"><label for="gs-cash">A caja</label><select id="gs-cash"><option value="">Todos</option><option value="1" ${gf.cash === '1' ? 'selected' : ''}>Sí</option><option value="0" ${gf.cash === '0' ? 'selected' : ''}>No</option></select></div>` : ''}
  </form>`;
}

function listView() {
  const list = filtered();
  const live = list.filter(liveExpense);
  const total = round2(live.reduce((a, e) => a + Number(e.amount || 0), 0));
  return html`<div class="card"><div class="card-head"><h2>Gastos</h2>${manager() ? html`<button type="button" class="btn ghost sm" data-act="export" ${list.length ? '' : 'disabled'}>${ic('download')} Excel</button>` : ''}</div>
    <p id="gs-total" class="lead"><b>${live.length} ${live.length === 1 ? 'gasto' : 'gastos'} · Total ${fmtMoney(total)}</b></p>
    ${list.length ? html`<ul class="list" id="gs-list">${list.slice(0, 300).map(e => html`<li><button type="button" class="row" data-exp="${e.id}">
      <span class="grow"><span class="title">${expenseTypeName(e.type_id) || 'Sin tipo'}${e.detail ? ` · ${e.detail}` : ''}</span>
      <span class="sub" style="display:block"><span class="mv-num">N° ${e.number || '—'}</span> · ${fmtDate(e.created_at)} ${fmtTime(e.created_at)} · ${expenseMethodLabel(e.method)} · a caja ${e.to_cash ? 'Sí' : 'No'}${e.purchase_id ? ' · compra' : ''}${multiBranch() ? html` · <span class="branch-tag">${branchName(e.branch_id)}</span>` : ''}</span></span>
      <b class="money">${fmtMoney(e.amount)}</b>${liveExpense(e) ? '' : html` <span class="badge err">Anulado</span>`}</button></li>`)}</ul>`
      : html`<p class="empty">No hay gastos${manager() ? ' con esos filtros' : ' en esta caja'}.</p>`}</div>`;
}

function reportView() {
  const { from, to } = range();
  const r = expensesReport(db.all('expenses'), { from, to, typeName: expenseTypeName });
  return html`<div class="card"><div class="card-head"><h2>Gastos por tipo</h2>
      <div class="btn-row"><button type="button" class="btn ghost sm" data-act="print" ${r.count ? '' : 'disabled'}>${ic('print')} Imprimir</button>
      <button type="button" class="btn ghost sm" data-act="export" ${r.count ? '' : 'disabled'}>${ic('download')} Excel</button></div></div>
    <div class="stats"><div class="stat"><div class="k">Total del período</div><div class="v money" id="gs-rtotal">${fmtMoney(r.total)}</div></div>
      <div class="stat"><div class="k">Gastos del resultado</div><div class="v money">${fmtMoney(r.result)}</div></div></div>
    ${r.byType.length ? html`<ul class="t-rows" id="gs-rep">${r.byType.map(t => html`<li><span>${t.name}${t.result ? '' : html` <span class="badge info">no es gasto del resultado</span>`}</span>
      <span class="nums"><span class="muted">${t.count}</span><b class="money">${fmtMoney(t.total)}</b></span></li>`)}
      <li class="t-total"><span>Total</span><span class="nums"><span>${r.count}</span><b class="money">${fmtMoney(r.total)}</b></span></li></ul>`
      : html`<p class="empty">No hay gastos en ese período.</p>`}
    <p class="small muted">“Proveedores” y “Retiro de efectivo” no restan en el resultado del balance (la mercadería ya está en el costo de ventas y el retiro no es un gasto).</p></div>`;
}

function typesView() {
  const list = expenseTypes({ includeInactive: true });
  return html`<div class="card"><div class="card-head"><h2>Tipos de gasto</h2><button type="button" class="btn ghost sm" data-act="new-type">${ic('plus')} Nuevo tipo</button></div>
    <ul class="list" id="gs-types">${list.map(t => html`<li><button type="button" class="row" data-et="${t.id}"><span class="grow">${t.name}</span>${t.active === 0 ? html`<span class="badge">Inactivo</span>` : ''}</button></li>`)}</ul></div>`;
}

async function typeDialog(t = null) {
  return modal({
    title: t ? 'Tipo de gasto' : 'Nuevo tipo de gasto',
    body: html`<form id="et" novalidate><div class="field"><label for="et-n">Nombre</label><input id="et-n" value="${t ? t.name : ''}" autocomplete="off"></div>
      <label class="check"><input type="checkbox" id="et-a" ${!t || t.active !== 0 ? 'checked' : ''}> Activo</label></form>`,
    actions: [{ label: 'Cancelar', value: null }, { label: 'Guardar', kind: 'primary', onClick: async (close, w) => {
      try { close(await saveExpenseType({ id: t && t.id, name: $('#et-n', w).value, active: $('#et-a', w).checked })); toast('Tipo de gasto guardado.'); } catch (e) { fieldError($('#et-n', w), e.message); }
    } }],
  });
}

/** Ventana para cargar un gasto (la usa también Caja). opts.toCash: valor inicial de "a Caja" */
export async function expenseDialog(opts = {}) {
  const mgr = manager();
  const session = openSession();
  const types = expenseTypes();
  const purchases = mgr ? db.all('purchases').filter(p => p.status !== 'anulada').sort((a, b) => b.created_at - a.created_at).slice(0, 60) : [];
  const now = Date.now();
  const startCash = opts.toCash ?? !!session;
  return modal({
    title: 'Cargar gasto',
    body: html`<form id="ge" novalidate>
      <div class="grid2"><div class="field"><label for="ge-date">Fecha</label><input id="ge-date" type="date" value="${toISODate(now)}" ${mgr ? '' : 'disabled'}></div>
        <div class="field"><label for="ge-time">Hora</label><input id="ge-time" type="time" value="${fmtTime(now)}" ${mgr ? '' : 'disabled'}></div></div>
      <div class="field"><label for="ge-t">Tipo de gasto</label><select id="ge-t"><option value="">— Elegí —</option>${types.map(t => html`<option value="${t.id}">${t.name}</option>`)}</select></div>
      <div class="field"><label for="ge-a">Importe</label><input id="ge-a" class="money-input" inputmode="decimal" placeholder="0,00" autocomplete="off"></div>
      <div class="field"><label for="ge-m">Condición</label><select id="ge-m" ${mgr ? '' : 'disabled'}>${EXPENSE_METHODS.map(([k, l]) => html`<option value="${k}">${l}</option>`)}</select></div>
      <div id="ge-chq" class="hidden"><p class="small"><b>Elegí el cheque de la cartera</b> (el importe es el del cheque)</p>${mgr ? walletPickerHTML('gec') : ''}</div>
      <div class="field"><label for="ge-d">Detalle <span class="muted">(ej: a quién se le pagó)</span></label><input id="ge-d" autocomplete="off"></div>
      ${mgr ? html`<div class="field"><label for="ge-p">Compra N° <span class="muted">(opcional)</span></label><select id="ge-p"><option value="">— Ninguna —</option>${purchases.map(p => html`<option value="${p.id}">${fmtDate(p.created_at)} · ${purchaseDocLabel(p) || 'Compra'} · ${(db.get('suppliers', p.supplier_id) || {}).name || ''} · ${fmtMoney(p.total)}</option>`)}</select></div>` : ''}
      <fieldset class="seg" id="ge-cashrow"><legend>A Caja</legend>
        <label><input type="radio" name="ge-cash" value="1" ${startCash ? 'checked' : ''} ${mgr ? '' : 'disabled'}><span>Sí</span></label>
        <label><input type="radio" name="ge-cash" value="0" ${startCash ? '' : 'checked'} ${mgr ? '' : 'disabled'}><span>No</span></label></fieldset>
      <p class="small muted" id="ge-info" aria-live="polite"></p>
    </form>`,
    onMount(m) {
      const info = () => {
        const met = $('#ge-m', m).value;
        const cash = m.querySelector('[name=ge-cash]:checked').value === '1';
        $('#ge-chq', m).classList.toggle('hidden', met !== 'cheque');
        $('#ge-cashrow', m).classList.toggle('hidden', !['efectivo', 'mercadopago', 'cheque'].includes(met));
        $('#ge-info', m).textContent = !cash || !['efectivo', 'mercadopago', 'cheque'].includes(met) ? 'No sale de la caja: queda registrado como gasto.'
          : session ? (met === 'efectivo' ? 'Sale de la caja abierta en efectivo (resta del efectivo esperado).' : 'Queda en la caja como salida con ' + expenseMethodLabel(met) + ' (no cambia el efectivo).')
            : 'La caja está cerrada: abrila o marcá a Caja = No.';
      };
      m.addEventListener('change', e => {
        if (e.target.matches('[data-gec]')) { const pc = pickedCheques(m, 'gec'); $('#ge-a', m).value = pc.cents ? (pc.cents / 100).toLocaleString('es-AR', { minimumFractionDigits: 2 }) : ''; }
        info();
      });
      $('#ge', m).addEventListener('submit', e => { e.preventDefault(); m.querySelector('.modal-foot .primary').click(); });
      info();
    },
    actions: [{ label: 'Cancelar', value: null }, { label: 'Guardar gasto', kind: 'primary', id: 'ge-go', onClick: async (close, w) => {
      const t = $('#ge-t', w);
      if (!t.value) return fieldError(t, 'Elegí el tipo de gasto.');
      const a = $('#ge-a', w), v = parseNum(a.value);
      if (!isFinite(v) || v <= 0) return fieldError(a, 'Escribí un importe mayor a cero.');
      const method = $('#ge-m', w).value;
      const picked = method === 'cheque' ? pickedCheques(w, 'gec').ids : [];
      if (method === 'cheque' && picked.length !== 1) return fieldError($('#ge-m', w), 'Elegí un cheque de la cartera.');
      const toCash = w.querySelector('[name=ge-cash]:checked').value === '1';
      let createdAt = null;
      if (mgr && !toCash) {
        const d = $('#ge-date', w).value, h = $('#ge-time', w).value || '12:00';
        if (d && d !== toISODate(Date.now())) { const [y, mo, dd] = d.split('-').map(Number); const [hh, mm] = h.split(':').map(Number); createdAt = new Date(y, mo - 1, dd, hh, mm).getTime(); }
      }
      try {
        const e = await saveExpense({ type_id: t.value, amount: v, method, detail: $('#ge-d', w).value, purchase_id: ($('#ge-p', w) || {}).value || null, to_cash: toCash, cheque_id: picked[0] || null, created_at: createdAt });
        toast(`Gasto N° ${e.number} guardado: ${fmtMoney(e.amount)}${e.to_cash ? ' (salió de la caja)' : ''}.`);
        close(e);
      } catch (e) { fieldError(a, e.message); }
    } }],
  });
}

async function expenseDetail(e) {
  if (!e) return;
  const p = e.purchase_id ? db.get('purchases', e.purchase_id) : null;
  const r = await modal({
    title: `Gasto N° ${e.number || '—'}`,
    body: html`<ul class="t-rows">
      <li><span>Fecha</span><b>${fmtDate(e.created_at)} ${fmtTime(e.created_at)}</b></li>
      <li><span>Tipo</span><b>${expenseTypeName(e.type_id)}</b></li>
      <li><span>Importe</span><b class="money">${fmtMoney(e.amount)}</b></li>
      <li><span>Condición</span><b>${expenseMethodLabel(e.method)}</b></li>
      <li><span>A caja</span><b>${e.to_cash ? 'Sí' : 'No'}</b></li>
      <li><span>Detalle</span><b>${e.detail || '—'}</b></li>
      ${p ? html`<li><span>Compra</span><b>${purchaseDocLabel(p) || fmtDate(p.created_at)}</b></li>` : ''}
      <li><span>Cargó</span><b>${userName(e.user_id)}</b></li>
      <li><span>Estado</span><b>${liveExpense(e) ? 'Vigente' : 'Anulado'}</b></li></ul>
      ${isResultExpense(expenseTypeName(e.type_id)) ? '' : html`<p class="small muted">Este tipo no resta en el resultado del balance.</p>`}`,
    actions: [...(manager() && liveExpense(e) ? [{ label: 'Anular gasto', kind: 'danger', value: 'void' }] : []), { label: 'Cerrar', kind: 'primary', value: null }],
  });
  if (r !== 'void') return;
  if (!(await confirm('¿Anular este gasto? Si salió de una caja que sigue abierta, la plata vuelve a la caja.', { title: 'Anular gasto', ok: 'Anular', danger: true }))) return;
  try { const res = await voidExpense(e.id); toast('Gasto anulado.' + (res.note ? ' ' + res.note : ''), 'ok', 4500); } catch (er) { toast(er.message, 'error'); }
}

async function exportList() {
  if (tab === 'informe') {
    const { from, to } = range();
    const r = expensesReport(db.all('expenses'), { from, to, typeName: expenseTypeName });
    const rows = [['Tipo', 'Cantidad', 'Total', 'Resta en el resultado']];
    for (const t of r.byType) rows.push([t.name, t.count, t.total, t.result ? 'Sí' : 'No']);
    rows.push(['TOTAL', r.count, r.total, '']);
    await exportTable(`gastos-por-tipo-${gf.from}-${gf.to}`, 'Gastos por tipo', rows);
    return;
  }
  const rows = [['N°', 'Fecha', 'Hora', 'Sucursal', 'Tipo', 'Importe', 'Condición', 'Detalle', 'Compra', 'A caja', 'Usuario', 'Estado']];
  for (const e of filtered().reverse()) {
    const p = e.purchase_id ? db.get('purchases', e.purchase_id) : null;
    rows.push([e.number || '', fmtDate(e.created_at), fmtTime(e.created_at), branchName(e.branch_id), expenseTypeName(e.type_id), round2(e.amount), expenseMethodLabel(e.method), e.detail || '', p ? purchaseDocLabel(p) : '', e.to_cash ? 'Sí' : 'No', userName(e.user_id), liveExpense(e) ? 'ok' : 'anulado']);
  }
  await exportTable(`gastos-${gf.from}-${gf.to}`, 'Gastos', rows);
}

async function printReport() {
  const { from, to } = range();
  const r = expensesReport(db.all('expenses'), { from, to, typeName: expenseTypeName });
  await printA4(html`<div class="ticket doc-a4">${printHead('Gastos por tipo', [`Del ${gf.from ? fmtDate(dayStart(gf.from)) : 'principio'} al ${gf.to ? fmtDate(dayStart(gf.to)) : 'hoy'}`])}
    <table class="ptable"><thead><tr><th>Tipo</th><th class="r">Cantidad</th><th class="r">Total</th></tr></thead><tbody>
    ${r.byType.map(t => html`<tr><td>${t.name}</td><td class="r">${t.count}</td><td class="r">${fmtMoney(t.total)}</td></tr>`)}</tbody>
    <tfoot><tr><td>Total</td><td class="r">${r.count}</td><td class="r">${fmtMoney(r.total)}</td></tr></tfoot></table></div>`);
}
