// =====================================================================
// compras-ops.js — Guardar y anular compras completas (como SGI): comprobante del proveedor,
// stock, costos (y precios), cuenta corriente, caja y cheques entregados, todo en UNA transacción.
// =====================================================================
import * as db from './db.js';
import { ctx, openSession, mainBranchId, settings } from './ops.js';
import { uuid, round2, round3, applyStockDelta, can, branchOf } from './logic.js';
import { purchaseDebt } from './cuentas.js';
import { computePurchase, costForProduct, recalcPrice, fmtDocNumber, purchaseDocLabel, paymentLabel, toCents, fromCents, LETTERS } from './compras-calc.js';
import { nextNumber } from './tesoreria-calc.js';
import { auditOps } from './seguridad.js';
import { cloudRestricted } from './sync.js';
import { learnRecords } from './ia-match.js';

const addCents = (a, b) => fromCents(toCents(a || 0) + toCents(b || 0));

/** Error de "el total no cuadra con la factura": la pantalla pregunta si se guarda igual */
export class MismatchError extends Error {
  constructor(calc) { super(`El total calculado (${calc.total}) no coincide con el TOTAL FACTURA (${calc.invoice_total}).`); this.calc = calc; this.code = 'MISMATCH'; }
}

/** Medio del movimiento de caja según la condición de la compra */
const cashMethodOf = payment => (payment === 'mercadopago' ? 'mercadopago' : payment === 'cheque' ? 'cheque' : 'efectivo');

/**
 * Guarda un comprobante de compra.
 * input: {supplier_id, doc_type, letter, doc_number, doc_date, time, items: [{product_id, name, barcode, qty, unit_cost, disc1, disc2, iva_rate}],
 *   discounts: [3 %], iva_override, non_taxed, perc_iva, ret_iva, ret_gan, ret_iibb, perc_iibb, other_taxes, invoice_total,
 *   payment, paid (lo pagado al comprar, solo cta. cte.), due_date, update_costs, price_mode ('no'|'keep'|'pct'), price_pct,
 *   to_cash, cheque_ids, notes, force (guardar aunque el total no cuadre),
 *   price_mode 'lines' + price_updates {product_id: precio} (precio de venta renglón por renglón, carga con foto),
 *   docs [data URL] (imagen comprimida del comprobante → purchase_docs), learn [{codigo, ean, descripcion, product_id, unit_cost}]
 *   (lo que se confirmó de cada renglón leído → supplier_items), ai {engine, lights} (para la auditoría) }
 * FC suma stock, NC lo resta (mercadería devuelta), ND no mueve stock. A cuenta corriente suma (o resta, la NC) al saldo del proveedor.
 * "a Caja": el pago sale de (o, con NC, entra a) la caja abierta del equipo.
 */
export async function savePurchaseFull(input) {
  if (!ctx.user || !can(ctx.user, 'cargar_compras')) throw new Error('Tu usuario no puede cargar compras.');
  // Cajero y vendedor (también lo controla la nube): sin cheques, contado solo de su caja abierta, a cuenta corriente sin
  // "pagado al comprar", siempre actualiza el costo y nunca recalcula precios de venta
  const limited = !can(ctx.user, 'compras');
  if (limited) input = { ...input, update_costs: true, price_mode: 'no', price_pct: 0, cheque_ids: [], price_updates: null };
  // El precio de venta lo cambia solo quien tiene el permiso (también lo controla la nube)
  if (input.price_mode && input.price_mode !== 'no' && !can(ctx.user, 'editar_productos')) input = { ...input, price_mode: 'no', price_updates: null };
  const branch_id = ctx.branchId;
  if (!branch_id || !db.get('branches', branch_id)) throw new Error('Elegí en qué sucursal trabaja este equipo.');
  const docType = ['FC', 'NC', 'ND'].includes(input.doc_type) ? input.doc_type : 'FC';
  const letter = LETTERS.includes(input.letter) ? input.letter : 'X';
  const payment = ['contado', 'cuenta_corriente', 'mercadopago', 'transferencia', 'cheque'].includes(input.payment) ? input.payment : 'contado';
  const sup = input.supplier_id ? db.get('suppliers', input.supplier_id) : null;
  if (payment === 'cuenta_corriente' && !sup) throw new Error('Para comprar a cuenta corriente elegí el proveedor.');
  if (limited) {
    if (payment === 'cheque') throw new Error('Los pagos con cheque los hace el dueño o el encargado. Elegí Cta. cte., Contado (de tu caja), Mercado Pago o Transferencia.');
    if (payment === 'cuenta_corriente' && round2(input.paid || 0) > 0) throw new Error('A cuenta corriente no se registra lo pagado: el pago al proveedor lo hace el dueño o el encargado.');
    // Contado: sale de la caja abierta. Mercado Pago: queda registrado en la caja si está abierta (no cambia el efectivo).
    if (payment === 'contado') input = { ...input, to_cash: true };
    if (payment === 'mercadopago') input = { ...input, to_cash: !!openSession() };
  }
  const items = (input.items || []).map(it => ({
    product_id: it.product_id || null, name: String(it.name || '').trim(), barcode: it.barcode || '',
    qty: round3(it.qty), unit_cost: round2(it.unit_cost), disc1: round3(it.disc1 || 0), disc2: round3(it.disc2 || 0),
    iva_rate: Number(it.iva_rate ?? 21),
  }));
  if (!items.length && !(Number(input.non_taxed) || Number(input.invoice_total))) throw new Error('Agregá al menos un producto.');
  if (items.some(it => !(it.qty > 0))) throw new Error('Revisá las cantidades: tienen que ser mayores a cero.');
  if (items.some(it => !(it.unit_cost >= 0))) throw new Error('Revisá los importes: no pueden ser negativos.');
  if (items.some(it => it.disc1 < 0 || it.disc1 >= 100 || it.disc2 < 0 || it.disc2 >= 100)) throw new Error('Los descuentos tienen que estar entre 0 y 99,99 %.');
  const discounts = (input.discounts || []).slice(0, 3).map(x => round3(x || 0));
  if (discounts.some(x => x < 0 || x >= 100)) throw new Error('Los descuentos generales tienen que estar entre 0 y 99,99 %.');
  for (const k of ['non_taxed', 'perc_iva', 'ret_iva', 'ret_gan', 'ret_iibb', 'perc_iibb', 'other_taxes']) {
    const v = Number(input[k] || 0);
    if (!Number.isFinite(v) || v < 0) throw new Error('Los impuestos y conceptos no gravados no pueden ser negativos.');
  }
  const calc = computePurchase({ ...input, items, discounts, letter });
  if (!calc.ok && !input.force) throw new MismatchError(calc);
  if (!(calc.total > 0) && !items.length) throw new Error('El total del comprobante tiene que ser mayor a cero.');
  if (calc.total < 0) throw new Error('El total no puede ser negativo.');
  const sign = docType === 'NC' ? -1 : 1;
  const onAccount = payment === 'cuenta_corriente';
  const toPay = calc.to_pay;
  const paidNow = onAccount ? round2(input.paid || 0) : toPay;
  if (onAccount && !(paidNow >= 0 && paidNow <= toPay)) throw new Error('Lo pagado al comprar no puede ser más que el total a pagar.');
  // Cheques entregados en el pago
  const cheques = payment === 'cheque' ? (input.cheque_ids || []).map(id => db.get('cheques', id)).filter(Boolean) : [];
  if (payment === 'cheque') {
    if (docType === 'NC') throw new Error('Una nota de crédito no se paga con cheque: elegí Cta. cte. o Contado.');
    if (!cheques.length) throw new Error('Elegí los cheques de la cartera que le entregás al proveedor.');
    if (cheques.some(c => c.status !== 'en_cartera' || c.deleted)) throw new Error('Alguno de los cheques ya no está en cartera.');
    const sum = cheques.reduce((a, c) => a + toCents(c.amount), 0);
    if (sum !== toCents(toPay)) throw new Error(`Los cheques suman ${fromCents(sum).toLocaleString('es-AR', { minimumFractionDigits: 2 })} y hay que pagar ${toPay.toLocaleString('es-AR', { minimumFractionDigits: 2 })}. Para pagar una parte con cheque, cargala a Cta. cte. y pagá desde el proveedor.`);
  }
  const toCash = !!input.to_cash && !onAccount && payment !== 'transferencia';
  const session = toCash ? openSession() : null;
  if (toCash && !session) throw new Error(limited ? 'Para pagar de contado abrí tu caja: la plata sale de ahí.' : 'Para que salga de la caja (a Caja = Sí) abrí la caja de esta sucursal.');
  const now = Date.now();
  const st = settings();
  const docNumber = fmtDocNumber(input.doc_number);
  const purchase = {
    id: uuid(), branch_id, created_at: now, supplier_id: sup ? sup.id : null, user_id: ctx.user.id,
    doc_type: docType, letter, doc_number: docNumber, doc_date: input.doc_date || null, time: input.time || null,
    supplier_iva: sup ? sup.iva_condition || null : null, supplier_cuit: sup ? sup.cuit || '' : '',
    items: items.map((it, i) => ({ ...it, unit_net: calc.lines[i].net_unit, subtotal: calc.lines[i].cents })),
    net: calc.gravado, discounts: calc.discounts, iva_lines: calc.iva_lines.map(l => ({ rate: l.rate, base: l.base, amount: l.amount })),
    non_taxed: round2(calc.non_taxed + calc.exempt), perc_iva: calc.perc_iva, ret_iva: calc.ret_iva, ret_gan: calc.ret_gan, ret_iibb: calc.ret_iibb,
    perc_iibb: calc.perc_iibb, other_taxes: calc.other_taxes, total: calc.total,
    invoice_ref: [letter, docNumber].filter(Boolean).join(' '),
    payment, paid: paidNow, due_date: onAccount && input.due_date ? String(input.due_date) : null,
    update_costs: input.update_costs ? 1 : 0, to_cash: toCash ? 1 : 0, session_id: session ? session.id : null, cash_movement_id: null,
    cheque_ids: cheques.map(c => c.id), notes: String(input.notes || '').trim(), status: 'ok',
  };
  const ops = [{ coll: 'purchases', rec: purchase }];
  // Cuenta corriente: suma (la NC resta) al saldo del proveedor. Si este equipo está en la nube con un usuario cajero o
  // vendedor, la nube no le acepta cambios a proveedores: se lo suma ella al recibir la compra (una sola vez).
  if (onAccount && !(limited && cloudRestricted())) ops.push({ coll: 'suppliers', rec: { id: sup.id, balance: addCents(sup.balance, purchaseDebt(purchase)) } });
  // Stock y costos
  const delta = {};
  items.forEach((it, i) => {
    if (!it.product_id) return;
    const d = delta[it.product_id] = delta[it.product_id] || { q: 0, netUnit: 0, rate: it.iva_rate };
    d.q = round3(d.q + it.qty);
    d.netUnit = calc.lines[i].net_unit;
  });
  const priceChanges = [];
  for (const [pid, d] of Object.entries(delta)) {
    const p = db.get('products', pid);
    if (!p) continue;
    const rec = { id: pid };
    if (docType !== 'ND') {
      Object.assign(rec, applyStockDelta(p, branch_id, sign * d.q, mainBranchId()));
      ops.push({ coll: 'stock_moves', rec: { product_id: pid, branch_id, qty: sign * d.q, reason: 'compra', ref_id: purchase.id, created_at: now, user_id: ctx.user.id, note: docType === 'NC' ? 'Nota de crédito del proveedor' : null } });
    }
    if (docType === 'FC' && input.update_costs) {
      const cost = costForProduct({ netUnit: d.netUnit, ivaRate: p.iva_rate ?? d.rate, letter, businessIva: st.iva_condition });
      if (input.price_mode === 'lines') {
        // Precio revisado renglón por renglón (con tilde "aplicar")
        const want = round2((input.price_updates || {})[pid] || 0);
        if (want > 0 && want !== round2(p.price)) {
          rec.price = want;
          priceChanges.push({ product_id: pid, name: p.name, from: round2(p.price), to: want });
          ops.push(...auditOps('producto_precio', 'products', pid, { name: p.name, old: round2(p.price), price: want, cost: cost > 0 ? cost : round2(p.cost), source: 'compra' }));
        }
      }
      if (cost > 0) {
        if (input.price_mode && input.price_mode !== 'no' && input.price_mode !== 'lines') {
          const price = recalcPrice({ price: Number(p.price) || 0, oldCost: Number(p.cost) || 0, newCost: cost, ivaRate: p.iva_rate ?? 21, mode: input.price_mode, pct: input.price_pct, businessIva: st.iva_condition });
          if (price !== round2(p.price)) { rec.price = price; priceChanges.push({ product_id: pid, name: p.name, from: round2(p.price), to: price }); }
        }
        rec.cost = cost;
      }
      if (sup) rec.supplier_id = sup.id;
    }
    if (Object.keys(rec).length > 1) ops.push({ coll: 'products', rec });
  }
  const label = `${purchaseDocLabel(purchase) || 'Compra'}${sup ? ` · ${sup.name}` : ''}`;
  // Caja: el pago sale de la caja abierta (la NC de contado devuelve plata a la caja)
  if (session) {
    const number = nextNumber(db.all('cash_movements', { includeDeleted: true }));
    const base = { session_id: session.id, branch_id: branchOf(session, mainBranchId()), type: sign > 0 ? 'egreso' : 'ingreso', created_at: now, user_id: ctx.user.id, supplier_id: sup ? sup.id : null, ref_id: purchase.id, number, category: 'compra' };
    if (cheques.length) {
      cheques.forEach((c, i) => {
        const mov = { ...base, id: uuid(), amount: round2(c.amount), method: 'cheque', cheque_id: c.id, reason: `${label} · cheque ${c.number || ''}`.trim() };
        if (!i) purchase.cash_movement_id = mov.id;
        ops.push({ coll: 'cash_movements', rec: mov });
      });
    } else {
      const method = cashMethodOf(payment);
      const mov = { ...base, id: uuid(), amount: toPay, method, mp_amount: method === 'mercadopago' ? toPay : 0, reason: label };
      purchase.cash_movement_id = mov.id;
      ops.push({ coll: 'cash_movements', rec: mov });
    }
  }
  for (const c of cheques) {
    ops.push({ coll: 'cheques', rec: { id: c.id, status: 'entregado', delivered_to: sup ? sup.id : '', ref: 'purchase:' + purchase.id, status_at: now,
      history: [...(c.history || []), { at: now, status: 'entregado', user_id: ctx.user.id, note: label }] } });
  }
  // Imagen del comprobante (carga con foto) y lo aprendido de cada renglón para la próxima vez
  const docs = (Array.isArray(input.docs) ? input.docs : []).filter(d => typeof d === 'string' && /^data:image\/(jpeg|png|webp);base64,/.test(d) && d.length <= 200000).slice(0, 4);
  docs.forEach((photo, page) => ops.push({ coll: 'purchase_docs', rec: { purchase_id: purchase.id, page, photo, created_at: now, user_id: ctx.user.id, branch_id } }));
  if (sup && Array.isArray(input.learn) && input.learn.length && db.COLLECTIONS.includes('supplier_items')) {
    for (const rec of learnRecords(sup.id, input.learn, id => db.get('supplier_items', id), { now, userId: ctx.user.id })) ops.push({ coll: 'supplier_items', rec });
  }
  ops.push(...auditOps('compra', 'purchases', purchase.id, { total: purchase.total, doc: purchase.invoice_ref, type: docType, payment, supplier: sup ? sup.name : undefined, role: ctx.user.role, forced: calc.ok ? undefined : calc.diff, price_changes: priceChanges.length || undefined, ai: input.ai || undefined, docs: docs.length || undefined }));
  await db.putBatch(ops);
  return { purchase: db.get('purchases', purchase.id), calc, priceChanges };
}

/**
 * Anula una compra: devuelve el stock, saca su efecto de la cuenta corriente del proveedor, devuelve los cheques a la
 * cartera y, si salió de una caja que sigue abierta, hace el movimiento contrario. Los costos no se tocan.
 */
export async function voidPurchase(id, reason = '') {
  if (!ctx.user || !can(ctx.user, 'compras')) throw new Error('Solo el dueño o el encargado anulan compras.');
  const p = db.get('purchases', id);
  if (!p || p.deleted) throw new Error('Compra no encontrada.');
  if (p.status === 'anulada') throw new Error('Esa compra ya está anulada.');
  const now = Date.now();
  const mainId = mainBranchId();
  const ops = [{ coll: 'purchases', rec: { id, status: 'anulada', notes: [p.notes, `Anulada ${new Date(now).toLocaleDateString('es-AR')}${reason ? ': ' + reason : ''}`].filter(Boolean).join(' · ') } }];
  const debt = purchaseDebt(p);
  if (debt && p.supplier_id) {
    const s = db.get('suppliers', p.supplier_id);
    if (s) ops.push({ coll: 'suppliers', rec: { id: s.id, balance: addCents(s.balance, -debt) } });
  }
  // Stock: lo contrario de lo que movió (por sus movimientos)
  const moves = db.all('stock_moves').filter(m => m.ref_id === id && m.reason === 'compra');
  const per = {};
  for (const m of moves) { const k = m.product_id + '|' + branchOf(m, mainId); per[k] = per[k] || { pid: m.product_id, b: branchOf(m, mainId), q: 0 }; per[k].q = round3(per[k].q + Number(m.qty)); }
  const prodCache = {};
  for (const { pid, b, q } of Object.values(per)) {
    if (!q) continue;
    const prod = prodCache[pid] || db.get('products', pid);
    if (!prod) continue;
    const next = { ...prod, ...applyStockDelta(prod, b, -q, mainId) };
    prodCache[pid] = next;
    ops.push({ coll: 'stock_moves', rec: { product_id: pid, branch_id: b, qty: -q, reason: 'compra_anulada', ref_id: id, created_at: now, user_id: ctx.user.id, note: reason || null } });
  }
  for (const [pid, prod] of Object.entries(prodCache)) ops.push({ coll: 'products', rec: { id: pid, stocks: prod.stocks, stock: prod.stock } });
  for (const cid of p.cheque_ids || []) {
    const c = db.get('cheques', cid);
    if (c && c.status === 'entregado') ops.push({ coll: 'cheques', rec: { id: cid, status: 'en_cartera', delivered_to: null, status_at: now, history: [...(c.history || []), { at: now, status: 'en_cartera', user_id: ctx.user.id, note: 'Compra anulada' }] } });
  }
  let cashNote = '';
  const movs = db.all('cash_movements').filter(m => m.ref_id === id && m.category === 'compra');
  if (movs.length) {
    const s = db.get('cash_sessions', movs[0].session_id);
    if (s && !s.closed_at) {
      const number = nextNumber(db.all('cash_movements', { includeDeleted: true }));
      for (const m of movs) ops.push({ coll: 'cash_movements', rec: { id: uuid(), session_id: s.id, branch_id: m.branch_id, type: m.type === 'egreso' ? 'ingreso' : 'egreso', amount: m.amount, method: m.method, cheque_id: m.cheque_id || null, mp_amount: m.mp_amount || 0, reason: `Anulación: ${m.reason}`, ref_id: id, supplier_id: m.supplier_id, created_at: now, user_id: ctx.user.id, number, category: 'compra' } });
    } else cashNote = 'La caja de esa compra ya está cerrada: el movimiento de caja queda como estaba.';
  }
  ops.push(...auditOps('anular_compra', 'purchases', id, { total: p.total, doc: p.invoice_ref, reason }));
  await db.putBatch(ops);
  return { cashNote };
}

export { paymentLabel };
