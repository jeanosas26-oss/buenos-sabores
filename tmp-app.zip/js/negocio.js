// =====================================================================
// negocio.js — Lógica pura de devoluciones (notas de crédito parciales),
// remitos entre sucursales y tablero del día. Sin DOM ni IndexedDB:
// se prueba desde Node (tests/negocio.test.mjs).
// =====================================================================
import { round2, round3, salesReport, computeArqueo, branchOf, stockIn, toISODate, dayStart } from './logic.js';

const QTY_EPS = 0.0005;
const toCents = x => Math.round(Number((Number(x) * 100).toFixed(6)));

// ---------- Devoluciones / notas de crédito ----------

export const REFUND_METHODS = [
  { id: 'efectivo', label: 'Efectivo', hint: 'sale de la caja abierta' },
  { id: 'cuenta_corriente', label: 'A cuenta corriente', hint: 'baja lo que debe el cliente' },
  { id: 'mismo_medio', label: 'Mismo medio de pago', hint: 'como pagó la venta' },
];

/** Lo ya devuelto de cada renglón de la venta: [{qty, cents}] (sumando todas las devoluciones no borradas) */
export function returnedByLine(sale, returns = []) {
  const out = (sale.items || []).map(() => ({ qty: 0, cents: 0 }));
  for (const r of returns) {
    if (!r || r.deleted || r.sale_id !== sale.id) continue;
    for (const it of r.items || []) {
      const p = out[Number(it.line)];
      if (!p) continue;
      p.qty = round3(p.qty + Number(it.qty));
      p.cents += toCents(it.subtotal);
    }
  }
  return out;
}

/**
 * Importe (centavos) de devolver `qty` del renglón: proporcional a su subtotal (que ya tiene el descuento
 * general prorrateado) y, si con esto se devuelve todo lo que quedaba, exactamente lo que falta.
 * Es la misma cuenta que hace el servidor (server/src/arca/invoice.js → returnLineCents).
 */
export function returnLineCents(line, qty, prev = { qty: 0, cents: 0 }) {
  const sold = round3(line.qty);
  const lineCents = toCents(line.subtotal);
  const left = Math.max(0, lineCents - prev.cents);
  if (Math.abs(prev.qty + qty - sold) < QTY_EPS) return left;
  // Nunca más de lo que queda del renglón ni menos de 0 (con centavos muy chicos el redondeo podía pasarse
  // y la última devolución daba negativa). En los casos normales es la misma cuenta que el servidor.
  return Math.min(left, Math.max(0, Math.round((lineCents * qty) / sold)));
}

/** Renglones de la venta con lo vendido, lo ya devuelto y lo que se puede devolver */
export function returnableLines(sale, returns = []) {
  const prev = returnedByLine(sale, returns);
  return (sale.items || []).map((it, i) => ({
    line: i, product_id: it.product_id || null, name: it.name, unit_price: it.unit_price, iva_rate: it.iva_rate,
    sold: round3(it.qty), returned: prev[i].qty, left: round3(Math.max(0, Number(it.qty) - prev[i].qty)),
    subtotal: round2(it.subtotal), returnedAmount: round2(prev[i].cents / 100), leftAmount: round2((toCents(it.subtotal) - prev[i].cents) / 100),
  }));
}

/** ¿Queda algo por devolver de la venta? */
export function canReturnMore(sale, returns = []) {
  return returnableLines(sale, returns).some(l => l.left > QTY_EPS);
}

/**
 * Arma una devolución. picks: {line: qty} (qty 0 = no se devuelve). discrimina: el emisor discrimina IVA (RI).
 * Devuelve {items, total, net, iva}. Lanza Error si se quiere devolver más de lo vendido (sumando devoluciones anteriores).
 */
export function buildReturn(sale, returns, picks, discrimina = true) {
  const lines = returnableLines(sale, returns);
  const prev = returnedByLine(sale, returns);
  const items = [];
  let cents = 0, net = 0, iva = 0;
  for (const [k, v] of Object.entries(picks || {})) {
    const i = Number(k);
    const l = lines[i];
    const qty = round3(v);
    if (!l || !(qty > 0)) continue;
    if (qty > l.left + QTY_EPS) {
      throw new Error(`De “${l.name}” se pueden devolver como máximo ${l.left}${l.returned ? ` (se vendieron ${l.sold} y ya se devolvieron ${l.returned})` : ''}.`);
    }
    const c = returnLineCents(sale.items[i], qty, prev[i]);
    const subtotal = c / 100;
    const rate = Number(l.iva_rate || 0);
    const n = discrimina && rate ? round2(subtotal / (1 + rate / 100)) : subtotal;
    cents += c; net += n; iva += subtotal - n;
    items.push({ line: i, product_id: l.product_id, name: l.name, qty, unit_price: l.unit_price, iva_rate: l.iva_rate, subtotal: round2(subtotal) });
  }
  if (!items.length) throw new Error('Elegí qué productos se devuelven y cuántos.');
  return { items, total: round2(cents / 100), net: round2(net), iva: round2(iva) };
}

/** Todo lo que queda por devolver de la venta (para "Devolver todo") */
export function allLeftPicks(sale, returns = []) {
  const out = {};
  for (const l of returnableLines(sale, returns)) if (l.left > QTY_EPS) out[l.line] = l.left;
  return out;
}

/**
 * Cómo se devuelve la plata: [{method, amount}] (la suma da exactamente el total).
 * - efectivo / cuenta_corriente: todo por ese medio.
 * - mismo_medio: repartido en proporción a cómo se pagó la venta (en centavos exactos, por mayor resto).
 */
export function refundSplit(sale, total, method) {
  const T = toCents(total);
  if (method !== 'mismo_medio') return [{ method, amount: round2(T / 100) }];
  const pays = (sale.payments || []).filter(p => Number(p.amount) > 0);
  const sum = pays.reduce((a, p) => a + toCents(p.amount), 0);
  if (!pays.length || sum <= 0) return [{ method: 'efectivo', amount: round2(T / 100) }];
  const raw = pays.map(p => (toCents(p.amount) * T) / sum);
  const fl = raw.map(Math.floor);
  let rest = T - fl.reduce((a, b) => a + b, 0);
  raw.map((r, i) => [r - fl[i], i]).sort((a, b) => b[0] - a[0]).forEach(([, i]) => { if (rest > 0) { fl[i]++; rest--; } });
  const grouped = {};
  pays.forEach((p, i) => { grouped[p.method] = (grouped[p.method] || 0) + fl[i]; });
  return Object.entries(grouped).filter(([, c]) => c > 0).map(([m, c]) => ({ method: m, amount: round2(c / 100) }));
}

/** Efecto de los reintegros: efectivo que sale de la caja y lo que baja la cuenta corriente */
export function refundEffects(refunds = []) {
  let cash = 0, account = 0, other = 0;
  for (const p of refunds) {
    if (p.method === 'efectivo') cash += Number(p.amount) || 0;
    else if (p.method === 'cuenta_corriente') account += Number(p.amount) || 0;
    else other += Number(p.amount) || 0;
  }
  return { cash: round2(cash), account: round2(account), other: round2(other) };
}

// ---------- Remitos entre sucursales ----------

/** Junta las líneas por producto (sumando cantidades) y valida que todas sean > 0 */
export function cleanTransferItems(items) {
  const by = new Map();
  for (const it of items || []) {
    const q = round3(it.qty);
    if (!it.product_id || !(q > 0)) continue;
    const prev = by.get(it.product_id);
    if (prev) prev.qty = round3(prev.qty + q);
    else by.set(it.product_id, { product_id: it.product_id, name: it.name, qty: q });
  }
  return [...by.values()];
}

/**
 * Diferencias de un remito al recibirlo. received: {product_id: cantidad recibida} (lo que falta = 0).
 * Devuelve [{product_id, name, sent, received, diff}] solo de los productos con diferencia (diff < 0 = faltante).
 */
export function transferDifferences(items, received) {
  const out = [];
  for (const it of items || []) {
    const got = round3(received && received[it.product_id] !== undefined && received[it.product_id] !== '' ? received[it.product_id] : 0);
    const diff = round3(got - Number(it.qty));
    if (Math.abs(diff) > QTY_EPS) out.push({ product_id: it.product_id, name: it.name, sent: round3(it.qty), received: got, diff });
  }
  return out;
}

// ---------- Tablero del día ----------

const pct = (a, b) => (b > 0 ? Math.round(((a - b) / b) * 1000) / 10 : null);

/**
 * Resumen del día para el dueño o el encargado (pantalla "Hoy").
 * d: {sales, returns, cash_sessions, cash_movements, transfers, products, customers, branches}
 * opt: {now, branch ('all' o id), mainId, costOf}
 * Compara con ayer y con el mismo día de la semana pasada HASTA LA MISMA HORA (así a las 11 no compara
 * con el día completo de ayer), y también da el total del día completo de ayer.
 */
export function dayDashboard(d, { now = Date.now(), branch = 'all', mainId = 'main', costOf = () => 0 } = {}) {
  const inB = rec => branch === 'all' || branchOf(rec, mainId) === branch;
  const sales = (d.sales || []).filter(s => !s.deleted && inB(s));
  const returns = (d.returns || []).filter(r => !r.deleted && inB(r));
  const from = dayStart(toISODate(now));
  const sinceStart = now - from;
  const DAY = 86400000;
  // Ayer y hace una semana, del inicio de ese día hasta la misma hora (los días con cambio de hora no importan en Argentina)
  const yFrom = dayStart(toISODate(from - DAY / 2));
  const wFrom = dayStart(toISODate(from - 6.5 * DAY));
  const rep = (a, b) => salesReport(sales, { from: a, to: b, costOf, returns });
  const today = rep(from, now);
  const yesterdaySoFar = rep(yFrom, yFrom + sinceStart);
  const yesterday = rep(yFrom, from - 1);
  const lastWeekSoFar = rep(wFrom, wFrom + sinceStart);

  // Ventas por hora (de hoy): solo las horas con movimiento, de la primera a la última
  const hours = new Array(24).fill(0);
  for (const s of sales) if (s.status === 'ok' && !s.test && s.created_at >= from && s.created_at <= now) hours[new Date(s.created_at).getHours()] += Number(s.total) || 0;
  const firstH = hours.findIndex(v => v > 0), lastH = 23 - [...hours].reverse().findIndex(v => v > 0);
  const byHour = firstH < 0 ? [] : hours.slice(firstH, lastH + 1).map((v, i) => ({ hour: firstH + i, total: round2(v) }));

  // Cajas abiertas (de cualquier día) y efectivo que debería haber
  const sessions = (d.cash_sessions || []).filter(s => !s.deleted && !s.closed_at && inB(s));
  const cash = sessions.map(s => {
    const a = computeArqueo({
      opening: s.opening_amount,
      sales: (d.sales || []).filter(x => x.session_id === s.id && !x.deleted),
      movements: (d.cash_movements || []).filter(m => m.session_id === s.id && !m.deleted),
      returns: (d.returns || []).filter(r => r.session_id === s.id && !r.deleted),
    });
    return { session: s, branch_id: branchOf(s, mainId), expected: a.expected, opened_at: s.opened_at, opened_by: s.opened_by, count: a.count };
  });

  // Egresos de caja de hoy
  const egresos = (d.cash_movements || []).filter(m => !m.deleted && m.type === 'egreso' && m.created_at >= from && m.created_at <= now && inB(m));
  const egresosTotal = round2(egresos.reduce((a, m) => a + (Number(m.amount) || 0), 0));

  const todayReturns = returns.filter(r => !r.test && r.created_at >= from && r.created_at <= now);

  // ARCA: facturas y notas de crédito pendientes o rechazadas (de cualquier día, no de prueba)
  const arcaPend = [], arcaRej = [];
  for (const s of sales) {
    const doc = s.doc || {};
    if (s.test || s.status !== 'ok' || doc.kind !== 'factura' || doc.status === 'autorizado') continue;
    (doc.status === 'rechazado' ? arcaRej : arcaPend).push({ kind: 'factura', rec: s });
  }
  for (const r of returns) {
    const doc = r.doc || {};
    if (r.test || doc.kind !== 'nota_credito' || doc.status === 'autorizado') continue;
    (doc.status === 'rechazado' ? arcaRej : arcaPend).push({ kind: 'nota_credito', rec: r });
  }

  // Stock bajo (en la sucursal elegida, o en cualquiera de las activas)
  const activeBranches = (d.branches || []).filter(b => !b.deleted && b.active !== 0).map(b => b.id);
  const lowIn = branch === 'all' ? (activeBranches.length ? activeBranches : [mainId]) : [branch];
  const low = (d.products || []).filter(p => !p.deleted && p.active !== 0 && Number(p.stock_min) > 0
    && lowIn.some(b => stockIn(p, b, mainId) <= Number(p.stock_min)));

  // Remitos en camino (enviados sin recibir) que tocan la sucursal elegida
  const transfers = (d.transfers || []).filter(t => !t.deleted && t.status === 'enviado'
    && (branch === 'all' || t.from_branch === branch || t.to_branch === branch));

  // Cuentas corrientes: lo que deben los clientes
  const debtors = (d.customers || []).filter(c => !c.deleted && Number(c.balance) > 0.004);
  const receivable = round2(debtors.reduce((a, c) => a + Number(c.balance), 0));

  // Por sucursal (con "Todas")
  const perBranch = branch === 'all'
    ? (d.branches || []).filter(b => !b.deleted).map(b => {
      const r = salesReport((d.sales || []).filter(s => !s.deleted && branchOf(s, mainId) === b.id), { from, to: now, costOf, returns: (d.returns || []).filter(x => !x.deleted && branchOf(x, mainId) === b.id) });
      return { branch: b, total: r.total, count: r.count, avg: r.avg };
    }).filter(x => x.branch.active !== 0 || x.count)
    : [];

  return {
    from, now,
    today,
    margin: today.total > 0 ? Math.round((today.profit / today.total) * 1000) / 10 : null,
    vsYesterday: pct(today.total, yesterdaySoFar.total), yesterdaySoFar: yesterdaySoFar.total, yesterdayTotal: yesterday.total,
    vsLastWeek: pct(today.total, lastWeekSoFar.total), lastWeekSoFar: lastWeekSoFar.total,
    byHour,
    cash, cashExpected: round2(cash.reduce((a, c) => a + c.expected, 0)),
    egresos, egresosTotal,
    returnsToday: { count: todayReturns.length, total: round2(todayReturns.reduce((a, r) => a + (Number(r.total) || 0), 0)) },
    arca: { pending: arcaPend, rejected: arcaRej },
    lowStock: low,
    transfers,
    receivable, debtors: debtors.length,
    perBranch,
  };
}
