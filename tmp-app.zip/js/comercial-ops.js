// =====================================================================
// comercial-ops.js — Operaciones de VENTAS como SGI que guardan en la base: tarjetas y medios de pago,
// presupuestos, pedidos de clientes y a proveedores, notas de débito, promociones, rubros/subrubros y lotes.
// =====================================================================
import * as db from './db.js';
import { ctx, settings, createSale, savePurchase, mainBranchId } from './ops.js';
import { round2, round3, uuid, norm, can, setPayLabels, discriminaIva } from './logic.js';
import {
  DEFAULT_CARDS, BASE_METHODS, DEFAULT_CUSTOM_METHODS, payMethodList, activeCards, methodCode, RESERVED_CODES,
  debitNoteItems, promoError, categoriesToCreate, categoryId, computeSaleSGI,
} from './comercial.js';
import { auditOps } from './seguridad.js';
import { newLotOp } from './lotes.js';

const has = c => db.COLLECTIONS.includes(c);
const manager = () => !!ctx.user && can(ctx.user, 'editar_productos');
function mustManage() { if (!manager()) throw new Error('Solo el dueño o el encargado pueden cambiar esto.'); }
function mustOwner() { if (!ctx.user || ctx.user.role !== 'dueno') throw new Error('Solo el dueño puede cambiar las tarjetas y los medios de pago.'); }
function nextNumber(coll) {
  let max = 0;
  for (const r of db.all(coll, { includeDeleted: true })) if (Number(r.number) > max) max = Number(r.number);
  return max + 1;
}

// ---------- Tarjetas y medios de pago ----------

/** Precarga (una sola vez, con ids fijos) las tarjetas de SGI y el medio "Coca Cola". Solo dueño o encargado. */
export async function seedCatalogs() {
  if (!manager() || !has('card_types') || !has('payment_methods')) return 0;
  const ops = [];
  if (!db.all('card_types', { includeDeleted: true }).length) for (const c of DEFAULT_CARDS) ops.push({ coll: 'card_types', rec: { ...c } });
  if (!db.all('payment_methods', { includeDeleted: true }).length) {
    for (const m of DEFAULT_CUSTOM_METHODS) ops.push({ coll: 'payment_methods', rec: { id: 'pm-' + m.code, ...m, active: 1 } });
  }
  if (ops.length) await db.putBatch(ops);
  return ops.length;
}

/** Tarjetas para cobrar (si en este equipo todavía no llegaron las del dueño, las de SGI con 0 %) */
export function cardList() {
  const list = has('card_types') ? activeCards(db.all('card_types')) : [];
  if (list.length || (has('card_types') && db.all('card_types', { includeDeleted: true }).length)) return list;
  return activeCards(DEFAULT_CARDS);
}
export function allCards() { return has('card_types') ? db.all('card_types').sort((a, b) => String(a.name).localeCompare(String(b.name), 'es')) : []; }

/** Medios de pago para cobrar */
export function methodList() {
  return payMethodList(has('payment_methods') ? db.all('payment_methods') : [], { withCheque: has('cheques') });
}

/** Los nombres de los medios propios quedan disponibles para tickets e informes (payLabel) */
export function refreshPayLabels() {
  const map = {};
  for (const m of methodList()) if (!['efectivo', 'debito', 'credito', 'transferencia', 'mercadopago', 'cuenta_corriente'].includes(m.code)) map[m.code] = m.name;
  if (has('payment_methods')) for (const p of db.all('payment_methods', { includeDeleted: true })) if (p.code && !BASE_METHODS.some(b => b.code === p.code)) map[p.code] = p.name || p.code;
  setPayLabels(map);
}
db.onChange(colls => { if (colls.includes('payment_methods')) refreshPayLabels(); });

export async function saveCard({ id, name, kind, surcharge_pct, max_installments, plans = [], active = 1 }) {
  mustOwner();
  const n = String(name || '').trim().toUpperCase();
  if (!n) throw new Error('Escribí el nombre de la tarjeta.');
  if (!['credito', 'debito'].includes(kind)) throw new Error('Elegí si es de crédito o de débito.');
  const pct = round2(Number(surcharge_pct) || 0);
  if (!(pct >= 0 && pct <= 1000)) throw new Error('El recargo va de 0 a 1000 %.');
  const max = kind === 'debito' ? 1 : Math.round(Number(max_installments) || 1);
  if (!(max >= 1 && max <= 99)) throw new Error('Las cuotas van de 1 a 99.');
  const clean = (plans || []).map(p => ({ installments: Math.round(Number(p.installments)), surcharge_pct: round2(Number(p.surcharge_pct) || 0) }))
    .filter(p => p.installments >= 1 && p.installments <= 99 && p.surcharge_pct >= 0 && p.surcharge_pct <= 1000);
  if (db.all('card_types').some(c => c.id !== id && norm(c.name) === norm(n))) throw new Error(`Ya hay una tarjeta “${n}”.`);
  return db.put('card_types', { id: id || uuid(), name: n, kind, surcharge_pct: pct, max_installments: max, plans: kind === 'debito' ? [] : clean, active: active ? 1 : 0 });
}

export async function savePaymentMethod({ id, code, name, kind = 'otro', active = 1, affects_cash = 0 }) {
  mustOwner();
  const n = String(name || '').trim();
  if (!n) throw new Error('Escribí el nombre del medio de pago.');
  const all = db.all('payment_methods', { includeDeleted: true });
  const base = BASE_METHODS.find(b => b.code === code);
  if (base) {
    // Medio fijo: solo se renombra o se desactiva (el efectivo siempre queda)
    const ex = all.find(p => p.code === code);
    return db.put('payment_methods', { id: (ex && ex.id) || 'pm-' + code, code, name: n, kind: base.kind, affects_cash: base.affects_cash, active: code === 'efectivo' ? 1 : (active ? 1 : 0), deleted: 0 });
  }
  const ex = id ? db.get('payment_methods', id) : null;
  const c = ex ? ex.code : methodCode(n, all.map(p => p.code).concat(RESERVED_CODES));
  if (db.all('payment_methods').some(p => p.id !== id && norm(p.name) === norm(n))) throw new Error(`Ya hay un medio “${n}”.`);
  return db.put('payment_methods', { id: id || 'pm-' + c, code: c, name: n, kind: ['efectivo', 'tarjeta', 'mercadopago', 'qr', 'transferencia', 'cuenta_corriente', 'otro'].includes(kind) ? kind : 'otro', active: active ? 1 : 0, affects_cash: affects_cash ? 1 : 0 });
}

// ---------- Presupuestos, pedidos de clientes y pedidos a proveedores ----------

export const DOC_COLLS = { quote: 'quotes', order: 'orders', supplier_order: 'supplier_orders' };

/**
 * Guarda un presupuesto / pedido de cliente. items: carrito [{product_id,name,qty,unit_price,iva_rate,unit}].
 * Los importes se calculan como una venta (descuento general prorrateado).
 */
export async function saveCustomerDoc(kind, { id, customer_id = null, items, discount = 0, notes = '', valid_until = '', delivery_date = '', status }) {
  const coll = DOC_COLLS[kind];
  if (!has(coll)) throw new Error('Actualizá la app en todos los equipos para usar presupuestos y pedidos.');
  if (!items || !items.length) throw new Error('Agregá al menos un producto.');
  const calc = computeSaleSGI(items, { discount }, discriminaIva(settings().iva_condition));
  const prev = id ? db.get(coll, id) : null;
  const c = customer_id ? db.get('customers', customer_id) : null;
  const rec = {
    id: id || uuid(), number: prev ? prev.number : nextNumber(coll), created_at: prev ? prev.created_at : Date.now(),
    branch_id: prev ? prev.branch_id : (ctx.branchId || mainBranchId()), user_id: prev ? prev.user_id : ctx.user.id,
    customer_id: c ? c.id : null, customer_name: c ? c.name : '',
    items: calc.items.map(it => ({ product_id: it.product_id || null, name: it.name, qty: it.qty, unit_price: it.unit_price, iva_rate: it.iva_rate, discount: it.discount, subtotal: it.subtotal, unit: it.unit || 'u' })),
    discount: calc.discount, total: calc.total, status: status || (prev && prev.status) || (kind === 'quote' ? 'abierto' : 'pendiente'),
    notes: String(notes || '').trim(), converted_sale_id: prev ? prev.converted_sale_id || null : null,
  };
  if (kind === 'quote') rec.valid_until = valid_until || null; else rec.delivery_date = delivery_date || null;
  return db.put(coll, rec);
}

export async function setDocStatus(kind, id, status) {
  const coll = DOC_COLLS[kind];
  const d = db.get(coll, id);
  if (!d) throw new Error('No se encontró.');
  if (d.status === 'convertido' || d.status === 'recibido') throw new Error('Ya se convirtió: no se puede cambiar.');
  return db.put(coll, { id, status });
}

/**
 * Convierte en venta (lo usa Vender al cobrar un presupuesto/pedido): la venta y el cambio de estado van en la
 * MISMA transacción (extraOps de createSale con el id de la venta ya elegido).
 */
export function convertOps(kind, id, saleId) {
  const coll = DOC_COLLS[kind];
  if (!coll || !id || !db.get(coll, id)) return [];
  return [{ coll, rec: { id, status: 'convertido', converted_sale_id: saleId } }];
}

/** Pedido a proveedor (items: [{product_id, name, qty, unit_cost, code}]) */
export async function saveSupplierOrder({ id, supplier_id = null, items, notes = '', expected_date = '', status }) {
  mustManage();
  if (!has('supplier_orders')) throw new Error('Actualizá la app para usar pedidos a proveedores.');
  const clean = (items || []).map(it => ({ product_id: it.product_id || null, name: it.name, code: it.code || '', qty: round3(it.qty), unit_cost: round2(it.unit_cost || 0) })).filter(it => it.qty > 0);
  if (!clean.length) throw new Error('Agregá al menos un producto con cantidad.');
  const prev = id ? db.get('supplier_orders', id) : null;
  return db.put('supplier_orders', {
    id: id || uuid(), number: prev ? prev.number : nextNumber('supplier_orders'), created_at: prev ? prev.created_at : Date.now(),
    branch_id: prev ? prev.branch_id : (ctx.branchId || mainBranchId()), user_id: prev ? prev.user_id : ctx.user.id,
    supplier_id: supplier_id || null, items: clean, total: round2(clean.reduce((a, it) => a + round2(it.qty * it.unit_cost), 0)),
    status: status || (prev && prev.status) || 'borrador', expected_date: expected_date || null, notes: String(notes || '').trim(),
    purchase_id: prev ? prev.purchase_id || null : null,
  });
}

/**
 * Convierte un pedido a proveedor en compra: carga la compra (stock + costos + cuenta corriente) con lo que llegó y
 * los lotes con vencimiento que se hayan cargado. items: [{product_id, name, qty, unit_cost, lot, expires_at}]
 */
export async function receiveSupplierOrder(id, { items, payment = 'contado', paid = 0, due_date = '', invoice_ref = '' }) {
  mustManage();
  const so = db.get('supplier_orders', id);
  if (!so) throw new Error('No se encontró el pedido.');
  if (so.status === 'recibido') throw new Error('Este pedido ya se cargó como compra.');
  const rows = (items || []).filter(it => it.product_id && Number(it.qty) > 0);
  if (!rows.length) throw new Error('No llegó nada: poné las cantidades recibidas.');
  const lotOps = rows.filter(it => it.expires_at).map(it => newLotOp({ product_id: it.product_id, branch_id: ctx.branchId || mainBranchId(), lot: it.lot, expires_at: it.expires_at, qty: it.qty }));
  const clean = rows.map(it => ({ product_id: it.product_id, name: it.name, qty: round3(it.qty), unit_cost: round2(it.unit_cost) }));
  let purchase;
  try {
    // Compra completa como SGI (compras-ops.js, del módulo de compras): comprobante X con el N° del pedido, actualiza costos
    const { savePurchaseFull } = await import('./compras-ops.js');
    const r = await savePurchaseFull({ supplier_id: so.supplier_id, doc_type: 'FC', letter: 'X', doc_number: invoice_ref || '', items: clean.map(it => ({ ...it, iva_rate: (db.get('products', it.product_id) || {}).iva_rate ?? 21 })),
      payment, paid, due_date, update_costs: 1, price_mode: 'no', force: true, notes: `Pedido a proveedor N° ${so.number}` });
    purchase = r && (r.purchase || r);
  } catch (e) {
    if (!/Failed to fetch|import|module/i.test(e.message || '')) throw e;
    purchase = await savePurchase({ supplier_id: so.supplier_id, items: clean, invoice_ref: invoice_ref || `Pedido N° ${so.number}`, payment, paid, due_date });
  }
  const pid = purchase && purchase.id;
  await db.putBatch([{ coll: 'supplier_orders', rec: { id, status: 'recibido', purchase_id: pid || null } }, ...lotOps.map(o => ({ ...o, rec: { ...o.rec, purchase_id: pid || null } }))]);
  return purchase;
}

// ---------- Nota de débito ----------

/**
 * Nota de débito a un cliente (recargo posterior: interés por pago fuera de término, diferencia de precio, etc.).
 * Es una venta con doc_type "ND", letra X (comprobante interno: la nube todavía no factura ND en ARCA), un renglón
 * con el concepto y, por defecto, a cuenta corriente (suma a lo que debe; no hace falta la caja abierta).
 */
export async function createDebitNote({ customer_id, concept, amount, iva_rate = 21, method = 'cuenta_corriente', observations = '', ref_sale = null }) {
  mustManage();
  const a = round2(Number(amount));
  if (!(a > 0)) throw new Error('Poné el importe de la nota de débito.');
  if (!customer_id && method === 'cuenta_corriente') throw new Error('Elegí el cliente.');
  const obs = [observations, ref_sale ? `Sobre la venta N° ${ref_sale.number}` : ''].filter(Boolean).join(' · ');
  return createSale({
    cart: debitNoteItems(concept, a, iva_rate), discount: 0, payments: [{ method, amount: a }], customer_id, wantFactura: false,
    extra: { doc_type: 'ND', observations: obs }, requireSession: method !== 'cuenta_corriente',
    extraOps: auditOps('nota_debito', 'sales', '', { customer_id, concept, amount: a, method }),
  });
}

// ---------- Promociones ----------

export async function savePromotion(p) {
  mustManage();
  if (!has('promotions')) throw new Error('Actualizá la app para usar promociones.');
  const rec = {
    id: p.id || uuid(), name: String(p.name || '').trim(), kind: p.kind,
    product_ids: (p.product_ids || []).filter(Boolean), category: String(p.category || '').trim(), subcategory: String(p.subcategory || '').trim(),
    params: p.params || {}, from: p.from || null, to: p.to || null, active: p.active === 0 ? 0 : 1,
    branch_ids: (p.branch_ids || []).filter(Boolean),
  };
  const err = promoError(rec);
  if (err) throw new Error(err);
  return db.put('promotions', rec);
}
export function livePromotions() { return has('promotions') ? db.all('promotions') : []; }

// ---------- Rubros y subrubros ----------

/** Crea los rubros que faltan a partir de las categorías de los productos (no cambia ningún producto) */
export async function migrateCategories() {
  if (!manager() || !has('categories')) return 0;
  const names = categoriesToCreate(db.all('products'), db.all('categories', { includeDeleted: false }));
  // Un rubro borrado con el mismo nombre se revive (mismo id fijo)
  const ops = names.map(name => ({ coll: 'categories', rec: { id: categoryId(name), name, active: 1, deleted: 0 } }));
  for (let i = 0; i < ops.length; i += 500) await db.putBatch(ops.slice(i, i + 500));
  return ops.length;
}

/** Rubros vivos con la cantidad de productos de cada uno */
export function categoryList() {
  const count = new Map();
  for (const p of db.all('products')) { const k = norm(p.category || ''); count.set(k, (count.get(k) || 0) + 1); }
  const subs = has('subcategories') ? db.all('subcategories') : [];
  return (has('categories') ? db.all('categories') : []).map(c => ({ ...c, products: count.get(norm(c.name)) || 0, subs: subs.filter(s => s.category_id === c.id).sort((a, b) => a.name.localeCompare(b.name, 'es')) }))
    .sort((a, b) => a.name.localeCompare(b.name, 'es'));
}

/** Crea o renombra un rubro. Al renombrar, cambia también la categoría de sus productos y promociones. */
export async function saveCategory({ id, name, active = 1 }) {
  mustManage();
  const n = String(name || '').trim();
  if (!n) throw new Error('Escribí el nombre del rubro.');
  const dup = db.all('categories').find(c => c.id !== id && norm(c.name) === norm(n));
  if (dup) throw new Error(`Ya existe el rubro “${dup.name}”.`);
  const prev = id ? db.get('categories', id) : null;
  const ops = [{ coll: 'categories', rec: { id: id || categoryId(n), name: n, active: active ? 1 : 0, deleted: 0 } }];
  if (prev && prev.name !== n) {
    for (const p of db.all('products')) if (norm(p.category) === norm(prev.name)) ops.push({ coll: 'products', rec: { id: p.id, category: n } });
    for (const pr of livePromotions()) if (pr.category && norm(pr.category) === norm(prev.name)) ops.push({ coll: 'promotions', rec: { id: pr.id, category: n } });
    ops.push(...auditOps('lote_categoria', 'categories', id, { from: prev.name, category: n, count: ops.length - 1 }));
  }
  for (let i = 0; i < ops.length; i += 800) await db.putBatch(ops.slice(i, i + 800));
  return db.get('categories', ops[0].rec.id);
}

/** Borra un rubro: si tiene productos, se pasan al rubro `moveTo` (obligatorio) */
export async function deleteCategory(id, moveTo = '') {
  mustManage();
  const c = db.get('categories', id);
  if (!c) return;
  const prods = db.all('products').filter(p => norm(p.category) === norm(c.name));
  if (prods.length && !String(moveTo || '').trim()) throw new Error(`“${c.name}” tiene ${prods.length} productos: elegí a qué rubro pasarlos.`);
  const ops = [{ coll: 'categories', rec: { id, deleted: 1 } }, ...prods.map(p => ({ coll: 'products', rec: { id: p.id, category: moveTo, subcategory: '' } }))];
  if (has('subcategories')) for (const s of db.all('subcategories')) if (s.category_id === id) ops.push({ coll: 'subcategories', rec: { id: s.id, deleted: 1 } });
  for (let i = 0; i < ops.length; i += 800) await db.putBatch(ops.slice(i, i + 800));
}

export async function saveSubcategory({ id, name, category_id, active = 1 }) {
  mustManage();
  const n = String(name || '').trim();
  if (!n) throw new Error('Escribí el nombre del subrubro.');
  if (!category_id || !db.get('categories', category_id)) throw new Error('Elegí el rubro.');
  if (db.all('subcategories').some(s => s.id !== id && s.category_id === category_id && norm(s.name) === norm(n))) throw new Error('Ese subrubro ya existe en el rubro.');
  const prev = id ? db.get('subcategories', id) : null;
  const ops = [{ coll: 'subcategories', rec: { id: id || uuid(), name: n, category_id, active: active ? 1 : 0 } }];
  if (prev && prev.name !== n) {
    const cat = db.get('categories', category_id);
    for (const p of db.all('products')) if (norm(p.category) === norm(cat.name) && norm(p.subcategory) === norm(prev.name)) ops.push({ coll: 'products', rec: { id: p.id, subcategory: n } });
  }
  for (let i = 0; i < ops.length; i += 800) await db.putBatch(ops.slice(i, i + 800));
  return db.get('subcategories', ops[0].rec.id);
}
export async function deleteSubcategory(id) {
  mustManage();
  const s = db.get('subcategories', id);
  if (!s) return;
  const cat = db.get('categories', s.category_id);
  const ops = [{ coll: 'subcategories', rec: { id, deleted: 1 } }];
  if (cat) for (const p of db.all('products')) if (norm(p.category) === norm(cat.name) && norm(p.subcategory) === norm(s.name)) ops.push({ coll: 'products', rec: { id: p.id, subcategory: '' } });
  for (let i = 0; i < ops.length; i += 800) await db.putBatch(ops.slice(i, i + 800));
}
/** Subrubros de un rubro (por nombre del rubro) */
export function subcategoriesOf(categoryName) {
  if (!has('categories') || !has('subcategories')) return [];
  const c = db.all('categories').find(x => norm(x.name) === norm(categoryName));
  return c ? db.all('subcategories').filter(s => s.category_id === c.id && s.active !== 0).sort((a, b) => a.name.localeCompare(b.name, 'es')) : [];
}

// ---------- Lotes y vencimientos ----------

export async function saveLot({ id, product_id, branch_id, lot = '', expires_at, qty, notes = '' }) {
  if (!has('product_lots')) throw new Error('Actualizá la app para cargar vencimientos.');
  if (id) {
    const n = round3(Number(qty));
    if (!(n >= 0)) throw new Error('Revisá la cantidad.');
    if (!/^\d{4}-\d{2}-\d{2}$/.test(String(expires_at || ''))) throw new Error('Poné la fecha de vencimiento.');
    return db.put('product_lots', { id, lot: String(lot || '').trim(), expires_at, qty: n, notes: String(notes || '').trim() });
  }
  const op = newLotOp({ product_id, branch_id: branch_id || ctx.branchId || mainBranchId(), lot, expires_at, qty, notes });
  const [r] = await db.putBatch([op]);
  return r;
}

/** Productos cuyo precio cambió desde una fecha (auditoría: cambios de precio de a uno y en lote) */
export function priceChangedIds(fromMs) {
  const ids = new Set();
  for (const a of db.all('audit_log')) {
    if (a.created_at < fromMs) continue;
    if (a.action === 'producto_precio' && a.entity_id) ids.add(a.entity_id);
    if (a.action === 'lote_precio') for (const r of (a.detail && a.detail.sample) || []) if (r.id) ids.add(r.id);
  }
  return ids;
}

