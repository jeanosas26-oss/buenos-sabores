// =====================================================================
// autoriza.js — Autorización en el momento con el PIN del dueño o del
// encargado (para lo que un cajero o vendedor no puede hacer solo) y
// confirmaciones anti-error de tipeo.
// =====================================================================
import * as db from './db.js';
import { ctx } from './ops.js';
import * as sync from './sync.js';
import { checkLocalPin, hasLocalPin } from './pin.js';
import { html, $, modal } from './ui.js';
import { ROLES, can } from './logic.js';
import { isManager } from './control.js';
import { audit, clockCheck, clockAccept } from './seguridad.js';

let locked = 0; // después de 3 PIN incorrectos seguidos, 60 segundos sin poder probar
let fails = 0;

/**
 * Pide la autorización de un dueño o encargado para hacer `what` (texto: "anular la venta N° 12").
 * Si quien está usando la app ya es dueño o encargado, no pide nada.
 * Devuelve {by: usuario que autoriza, self: true|false} o null si se canceló.
 */
export async function authorize(what, { action = 'autorizacion', entity = '', entityId = '', perm = null } = {}) {
  // perm: el permiso que hace falta (Ajustes → Usuarios → Permisos). Lo autoriza quien lo tenga; sin perm, dueño o encargado.
  const allowed = u => !!u && (perm ? can(u, perm) : isManager(u.role));
  if (ctx.user && allowed(ctx.user)) return { by: ctx.user, self: true };
  // Con nube, el PIN de quien autoriza se valida EN LA NUBE (el equipo no guarda el verificador de dueño ni encargado):
  // sin internet no se puede autorizar (la venta sigue). Sin nube, con el verificador de este equipo.
  const cloud = sync.isConfigured();
  if (cloud && typeof navigator !== 'undefined' && navigator.onLine === false) {
    await modal({ title: 'Hace falta autorización', body: html`<div class="notice notice-warn" id="au-offline"><p><b>Sin internet no se puede autorizar; se puede seguir vendiendo.</b></p><p>Para ${what} hace falta el PIN del dueño o del encargado, y se valida en la nube. Probá de nuevo cuando vuelva internet.</p></div>`, actions: [{ label: 'Entendido', kind: 'primary', value: true }] });
    return null;
  }
  const managers = db.all('users').filter(u => u.active && allowed(u) && (cloud || hasLocalPin(u)))
    .sort((a, b) => (a.role === b.role ? String(a.name).localeCompare(String(b.name), 'es') : a.role === 'dueno' ? -1 : 1));
  if (!managers.length) {
    await modal({ title: 'Hace falta autorización', body: html`<div class="notice notice-warn"><p>Para ${what} hace falta el PIN del dueño o del encargado, y en este equipo ninguno tiene PIN cargado todavía.</p><p>Pedile que entre una vez con su usuario en este equipo.</p></div>`, actions: [{ label: 'Entendido', kind: 'primary', value: true }] });
    return null;
  }
  return modal({
    title: 'Autorización',
    body: html`<div class="notice notice-info"><p>Para <b>${what}</b> hace falta la autorización del dueño o del encargado. Queda registrado quién autorizó.</p></div>
      <fieldset class="seg" id="au-who"><legend>¿Quién autoriza?</legend>
        ${managers.map((u, i) => html`<label><input type="radio" name="au-u" value="${u.id}" ${i === 0 ? 'checked' : ''}><span>${u.name}&nbsp;<small style="font-weight:400">· ${ROLES[u.role] || u.role}</small></span></label>`)}</fieldset>
      <form id="au-f" novalidate><div class="field"><label for="au-pin">PIN de quien autoriza</label>
        <input id="au-pin" class="money-input" type="password" inputmode="numeric" maxlength="8" autocomplete="off" autofocus></div></form>
      <p id="au-err" class="field-err" role="alert"></p>`,
    onMount(m) {
      $('#au-f', m).addEventListener('submit', e => { e.preventDefault(); $('#au-go', m.parentElement).click(); });
      // Entra solo al completar el largo del PIN de quien autoriza (o con Enter / Autorizar)
      $('#au-pin', m).addEventListener('input', e => {
        const u = db.get('users', (m.querySelector('[name=au-u]:checked') || {}).value);
        if (e.target.value.replace(/\D/g, '').length === (Number(u && u.pin_len) || 4)) $('#au-go', m.parentElement).click();
      });
    },
    actions: [{ label: 'Cancelar', value: null }, {
      label: 'Autorizar', kind: 'primary', id: 'au-go', onClick: async (close, w) => {
        const err = $('#au-err', w), inp = $('#au-pin', w);
        if (Date.now() < locked) { err.textContent = `Demasiados intentos. Esperá ${Math.ceil((locked - Date.now()) / 1000)} segundos.`; return; }
        const u = db.get('users', (w.querySelector('[name=au-u]:checked') || {}).value);
        const pin = inp.value.replace(/\D/g, '');
        if (pin.length < 4 || pin.length > 8) { err.textContent = 'El PIN tiene de 4 a 8 números.'; inp.focus(); return; }
        const btn = $('#au-go', w);
        let ok = false;
        if (u && cloud) {
          btn.disabled = true; err.textContent = 'Verificando en la nube…';
          try { ok = await sync.verifySupervisor(u, pin, perm || ''); } catch (e) {
            btn.disabled = false;
            if (e.code !== 'BAD_PIN') { err.textContent = e.offline || e.network ? 'Sin internet no se puede autorizar; se puede seguir vendiendo.' : e.message; inp.value = ''; inp.focus(); return; }
          }
          btn.disabled = false; err.textContent = '';
        } else if (u) ok = (await checkLocalPin(u, pin)).ok;
        if (!ok) {
          fails++;
          inp.value = '';
          await audit('autorizacion_fallida', entity, entityId, { what, tried: u ? u.id : null, tried_name: u ? u.name : '' });
          if (fails >= 3) { locked = Date.now() + 60000; fails = 0; err.textContent = 'PIN incorrecto 3 veces. Esperá 1 minuto para volver a probar.'; }
          else err.textContent = 'PIN incorrecto.';
          inp.focus();
          return;
        }
        fails = 0;
        close({ by: u, self: false, action });
      },
    }],
  });
}

/** Pregunta para confirmar una advertencia ("¿Seguro?"). Devuelve true si confirma. */
export async function confirmWarnings(warnings, { title = 'Revisá antes de seguir', ok = 'Sí, está bien' } = {}) {
  const list = (warnings || []).map(w => (typeof w === 'string' ? w : w.msg)).filter(Boolean);
  if (!list.length) return true;
  const v = await modal({
    title,
    body: html`<div class="notice notice-warn">${list.length === 1 ? html`<p>${list[0]}</p>` : html`<ul class="stack" style="margin:0;padding-left:1.2rem">${list.map(t => html`<li>${t}</li>`)}</ul>`}</div>
      <p class="muted">¿Está bien así?</p>`,
    actions: [{ label: 'No, corregir', value: false, id: 'cw-no' }, { label: ok, kind: 'primary', value: true, id: 'cw-ok' }],
  });
  return v === true;
}

/**
 * Antes de vender, abrir o cerrar la caja: si la fecha/hora del equipo está atrasada (alguien la cambió),
 * avisa. El cajero necesita autorización para seguir; queda en la auditoría. Devuelve true si se puede seguir.
 */
export async function guardClock(what = 'seguir') {
  const behind = await clockCheck();
  if (!behind) return true;
  const txt = behind >= 120 ? `${Math.round(behind / 60)} horas` : `${behind} minutos`;
  const go = await modal({
    title: 'La fecha u hora del equipo está atrasada',
    body: html`<div class="notice notice-error"><p>El reloj de este equipo marca <b>${txt} antes</b> que el último movimiento que guardó. Las ventas y la caja quedarían con fecha equivocada.</p>
      <p>Corregí la fecha y la hora en la configuración del equipo (automática por internet).</p></div>`,
    actions: [{ label: 'Cancelar', value: false }, { label: isManager(ctx.user.role) ? 'Seguir igual' : 'Seguir con autorización', kind: 'danger', value: true, id: 'clk-go' }],
  });
  if (!go) return false;
  const auth = await authorize(`${what} con la fecha del equipo atrasada`, { action: 'reloj_atrasado' });
  if (!auth) return false;
  await audit('reloj_atrasado', '', '', { minutes: behind, what }, auth);
  await clockAccept();
  return true;
}
