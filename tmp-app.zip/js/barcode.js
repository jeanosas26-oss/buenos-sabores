// =====================================================================
// barcode.js — Decodificador propio de códigos de barras de productos:
// EAN-13, EAN-8, UPC-A y UPC-E. JavaScript puro, sin DOM (se prueba en Node).
//
// Cómo funciona, para una línea de la imagen:
//   1) Luminancias (0 = negro, 255 = blanco) → umbral adaptativo (mitad entre el mínimo y el
//      máximo de la zona) y también un umbral global.
//   2) Corridas de claro/oscuro con bordes en posición fraccionaria (interpolando dónde la señal
//      cruza el umbral): así aguanta barras de 1–2 px y desenfoque leve.
//   3) Busca la guarda de inicio (barra-espacio-barra) con margen blanco antes, y decodifica cada
//      dígito por los anchos RELATIVOS de sus 4 elementos (no importa la escala).
//   4) Valida guardas del medio y del final, margen después y el dígito verificador.
// Para una imagen se prueban varias líneas horizontales y verticales (código girado 90°),
// en los dos sentidos (código al revés).
// =====================================================================

// Anchos (en módulos) de los dígitos 0–9 en codificación "L" (impar). R tiene los mismos anchos
// con colores invertidos; G es L al revés.
const L = [[3, 2, 1, 1], [2, 2, 2, 1], [2, 1, 2, 2], [1, 4, 1, 1], [1, 1, 3, 2], [1, 2, 3, 1], [1, 1, 1, 4], [1, 3, 1, 2], [1, 2, 1, 3], [3, 1, 1, 2]];
const LG = L.concat(L.map(p => [...p].reverse())); // 0–9 = L, 10–19 = G
// Primer dígito del EAN-13 según la paridad de los 6 de la izquierda (bit 1 = G, el primero es el bit alto)
const EAN13_FIRST = [0x00, 0x0B, 0x0D, 0x0E, 0x13, 0x19, 0x1C, 0x15, 0x16, 0x1A];
// UPC-E: sistema numérico (0/1) y dígito verificador según la paridad de sus 6 dígitos
const UPCE_PARITY = [[0x38, 0x34, 0x32, 0x31, 0x2C, 0x26, 0x23, 0x2A, 0x29, 0x25], [0x07, 0x0B, 0x0D, 0x0E, 0x13, 0x19, 0x1C, 0x15, 0x16, 0x1A]];

const MAX_AVG = 0.42;   // variación promedio admitida al comparar con un patrón
const MAX_ONE = 0.7;    // variación máxima de un elemento (en módulos)
const QUIET = 3;        // margen blanco mínimo (en módulos) antes y después del código

/** Dígito verificador GS1 (EAN/UPC) de una cadena de dígitos SIN el verificador */
export function gs1Check(body) {
  let s = 0;
  for (let i = body.length - 1, w = 3; i >= 0; i--, w = 4 - w) s += Number(body[i]) * w;
  return String((10 - (s % 10)) % 10);
}
/** true si la cadena es un EAN-13/EAN-8/UPC-A con verificador correcto */
export function validGtin(code) {
  const c = String(code || '');
  return /^(\d{8}|\d{12}|\d{13}|\d{14})$/.test(c) && gs1Check(c.slice(0, -1)) === c.slice(-1);
}

/** UPC-E (8 dígitos: sistema + 6 + verificador) → UPC-A (12). null si no es válido. */
export function upceToUpca(upce) {
  const c = String(upce || '');
  if (!/^[01]\d{7}$/.test(c)) return null;
  const ns = c[0], d = c.slice(1, 7), ch = c[7];
  let body;
  const last = d[5];
  if (last <= '2') body = ns + d[0] + d[1] + last + '0000' + d[2] + d[3] + d[4];
  else if (last === '3') body = ns + d[0] + d[1] + d[2] + '00000' + d[3] + d[4];
  else if (last === '4') body = ns + d[0] + d[1] + d[2] + d[3] + '00000' + d[4];
  else body = ns + d.slice(0, 5) + '0000' + last;
  return gs1Check(body) === ch ? body + ch : null;
}

/**
 * Variantes de un código para buscarlo entre los productos, en orden de preferencia:
 * el código tal cual; UPC-A de 12 ⇄ EAN-13 con 0 adelante; UPC-E → UPC-A (12 y 13 dígitos).
 */
export function codeVariants(code) {
  const c = String(code || '').trim();
  if (!c) return [];
  const out = [c];
  if (/^\d{12}$/.test(c)) out.push('0' + c);
  if (/^0\d{12}$/.test(c)) out.push(c.slice(1));
  if (/^\d{8}$/.test(c)) { const a = upceToUpca(c); if (a) out.push(a, '0' + a); }
  return [...new Set(out)];
}

// ---------- Comparación de patrones ----------

function variance(runs, at, pattern) {
  const n = pattern.length;
  let total = 0, plen = 0;
  for (let i = 0; i < n; i++) { total += runs[at + i]; plen += pattern[i]; }
  if (!(total > 0)) return Infinity;
  const unit = total / plen, maxOne = MAX_ONE * unit;
  let v = 0;
  for (let i = 0; i < n; i++) {
    const d = Math.abs(runs[at + i] - pattern[i] * unit);
    if (d > maxOne) return Infinity;
    v += d;
  }
  return v / total;
}
const G1 = [1, 1, 1], G5 = [1, 1, 1, 1, 1], G6 = [1, 1, 1, 1, 1, 1];

// Distancias "borde a borde del mismo tipo" (barra+espacio) de cada patrón: no cambian si las
// barras salen más gordas o más finas por el desenfoque o la tinta
const EDGE = LG.map(p => [p[0] + p[1], p[1] + p[2]]);

/** Mejor dígito (0–19, ≥10 = G) para los 4 elementos en runs[at..at+3]; -1 si ninguno sirve */
function bestDigit(runs, at, allowG, maxAvg = MAX_AVG) {
  let best = -1, bv = maxAvg;
  const lim = allowG ? 20 : 10;
  for (let d = 0; d < lim; d++) {
    const v = variance(runs, at, LG[d]);
    if (v < bv) { bv = v; best = d; }
  }
  if (best >= 0) return best;
  // Segundo intento: por distancias borde a borde; 1/7 y 2/8 empatan y se separan por los anchos
  const unit = sum(runs, at, 4) / 7;
  const t1 = (runs[at] + runs[at + 1]) / unit, t2 = (runs[at + 1] + runs[at + 2]) / unit;
  const T1 = Math.round(t1), T2 = Math.round(t2);
  if (Math.abs(t1 - T1) > 0.35 || Math.abs(t2 - T2) > 0.35) return -1;
  let bd = Infinity;
  for (let d = 0; d < lim; d++) {
    if (EDGE[d][0] !== T1 || EDGE[d][1] !== T2) continue;
    let v = 0;
    for (let k = 0; k < 4; k++) v += Math.abs(runs[at + k] / unit - LG[d][k]);
    if (v < bd) { bd = v; best = d; }
  }
  return bd <= 2.6 ? best : -1;
}

function sum(runs, from, n) { let s = 0; for (let i = 0; i < n; i++) s += runs[from + i]; return s; }

// Verifica que cada grupo de 4 elementos (un dígito) mida ~7 módulos
function groupOk(runs, at, module) { const w = sum(runs, at, 4) / module; return w > 5.3 && w < 8.7; }

/**
 * Intenta leer un código que empieza en runs[i] (una barra; runs[i-1] es el margen blanco).
 * Devuelve {text, format} o null.
 */
function decodeAt(runs, i) {
  const n = runs.length;
  if (variance(runs, i, G1) > MAX_AVG) return null;
  const guard = (runs[i] + runs[i + 1] + runs[i + 2]) / 3;
  const quietOk = (q, module) => q >= QUIET * module;

  // EAN-13 / UPC-A: 3 + 24 + 5 + 24 + 3 = 59 elementos, 95 módulos
  if (i + 59 < n + 1) {
    const r = ean(runs, i, 6, guard, quietOk);
    if (r) return r;
  }
  // EAN-8: 3 + 16 + 5 + 16 + 3 = 43 elementos, 67 módulos
  if (i + 43 < n + 1) {
    const r = ean(runs, i, 4, guard, quietOk);
    if (r) return r;
  }
  // UPC-E: 3 + 24 + 6 = 33 elementos, 51 módulos
  if (i + 33 < n + 1) {
    const span = sum(runs, i, 33);
    const module = span / 51;
    // UPC-E no tiene guarda del medio ni verificador explícito: se le exige más (margen y anchos)
    if (guard < module * 0.6 || guard > module * 1.5) return null;
    if (i + 33 >= n || runs[i - 1] < 7 * module || runs[i + 33] < 7 * module) return null;
    if (variance(runs, i + 27, G6) > MAX_AVG * 0.8) return null;
    let digits = '', parity = 0;
    for (let k = 0; k < 6; k++) {
      const at = i + 3 + k * 4;
      if (!groupOk(runs, at, module)) return null;
      const d = bestDigit(runs, at, true, MAX_AVG * 0.8);
      if (d < 0) return null;
      digits += d % 10;
      if (d >= 10) parity |= 1 << (5 - k);
    }
    for (let ns = 0; ns < 2; ns++) {
      const ck = UPCE_PARITY[ns].indexOf(parity);
      if (ck >= 0) {
        const code = ns + digits + ck;
        if (upceToUpca(code)) return { text: code, format: 'upc_e' };
      }
    }
  }
  return null;
}

function ean(runs, i, half, guard, quietOk) {
  const nEl = 3 + half * 4 + 5 + half * 4 + 3;
  const modules = 3 + half * 7 + 5 + half * 7 + 3;
  const span = sum(runs, i, nEl);
  const module = span / modules;
  if (guard < module * 0.5 || guard > module * 1.6) return null;
  if (!quietOk(runs[i - 1], module)) return null;
  const after = i + nEl;
  if (after >= runs.length || !quietOk(runs[after], module)) return null;
  const mid = i + 3 + half * 4;
  if (variance(runs, mid, G5) > MAX_AVG) return null;
  if (variance(runs, after - 3, G1) > MAX_AVG) return null;
  let left = '', parity = 0, right = '';
  for (let k = 0; k < half; k++) {
    const at = i + 3 + k * 4;
    if (!groupOk(runs, at, module)) return null;
    const d = bestDigit(runs, at, half === 6);
    if (d < 0) return null;
    left += d % 10;
    if (d >= 10) parity |= 1 << (half - 1 - k);
  }
  for (let k = 0; k < half; k++) {
    const at = mid + 5 + k * 4;
    if (!groupOk(runs, at, module)) return null;
    const d = bestDigit(runs, at, false);
    if (d < 0) return null;
    right += d;
  }
  let code;
  if (half === 6) {
    const first = EAN13_FIRST.indexOf(parity);
    if (first < 0) return null;
    code = first + left + right;
  } else code = left + right;
  if (gs1Check(code.slice(0, -1)) !== code.slice(-1)) return null;
  if (half === 4) return { text: code, format: 'ean_8' };
  if (code[0] === '0') return { text: code.slice(1), format: 'upc_a' };
  return { text: code, format: 'ean_13' };
}

/**
 * Lee un código en una lista de corridas que empieza con blanco: [blanco, negro, blanco, …].
 * Prueba en los dos sentidos. Devuelve {text, format} o null.
 */
export function decodeRuns(runs) {
  for (let pass = 0; pass < 2; pass++) {
    const r = pass ? reverseRuns(runs) : runs;
    for (let i = 1; i + 33 <= r.length; i += 2) {
      const res = decodeAt(r, i);
      if (res) return res;
    }
  }
  return null;
}
function reverseRuns(runs) {
  const out = runs.slice().reverse();
  if (runs.length % 2 === 0) out.unshift(0); // terminaba en negro: que empiece con blanco
  return out;
}

// ---------- Binarización de una línea ----------

/** Mínimo y máximo en una ventana deslizante (O(n)) */
function slidingMinMax(a, half) {
  const n = a.length, mn = new Float32Array(n), mx = new Float32Array(n);
  const qmin = new Int32Array(n), qmax = new Int32Array(n);
  let h1 = 0, t1 = 0, h2 = 0, t2 = 0;
  // ventana [j-half, j+half]: se recorre agregando el índice j+half
  for (let k = 0; k < n + half; k++) {
    if (k < n) {
      while (t1 > h1 && a[qmin[t1 - 1]] >= a[k]) t1--;
      qmin[t1++] = k;
      while (t2 > h2 && a[qmax[t2 - 1]] <= a[k]) t2--;
      qmax[t2++] = k;
    }
    const j = k - half;
    if (j < 0) continue;
    while (qmin[h1] < j - half) h1++;
    while (qmax[h2] < j - half) h2++;
    mn[j] = a[qmin[h1]]; mx[j] = a[qmax[h2]];
  }
  return { mn, mx };
}

/** Corridas (empezando con blanco) con bordes fraccionarios según un umbral por píxel */
export function toRuns(lum, thr) {
  const n = lum.length;
  const runs = [];
  let dark = lum[0] < thr[0];
  if (dark) runs.push(0);
  let start = 0;
  for (let i = 1; i < n; i++) {
    const d = lum[i] < thr[i];
    if (d === dark) continue;
    const t = (thr[i - 1] + thr[i]) / 2;
    const a = lum[i - 1] - t, b = lum[i] - t;
    let f = a === b ? 0.5 : a / (a - b);
    if (f < 0) f = 0; else if (f > 1) f = 1;
    const pos = i - 0.5 + f; // borde entre los centros de los píxeles i-1 e i
    runs.push(pos - start);
    start = pos;
    dark = d;
  }
  runs.push(n - start);
  return runs;
}

/**
 * Corridas por detección de bordes: cada borde es un máximo local del gradiente (posición
 * subpíxel por interpolación parabólica). Aguanta mejor el desenfoque que un umbral, porque una
 * barra fina borrosa igual deja su par de bordes aunque no llegue a ponerse negra.
 */
export let EDGE_REL = 0.12;
export function edgeRuns(lum) {
  const n = lum.length;
  if (n < 4) return [n];
  const d = new Float32Array(n - 1), a = new Float32Array(n - 1);
  let gmin = 255, gmax = 0;
  for (let i = 0; i < n; i++) { const v = lum[i]; if (v < gmin) gmin = v; if (v > gmax) gmax = v; }
  for (let i = 0; i < n - 1; i++) { d[i] = lum[i + 1] - lum[i]; a[i] = Math.abs(d[i]); }
  const { mx } = slidingMinMax(a, Math.max(8, Math.round(n / 14)));
  // piso de ruido: el gradiente típico de las zonas lisas (percentil 30)
  const sorted = Float32Array.from(a).sort();
  const minAbs = Math.max(4, (gmax - gmin) * 0.06, sorted[Math.floor(sorted.length * 0.3)] * 3);
  const edges = []; // [posición, signo, fuerza]
  for (let i = 1; i < n - 2; i++) {
    const v = a[i];
    if (!(v >= a[i - 1] && v > a[i + 1]) || v < minAbs || v < mx[i] * EDGE_REL) continue;
    const l = a[i - 1], r = a[i + 1], den = l - 2 * v + r;
    const off = den < 0 ? Math.max(-0.5, Math.min(0.5, 0.5 * (l - r) / den)) : 0;
    const pos = i + 0.5 + off, sg = d[i] < 0 ? -1 : 1;
    const last = edges[edges.length - 1];
    if (last && last[1] === sg) { if (v > last[2]) { last[0] = pos; last[2] = v; } continue; }
    edges.push([pos, sg, v]);
  }
  const runs = [];
  if (edges.length && edges[0][1] > 0) runs.push(0); // arranca oscuro
  let start = 0;
  for (const e of edges) { runs.push(e[0] - start); start = e[0]; }
  runs.push(n - start);
  return runs;
}

function smooth(lum) {
  const n = lum.length, o = new Float32Array(n);
  for (let i = 0; i < n; i++) o[i] = ((lum[i - 1] ?? lum[i]) + 2 * lum[i] + (lum[i + 1] ?? lum[i])) / 4;
  return o;
}

/** Umbrales a probar para una línea: adaptativos (dos tamaños de ventana) y globales */
function thresholds(lum) {
  const n = lum.length;
  const sorted = Float32Array.from(lum).sort();
  const lo = sorted[Math.floor(n * 0.04)], hi = sorted[Math.floor(n * 0.96)];
  const range = hi - lo;
  if (range < 20) return [];
  const gmid = (lo + hi) / 2;
  const out = [];
  // mínimo y máximo locales sobre la línea suavizada (el ruido no los estira)
  const minC = Math.max(16, range * 0.3);
  for (const [src, half] of [[lum, Math.max(6, Math.round(n / 28))], [smooth(smooth(lum)), Math.max(6, Math.round(n / 28))], [lum, Math.max(10, Math.round(n / 12))]]) {
    const { mn, mx } = slidingMinMax(src, half);
    const t = new Float32Array(n);
    for (let i = 0; i < n; i++) t[i] = mx[i] - mn[i] >= minC ? (mn[i] + mx[i]) / 2 : gmid;
    out.push(t);
  }
  const mm = (sorted[0] + sorted[n - 1]) / 2;
  for (const v of [gmid, mm, gmid - 0.08 * range, gmid + 0.08 * range, gmid - 0.16 * range, gmid + 0.16 * range]) out.push(new Float32Array(n).fill(v));
  return out;
}

/**
 * Lee un código de una fila de luminancias (array de números 0–255).
 * Devuelve {text, format} o null.
 */
export function decodeRow(lum) {
  const rows = [lum, smooth(lum)];
  for (const row of rows) {
    for (const t of thresholds(row)) {
      const r = decodeRuns(toRuns(row, t));
      if (r) return r;
    }
    const r = decodeRuns(edgeRuns(row));
    if (r) return r;
  }
  return null;
}

// ---------- Imagen completa ----------

/** RGBA (ImageData) → escala de grises */
export function toGray(img) {
  const { data, width, height } = img;
  if (data.length === width * height) return data; // ya está en grises
  const g = new Uint8Array(width * height);
  for (let i = 0, j = 0; j < g.length; i += 4, j++) g[j] = (data[i] * 77 + data[i + 1] * 150 + data[i + 2] * 29) >> 8;
  return g;
}

/** Posiciones de las líneas a analizar: del centro hacia afuera */
function linePositions(size, count) {
  const out = [], c = (size - 1) / 2;
  const step = (size * 0.8) / count;
  for (let k = 0; k < count; k++) {
    const off = Math.ceil(k / 2) * step * (k % 2 ? -1 : 1);
    const p = Math.round(c + off);
    if (p >= 2 && p < size - 2) out.push(p);
  }
  return out;
}

/**
 * Lee un código de una imagen ({data, width, height}: ImageData RGBA o grises de 1 byte por píxel).
 * Analiza `lines` líneas horizontales y, con `rotate`, otras tantas verticales (código girado 90°).
 * Devuelve {text, format, votes} (votes = cuántas líneas leyeron lo mismo) o null.
 */
export function decodeImage(img, { lines = 14, rotate = true } = {}) {
  const { width: w, height: h } = img;
  const g = toGray(img);
  const votes = new Map();
  let best = null;
  const take = r => {
    if (!r) return false;
    const v = (votes.get(r.text) || 0) + 1;
    votes.set(r.text, v);
    if (!best || v > best.votes) best = { ...r, votes: v };
    return v >= 2;
  };
  // Cada línea es el promedio de 5 filas (o columnas) vecinas: baja el ruido sin borrar las barras
  const row = new Float32Array(w);
  for (const y of linePositions(h, lines)) {
    for (let x = 0; x < w; x++) row[x] = (g[(y - 2) * w + x] + g[(y - 1) * w + x] + g[y * w + x] + g[(y + 1) * w + x] + g[(y + 2) * w + x]) / 5;
    if (take(decodeRow(row))) return best;
  }
  if (rotate) {
    const col = new Float32Array(h);
    for (const x of linePositions(w, lines)) {
      for (let y = 0; y < h; y++) { const o = y * w + x; col[y] = (g[o - 2] + g[o - 1] + g[o] + g[o + 1] + g[o + 2]) / 5; }
      if (take(decodeRow(col))) return best;
    }
  }
  return best;
}

/**
 * Exige N lecturas iguales seguidas antes de aceptar (evita errores de una sola lectura).
 * push(texto|null) → devuelve el texto cuando se confirma; un código distinto reinicia la cuenta.
 * Los cuadros sin lectura no cortan la racha, salvo que pase más de `windowMs`.
 */
export function createConfirmer({ needed = 2, windowMs = 1500, now = () => Date.now() } = {}) {
  let last = null, count = 0, at = 0;
  return {
    push(text) {
      const t = now();
      if (!text) { if (t - at > windowMs) { last = null; count = 0; } return null; }
      if (text === last && t - at <= windowMs) count++;
      else { last = text; count = 1; }
      at = t;
      if (count >= needed) { last = null; count = 0; return text; }
      return null;
    },
    reset() { last = null; count = 0; },
  };
}
