// =====================================================================
// pin.js — Verificador local del PIN (para entrar SIN internet).
// PBKDF2-SHA256 con sal aleatoria por usuario, en dos rondas de 100.000 (200.000 iteraciones):
// "pbkdf2x2-sha256$100000$<sal base64>$<hash base64>". Es el MISMO formato que calcula la nube
// (server/src/devices.js → localVerifier), que no acepta más de 100.000 iteraciones por llamada.
// Solo lo tienen cajeros y vendedores sin permisos sensibles: dueño, encargado y quien tenga permisos
// sensibles entran validando el PIN en la nube (sus equipos no guardan ningún verificador).
// El verificador viejo (sha256 de "jeano-gestion:<id>:<pin>", hasta jg-v25) se acepta una vez y se cambia
// por el nuevo en el primer ingreso correcto.
// =====================================================================
import { pinHash } from './logic.js';

export const LOCAL_ITER = 100000;
const PREFIX = 'pbkdf2x2-sha256';
const enc = new TextEncoder();

function b64(bytes) { let s = ''; for (const b of bytes) s += String.fromCharCode(b); return btoa(s); }
function unb64(str) { const bin = atob(str); const out = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i); return out; }

async function pbkdf2(keyBytes, salt, iterations) {
  const key = await crypto.subtle.importKey('raw', keyBytes, 'PBKDF2', false, ['deriveBits']);
  return new Uint8Array(await crypto.subtle.deriveBits({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations }, key, 256));
}
async function hash2(pin, salt, iterations) { return pbkdf2(await pbkdf2(enc.encode(String(pin)), salt, iterations), salt, iterations); }

function same(a, b) {
  if (a.length !== b.length) return false;
  let d = 0;
  for (let i = 0; i < a.length; i++) d |= a[i] ^ b[i];
  return d === 0;
}

/** Verificador nuevo del PIN (tarda ~100-300 ms según el equipo) */
export async function localVerifier(pin) {
  const salt = crypto.getRandomValues(new Uint8Array(16));
  return `${PREFIX}$${LOCAL_ITER}$${b64(salt)}$${b64(await hash2(pin, salt, LOCAL_ITER))}`;
}

export function isLocalVerifier(v) { return typeof v === 'string' && v.startsWith(PREFIX + '$') && v.split('$').length === 4; }

/**
 * ¿El PIN es el del usuario según lo guardado en este equipo? Devuelve {ok, legacy}: legacy = coincidió con el
 * verificador viejo (sha256) y conviene cambiarlo por el nuevo.
 */
export async function checkLocalPin(user, pin) {
  if (!user) return { ok: false };
  if (isLocalVerifier(user.pin_local)) {
    const [, it, salt, h] = user.pin_local.split('$');
    const n = Number(it);
    if (!Number.isInteger(n) || n < 1 || n > LOCAL_ITER) return { ok: false };
    return { ok: same(await hash2(pin, unb64(salt), n), unb64(h)) };
  }
  if (typeof user.pin_hash === 'string' && /^[0-9a-f]{64}$/.test(user.pin_hash)) {
    return { ok: user.pin_hash === pinHash(user.id, pin), legacy: true };
  }
  return { ok: false };
}

/** ¿Este equipo tiene con qué verificar el PIN del usuario sin internet? */
export function hasLocalPin(user) { return !!user && (isLocalVerifier(user.pin_local) || (typeof user.pin_hash === 'string' && /^[0-9a-f]{64}$/.test(user.pin_hash))); }
