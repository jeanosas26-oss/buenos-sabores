// =====================================================================
// comercial.js — Lógica pura de VENTAS "como SGI": tarjetas con recargo y cuotas, pagos mixtos, promociones,
// comprobante (FC/NC/ND, letra), presupuestos y pedidos, punto de pedido, vencimientos y etiquetas (EAN-13 en SVG).
// Sin DOM ni IndexedDB: se prueba con node --test (tests/comercial.test.mjs).
// Todas las cuentas de plata se hacen en CENTAVOS ENTEROS.
// =====================================================================
import {
  round2, round3, computeSale, calcPayment, cbteTipo, cbteLetra, fmtMoney, fmtQty, fmtDate, norm, toISODate,
} from './logic.js';

export const toC = x => Math.round(round2(x) * 100);
export const fromC = c => round2(Math.round(Number(c) || 0) / 100);

/** Porcentaje (hasta 3 decimales) de un importe en centavos, redondeado al centavo (mitad hacia arriba) */
export function pctC(cents, pct) {
  const milli = Math.round((Number(pct) || 0) * 1000);
  const n = Math.round(cents) * milli;
  const s = n < 0 ? -1 : 1;
  return s * Math.floor((Math.abs(n) * 2 + 100000) / 200000);
}

/** Reparte `amountC` centavos entre pesos `weights` (centavos) por mayor resto: la suma da exacto. */
export function prorateC(weights, amountC) {
  const W = weights.reduce((a, w) => a + Math.max(0, w), 0);
  if (amountC <= 0 || W <= 0) return weights.map(() => 0);
  const raw = weights.map(w => (Math.max(0, w) * amountC) / W);
  const fl = raw.map(Math.floor);
  let rest = amountC - fl.reduce((a, b) => a + b, 0);
  const order = raw.map((r, i) => [r - fl[i], i]).sort((a, b) => b[0] - a[0] || a[1] - b[1]);
  for (let k = 0; k < order.length && rest > 0; k++, rest--) fl[order[k][1]]++;
  return fl;
}

// ---------- Tarjetas y medios de pago ----------

/** Tarjetas que trae SGI Libra (se precargan con recargo 0 %: el dueño pone el % de cada una en Ajustes) */
export const DEFAULT_CARDS = [
  ['CABAL', 'credito'], ['CABAL DEBITO', 'debito'], ['CMR FALABELLA', 'credito'], ['CONFINA', 'credito'],
  ['CREDENCIAL', 'credito'], ['DEBITO', 'debito'], ['DINERS', 'credito'], ['MAESTRO', 'debito'], ['MASTERCARD', 'credito'],
  ['MONTEMAR', 'credito'], ['NARANJA', 'credito'], ['NATIVA', 'credito'], ['PROVENCRED', 'credito'], ['VISA', 'credito'],
  ['VISA ELECTRON', 'debito'],
].map(([name, kind]) => ({
  id: 'card-' + norm(name).replace(/[^a-z0-9]+/g, '-'), name, kind, surcharge_pct: 0,
  max_installments: kind === 'debito' ? 1 : 12, plans: [], active: 1,
}));

/** Medios fijos (code = method que se guarda en sales.payments). El dueño los puede renombrar o desactivar. */
export const BASE_METHODS = [
  { code: 'efectivo', name: 'Contado (efectivo)', kind: 'efectivo', affects_cash: 1 },
  { code: 'tarjeta', name: 'Tarjeta', kind: 'tarjeta', affects_cash: 0 },
  { code: 'mercadopago', name: 'Mercado Pago', kind: 'mercadopago', affects_cash: 0 },
  { code: 'qr', name: 'QR', kind: 'qr', affects_cash: 0 },
  { code: 'transferencia', name: 'Transferencia', kind: 'transferencia', affects_cash: 0 },
  { code: 'cuenta_corriente', name: 'Cta. Cte.', kind: 'cuenta_corriente', affects_cash: 0 },
];
/** Medio propio que tiene SGI (convenio) */
export const DEFAULT_CUSTOM_METHODS = [{ code: 'cocacola', name: 'Coca Cola', kind: 'otro', affects_cash: 0 }];
/** Códigos reservados (los usan las ventas viejas y los informes) */
export const RESERVED_CODES = ['efectivo', 'tarjeta', 'debito', 'credito', 'mercadopago', 'qr', 'transferencia', 'cuenta_corriente', 'cheque', 'otro'];

/** Código para un medio nuevo a partir del nombre ("Coca Cola" → "cocacola") */
export function methodCode(name, existing = []) {
  let base = norm(name).replace(/[^a-z0-9]+/g, '').slice(0, 24) || 'medio';
  if (RESERVED_CODES.includes(base)) base = 'pm' + base;
  let c = base, i = 2;
  while (existing.includes(c)) c = base + i++;
  return c;
}

/**
 * Lista de medios para cobrar: los fijos (con nombre/estado del dueño si los cambió) y los propios activos.
 * pms: registros de payment_methods. withCheque: si existe la cartera de cheques.
 */
export function payMethodList(pms = [], { withCheque = false } = {}) {
  const byCode = new Map(pms.filter(p => p && !p.deleted).map(p => [p.code, p]));
  const out = [];
  for (const b of BASE_METHODS) {
    const o = byCode.get(b.code);
    if (o && o.active === 0 && b.code !== 'efectivo') continue;
    out.push({ ...b, name: (o && o.name) || b.name, builtin: true });
  }
  if (withCheque) out.push({ code: 'cheque', name: 'Cheque', kind: 'otro', affects_cash: 0, builtin: true });
  for (const p of pms) {
    if (!p || p.deleted || p.active === 0 || BASE_METHODS.some(b => b.code === p.code) || !p.code) continue;
    out.push({ code: p.code, name: p.name || p.code, kind: p.kind || 'otro', affects_cash: p.affects_cash ? 1 : 0, builtin: false });
  }
  return out;
}

/** Tarjetas activas ordenadas por nombre */
export function activeCards(cards = []) {
  return cards.filter(c => c && !c.deleted && c.active !== 0).sort((a, b) => String(a.name).localeCompare(String(b.name), 'es'));
}

/** % de recargo de una tarjeta para esas cuotas: el del plan de esas cuotas si existe; si no, el general */
export function cardPct(card, installments = 1) {
  if (!card) return 0;
  const n = Math.max(1, Math.round(Number(installments) || 1));
  const plan = (Array.isArray(card.plans) ? card.plans : []).find(p => Number(p.installments) === n);
  if (plan && Number.isFinite(Number(plan.surcharge_pct))) return round3(Number(plan.surcharge_pct));
  return round3(Number(card.surcharge_pct) || 0);
}

/** Cuotas que se pueden elegir con una tarjeta (1 … máximo; débito = 1) */
export function cardInstallments(card) {
  if (!card || card.kind === 'debito') return [1];
  const max = Math.max(1, Math.min(99, Math.round(Number(card.max_installments) || 1)));
  const fromPlans = (Array.isArray(card.plans) ? card.plans : []).map(p => Number(p.installments)).filter(n => n >= 1 && n <= 99);
  return [...new Set([...Array.from({ length: max }, (_, i) => i + 1), ...fromPlans])].sort((a, b) => a - b);
}

/**
 * Cuenta de un pago con tarjeta: sobre `base` (lo que se paga con la tarjeta del total de la venta) se suma el recargo.
 * → {base, surcharge_pct, surcharge, amount (base + recargo), installments, installment_amount}
 * La cuota se redondea al centavo; `last_installment` ajusta la diferencia para que las cuotas sumen exacto.
 */
export function cardCharge(base, pct = 0, installments = 1) {
  const b = toC(base);
  const n = Math.max(1, Math.round(Number(installments) || 1));
  const s = pctC(b, pct);
  const total = b + s;
  const cuota = Math.round(total / n);
  return {
    base: fromC(b), surcharge_pct: round3(Number(pct) || 0), surcharge: fromC(s), amount: fromC(total), installments: n,
    installment_amount: fromC(cuota), last_installment: fromC(total - cuota * (n - 1)),
  };
}

/** Recargo inverso: ¿qué base da `amount` con ese %? (para "el cliente paga $X con tarjeta") */
export function cardBaseFor(amount, pct = 0) {
  const a = toC(amount);
  let b = Math.round(a / (1 + (Number(pct) || 0) / 100));
  // Ajuste fino para que base + recargo(base) = amount, si se puede
  for (const d of [0, -1, 1, -2, 2]) if (b + d >= 0 && b + d + pctC(b + d, pct) === a) return fromC(b + d);
  return fromC(b);
}

const DETAIL_KEYS = ['card_type_id', 'pm_code', 'cheque', 'cheque_id'];
const isDetailed = p => p && (DETAIL_KEYS.some(k => p[k]) || Number(p.surcharge_pct) > 0 || Number(p.installments) > 1);

/**
 * Cobro "como SGI": pagos mixtos (tarjetas con recargo y cuotas + Mercado Pago + QR + efectivo + resto).
 * baseTotal = total de la venta SIN recargo. payments: [{method, amount (base que se paga con ese medio; en efectivo:
 * con cuánto paga), card_type_id, card_name, installments, surcharge_pct, pm_code, cheque}].
 * Solo el efectivo da vuelto. El recargo de cada tarjeta SUBE el total.
 * → {base, surcharge, total, paid, cash, nonCash, missing, change, ok, error, applied}
 *   applied: lo que se guarda en sales.payments; Σ amount = total (con recargo), exacto al centavo.
 * Sin tarjetas con recargo ni medios propios da exactamente lo mismo que calcPayment (ventas de siempre).
 */
export function calcPaymentsSGI(baseTotal, payments = []) {
  const list0 = (payments || []).filter(Boolean);
  if (!list0.some(isDetailed)) {
    const r = calcPayment(baseTotal, list0);
    return { ...r, base: round2(baseTotal), surcharge: 0 };
  }
  const T = toC(baseTotal);
  const list = list0.map(p => ({ ...p, baseC: toC(p.amount) })).filter(p => p.baseC > 0);
  const cashC = list.filter(p => p.method === 'efectivo').reduce((a, p) => a + p.baseC, 0);
  const nonCash = list.filter(p => p.method !== 'efectivo');
  const nonCashC = nonCash.reduce((a, p) => a + p.baseC, 0);
  const res = { base: fromC(T), surcharge: 0, total: fromC(T), paid: fromC(cashC + nonCashC), cash: fromC(cashC), nonCash: fromC(nonCashC), missing: 0, change: 0, ok: false, error: '', applied: [] };
  if (nonCashC > T) { res.error = 'Los pagos que no son en efectivo superan el total.'; return res; }
  if (cashC + nonCashC < T) { res.missing = fromC(T - cashC - nonCashC); res.error = `Faltan ${fmtMoney(res.missing)}`; return res; }
  const changeC = cashC + nonCashC - T;
  let surC = 0;
  const applied = [];
  // Medios no efectivo: cada tarjeta queda en su propio renglón (dos tarjetas distintas no se juntan)
  const plain = new Map();
  for (const p of nonCash) {
    if (!isDetailed(p)) { plain.set(p.method, (plain.get(p.method) || 0) + p.baseC); continue; }
    const pct = Number(p.surcharge_pct) || 0;
    const ch = cardCharge(fromC(p.baseC), pct, p.installments || 1);
    surC += toC(ch.surcharge);
    const row = { method: p.method, amount: ch.amount };
    if (p.card_type_id) Object.assign(row, { card_type_id: p.card_type_id, card_name: p.card_name || '' });
    if (p.card_type_id || pct || Number(p.installments) > 1) Object.assign(row, { installments: ch.installments, installment_amount: ch.installment_amount, surcharge_pct: ch.surcharge_pct, surcharge: ch.surcharge, base: ch.base });
    if (p.pm_code) row.pm_code = p.pm_code;
    if (p.cheque) row.cheque = p.cheque;
    if (p.cheque_id) row.cheque_id = p.cheque_id;
    applied.push(row);
  }
  for (const [method, c] of plain) applied.push({ method, amount: fromC(c) });
  if (cashC - changeC > 0) applied.unshift({ method: 'efectivo', amount: fromC(cashC - changeC), tendered: fromC(cashC) });
  res.surcharge = fromC(surC);
  res.total = fromC(T + surC);
  res.paid = fromC(cashC + nonCashC + surC);
  res.change = fromC(changeC);
  res.applied = applied;
  res.ok = true;
  return res;
}

// ---------- Total de la venta con promociones, descuento general y recargo ----------

/**
 * Como computeSale (logic.js) pero además con:
 * - promociones por renglón: items[i].promo_discount (pesos, ya calculado por applyPromotions);
 * - descuento general (pesos) prorrateado sobre lo que queda después de las promos;
 * - recargo de tarjeta (pesos) prorrateado sobre lo que queda después de los descuentos (sube el total y el IVA).
 * Cada renglón guarda discount (promo + general), promo_discount, surcharge y subtotal = bruto − discount + surcharge.
 * Garantía: Σ subtotal = total = bruto − promos − descuento + recargo; net + iva = total (al centavo).
 * Sin promos ni recargo devuelve exactamente lo de computeSale.
 */
export function computeSaleSGI(items, { discount = 0, surcharge = 0 } = {}, discriminaIva = true) {
  const hasPromo = items.some(it => toC(it.promo_discount) > 0);
  const surIn = Math.max(0, toC(surcharge));
  if (!hasPromo && !surIn) {
    const c = computeSale(items.map(stripPromo), discount, discriminaIva);
    return { ...c, promo: 0, general_discount: c.discount, surcharge: 0, base: c.total };
  }
  const grossC = items.map(it => toC(round2(round3(it.qty) * round2(it.unit_price))));
  const promoC = items.map((it, i) => Math.min(grossC[i], Math.max(0, toC(it.promo_discount))));
  const after = grossC.map((g, i) => g - promoC[i]);
  const afterSum = after.reduce((a, b) => a + b, 0);
  const discC = Math.min(Math.max(0, toC(discount)), afterSum);
  const dParts = prorateC(after, discC);
  const baseC = after.map((a, i) => a - dParts[i]);
  const sParts = prorateC(baseC.some(b => b > 0) ? baseC : grossC, surIn);
  let total = 0, net = 0, iva = 0;
  const byRate = {};
  const out = items.map((it, i) => {
    const subC = baseC[i] + sParts[i];
    const rate = Number(it.iva_rate ?? 21);
    const effRate = discriminaIva ? rate : 0;
    const netC = effRate ? Math.round(subC / (1 + effRate / 100)) : subC;
    const line = {
      ...stripPromo(it), qty: round3(it.qty), unit_price: round2(it.unit_price), iva_rate: rate,
      discount: fromC(promoC[i] + dParts[i]), subtotal: fromC(subC),
    };
    if (promoC[i]) { line.promo_discount = fromC(promoC[i]); if (it.promo_name) line.promo_name = it.promo_name; if (it.promo_id) line.promo_id = it.promo_id; }
    if (sParts[i]) line.surcharge = fromC(sParts[i]);
    total += subC; net += netC; iva += subC - netC;
    const k = String(effRate);
    byRate[k] = byRate[k] || { net: 0, iva: 0, total: 0 };
    byRate[k].net = round2(byRate[k].net + netC / 100);
    byRate[k].iva = round2(byRate[k].iva + (subC - netC) / 100);
    byRate[k].total = round2(byRate[k].total + subC / 100);
    return line;
  });
  return {
    items: out, gross: fromC(grossC.reduce((a, b) => a + b, 0)),
    promo: fromC(promoC.reduce((a, b) => a + b, 0)), general_discount: fromC(discC),
    discount: fromC(promoC.reduce((a, b) => a + b, 0) + discC),
    surcharge: fromC(surIn), base: fromC(total - surIn),
    total: fromC(total), net: fromC(net), iva: fromC(iva), byRate,
  };
}
function stripPromo(it) {
  const { promo_discount, promo_name, promo_id, surcharge, ...rest } = it;
  return rest;
}

// ---------- Promociones ----------

export const PROMO_KINDS = {
  nxm: 'Lleva N, paga M (2x1, 3x2)',
  pct: '% de descuento',
  precio_cantidad: 'Precio por cantidad (3 por $ X)',
  combo: 'Combo (varios productos a un precio)',
};

/** ¿La promo está vigente hoy en esta sucursal? from/to: "AAAA-MM-DD" (inclusive), vacíos = sin límite */
export function promoActive(p, { now = Date.now(), branchId = null } = {}) {
  if (!p || p.deleted || p.active === 0) return false;
  const today = toISODate(now);
  const day = v => (typeof v === 'number' ? toISODate(v) : String(v || '').slice(0, 10));
  if (p.from && day(p.from) > today) return false;
  if (p.to && day(p.to) < today) return false;
  const br = Array.isArray(p.branch_ids) ? p.branch_ids.filter(Boolean) : [];
  if (br.length && branchId && !br.includes(branchId)) return false;
  return true;
}

/** ¿El producto entra en la promo? (lista de productos, o rubro / subrubro) */
export function promoCovers(p, product) {
  if (!product) return false;
  const ids = Array.isArray(p.product_ids) ? p.product_ids.filter(Boolean) : [];
  if (ids.length) return ids.includes(product.id);
  if (!p.category) return false;
  if (norm(product.category) !== norm(p.category)) return false;
  if (p.subcategory && norm(product.subcategory) !== norm(p.subcategory)) return false;
  return true;
}

/** Texto corto de la promo para el ticket y la lista: "2x1", "15 % off", "3 por $ 5.000", "Combo $ 9.000" */
export function promoLabel(p) {
  const q = p.params || {};
  if (p.kind === 'nxm') return `${q.n || '?'}x${q.m || '?'}`;
  if (p.kind === 'pct') return `${fmtQty(q.pct || 0)} % off${Number(q.min_qty) > 1 ? ` llevando ${fmtQty(q.min_qty)}` : ''}`;
  if (p.kind === 'precio_cantidad') return `${fmtQty(q.qty || 0)} por ${fmtMoney(q.price || 0)}`;
  if (p.kind === 'combo') return `Combo ${fmtMoney(q.price || 0)}`;
  return p.kind || '';
}

/** Valida una promo antes de guardarla. Devuelve el texto del error o '' */
export function promoError(p) {
  if (!String(p.name || '').trim()) return 'Escribí el nombre de la promoción.';
  if (!PROMO_KINDS[p.kind]) return 'Elegí el tipo de promoción.';
  const q = p.params || {};
  const ids = Array.isArray(p.product_ids) ? p.product_ids.filter(Boolean) : [];
  if (p.kind !== 'combo' && !ids.length && !p.category) return 'Elegí los productos o el rubro de la promoción.';
  if (p.kind === 'nxm' && !(Number.isInteger(+q.n) && Number.isInteger(+q.m) && +q.n >= 2 && +q.m >= 1 && +q.m < +q.n)) return 'En “lleva N paga M”, N y M son enteros y M menor que N (ej. 2x1, 3x2).';
  if (p.kind === 'pct' && !(+q.pct > 0 && +q.pct <= 100)) return 'El porcentaje va de 0 a 100.';
  if (p.kind === 'precio_cantidad' && !(Number.isInteger(+q.qty) && +q.qty >= 2 && +q.price > 0)) return 'Poné la cantidad (2 o más) y el precio por esa cantidad.';
  if (p.kind === 'combo') {
    const its = Array.isArray(q.items) ? q.items.filter(x => x && x.product_id && +x.qty > 0) : [];
    if (its.length < 1 || (its.length === 1 && +its[0].qty < 2)) return 'El combo lleva al menos dos productos (o dos unidades).';
    if (!(+q.price > 0)) return 'Poné el precio del combo.';
  }
  if (p.from && p.to && String(p.from) > String(p.to)) return 'La fecha “desde” es posterior a “hasta”.';
  return '';
}

/**
 * Aplica las promociones vigentes al carrito. Cada renglón recibe como mucho UNA promoción (nunca dos veces la
 * misma ni dos distintas sobre el mismo renglón): se elige primero la que más descuenta y así sucesivamente.
 * cart: [{product_id, qty, unit_price, unit}] ; products: Map/función id → producto.
 * → {lines: [{promo_discount, promo_name, promo_id} | null por renglón], applied: [{promo_id, name, label, amount}], total}
 */
export function applyPromotions(cart, promos = [], { now = Date.now(), branchId = null, productOf = () => null } = {}) {
  const lines = cart.map(() => null);
  const applied = [];
  const live = promos.filter(p => promoActive(p, { now, branchId }) && !promoError(p));
  if (!live.length || !cart.length) return { lines, applied, total: 0 };
  const used = cart.map(it => !it.product_id || !(Number(it.qty) > 0) || it.no_promo);
  const lineGrossC = cart.map(it => toC(round2(round3(it.qty) * round2(it.unit_price))));
  const done = new Set();
  for (;;) {
    let best = null;
    for (const p of live) {
      if (done.has(p.id)) continue;
      const cand = evalPromo(p, cart, used, productOf, lineGrossC);
      if (cand && cand.cents > 0 && (!best || cand.cents > best.cents)) best = { p, ...cand };
    }
    if (!best) break;
    done.add(best.p.id);
    // Reparto entre los renglones que usó (nunca más que el bruto de cada renglón)
    const w = best.lines.map(i => lineGrossC[i]);
    const parts = prorateC(w, Math.min(best.cents, w.reduce((a, b) => a + b, 0)));
    best.lines.forEach((i, k) => { used[i] = true; if (parts[k] > 0) lines[i] = { promo_discount: fromC(parts[k]), promo_name: best.p.name, promo_id: best.p.id }; });
    applied.push({ promo_id: best.p.id, name: best.p.name, label: promoLabel(best.p), amount: fromC(parts.reduce((a, b) => a + b, 0)) });
  }
  return { lines, applied, total: fromC(applied.reduce((a, x) => a + toC(x.amount), 0)) };
}

/** Descuento (centavos) que daría una promo sobre los renglones libres → {cents, lines} */
function evalPromo(p, cart, used, productOf, lineGrossC) {
  const q = p.params || {};
  const free = cart.map((it, i) => (!used[i] ? i : -1)).filter(i => i >= 0);
  if (p.kind === 'combo') {
    const req = (q.items || []).filter(x => x && x.product_id && +x.qty > 0);
    const need = new Map();
    for (const r of req) need.set(r.product_id, (need.get(r.product_id) || 0) + Number(r.qty));
    let sets = Infinity;
    const linesOf = new Map();
    for (const [pid, n] of need) {
      // Por unidad cuenta unidades enteras; por kilo cuenta los kg (ej. combo con 0,5 kg de queso)
      const ls = free.filter(i => cart[i].product_id === pid);
      const units = ls.reduce((a, i) => a + (cart[i].unit === 'kg' ? round3(cart[i].qty) : Math.floor(round3(cart[i].qty))), 0);
      sets = Math.min(sets, Math.floor(units / n + 1e-6));
      linesOf.set(pid, ls);
    }
    if (!(sets >= 1) || !Number.isFinite(sets)) return null;
    let normalC = 0;
    for (const [pid, n] of need) {
      const ls = linesOf.get(pid);
      const price = Math.min(...ls.map(i => toC(cart[i].unit_price)));
      normalC += Math.round(price * n * sets);
    }
    const cents = normalC - toC(q.price) * sets;
    return cents > 0 ? { cents, lines: [...linesOf.values()].flat() } : null;
  }
  const scope = free.filter(i => promoCovers(p, productOf(cart[i].product_id)));
  if (!scope.length) return null;
  if (p.kind === 'pct') {
    const byP = groupBy(scope, i => cart[i].product_id);
    let cents = 0; const ls = [];
    for (const idx of byP.values()) {
      const qty = idx.reduce((a, i) => a + round3(cart[i].qty), 0);
      if (Number(q.min_qty) > 0 && qty + 1e-9 < Number(q.min_qty)) continue;
      for (const i of idx) { cents += pctC(lineGrossC[i], q.pct); ls.push(i); }
    }
    return cents > 0 ? { cents, lines: ls } : null;
  }
  // nxm y precio_cantidad: por unidades enteras (los productos por kilo no entran)
  const unitsScope = scope.filter(i => cart[i].unit !== 'kg');
  if (!unitsScope.length) return null;
  const groups = q.mix ? [unitsScope] : [...groupBy(unitsScope, i => cart[i].product_id).values()];
  let cents = 0; const ls = [];
  for (const idx of groups) {
    // Unidades con su precio, de mayor a menor
    const units = [];
    for (const i of idx) for (let k = 0; k < Math.floor(round3(cart[i].qty)); k++) units.push(toC(cart[i].unit_price));
    units.sort((a, b) => b - a);
    let c = 0;
    if (p.kind === 'nxm') {
      const n = Number(q.n), m = Number(q.m);
      const sets = Math.floor(units.length / n);
      // En cada grupo de N, las (N − M) más baratas van sin cargo
      for (let s = 0; s < sets; s++) { const g = units.slice(s * n, s * n + n); for (let k = m; k < n; k++) c += g[k]; }
    } else {
      const n = Number(q.qty), pr = toC(q.price);
      const sets = Math.floor(units.length / n);
      for (let s = 0; s < sets; s++) { const sum = units.slice(s * n, s * n + n).reduce((a, b) => a + b, 0); if (sum > pr) c += sum - pr; }
    }
    if (c > 0) { cents += c; ls.push(...idx); }
  }
  return cents > 0 ? { cents, lines: ls } : null;
}
function groupBy(list, key) {
  const m = new Map();
  for (const x of list) { const k = key(x); if (!m.has(k)) m.set(k, []); m.get(k).push(x); }
  return m;
}

// ---------- Comprobante (como SGI) ----------

export const DOC_TYPES = { FC: 'Factura', NC: 'Nota de crédito', ND: 'Nota de débito' };
/** Nota de débito de ARCA asociada al tipo de factura: A=2, B=7, C=12 */
export function ndTipo(tipo) { return { 1: 2, 6: 7, 11: 12 }[tipo] || null; }

/**
 * Letra del comprobante: con factura electrónica, la de ARCA (A/B/C según IVA del comercio y del cliente);
 * sin factura, "X" (comprobante interno, no fiscal).
 */
export function docLetter(emisorCond, clienteCond, fiscal) {
  return fiscal ? cbteLetra(cbteTipo(emisorCond, clienteCond || 'CF')) : 'X';
}

/** Título del comprobante de una venta: "Factura B", "Nota de débito X", "Comprobante interno X" */
export function docTitle(sale) {
  const t = sale.doc_type || 'FC';
  const d = sale.doc || {};
  const fiscal = d.kind === 'factura' && d.status === 'autorizado';
  const L = fiscal ? cbteLetra(d.cbte_tipo) || sale.letter : (sale.letter || 'X');
  if (!fiscal && t === 'FC') return `Comprobante interno ${L}`;
  return `${DOC_TYPES[t] || 'Factura'} ${L}`;
}

/** Venta de una nota de débito: un renglón con el concepto (recargo, interés, diferencia de precio…) */
export function debitNoteItems(concept, amount, iva_rate = 21) {
  return [{ product_id: null, name: String(concept || 'Nota de débito').trim() || 'Nota de débito', qty: 1, unit_price: round2(amount), iva_rate: Number(iva_rate) }];
}

// ---------- Presupuestos y pedidos ----------

export const QUOTE_STATUS = { abierto: 'Vigente', vencido: 'Vencido', convertido: 'Vendido', anulado: 'Anulado' };
export const ORDER_STATUS = { pendiente: 'Pendiente', preparado: 'Preparado', convertido: 'Entregado / vendido', anulado: 'Anulado' };
export const SUPPLIER_ORDER_STATUS = { borrador: 'Borrador', enviado: 'Enviado', recibido: 'Recibido (compra cargada)', anulado: 'Anulado' };

/** Estado a mostrar: un presupuesto abierto con valid_until pasado se ve "vencido" */
export function quoteStatus(q, now = Date.now()) {
  const s = q.status || 'abierto';
  if (s === 'abierto' && q.valid_until && String(q.valid_until).slice(0, 10) < toISODate(now)) return 'vencido';
  return s;
}

/**
 * Renglones para convertir un presupuesto / pedido en venta.
 * Si está vigente se respetan sus precios; vencido (o `current`), se toman los precios de hoy.
 * Los productos borrados o inactivos quedan afuera (missing).
 */
export function cartFromDoc(doc, productOf, { current = false } = {}) {
  const cart = [], missing = [], changed = [];
  for (const it of doc.items || []) {
    const p = it.product_id ? productOf(it.product_id) : null;
    if (it.product_id && (!p || p.deleted || p.active === 0)) { missing.push(it.name); continue; }
    let price = round2(it.unit_price);
    if (p && current && round2(p.price) !== price) { changed.push({ name: it.name, old: price, price: round2(p.price) }); price = round2(p.price); }
    cart.push({ product_id: it.product_id || null, name: p ? p.name : it.name, qty: round3(it.qty), unit_price: price, iva_rate: Number(it.iva_rate ?? (p ? p.iva_rate : 21) ?? 21), unit: (p && p.unit) || it.unit || 'u' });
  }
  return { cart, missing, changed };
}

/** Texto de presupuesto / pedido para WhatsApp */
export function docText(kind, d, settings = {}, customerName = '') {
  const title = { quote: 'PRESUPUESTO', order: 'PEDIDO', supplier_order: 'PEDIDO A PROVEEDOR' }[kind] || 'DOCUMENTO';
  const L = [`*${settings.business_name || 'Comercio'}*`, `${title} N° ${d.number}`, fmtDate(d.created_at)];
  if (customerName) L.push((kind === 'supplier_order' ? 'Proveedor: ' : 'Cliente: ') + customerName);
  if (d.valid_until) L.push(`Válido hasta: ${fmtDate(new Date(String(d.valid_until).slice(0, 10) + 'T12:00').getTime())}`);
  if (d.delivery_date || d.expected_date) L.push(`Entrega: ${fmtDate(new Date(String(d.delivery_date || d.expected_date).slice(0, 10) + 'T12:00').getTime())}`);
  L.push('');
  for (const it of d.items || []) {
    if (kind === 'supplier_order') L.push(`${fmtQty(it.qty)} x ${it.name}${it.code ? ` (${it.code})` : ''}`);
    else L.push(`${fmtQty(it.qty)} x ${it.name} — ${fmtMoney(it.subtotal ?? round2(it.qty * it.unit_price))}`);
  }
  if (kind !== 'supplier_order') {
    if (Number(d.discount) > 0) L.push(`Descuento: -${fmtMoney(d.discount)}`);
    L.push(`*TOTAL: ${fmtMoney(d.total)}*`);
  }
  if (d.notes) { L.push(''); L.push(d.notes); }
  return L.join('\n');
}

// ---------- Punto de pedido / faltantes ----------

/** Mínimo de un producto en una sucursal: stock_mins[branch] si existe; si no, stock_min (igual en todas) */
export function minOf(p, branchId) {
  const m = p && p.stock_mins && typeof p.stock_mins === 'object' ? p.stock_mins[branchId] : undefined;
  if (m !== undefined && m !== null && m !== '' && Number.isFinite(Number(m))) return round3(Number(m));
  return round3(Number(p && p.stock_min) || 0);
}

/**
 * Faltantes: productos activos con stock ≤ punto de pedido en la sucursal. Cantidad sugerida a pedir:
 * reorder_qty si está cargada; si no, lo que falta para llegar al doble del mínimo (al menos 1).
 * → [{product, stock, min, missing, suggested}] ordenado por lo que falta
 */
export function reorderList(products, { stockOf, branchId, supplierId = '', category = '' } = {}) {
  const out = [];
  for (const p of products) {
    if (!p || p.deleted || p.active === 0) continue;
    if (supplierId && p.supplier_id !== supplierId) continue;
    if (category && norm(p.category) !== norm(category)) continue;
    const min = minOf(p, branchId);
    if (!(min > 0)) continue;
    const st = round3(Number(stockOf(p, branchId)) || 0);
    if (st > min) continue;
    const rq = Number(p.reorder_qty) || 0;
    let sug = rq > 0 ? rq : round3(min * 2 - st);
    if (p.unit !== 'kg') sug = Math.max(1, Math.ceil(sug));
    out.push({ product: p, stock: st, min, missing: round3(min - st), suggested: round3(sug) });
  }
  return out.sort((a, b) => b.missing - a.missing || String(a.product.name).localeCompare(String(b.product.name), 'es'));
}

// ---------- Rubros y subrubros ----------

/**
 * Rubros a crear a partir de products.category (texto) sin perder ninguno: uno por nombre distinto (sin
 * distinguir mayúsculas ni acentos) que todavía no exista. Los productos siguen con su category de texto.
 */
export function categoriesToCreate(products, categories = []) {
  const have = new Set(categories.filter(c => c && !c.deleted).map(c => norm(c.name)));
  const out = new Map();
  for (const p of products) {
    if (!p || p.deleted) continue;
    const n = String(p.category || '').trim();
    if (!n || have.has(norm(n)) || out.has(norm(n))) continue;
    out.set(norm(n), n);
  }
  return [...out.values()].sort((a, b) => a.localeCompare(b, 'es'));
}
/** Id fijo para un rubro migrado (dos equipos que migran a la vez crean el mismo registro) */
export function categoryId(name) { return 'cat-' + norm(name).replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 60); }

// ---------- Vencimientos ----------

/** Días que faltan para "AAAA-MM-DD" (negativo = vencido) */
export function daysTo(iso, now = Date.now()) {
  if (!iso) return null;
  const [y, m, d] = String(iso).slice(0, 10).split('-').map(Number);
  if (!y || !m || !d) return null;
  const t = new Date(y, m - 1, d).getTime();
  const n = new Date(now); const t0 = new Date(n.getFullYear(), n.getMonth(), n.getDate()).getTime();
  return Math.round((t - t0) / 86400000);
}

/**
 * Lotes por vencer en los próximos `days` días (y los ya vencidos) de una sucursal (null = todas).
 * Incluye el vencimiento cargado en el producto (products.expires_at) cuando ese producto no tiene lotes.
 * → [{lot, product, branch_id, expires_at, days, qty, expired}]
 */
export function expiringLots(lots = [], products = [], { days = 30, now = Date.now(), branchId = null, productOf = null } = {}) {
  const get = productOf || (id => products.find(p => p.id === id));
  const out = [];
  const withLots = new Set();
  for (const l of lots) {
    if (!l || l.deleted || !l.expires_at) continue;
    withLots.add(l.product_id);
    if (branchId && l.branch_id && l.branch_id !== branchId) continue;
    if (!(Number(l.qty) > 0)) continue;
    const p = get(l.product_id);
    if (!p || p.deleted) continue;
    const dd = daysTo(l.expires_at, now);
    if (dd === null || dd > days) continue;
    out.push({ lot: l, product: p, branch_id: l.branch_id || null, expires_at: String(l.expires_at).slice(0, 10), days: dd, qty: round3(l.qty), expired: dd < 0 });
  }
  for (const p of products) {
    if (!p || p.deleted || p.active === 0 || !p.expires_at || withLots.has(p.id)) continue;
    const dd = daysTo(p.expires_at, now);
    if (dd === null || dd > days) continue;
    out.push({ lot: null, product: p, branch_id: null, expires_at: String(p.expires_at).slice(0, 10), days: dd, qty: null, expired: dd < 0 });
  }
  return out.sort((a, b) => a.days - b.days || String(a.product.name).localeCompare(String(b.product.name), 'es'));
}

// ---------- Etiquetas y carteles de góndola ----------

const EAN_L = ['0001101', '0011001', '0010011', '0111101', '0100011', '0110001', '0101111', '0111011', '0110111', '0001011'];
const EAN_G = ['0100111', '0110011', '0011011', '0100001', '0011101', '0111001', '0000101', '0010001', '0001001', '0010111'];
const EAN_R = ['1110010', '1100110', '1101100', '1000010', '1011100', '1001110', '1010000', '1000100', '1001000', '1110100'];
const EAN_PAR = ['LLLLLL', 'LLGLGG', 'LLGGLG', 'LLGGGL', 'LGLLGG', 'LGGLLG', 'LGGGLL', 'LGLGLG', 'LGLGGL', 'LGGLGL'];

/** Dígito verificador EAN/UPC de los dígitos sin el verificador */
export function eanCheck(digits) {
  const d = String(digits).split('').map(Number).reverse();
  const s = d.reduce((a, x, i) => a + x * (i % 2 === 0 ? 3 : 1), 0);
  return (10 - (s % 10)) % 10;
}
/** Normaliza un código a EAN-13 / EAN-8 válido (UPC-A de 12 → EAN-13 con 0 adelante). null si no es EAN. */
export function normalizeEan(code) {
  let c = String(code || '').trim();
  if (!/^\d+$/.test(c)) return null;
  if (c.length === 12) c = '0' + c;
  if (c.length === 13 || c.length === 8) return eanCheck(c.slice(0, -1)) === Number(c.slice(-1)) ? c : null;
  return null;
}
/** Módulos (1 = barra) de un EAN-13 o EAN-8 ya validado */
export function eanModules(code) {
  const c = normalizeEan(code);
  if (!c) return null;
  if (c.length === 8) {
    return '101' + c.slice(0, 4).split('').map(x => EAN_L[x]).join('') + '01010' + c.slice(4).split('').map(x => EAN_R[x]).join('') + '101';
  }
  const par = EAN_PAR[c[0]];
  const left = c.slice(1, 7).split('').map((x, i) => (par[i] === 'L' ? EAN_L : EAN_G)[x]).join('');
  const right = c.slice(7).split('').map(x => EAN_R[x]).join('');
  return '101' + left + '01010' + right + '101';
}

/** SVG propio del código de barras (EAN-13/EAN-8) con los números abajo. '' si el código no es EAN. */
export function eanSvg(code, { height = 50, module = 2 } = {}) {
  const c = normalizeEan(code);
  const mods = c && eanModules(c);
  if (!mods) return '';
  const quiet = 9 * module;
  const w = mods.length * module + quiet * 2;
  const guard = new Set();
  const g = c.length === 13 ? [0, 1, 2, 45, 46, 47, 48, 49, 92, 93, 94] : [0, 1, 2, 31, 32, 33, 34, 35, 64, 65, 66];
  g.forEach(i => guard.add(i));
  let bars = '';
  for (let i = 0; i < mods.length;) {
    if (mods[i] !== '1') { i++; continue; }
    let j = i; while (j < mods.length && mods[j] === '1') j++;
    const h = guard.has(i) ? height + 6 : height;
    bars += `<rect x="${quiet + i * module}" y="0" width="${(j - i) * module}" height="${h}"/>`;
    i = j;
  }
  const fs = Math.round(module * 6.5);
  const ty = height + fs + 2;
  let txt;
  if (c.length === 13) {
    txt = `<text x="${quiet - 2}" y="${ty}" text-anchor="end">${c[0]}</text>`
      + `<text x="${quiet + 24 * module}" y="${ty}" text-anchor="middle" letter-spacing="${module}">${c.slice(1, 7)}</text>`
      + `<text x="${quiet + 71 * module}" y="${ty}" text-anchor="middle" letter-spacing="${module}">${c.slice(7)}</text>`;
  } else {
    txt = `<text x="${quiet + 17 * module}" y="${ty}" text-anchor="middle">${c.slice(0, 4)}</text><text x="${quiet + 50 * module}" y="${ty}" text-anchor="middle">${c.slice(4)}</text>`;
  }
  return `<svg xmlns="http://www.w3.org/2000/svg" class="ean" viewBox="0 0 ${w} ${ty + 2}" role="img" aria-label="Código de barras ${c}"><g fill="#000">${bars}</g><g font-family="monospace" font-size="${fs}" fill="#000">${txt}</g></svg>`;
}

/**
 * Contenido del envase leído del nombre ("Yerba 1 kg", "Arroz 500 g", "Coca 2,25 L", "Shampoo 400 ml")
 * → {qty en kg o litros, unit: 'kg'|'l'} o null. Si hay "x 6" / "6 x" se multiplica.
 */
export function contentFromName(name) {
  const s = String(name || '').toLowerCase().replace(/(\d),(\d)/g, '$1.$2');
  const re = /(\d+(?:\.\d+)?)\s*(kgs?|kilos?|grs?|gramos|g|lts?|litros?|l|ml|cc|cm3)(?![a-z])/g;
  let m, last = null;
  while ((m = re.exec(s))) last = m;
  if (!last) return null;
  const v = Number(last[1]);
  if (!(v > 0)) return null;
  const u = last[2];
  let qty, unit;
  if (/^(kg|kgs|kilo|kilos)$/.test(u)) { qty = v; unit = 'kg'; }
  else if (/^(g|gr|grs|gramos)$/.test(u)) { qty = v / 1000; unit = 'kg'; }
  else if (/^(ml|cc|cm3)$/.test(u)) { qty = v / 1000; unit = 'l'; }
  else { qty = v; unit = 'l'; }
  const pack = s.match(/(?:x\s*(\d{1,2})\s*(?:u|un|unid)?\s*$)|(?:^|\s)(\d{1,2})\s*x\s/);
  const n = pack ? Number(pack[1] || pack[2]) : 1;
  if (n > 1 && n < 100) qty *= n;
  return qty > 0 ? { qty: round3(qty) || qty, unit } : null;
}

/** Precio por kilo o litro para el cartel (ley de góndola). Productos por kilo: su precio. null si no se sabe. */
export function unitPriceInfo(p) {
  if (!p) return null;
  if (p.unit === 'kg') return { price: round2(p.price), unit: 'kg' };
  const c = contentFromName(p.name);
  if (!c || !(Number(p.price) > 0)) return null;
  return { price: round2(Number(p.price) / c.qty), unit: c.unit };
}

/** Tamaños de etiqueta en A4 (columnas × filas por hoja) */
export const LABEL_SIZES = {
  chica: { name: 'Chica (precio de góndola) · 4 × 10', cols: 4, rows: 10 },
  mediana: { name: 'Mediana · 3 × 7', cols: 3, rows: 7 },
  grande: { name: 'Cartel grande · 2 × 4', cols: 2, rows: 4 },
  oferta: { name: 'Cartel de oferta · 1 × 2', cols: 1, rows: 2 },
};
/** Reparte las etiquetas en hojas */
export function labelPages(items, size = 'mediana') {
  const s = LABEL_SIZES[size] || LABEL_SIZES.mediana;
  const per = s.cols * s.rows;
  const pages = [];
  for (let i = 0; i < items.length; i += per) pages.push(items.slice(i, i + per));
  return pages;
}
