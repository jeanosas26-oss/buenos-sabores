// =====================================================================
// cuentas-ops.js — Operaciones de cuentas corrientes: proveedores (alta,
// pagos, saldo inicial de SGI), cobros de clientes y fotos de productos.
// Cada operación guarda el movimiento, el saldo y la caja en UNA transacción.
// =====================================================================
import * as db from './db.js';
import { ctx, openSession, mainBranchId } from './ops.js';
import { round2, uuid, can, validCuit, norm, dayStart, branchOf } from './logic.js';
import { toCents, fromCents, parseSgiBalance, SUPPLIER_METHODS, CUSTOMER_METHODS, isActive } from './cuentas.js';
import { newCheque } from './tesoreria-ops.js';

const manager = () => ctx.user && can(ctx.user, 'compras');
const branchId = () => ctx.branchId || mainBranchId();
const addCents = (a, b) => fromCents(toCents(a || 0) + toCents(b || 0));

// ---------- Proveedores ----------

/** Crea o actualiza un proveedor (no toca el saldo: el saldo cambia solo con movimientos) */
export async function saveSupplier(s) {
  if (!manager()) throw new Error('Solo el dueño o el encargado pueden modificar proveedores.');
  const name = String(s.name || '').trim();
  if (!name) throw new Error('Escribí el nombre del proveedor.');
  const cuit = String(s.cuit || '').replace(/\D/g, '');
  if (cuit && !validCuit(cuit)) throw new Error('El CUIT no es válido (revisá los 11 números).');
  if (s.iva_condition && !['RI', 'MT', 'EX', 'CF'].includes(s.iva_condition)) throw new Error('Elegí la condición de IVA.');
  const dup = db.all('suppliers').find(x => x.id !== s.id && ((cuit && String(x.cuit || '').replace(/\D/g, '') === cuit)));
  if (dup) throw new Error(`Ese CUIT ya lo tiene “${dup.name}”.`);
  const t = v => String(v || '').trim();
  const rec = {
    name, legal_name: t(s.legal_name), cuit, iva_condition: s.iva_condition || null, address: t(s.address), city: t(s.city), province: t(s.province),
    phone: t(s.phone), email: t(s.email), contact: t(s.contact), cbu: t(s.cbu), notes: String(s.notes || '').trim(), active: s.active === 0 || s.active === false ? 0 : 1,
  };
  if (s.id) rec.id = s.id;
  else rec.balance = 0;
  return db.put('suppliers', rec);
}

/** Productos de un proveedor */
export function supplierProducts(supplierId) {
  return db.all('products').filter(p => p.supplier_id === supplierId).sort((a, b) => String(a.name || '').localeCompare(String(b.name || ''), 'es'));
}

/** Asigna (o saca, con supplierId vacío) el proveedor de varios productos */
export async function assignSupplier(productIds, supplierId) {
  if (!can(ctx.user, 'editar_productos')) throw new Error('Solo el dueño o el encargado pueden cambiar productos.');
  const ops = productIds.filter(id => db.get('products', id)).map(id => ({ coll: 'products', rec: { id, supplier_id: supplierId || '' } }));
  for (let i = 0; i < ops.length; i += 500) await db.putBatch(ops.slice(i, i + 500));
  return ops.length;
}

/**
 * Pago a un proveedor (total o parcial). Si es en efectivo y hay caja abierta en este equipo, sale de la caja
 * (cash_movements "egreso", así resta del arqueo). Devuelve el pago guardado.
 */
export async function paySupplier({ supplier_id, amount, method = 'efectivo', reference = '', notes = '', applies_to = [], fromCash = true, cheque_ids = [] }) {
  if (!manager()) throw new Error('Solo el dueño o el encargado pueden registrar pagos a proveedores.');
  const s = db.get('suppliers', supplier_id);
  if (!s || s.deleted) throw new Error('Proveedor no encontrado.');
  const a = round2(amount);
  if (!(a > 0)) throw new Error('El importe tiene que ser mayor a cero.');
  if (!SUPPLIER_METHODS.some(m => m.id === method)) throw new Error('Elegí el medio de pago.');
  const now = Date.now();
  // Cheques de la cartera entregados en el pago: el importe es lo que suman
  const cheques = method === 'cheque' ? (cheque_ids || []).map(id => db.get('cheques', id)).filter(Boolean) : [];
  if (cheques.some(c => c.deleted || c.status !== 'en_cartera')) throw new Error('Alguno de los cheques ya no está en cartera.');
  if (cheques.length && cheques.reduce((t, c) => t + toCents(c.amount), 0) !== toCents(a)) throw new Error('El importe tiene que ser lo que suman los cheques elegidos.');
  const session = method === 'efectivo' && fromCash ? openSession() : null;
  const pay = {
    id: uuid(), supplier_id, branch_id: branchId(), session_id: session ? session.id : null, created_at: now, user_id: ctx.user.id,
    kind: 'pago', amount: a, method, reference: String(reference || '').trim(), notes: String(notes || '').trim(),
    applies_to: (applies_to || []).filter(Boolean), cash_movement_id: null, cheque_ids: cheques.map(c => c.id),
  };
  const ops = [];
  for (const c of cheques) {
    ops.push({ coll: 'cheques', rec: { id: c.id, status: 'entregado', delivered_to: supplier_id, ref: 'supplier_payment:' + pay.id, status_at: now,
      history: [...(c.history || []), { at: now, status: 'entregado', user_id: ctx.user.id, note: `Pago a ${s.name}` }] } });
  }
  if (session) {
    const mov = {
      id: uuid(), session_id: session.id, branch_id: branchOf(session, mainBranchId()), type: 'egreso', amount: a, method: 'efectivo',
      reason: `Pago a proveedor: ${s.name}${pay.reference ? ` (${pay.reference})` : ''}`, supplier_id, ref_id: pay.id, created_at: now, user_id: ctx.user.id,
    };
    pay.cash_movement_id = mov.id;
    ops.push({ coll: 'cash_movements', rec: mov });
  }
  ops.unshift({ coll: 'supplier_payments', rec: pay });
  ops.push({ coll: 'suppliers', rec: { id: s.id, balance: addCents(s.balance, -a) } });
  await db.putBatch(ops);
  return db.get('supplier_payments', pay.id);
}

/** ¿Ya tiene cargado el saldo inicial? */
export function hasInitialBalance(supplierId) {
  return db.all('supplier_payments').some(p => p.supplier_id === supplierId && p.kind === 'saldo_inicial');
}

/** Proveedores con "Saldo en SGI al …" en las notas que todavía no tienen saldo inicial */
export function pendingSgi() {
  const out = [];
  for (const s of db.all('suppliers')) {
    const sgi = parseSgiBalance(s.notes);
    if (sgi && !hasInitialBalance(s.id)) out.push({ supplier: s, sgi });
  }
  return out;
}

function sgiOps(s, sgi, now) {
  const at = sgi.iso ? dayStart(sgi.iso) : now;
  const rec = {
    id: uuid(), supplier_id: s.id, branch_id: branchId(), session_id: null, created_at: Number.isFinite(at) ? at : now, user_id: ctx.user.id,
    kind: 'saldo_inicial', amount: sgi.amount, method: null, reference: 'SGI', notes: `SGI al ${sgi.date}`, applies_to: [], cash_movement_id: null,
  };
  return [{ coll: 'supplier_payments', rec }, { coll: 'suppliers', rec: { id: s.id, balance: addCents(s.balance, sgi.amount) } }];
}

/** Convierte la nota "Saldo en SGI al …" de UN proveedor en su saldo inicial */
export async function takeSgiBalance(supplierId) {
  if (!manager()) throw new Error('Solo el dueño o el encargado pueden cargar saldos.');
  const s = db.get('suppliers', supplierId);
  const sgi = s && parseSgiBalance(s.notes);
  if (!sgi) throw new Error('Las notas de este proveedor no tienen “Saldo en SGI al …”.');
  if (hasInitialBalance(supplierId)) throw new Error('Este proveedor ya tiene el saldo inicial cargado.');
  await db.putBatch(sgiOps(s, sgi, Date.now()));
  return sgi;
}

/** Lo mismo para todos los que falten. Devuelve {count, total} (total en pesos). */
export async function takeAllSgiBalances(onProgress = () => {}) {
  if (!manager()) throw new Error('Solo el dueño o el encargado pueden cargar saldos.');
  const list = pendingSgi();
  const now = Date.now();
  let total = 0;
  for (let i = 0; i < list.length; i += 200) {
    const ops = [];
    for (const { supplier, sgi } of list.slice(i, i + 200)) { ops.push(...sgiOps(db.get('suppliers', supplier.id), sgi, now)); total += toCents(sgi.amount); }
    await db.putBatch(ops);
    onProgress(Math.min(i + 200, list.length), list.length);
  }
  return { count: list.length, total: fromCents(total) };
}

// ---------- Clientes ----------

/**
 * Cobro de cuenta corriente (total o parcial): baja el saldo del cliente y queda en customer_payments.
 * En efectivo entra a la caja abierta (cash_movements "ingreso"); con otro medio queda un "cobro" (no suma a la caja).
 * seller_id: el vendedor del cliente (o el usuario, si es vendedor): cuenta para su comisión por cobranza.
 */
export async function collectCustomer({ customer_id, amount, method = 'efectivo', reference = '', notes = '', cheques = [] }) {
  if (ctx.user && !can(ctx.user, 'cobrar_cc')) throw new Error('Tu usuario no puede cobrar cuentas corrientes.');
  const c = db.get('customers', customer_id);
  if (!c || c.deleted) throw new Error('Cliente no encontrado.');
  const a = round2(amount);
  if (!(a > 0)) throw new Error('El importe tiene que ser mayor a cero.');
  if (!CUSTOMER_METHODS.some(m => m.id === method)) throw new Error('Elegí el medio de pago.');
  const session = openSession();
  if (method === 'efectivo' && !session) throw new Error('Abrí la caja para cobrar en efectivo.');
  const now = Date.now();
  const seller = c.seller_id || (ctx.user.role === 'vendedor' ? ctx.user.id : null);
  const pay = {
    id: uuid(), customer_id: c.id, branch_id: branchId(), session_id: session ? session.id : null, created_at: now, user_id: ctx.user.id,
    kind: 'pago', amount: a, method, reference: String(reference || '').trim(), notes: String(notes || '').trim(), seller_id: seller, cash_movement_id: null,
  };
  const mov = {
    id: uuid(), session_id: session ? session.id : null, branch_id: session ? branchOf(session, mainBranchId()) : branchId(),
    type: method === 'efectivo' ? 'ingreso' : 'cobro', amount: a, method, reason: `Cobro cuenta corriente: ${c.name}`,
    customer_id: c.id, ref_id: pay.id, created_at: now, user_id: ctx.user.id,
  };
  pay.cash_movement_id = mov.id;
  // Cobro con cheques de terceros: entran a la cartera (el importe es lo que suman)
  const chq = method === 'cheque' ? (cheques || []).map(x => ({ ...newCheque({ ...x, kind: 'tercero' }, { ref: 'customer_payment:' + pay.id, received_from: c.id }), session_id: session ? session.id : null })) : [];
  if (chq.length && chq.reduce((t, x) => t + toCents(x.amount), 0) !== toCents(a)) throw new Error('El importe tiene que ser lo que suman los cheques.');
  pay.cheque_ids = chq.map(x => x.id);
  if (chq.length === 1) mov.cheque_id = chq[0].id;
  await db.putBatch([
    ...chq.map(rec => ({ coll: 'cheques', rec })),
    { coll: 'customer_payments', rec: pay },
    { coll: 'cash_movements', rec: mov },
    { coll: 'customers', rec: { id: c.id, balance: addCents(c.balance, -a) } },
  ]);
  return db.get('customer_payments', pay.id);
}

/** Clientes activos (para elegir en una venta) */
export const activeCustomers = () => db.all('customers').filter(isActive);

/** Búsqueda simple por texto en varios campos */
export const matches = (q, ...fields) => !q || norm(fields.filter(Boolean).join(' ')).includes(q);
