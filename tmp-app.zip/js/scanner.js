// =====================================================================
// scanner.js — Escanear códigos de barras con la cámara del celu o la PC.
//
// - Si el navegador trae BarcodeDetector (Chrome Android, Edge, Chrome Mac…) lo usa.
// - Si no (iPhone/Safari, Firefox, Chrome Linux…), usa el decodificador propio de barcode.js
//   (EAN-13, EAN-8, UPC-A, UPC-E) sobre cuadros del video.
// - En los dos casos exige 2 lecturas iguales seguidas antes de aceptar.
//
// API:
//   canScan()  → true si tiene sentido mostrar el botón de cámara
//   openScanner({ title, hint, multi, onCode }) → Promise<string|null>
//     Sin onCode: devuelve el primer código leído (o tipeado), o null si se cancela.
//     Con onCode(code, api): se llama con cada código; devuelve 'continue' para seguir
//     escaneando con la cámara abierta, o cualquier otra cosa para cerrar (y la promesa
//     devuelve ese código). api.flash(msg, kind) muestra un aviso; api.multi dice si está
//     tildado "Escanear varios seguidos" (opción multi: {label, key}).
// =====================================================================
import { decodeImage, createConfirmer, codeVariants } from './barcode.js';
import { html, raw, icon, esc } from './ui.js';

export { codeVariants };

const NATIVE_FORMATS = ['ean_13', 'ean_8', 'upc_a', 'upc_e', 'code_128'];
const MAX_SIDE = 960;
/** Último motor usado ('native' | 'js') y lecturas aceptadas: para diagnóstico y pruebas */
export const stats = { engine: null, accepted: 0, last: null, beeps: 0, errors: 0 }; // el cuadro se achica a esto antes de decodificar (rápido y alcanza)

/** Hay cámara para pedir (o la página no es https y hay que explicarlo) */
export function canScan() {
  const gum = !!(navigator.mediaDevices && navigator.mediaDevices.getUserMedia);
  return gum || window.isSecureContext === false;
}

/** Botón de cámara para poner dentro de un buscador o al lado de un campo */
export function scanButton(attrs = 'data-scan', label = 'Escanear con la cámara') {
  if (!canScan()) return '';
  return raw(`<button type="button" class="icon-btn scan-btn" ${attrs} aria-label="${esc(label)}" title="${esc(label)}">${icon('camera')}</button>`);
}

/** Forzar el decodificador propio: ?scanner=js en la dirección o localStorage jg-scanner=js */
function forceJs() {
  try { if (new URLSearchParams(location.search).get('scanner') === 'js') return true; } catch (e) { /* sin URL */ }
  try { return localStorage.getItem('jg-scanner') === 'js'; } catch (e) { return false; }
}

let nativeFormats; // cache de getSupportedFormats()
async function nativeDetector() {
  if (forceJs() || typeof window.BarcodeDetector !== 'function') return null;
  try {
    if (!nativeFormats) nativeFormats = await window.BarcodeDetector.getSupportedFormats();
    const formats = NATIVE_FORMATS.filter(f => nativeFormats.includes(f));
    if (!formats.includes('ean_13')) return null;
    return new window.BarcodeDetector({ formats });
  } catch (e) { return null; }
}

// ---------- Sonido y vibración ----------
// Bip como el de un lector de supermercado: onda casi cuadrada de ~2,8 kHz, 100 ms, ataque y
// caída de 4 ms y volumen fijo. El "error" (código que no está cargado) es un doble zumbido grave.
// La configuración (encendido + volumen) es de cada equipo: Ajustes → Sonido del lector.

const SOUND_KEY = 'jg-scan-sound';
export function soundSettings() {
  try {
    const v = JSON.parse(localStorage.getItem(SOUND_KEY) || 'null');
    if (v && typeof v === 'object') return { on: v.on !== false, volume: Math.max(0, Math.min(100, Number(v.volume ?? 80))) };
  } catch (e) { /* sin storage */ }
  return { on: true, volume: 80 };
}
export function setSoundSettings(patch) {
  const v = { ...soundSettings(), ...patch };
  try { localStorage.setItem(SOUND_KEY, JSON.stringify(v)); } catch (e) { /* sin storage */ }
  return v;
}

let audio = null, squareWave = null;
/**
 * Crea/reanuda el AudioContext. En iPhone tiene que pasar durante un toque del usuario:
 * la app lo llama con el primer toque en cualquier lado y al abrir la cámara.
 */
export function unlockAudio() {
  try {
    const AC = window.AudioContext || window.webkitAudioContext;
    if (!AC) return;
    if (!audio) {
      audio = new AC();
      // Cuadrada "redondeada" (armónicos impares 1, 3, 5 y 7): suena como el lector y no lastima
      const n = 8, re = new Float32Array(n), im = new Float32Array(n);
      [1, 3, 5, 7].forEach(k => { im[k] = 1 / k; });
      squareWave = audio.createPeriodicWave(re, im);
      // Un buffer mudo de 1 muestra "destraba" el audio en iOS
      const src = audio.createBufferSource();
      src.buffer = audio.createBuffer(1, 1, 22050);
      src.connect(audio.destination);
      src.start(0);
    }
    if (audio.state === 'suspended') audio.resume().catch(() => {});
  } catch (e) { audio = null; }
}
function prepareAudio() { unlockAudio(); }
/** true cuando el audio ya está destrabado */
export function audioReady() { return !!audio && audio.state === 'running'; }

/** Un tono con ataque y caída cortos y volumen constante */
function tone(freq, start, dur, gainLevel, wave) {
  const o = audio.createOscillator(), g = audio.createGain();
  if (wave === 'square' && squareWave) o.setPeriodicWave(squareWave); else o.type = wave;
  o.frequency.setValueAtTime(freq, start);
  g.gain.setValueAtTime(0, start);
  g.gain.linearRampToValueAtTime(gainLevel, start + 0.004);
  g.gain.setValueAtTime(gainLevel, start + dur - 0.004);
  g.gain.linearRampToValueAtTime(0, start + dur);
  o.connect(g); g.connect(audio.destination);
  o.start(start); o.stop(start + dur + 0.01);
}
function level() {
  const s = soundSettings();
  if (!s.on || !s.volume) return 0;
  return 0.45 * (s.volume / 100);
}
/** Bip de lectura correcta */
export function playBeep() {
  try {
    const g = level();
    if (!audio || !g) return;
    tone(2830, audio.currentTime + 0.005, 0.1, g, 'square');
    stats.beeps++;
  } catch (e) { /* sin sonido */ }
}
/** Doble zumbido grave: código que no está cargado */
export function playError() {
  try {
    const g = level();
    if (!audio || !g) return;
    const t = audio.currentTime + 0.12; // después del bip de lectura
    tone(440, t, 0.12, g * 0.9, 'sawtooth');
    tone(440, t + 0.18, 0.12, g * 0.9, 'sawtooth');
    stats.errors++;
  } catch (e) { /* sin sonido */ }
  try { if (navigator.vibrate) navigator.vibrate([90, 60, 90]); } catch (e) { /* sin vibración */ }
}
const beep = playBeep;
function buzz() { try { if (navigator.vibrate) navigator.vibrate(60); } catch (e) { /* sin vibración */ } }

// ---------- Mensajes de error ----------

function errorInfo(e) {
  if (window.isSecureContext === false) {
    return {
      title: 'La cámara necesita una dirección segura (https)',
      body: html`<p>El navegador solo deja usar la cámara si la app se abre con <b>https://</b> (o en la misma PC con <b>http://localhost</b>).</p>
        <p>Abrí la app desde su dirección publicada (la que empieza con https) y probá de nuevo. Mientras tanto podés <b>escribir el código</b>.</p>`,
    };
  }
  if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
    return { title: 'Este navegador no puede usar la cámara', body: html`<p>Probá con Chrome (Android o PC) o Safari (iPhone) actualizados. Mientras tanto podés <b>escribir el código</b>.</p>` };
  }
  const n = (e && e.name) || '';
  if (n === 'NotAllowedError' || n === 'PermissionDeniedError' || n === 'SecurityError') {
    return {
      title: 'Permití la cámara en el navegador',
      body: html`<p>La app necesita permiso para usar la cámara. Solo la usa mientras está abierta esta ventana.</p>
        <ul class="scan-steps">
          <li><b>Android (Chrome):</b> tocá el candado o el ícono ⓘ al lado de la dirección → <b>Permisos</b> → <b>Cámara</b> → <b>Permitir</b>.</li>
          <li><b>iPhone (Safari):</b> tocá <b>aA</b> en la barra de dirección → <b>Configuración del sitio web</b> → <b>Cámara</b> → <b>Permitir</b>. Si la instalaste en el inicio: <b>Ajustes</b> del iPhone → <b>Safari</b> → <b>Cámara</b> → <b>Permitir</b>.</li>
          <li><b>PC (Chrome o Edge):</b> tocá el ícono de la cámara tachada en la barra de dirección → <b>Permitir siempre</b>.</li>
        </ul>
        <p>Después tocá <b>Probar de nuevo</b>.</p>`,
    };
  }
  if (n === 'NotFoundError' || n === 'DevicesNotFoundError' || n === 'OverconstrainedError') {
    return { title: 'No encontramos ninguna cámara', body: html`<p>Este equipo no tiene cámara o está desconectada. Podés <b>escribir el código</b> o usar el lector USB en el buscador.</p>` };
  }
  if (n === 'NotReadableError' || n === 'TrackStartError' || n === 'AbortError') {
    return { title: 'La cámara está ocupada', body: html`<p>Otra app (o otra pestaña) está usando la cámara. Cerrala y tocá <b>Probar de nuevo</b>.</p>` };
  }
  return { title: 'No se pudo abrir la cámara', body: html`<p>${(e && e.message) || 'Error desconocido.'}</p><p>Tocá <b>Probar de nuevo</b> o <b>escribí el código</b>.</p>` };
}

async function getCamera() {
  if (window.isSecureContext === false || !navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) throw new Error('sin cámara');
  const ideal = { facingMode: { ideal: 'environment' }, width: { ideal: 1280 }, height: { ideal: 720 } };
  try {
    return await navigator.mediaDevices.getUserMedia({ video: ideal, audio: false });
  } catch (e) {
    if (e && e.name === 'OverconstrainedError') return navigator.mediaDevices.getUserMedia({ video: true, audio: false });
    throw e;
  }
}

// ---------- Ventana de escaneo ----------

let current = null; // una sola a la vez

export function openScanner({ title = 'Escanear código', hint = 'Poné el código de barras dentro del recuadro. Mantenelo derecho y quieto, a unos 15 cm.', multi = null, onCode = null } = {}) {
  if (current) current.close(null);
  prepareAudio(); // tiene que ser durante el toque del botón (iPhone)
  return new Promise(resolve => {
    let multiOn = false;
    if (multi) { try { multiOn = localStorage.getItem(multi.key) === '1'; } catch (e) { multiOn = false; } }
    const prevFocus = document.activeElement;
    const wrap = document.createElement('div');
    wrap.className = 'scan-wrap';
    wrap.setAttribute('role', 'dialog');
    wrap.setAttribute('aria-modal', 'true');
    wrap.setAttribute('aria-labelledby', 'scan-title');
    wrap.innerHTML = String(html`
      <header class="scan-head">
        <h2 id="scan-title">${title}</h2>
        <p class="scan-hint">${hint}</p>
      </header>
      <div class="scan-view">
        <video class="scan-video" playsinline muted autoplay></video>
        <div class="scan-frame" aria-hidden="true"><span class="scan-laser"></span></div>
        <div class="scan-state" id="scan-state" aria-live="polite"><p>Abriendo la cámara…</p></div>
        <div class="scan-error hidden" id="scan-error" role="alert"></div>
      </div>
      <footer class="scan-foot">
        <p class="scan-msg" id="scan-msg" role="status" aria-live="polite"></p>
        <form class="scan-type hidden" id="scan-type" novalidate>
          <label for="scan-code">Código de barras</label>
          <div class="scan-type-row">
            <input id="scan-code" inputmode="numeric" autocomplete="off" enterkeyhint="done" placeholder="Ej: 7790036974347">
            <button type="submit" class="btn primary">Usar</button>
          </div>
        </form>
        ${multi ? html`<label class="check scan-multi"><input type="checkbox" id="scan-multi" ${multiOn ? 'checked' : ''}> ${multi.label || 'Escanear varios seguidos'}</label>` : ''}
        <div class="scan-btns">
          <button type="button" class="btn primary hidden" id="scan-retry">Probar de nuevo</button>
          <button type="button" class="btn ghost hidden" id="scan-torch" aria-pressed="false">${raw(icon('flash'))} Linterna</button>
          <button type="button" class="btn ghost" id="scan-typebtn">${raw(icon('keyboard'))} Escribir código</button>
          <button type="button" class="btn primary" id="scan-close">Cancelar</button>
        </div>
      </footer>`);
    document.body.appendChild(wrap);
    document.body.classList.add('scan-open');
    const $ = s => wrap.querySelector(s);
    const video = $('.scan-video');
    const closeBtn = $('#scan-close');
    const multiBox = $('#scan-multi');
    const paintClose = () => { closeBtn.textContent = multiBox && multiBox.checked ? 'Listo' : 'Cancelar'; };
    paintClose();

    let stream = null, track = null, detector = null, closed = false, paused = false, timer = null, torchOn = false;
    // En modo "varios": el código recién leído no se vuelve a sumar mientras siga a la vista;
    // vale de nuevo cuando deja de verse por un momento (o se lee otro)
    let ignore = { code: null, seen: 0 };
    const confirmer = createConfirmer({ needed: 2, windowMs: 1500 });
    const canvas = document.createElement('canvas');
    let g2d = null;

    const api = {
      get multi() { return !!(multiBox && multiBox.checked); },
      flash(msg, kind = 'ok') {
        const m = $('#scan-msg');
        m.textContent = msg;
        m.className = 'scan-msg ' + kind;
        clearTimeout(api._ft);
        api._ft = setTimeout(() => { if (!closed) { m.textContent = ''; m.className = 'scan-msg'; } }, 2600);
      },
    };

    const stop = () => {
      clearTimeout(timer);
      if (stream) stream.getTracks().forEach(t => { try { t.stop(); } catch (e) { /* ya parada */ } });
      stream = null; track = null;
      try { video.srcObject = null; } catch (e) { /* nada */ }
    };
    const close = v => {
      if (closed) return;
      closed = true;
      stop();
      window.removeEventListener('keydown', onKey, true);
      document.removeEventListener('visibilitychange', onVis);
      wrap.remove();
      document.body.classList.remove('scan-open');
      if (current && current.wrap === wrap) current = null;
      if (prevFocus && prevFocus.focus && document.contains(prevFocus)) { try { prevFocus.focus({ preventScroll: true }); } catch (e) { /* nada */ } }
      resolve(v === undefined ? null : v);
    };
    current = { wrap, close };

    const showError = e => {
      stop();
      const info = errorInfo(e);
      $('#scan-state').classList.add('hidden');
      $('.scan-frame').classList.add('hidden');
      const box = $('#scan-error');
      box.classList.remove('hidden');
      box.innerHTML = String(html`<h3>${info.title}</h3>${info.body}`);
      wrap.dataset.state = 'error';
      const canRetry = window.isSecureContext !== false && !!navigator.mediaDevices;
      $('#scan-retry').classList.toggle('hidden', !canRetry);
      $('#scan-torch').classList.add('hidden');
      closeBtn.className = 'btn ghost';
      if (multiBox) multiBox.closest('label').classList.add('hidden');
    };

    const handle = async (code, typed) => {
      code = String(code || '').trim();
      if (!code || closed) return;
      if (!typed) { beep(); buzz(); stats.accepted++; stats.last = code; }
      wrap.classList.add('hit');
      setTimeout(() => wrap.classList.remove('hit'), 350);
      if (!onCode) { close(code); return; }
      paused = true;
      let r;
      try { r = await onCode(code, api); } catch (e) { r = 'continue'; api.flash(e.message || String(e), 'error'); }
      if (closed) return;
      if (r === 'continue') {
        ignore = { code, seen: Date.now() };
        confirmer.reset();
        setTimeout(() => { paused = false; }, 700);
        return;
      }
      close(code);
    };

    // Un cuadro: lo achica, decodifica y pasa por la confirmación
    const frame = async () => {
      let text = null;
      if (detector) {
        try {
          const found = await detector.detect(video);
          const hit = found.find(b => b.rawValue && String(b.rawValue).trim());
          text = hit ? String(hit.rawValue).trim() : null;
        } catch (e) { detector = null; wrap.dataset.engine = stats.engine = 'js'; } // si falla, seguimos con el propio
      }
      if (!detector) {
        const vw = video.videoWidth, vh = video.videoHeight;
        if (!vw || !vh) return null;
        const k = Math.min(1, MAX_SIDE / Math.max(vw, vh));
        const w = Math.round(vw * k), h = Math.round(vh * k);
        if (canvas.width !== w || canvas.height !== h) { canvas.width = w; canvas.height = h; g2d = null; }
        if (!g2d) g2d = canvas.getContext('2d', { willReadFrequently: true });
        g2d.drawImage(video, 0, 0, w, h);
        const r = decodeImage(g2d.getImageData(0, 0, w, h), { lines: 10 });
        // UPC-E es corto y sin guarda del medio: se le pide que lo lean 2 líneas del mismo cuadro
        if (r && (r.format !== 'upc_e' || r.votes >= 2)) text = r.text;
      }
      if (ignore.code) {
        const t = Date.now();
        if (text === ignore.code) { ignore.seen = t; return null; }
        if (text || t - ignore.seen > 1200) ignore = { code: null, seen: 0 };
      }
      return confirmer.push(text);
    };
    const loop = async () => {
      if (closed) return;
      let wait = 120;
      if (!paused && !document.hidden && video.readyState >= 2) {
        const t0 = performance.now();
        let ok = null;
        try { ok = await frame(); } catch (e) { ok = null; }
        if (closed) return;
        // Deja respirar al celu: si un cuadro tarda 80 ms, espera ~100 ms hasta el próximo
        wait = Math.max(40, Math.min(300, (performance.now() - t0) * 1.3));
        if (ok) await handle(ok, false);
      }
      if (!closed) timer = setTimeout(loop, wait);
    };

    const start = async () => {
      $('#scan-error').classList.add('hidden');
      $('#scan-retry').classList.add('hidden');
      closeBtn.className = 'btn primary';
      if (multiBox) multiBox.closest('label').classList.remove('hidden');
      $('.scan-frame').classList.remove('hidden');
      const st = $('#scan-state');
      st.classList.remove('hidden');
      st.innerHTML = '<p>Abriendo la cámara…</p>';
      wrap.dataset.state = 'starting';
      try {
        const [s, det] = await Promise.all([getCamera(), nativeDetector()]);
        if (closed) { s.getTracks().forEach(t => t.stop()); return; }
        stream = s; detector = det;
        wrap.dataset.engine = stats.engine = det ? 'native' : 'js';
        track = stream.getVideoTracks()[0] || null;
        video.srcObject = stream;
        try { await video.play(); } catch (e) { /* autoplay: igual arranca con muted+playsinline */ }
        st.classList.add('hidden');
        wrap.dataset.state = 'scanning';
        // Linterna y enfoque continuo, si la cámara los tiene
        const caps = track && track.getCapabilities ? track.getCapabilities() : {};
        if (caps.torch) $('#scan-torch').classList.remove('hidden');
        if (Array.isArray(caps.focusMode) && caps.focusMode.includes('continuous')) track.applyConstraints({ advanced: [{ focusMode: 'continuous' }] }).catch(() => {});
        clearTimeout(timer);
        loop();
      } catch (e) {
        if (!closed) showError(e);
      }
    };

    // ---------- Botones y teclado ----------
    closeBtn.onclick = () => close(null);
    $('#scan-retry').onclick = () => start();
    if (multiBox) multiBox.onchange = () => { paintClose(); try { localStorage.setItem(multi.key, multiBox.checked ? '1' : '0'); } catch (e) { /* sin storage */ } };
    $('#scan-torch').onclick = async () => {
      if (!track) return;
      try {
        await track.applyConstraints({ advanced: [{ torch: !torchOn }] });
        torchOn = !torchOn;
        $('#scan-torch').setAttribute('aria-pressed', String(torchOn));
      } catch (e) { api.flash('No se pudo prender la linterna.', 'error'); }
    };
    $('#scan-typebtn').onclick = () => {
      const f = $('#scan-type');
      f.classList.toggle('hidden');
      if (!f.classList.contains('hidden')) $('#scan-code').focus();
    };
    $('#scan-type').addEventListener('submit', e => {
      e.preventDefault();
      const inp = $('#scan-code');
      const v = inp.value.trim();
      if (!v) { inp.focus(); return; }
      inp.value = '';
      handle(v, true);
    });
    const onKey = e => {
      if (closed) return;
      if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); close(null); return; }
      if (e.key === 'Tab') { // el foco queda dentro de esta ventana (y no lo toma otra de abajo)
        e.stopPropagation();
        const f = [...wrap.querySelectorAll('button, input')].filter(x => !x.disabled && x.offsetParent !== null);
        if (!f.length) return;
        const i = f.indexOf(document.activeElement);
        if (e.shiftKey && i <= 0) { e.preventDefault(); f[f.length - 1].focus(); }
        else if (!e.shiftKey && (i === f.length - 1 || i < 0)) { e.preventDefault(); f[0].focus(); }
      }
    };
    window.addEventListener('keydown', onKey, true);
    // Si la app pasa a segundo plano se libera la cámara; al volver se vuelve a abrir
    const onVis = () => {
      if (closed) return;
      if (document.hidden) { if (stream) { stop(); wrap.dataset.state = 'paused'; } }
      else if (wrap.dataset.state === 'paused') start();
    };
    document.addEventListener('visibilitychange', onVis);
    setTimeout(() => { if (!closed) closeBtn.focus(); }, 30);
    start();
  });
}
