// =====================================================================
// ui.js — Ayudantes de interfaz: plantillas seguras, avisos, ventanas.
// =====================================================================

/** Escapa texto para insertarlo en HTML */
export function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

class Safe { constructor(s) { this.s = s; } toString() { return this.s; } }
/** Marca un texto como HTML ya seguro */
export const raw = s => new Safe(String(s));

function part(v) {
  if (v instanceof Safe) return v.s;
  if (Array.isArray(v)) return v.map(part).join('');
  if (v === null || v === undefined || v === false) return '';
  return esc(v);
}
/** Plantilla que escapa todo lo interpolado salvo raw()/html`` anidados */
export function html(strings, ...vals) {
  let out = '';
  strings.forEach((s, i) => { out += s + (i < vals.length ? part(vals[i]) : ''); });
  return new Safe(out);
}

export const $ = (sel, root = document) => root.querySelector(sel);
export const $$ = (sel, root = document) => [...root.querySelectorAll(sel)];

/** Delegación de eventos: on(root, 'click', '[data-act]', (e, el) => ...) */
export function on(root, type, sel, fn) {
  const h = e => {
    const el = e.target.closest(sel);
    if (el && root.contains(el)) fn(e, el);
  };
  root.addEventListener(type, h);
  return () => root.removeEventListener(type, h);
}

// ---------- Avisos ----------

export function toast(msg, type = 'ok', ms = 2600) {
  let box = $('#toasts');
  if (!box) {
    box = document.createElement('div');
    box.id = 'toasts';
    box.setAttribute('role', 'status');
    box.setAttribute('aria-live', 'polite');
    document.body.appendChild(box);
  }
  const t = document.createElement('div');
  t.className = 'toast toast-' + type;
  t.textContent = msg;
  box.appendChild(t);
  // Como mucho 2 avisos a la vez: el más viejo se va
  while (box.children.length > 2) box.firstElementChild.remove();
  setTimeout(() => { t.classList.add('out'); setTimeout(() => t.remove(), 300); }, ms);
}

// ---------- Ventanas (modales) ----------

let openCount = 0;

/**
 * Abre una ventana. body: html`` o string seguro.
 * actions: [{label, value, kind:'primary'|'danger'|'ghost', id}]
 * onMount(el, close) permite enganchar eventos; close(valor) cierra y resuelve la promesa.
 * Devuelve Promise con el valor (null si se cierra con Escape/×).
 */
export function modal({ title, body = '', actions = [], onMount, size = '', dismissable = true }) {
  return new Promise(resolve => {
    const prevFocus = document.activeElement;
    const wrap = document.createElement('div');
    wrap.className = 'modal-wrap';
    const tid = 'mt' + Math.random().toString(36).slice(2);
    wrap.innerHTML = String(html`
      <div class="modal ${size}" role="dialog" aria-modal="true" aria-labelledby="${tid}">
        <header class="modal-head">
          <h2 id="${tid}">${title}</h2>
          ${dismissable ? html`<button type="button" class="icon-btn" data-close aria-label="Cerrar">${raw(icon('x'))}</button>` : ''}
        </header>
        <div class="modal-body">${body}</div>
        ${actions.length ? html`<footer class="modal-foot">${actions.map((a, i) => html`
          <button type="button" class="btn ${a.kind || 'ghost'}" data-i="${i}" ${a.id ? raw(`id="${esc(a.id)}"`) : ''}>${a.label}</button>`)}</footer>` : ''}
      </div>`);
    document.body.appendChild(wrap);
    openCount++;
    document.body.classList.add('modal-open');
    let done = false;
    const close = v => {
      if (done) return;
      done = true;
      wrap.remove();
      openCount--;
      if (!openCount) document.body.classList.remove('modal-open');
      document.removeEventListener('keydown', onKey, true);
      if (prevFocus && prevFocus.focus) { try { prevFocus.focus({ preventScroll: true }); } catch (e) { /* elemento ya no existe */ } }
      resolve(v === undefined ? null : v);
    };
    const onKey = e => {
      if (wrap !== $$('.modal-wrap').pop()) return; // solo la ventana de arriba
      if (e.key === 'Escape' && dismissable) { e.preventDefault(); close(null); }
      if (e.key === 'Tab') { // mantener el foco dentro de la ventana
        const f = $$('button, [href], input, select, textarea, [tabindex]:not([tabindex="-1"])', wrap).filter(x => !x.disabled && x.offsetParent !== null);
        if (!f.length) return;
        const first = f[0], last = f[f.length - 1];
        if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
        else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
      }
    };
    document.addEventListener('keydown', onKey, true);
    wrap.addEventListener('click', e => {
      if (e.target === wrap && dismissable) close(null);
      if (e.target.closest('[data-close]')) close(null);
      const b = e.target.closest('.modal-foot [data-i]');
      if (b) {
        const a = actions[Number(b.dataset.i)];
        if (a.onClick) { a.onClick(close, wrap); } else close(a.value);
      }
    });
    const m = $('.modal', wrap);
    if (onMount) onMount(m, close);
    // Foco inicial: primer campo, o el botón principal. Se pone en el momento (así lo que se tipea o escanea
    // enseguida va al campo correcto) y se reintenta a los 30 ms solo si el foco todavía no está en la ventana:
    // antes, ese segundo intento le robaba el foco al campo donde ya se estaba escribiendo (el "900" del costo
    // terminaba pegado al nombre del producto).
    const initialFocus = () => {
      if (done || wrap.contains(document.activeElement)) return;
      const f = $('[autofocus]', m) || $('input:not([type=hidden]):not([readonly]), select, textarea', m) || $('.modal-foot .primary', m) || $('[data-close]', m);
      if (f) f.focus();
    };
    initialFocus();
    setTimeout(initialFocus, 30);
  });
}

/** Pregunta Sí/No */
export async function confirm(msg, { title = 'Confirmar', ok = 'Sí', cancel = 'Cancelar', danger = false } = {}) {
  const v = await modal({
    title,
    body: html`<p class="lead">${msg}</p>`,
    actions: [{ label: cancel, value: false, kind: 'ghost' }, { label: ok, value: true, kind: danger ? 'danger' : 'primary' }],
  });
  return v === true;
}

/** Aviso simple con un botón */
export async function alertBox(msg, { title = 'Aviso', kind = 'info' } = {}) {
  await modal({ title, body: html`<div class="notice notice-${kind}">${msg}</div>`, actions: [{ label: 'Entendido', value: true, kind: 'primary' }] });
}

/** Lee los campos de un formulario como objeto (por name) */
export function formData(form) {
  const o = {};
  for (const el of form.elements) {
    if (!el.name) continue;
    if (el.type === 'checkbox') o[el.name] = el.checked;
    else if (el.type === 'radio') { if (el.checked) o[el.name] = el.value; }
    else o[el.name] = el.value;
  }
  return o;
}

/** Marca un campo con error y lo enfoca */
export function fieldError(input, msg) {
  if (!input) { toast(msg, 'error'); return; }
  input.setAttribute('aria-invalid', 'true');
  let m = input.parentElement.querySelector('.field-err');
  if (!m) { m = document.createElement('div'); m.className = 'field-err'; input.parentElement.appendChild(m); }
  m.textContent = msg;
  const id = input.id || (input.id = 'f' + Math.random().toString(36).slice(2));
  m.id = id + '-err';
  input.setAttribute('aria-describedby', m.id);
  input.focus();
  input.addEventListener('input', () => { input.removeAttribute('aria-invalid'); m.remove(); }, { once: true });
}

/** Descarga un archivo generado en el navegador */
export function download(filename, content, type = 'application/json') {
  const blob = content instanceof Blob ? content : new Blob([content], { type });
  const a = document.createElement('a');
  a.href = URL.createObjectURL(blob);
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 1000);
}

/** Pide un archivo al usuario */
export function pickFile(accept) {
  return new Promise(resolve => {
    const i = document.createElement('input');
    i.type = 'file';
    i.accept = accept;
    i.style.display = 'none';
    i.addEventListener('change', () => { resolve(i.files[0] || null); i.remove(); });
    document.body.appendChild(i);
    i.click();
  });
}

/** Carga un script externo una sola vez (p. ej. xlsx desde cdnjs) */
const scripts = {};
export function loadScript(src) {
  if (!scripts[src]) {
    scripts[src] = new Promise((resolve, reject) => {
      const s = document.createElement('script');
      s.src = src;
      s.crossOrigin = 'anonymous';
      s.onload = resolve;
      s.onerror = () => { delete scripts[src]; s.remove(); reject(new Error('No se pudo cargar un componente (¿hay internet?).')); };
      document.head.appendChild(s);
    });
  }
  return scripts[src];
}

// ---------- Íconos (SVG en línea, trazo simple) ----------

const ICONS = {
  cart: '<circle cx="9" cy="20" r="1.5"/><circle cx="18" cy="20" r="1.5"/><path d="M2 3h3l2.6 12.2a1 1 0 0 0 1 .8h9.7a1 1 0 0 0 1-.8L21 7H6"/>',
  cash: '<rect x="2" y="6" width="20" height="12" rx="2"/><circle cx="12" cy="12" r="3"/><path d="M6 12h.01M18 12h.01"/>',
  box: '<path d="M21 8 12 3 3 8v8l9 5 9-5z"/><path d="m3 8 9 5 9-5M12 13v8"/>',
  truck: '<path d="M1 4h13v12H1zM14 8h4l4 4v4h-8"/><circle cx="6" cy="18" r="2"/><circle cx="18" cy="18" r="2"/>',
  users: '<circle cx="9" cy="8" r="4"/><path d="M1 21v-1a7 7 0 0 1 14 0v1"/><path d="M16 4a4 4 0 0 1 0 8M23 21v-1a6 6 0 0 0-4-5.6"/>',
  receipt: '<path d="M5 2h14v20l-3-2-2 2-2-2-2 2-2-2-3 2z"/><path d="M9 7h6M9 11h6M9 15h4"/>',
  chart: '<path d="M3 3v18h18"/><path d="M7 15v3M12 10v8M17 6v12"/>',
  gear: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/>',
  menu: '<path d="M3 6h18M3 12h18M3 18h18"/>',
  x: '<path d="M18 6 6 18M6 6l12 12"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  minus: '<path d="M5 12h14"/>',
  search: '<circle cx="11" cy="11" r="7"/><path d="m21 21-4.3-4.3"/>',
  trash: '<path d="M3 6h18M8 6V4h8v2M6 6l1 15h10l1-15"/>',
  print: '<path d="M6 9V2h12v7"/><rect x="2" y="9" width="20" height="9" rx="2"/><path d="M6 14h12v8H6z"/>',
  whatsapp: '<path d="M3 21l1.7-5A8.5 8.5 0 1 1 8 19.3z"/><path d="M9 9.5c0 3 2.5 5.5 5.5 5.5l1-1.5-2-1-1 1c-1-.4-1.6-1-2-2l1-1-1-2z"/>',
  cloud: '<path d="M7 18a5 5 0 1 1 1-9.9A6 6 0 0 1 19.5 10 4 4 0 0 1 18 18z"/>',
  device: '<rect x="6" y="2" width="12" height="20" rx="2"/><path d="M11 18h2"/>',
  lock: '<rect x="4" y="11" width="16" height="10" rx="2"/><path d="M8 11V7a4 4 0 0 1 8 0v4"/>',
  user: '<circle cx="12" cy="8" r="4"/><path d="M4 21v-1a8 8 0 0 1 16 0v1"/>',
  download: '<path d="M12 3v12M7 10l5 5 5-5M4 21h16"/>',
  upload: '<path d="M12 21V9M7 14l5-5 5 5M4 3h16"/>',
  alert: '<path d="M12 3 2 21h20z"/><path d="M12 10v5M12 18h.01"/>',
  check: '<path d="m5 12 5 5L20 7"/>',
  edit: '<path d="M4 20h4L19 9l-4-4L4 16z"/>',
  more: '<circle cx="5" cy="12" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="19" cy="12" r="1.5"/>',
  tag: '<path d="M3 12V3h9l9 9-9 9z"/><circle cx="7.5" cy="7.5" r="1.5"/>',
  install: '<rect x="5" y="2" width="14" height="20" rx="2"/><path d="M12 7v7M9 11l3 3 3-3"/>',
  scale: '<path d="M12 3v18M5 7h14M5 7l-3 7a3 3 0 0 0 6 0zM19 7l-3 7a3 3 0 0 0 6 0z"/>',
  back: '<path d="M15 18 9 12l6-6"/>',
  camera: '<path d="M3 8a2 2 0 0 1 2-2h2.5l1.5-2h6l1.5 2H19a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><circle cx="12" cy="13" r="3.5"/>',
  flash: '<path d="M13 2 4 14h7l-1 8 9-12h-7z"/>',
  keyboard: '<rect x="2" y="6" width="20" height="12" rx="2"/><path d="M6 10h.01M10 10h.01M14 10h.01M18 10h.01M7 14h10"/>',
  store: '<path d="M3 9 4.5 4h15L21 9"/><path d="M3 9a3 3 0 0 0 6 0 3 3 0 0 0 6 0 3 3 0 0 0 6 0"/><path d="M5 11.5V20h14v-8.5M10 20v-5h4v5"/>',
};
export function icon(name, cls = '') {
  return `<svg class="ico ${cls}" viewBox="0 0 24 24" aria-hidden="true" focusable="false" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${ICONS[name] || ''}</svg>`;
}
export const ic = (n, c) => raw(icon(n, c));

// ---------- Excel (xlsx 0.18.5 desde cdnjs, se carga solo cuando hace falta) ----------

const XLSX_URL = 'https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js';
export async function loadXlsx() {
  await loadScript(XLSX_URL);
  if (!window.XLSX) throw new Error('No se pudo cargar el componente de Excel.');
  return window.XLSX;
}

/**
 * Exporta una tabla (array de filas; la primera es el encabezado) a Excel.
 * Si no hay internet para cargar el componente, baja un CSV que Excel también abre.
 */
export async function exportTable(baseName, sheetName, rows) {
  try {
    const XLSX = await loadXlsx();
    const ws = XLSX.utils.aoa_to_sheet(rows);
    ws['!cols'] = rows[0].map((h, i) => ({ wch: Math.min(50, Math.max(String(h).length, ...rows.slice(1, 200).map(r => String(r[i] ?? '').length)) + 2) }));
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, sheetName.slice(0, 31));
    XLSX.writeFile(wb, baseName + '.xlsx');
  } catch (e) {
    const csv = rows.map(r => r.map(v => {
      const s = typeof v === 'number' ? String(v).replace('.', ',') : String(v ?? '');
      return /[";\n]/.test(s) ? '"' + s.replace(/"/g, '""') + '"' : s;
    }).join(';')).join('\r\n');
    download(baseName + '.csv', '﻿' + csv, 'text/csv;charset=utf-8');
    toast('Sin internet: se descargó en formato CSV (se abre con Excel).', 'warn', 5000);
  }
}
