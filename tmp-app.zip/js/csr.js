// Pedido de certificado para ARCA (CSR PKCS#10) armado en el navegador con Web Crypto.
// Genera una clave RSA 2048 y el pedido firmado con SHA-256, con el sujeto que pide ARCA:
// C=AR, O=<razón social>, CN=<alias>, serialNumber=CUIT <cuit>.

const enc = new TextEncoder();

function len(n) {
  if (n < 0x80) return [n];
  const b = [];
  while (n > 0) { b.unshift(n & 0xff); n >>= 8; }
  return [0x80 | b.length, ...b];
}
function tlv(tag, bytes) { return Uint8Array.from([tag, ...len(bytes.length), ...bytes]); }
function cat(...parts) {
  const out = new Uint8Array(parts.reduce((a, p) => a + p.length, 0));
  let o = 0;
  for (const p of parts) { out.set(p, o); o += p.length; }
  return out;
}
const seq = (...p) => tlv(0x30, cat(...p));
const set = (...p) => tlv(0x31, cat(...p));
function oid(s) {
  const n = s.split('.').map(Number);
  const out = [40 * n[0] + n[1]];
  for (const v of n.slice(2)) {
    const b = [v & 0x7f];
    let x = v >> 7;
    while (x > 0) { b.unshift((x & 0x7f) | 0x80); x >>= 7; }
    out.push(...b);
  }
  return tlv(0x06, Uint8Array.from(out));
}
const utf8 = s => tlv(0x0c, enc.encode(s));
const printable = s => tlv(0x13, enc.encode(s));
const rdn = (o, v) => set(seq(oid(o), v));

function b64(bytes) {
  let s = '';
  for (let i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]);
  return btoa(s);
}
function pem(label, bytes) {
  const body = b64(bytes).replace(/(.{64})/g, '$1\n').replace(/\n$/, '');
  return `-----BEGIN ${label}-----\n${body}\n-----END ${label}-----\n`;
}

/** Limpia el texto para que entre en PrintableString / el alias de ARCA. */
export function cleanAlias(s) {
  return String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^A-Za-z0-9]/g, '').toLowerCase().slice(0, 30);
}

/**
 * @param {{cuit:string, org:string, alias:string}} p
 * @returns {Promise<{keyPem:string, csrPem:string}>}
 */
export async function generateCsr({ cuit, org, alias }, subtle = globalThis.crypto.subtle) {
  const c = String(cuit || '').replace(/\D/g, '');
  if (c.length !== 11) throw new Error('Falta el CUIT (11 números) en Ajustes → Datos del comercio.');
  const o = String(org || '').trim();
  if (!o) throw new Error('Falta la razón social en Ajustes → Datos del comercio.');
  const a = cleanAlias(alias);
  if (!a) throw new Error('Escribí un nombre para el certificado (solo letras y números).');
  const keys = await subtle.generateKey(
    { name: 'RSASSA-PKCS1-v1_5', modulusLength: 2048, publicExponent: new Uint8Array([1, 0, 1]), hash: 'SHA-256' },
    true, ['sign', 'verify'],
  );
  const spki = new Uint8Array(await subtle.exportKey('spki', keys.publicKey));
  const subject = seq(
    rdn('2.5.4.6', printable('AR')),
    rdn('2.5.4.10', utf8(o)),
    rdn('2.5.4.3', utf8(a)),
    rdn('2.5.4.5', printable('CUIT ' + c)),
  );
  const info = seq(tlv(0x02, Uint8Array.from([0])), subject, spki, Uint8Array.from([0xa0, 0x00]));
  const sig = new Uint8Array(await subtle.sign('RSASSA-PKCS1-v1_5', keys.privateKey, info));
  const algo = seq(oid('1.2.840.113549.1.1.11'), Uint8Array.from([0x05, 0x00]));
  const csr = seq(info, algo, tlv(0x03, cat(Uint8Array.from([0]), sig)));
  const pkcs8 = new Uint8Array(await subtle.exportKey('pkcs8', keys.privateKey));
  return { keyPem: pem('PRIVATE KEY', pkcs8), csrPem: pem('CERTIFICATE REQUEST', csr), alias: a };
}
