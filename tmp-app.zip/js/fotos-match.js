// =====================================================================
// fotos-match.js — A qué producto va cada imagen de "Importar fotos" (sin
// pantalla: se prueba con node). Por nombre de archivo, en este orden:
//   1. código de barras (7790070318046.jpg, 7790070318046_1.jpg, 7790070318046-frente.png…)
//   2. código interno (SKU), con o sin sufijo
//   3. nombre del producto ("Yerba Playadito 1 kg.jpg"), sin acentos ni mayúsculas
// Si varias imágenes van al mismo producto queda una: la sin sufijo, si no la "frente"/"_1", si no la primera.
// =====================================================================
import { norm } from './logic.js';
import { codeVariants } from './barcode.js';

/** Nombre del archivo sin carpeta ni extensión */
export function fileStem(name) {
  const base = String(name || '').split(/[\\/]/).pop();
  return base.replace(/\.[a-z0-9]{2,5}$/i, '').trim();
}

/** Texto para comparar nombres: sin acentos, minúsculas, solo letras y números separados por un espacio */
export function normName(s) {
  return norm(s).replace(/[^a-z0-9ñ]+/g, ' ').trim();
}

const SEP = /[\s_\-.()[\]+,]/;
// Palabras que suelen ir al final del nombre de una foto y no son parte del producto
const SUFFIX = /^(\d{1,2}|[a-z]|frente|frontal|front|dorso|atras|back|lado|costado|copia|copy|foto|img|imagen|image|final|nuevo|nueva|ok|hd|web|chica|grande)$/;
const PREFIX = /^(img|foto|imagen|image|producto|prod)$/;
const FRONT = /^(1|01|a|frente|frontal|front)$/;

/**
 * Índice de los productos para buscar rápido (una vez por importación, no por archivo).
 * products: registros vivos (se ignoran los borrados).
 */
export function buildPhotoIndex(products) {
  const byCode = new Map(), bySku = new Map(), byName = new Map();
  const add = (m, k, p) => { if (!k) return; const a = m.get(k); if (!a) m.set(k, [p]); else if (!a.includes(p)) a.push(p); };
  for (const p of products || []) {
    if (!p || p.deleted) continue;
    const bc = String(p.barcode || '').trim();
    if (bc) for (const v of codeVariants(bc)) add(byCode, v, p);
    const sku = String(p.sku || '').trim().toLowerCase();
    if (sku) add(bySku, sku, p);
    add(byName, normName(p.name), p);
  }
  return { byCode, bySku, byName };
}

// Si hay varios, vale uno solo si es el único activo
function one(list) {
  if (!list || !list.length) return { p: null, n: 0 };
  if (list.length === 1) return { p: list[0], n: 1 };
  const act = list.filter(p => p.active !== 0);
  return act.length === 1 ? { p: act[0], n: 1 } : { p: null, n: list.length };
}

/** Códigos a probar: el nombre entero y después cortando lo que va después de cada separador (de más largo a más corto) */
function codeCandidates(stem) {
  const out = [stem];
  for (let i = stem.length - 1; i > 0; i--) if (SEP.test(stem[i])) { const c = stem.slice(0, i).trim(); if (c) out.push(c); }
  const lead = /^\d{8,14}/.exec(stem); // "7790070318046frente"
  if (lead) out.push(lead[0]);
  // "IMG_7790070318046_2": un número de 12 a 14 cifras suelto en el medio
  for (const t of stem.split(SEP)) if (/^\d{12,14}$/.test(t)) out.push(t);
  return [...new Set(out)];
}

/**
 * Producto que corresponde a un archivo. Devuelve
 * {product, by: 'codigo'|'sku'|'nombre', rank} — rank: 0 = nombre exacto, 1 = "frente"/"_1", 2 = otro sufijo —
 * o {product: null, reason: 'sin_coincidencia'|'ambiguo', n}.
 */
export function matchPhotoFile(fileName, index) {
  const stem = fileStem(fileName);
  if (!stem) return { product: null, reason: 'sin_coincidencia' };
  let amb = 0;
  const cands = codeCandidates(stem);
  const rankOf = c => {
    if (c === stem) return 0;
    const rest = normName(stem.slice(c.length));
    return FRONT.test(rest) ? 1 : 2;
  };
  for (const c of cands) {
    // Un código corto o un código interno con algo después vale solo si lo de después es un sufijo ("_2", "frente"):
    // así "1 Leche.jpg" no va al producto de código interno "1"
    const restOk = c === stem || normName(stem.slice(c.length)).split(' ').filter(Boolean).every(w => SUFFIX.test(w));
    if (/^\d{8,14}$/.test(c) || (restOk && /^\d{6,7}$/.test(c))) {
      for (const v of codeVariants(c)) {
        const r = one(index.byCode.get(v));
        if (r.p) return { product: r.p, by: 'codigo', rank: rankOf(c) };
        if (r.n > 1) amb = Math.max(amb, r.n);
      }
    }
    if (!restOk) continue;
    const r = one(index.bySku.get(c.toLowerCase()));
    if (r.p) return { product: r.p, by: 'sku', rank: rankOf(c) };
    if (r.n > 1) amb = Math.max(amb, r.n);
  }
  // Por nombre: exacto y después sacando sufijos ("_2", "frente", "copia") y prefijos ("IMG", "foto")
  const all = normName(stem).split(' ').filter(Boolean);
  let k = 0;
  while (k < all.length - 1 && PREFIX.test(all[k])) k++;
  for (const start of k ? [all, all.slice(k)] : [all]) {
    let words = start, rank = 0;
    while (words.length) {
      const r = one(index.byName.get(words.join(' ')));
      if (r.p) return { product: r.p, by: 'nombre', rank };
      if (r.n > 1) { amb = Math.max(amb, r.n); break; }
      const last = words[words.length - 1];
      if (!SUFFIX.test(last) || words.length === 1) break;
      rank = rank === 0 && FRONT.test(last) ? 1 : 2;
      words = words.slice(0, -1);
    }
  }
  return amb ? { product: null, reason: 'ambiguo', n: amb } : { product: null, reason: 'sin_coincidencia' };
}

/**
 * Plan de la importación. files: [{name, ...}] (lo que haga falta para leerlas después).
 * hasPhoto(productId) → bool. replace: reemplazar las fotos que ya están.
 * Devuelve {todo: [{file, product, by}], skipped: [{file, product}] (ya tenían foto),
 *           unmatched: [{file, reason, n}], dupes: [{file, product, kept}]}.
 */
export function planPhotoImport(files, products, { hasPhoto = () => false, replace = false } = {}) {
  const index = buildPhotoIndex(products);
  const best = new Map(); // product id → {file, product, by, rank}
  const unmatched = [], dupes = [];
  for (const file of files) {
    const m = matchPhotoFile(file.name, index);
    if (!m.product) { unmatched.push({ file, reason: m.reason, n: m.n || 0 }); continue; }
    const cur = best.get(m.product.id);
    const cand = { file, product: m.product, by: m.by, rank: m.rank };
    const better = !cur || m.rank < cur.rank || (m.rank === cur.rank && fileStem(file.name).length < fileStem(cur.file.name).length);
    if (better) { if (cur) dupes.push({ file: cur.file, product: cur.product, kept: file }); best.set(m.product.id, cand); }
    else dupes.push({ file, product: m.product, kept: cur.file });
  }
  const todo = [], skipped = [];
  for (const x of best.values()) {
    if (!replace && hasPhoto(x.product.id)) skipped.push({ file: x.file, product: x.product });
    else todo.push({ file: x.file, product: x.product, by: x.by });
  }
  return { todo, skipped, unmatched, dupes };
}

export const REASONS = {
  sin_coincidencia: 'No coincide con ningún código de barras, código interno ni nombre de producto',
  ambiguo: 'El nombre coincide con varios productos',
  repetida: 'Ya se usó otra imagen para este producto',
  ya_tiene: 'El producto ya tenía foto (no se reemplazó)',
  error: 'No se pudo leer la imagen',
};
