// =====================================================================
// db.js — Wrapper propio de IndexedDB con caché en memoria.
// Cada cambio pone updated_at = Date.now(), deleted = 0/1 y deja el
// registro en la "bandeja de salida" (outbox) para sincronizar con la nube.
// =====================================================================
import { uuid } from './logic.js';

export const COLLECTIONS = [
  'products', 'customers', 'suppliers', 'cash_sessions', 'cash_movements',
  'sales', 'purchases', 'stock_moves', 'users', 'settings', 'branches', 'returns', 'transfers',
  'supplier_payments', 'customer_payments', 'audit_log', 'product_photos',
  // v5 (esquema 0006)
  'expense_types', 'expenses', 'banks', 'cheques', 'card_types', 'payment_methods', 'quotes', 'orders', 'supplier_orders',
  'promotions', 'categories', 'subcategories', 'product_lots',
  // v6 (esquema 0011, IA): lo aprendido de cada proveedor (código/descripción → producto) e imágenes de comprobantes
  'supplier_items', 'purchase_docs',
];

const DB_NAME = 'jeano-gestion';
// v2: agrega el store "branches" (sucursales). v3: "returns" (devoluciones / notas de crédito) y "transfers" (remitos).
// v4: "supplier_payments" (pagos a proveedores), "customer_payments" (cobros de clientes), "audit_log" (auditoría)
// y "product_photos" (fotos de productos, id = id del producto).
// v5 (esquema 0006): gastos y tipos de gasto, bancos y cheques, tarjetas, medios de pago, presupuestos, pedidos de
// clientes y a proveedores, promociones, rubros, subrubros y lotes con vencimiento.
// v6 (esquema 0011): "supplier_items" (aprendizaje de la carga con foto) y "purchase_docs" (imagen del comprobante).
// Al subir de versión solo se crean los stores que faltan.
const DB_VERSION = 6;

// Cortes de luz: las escrituras propias (ventas, caja, stock…) se confirman en disco ANTES de avisar "listo"
// (durability "strict": el navegador espera el fsync). Lo que baja de la nube puede ir en modo normal.
const STRICT = { durability: 'strict' };
function rwTx(stores, strict = true) {
  if (closing) throw new Closing();
  try { return idb.transaction(stores, 'readwrite', strict ? STRICT : undefined); } catch (e) { return idb.transaction(stores, 'readwrite'); }
}

// Colecciones que no hacen falta para abrir la app (movimientos de stock, auditoría y fotos): se leen en segundo
// plano apenas arranca. Con miles de ventas los movimientos de stock son lo más pesado de leer (3-4 por venta): así la
// app abre en la mitad del tiempo. Todo lo que escribe o sincroniza espera a que estén leídas (whenLoaded).
export const LAZY = ['stock_moves', 'audit_log', 'product_photos', 'purchase_docs'];

/** La base se está cerrando para actualizarse (la página se recarga enseguida) */
class Closing extends Error { constructor() { super('Actualizando JEANO Gestión…'); this.name = 'Closing'; } }
/** Envuelve una operación de la base: si se está cerrando para actualizarse, espera la recarga en vez de fallar */
async function guard(fn) {
  if (closing) return NEVER;
  try { return await fn(); } catch (e) { if (closing) return NEVER; throw e; }
}

let idb = null;
let closing = false; // otra pestaña está actualizando la base: esta se va a recargar
const NEVER = new Promise(() => {});
const cache = {};             // coll -> Map(id -> registro)
let lazyReady = Promise.resolve();
let lazyDone = true;
const listeners = new Set();  // avisos de cambios para refrescar pantallas
// Usuario que está usando la app: cada cambio de la bandeja de salida lleva quién lo hizo (by). Con la nube por
// usuario (equipos autorizados), cajero y vendedor suben solo lo suyo; lo de otro espera a su autor o al dueño/encargado.
let author = '';
/** Quién hace los cambios desde ahora (id del usuario que entró con su PIN, o '' en la pantalla de ingreso) */
export function setAuthor(id) { author = id ? String(id) : ''; }

function req2promise(req) {
  return new Promise((resolve, reject) => {
    req.onsuccess = () => resolve(req.result);
    req.onerror = () => reject(req.error);
  });
}
function txDone(tx) {
  return new Promise((resolve, reject) => {
    tx.oncomplete = () => resolve();
    tx.onerror = () => reject(tx.error || new Error('Error de base de datos'));
    tx.onabort = () => reject(tx.error || new Error('Operación cancelada'));
  });
}

function rootMsg(h) { const el = typeof document !== 'undefined' && document.getElementById('root'); if (el) el.innerHTML = h; }
const RETRY_BTN = '<p><button type="button" class="btn primary" onclick="location.reload()">Reintentar</button></p>';

/**
 * Abre IndexedDB sin quedar nunca trabado en "Cargando…":
 * - otra pestaña con la versión vieja abierta (blocked): se avisa; esa pestaña se cierra sola al recibir el aviso;
 * - la base del equipo es de una versión MÁS NUEVA que este código (quedó abierta una copia vieja de la app):
 *   se abre en la versión que tiene (los almacenes que usa este código ya existen);
 * - si el navegador no contesta en 8 s, se ofrece Reintentar (y se sigue esperando).
 */
function openIdb(version) {
  return new Promise((resolve, reject) => {
    let settled = false;
    const r = version ? indexedDB.open(DB_NAME, version) : indexedDB.open(DB_NAME);
    const slow = setTimeout(() => {
      if (!settled) rootMsg(`<div class="login"><div class="login-box"><p><b>La base de datos está tardando en abrir.</b></p><p class="muted">Si tenés JEANO Gestión abierta en otra ventana o pestaña, cerrala. Si no, tocá Reintentar.</p>${RETRY_BTN}</div></div>`);
    }, 8000);
    const done = (fn, v) => { if (settled) return; settled = true; clearTimeout(slow); fn(v); };
    r.onupgradeneeded = () => {
      const d = r.result;
      for (const c of COLLECTIONS) if (!d.objectStoreNames.contains(c)) d.createObjectStore(c, { keyPath: 'id' });
      if (!d.objectStoreNames.contains('meta')) d.createObjectStore('meta', { keyPath: 'key' });
      if (!d.objectStoreNames.contains('outbox')) d.createObjectStore('outbox', { keyPath: 'key' });
    };
    r.onsuccess = () => {
      const d = r.result;
      const missing = [...COLLECTIONS, 'meta', 'outbox'].filter(c => !d.objectStoreNames.contains(c));
      if (missing.length && !version) { d.close(); done(reject, new Error('La base de datos está incompleta. Cerrá las otras pestañas de la app y tocá Reintentar.')); return; }
      done(resolve, d);
    };
    r.onerror = e => {
      const err = r.error;
      if (err && err.name === 'VersionError' && version) {
        // La base es más nueva que este código: se abre igual (sin bajar de versión, que no se puede)
        if (e && e.preventDefault) e.preventDefault();
        settled = true; clearTimeout(slow);
        openIdb(0).then(resolve, reject);
        return;
      }
      done(reject, err || new Error('No se pudo abrir la base de datos.'));
    };
    // Otra pestaña/ventana con la versión vieja abierta: esperamos (se cierra sola al recibir el aviso)
    r.onblocked = () => rootMsg(`<div class="login"><div class="login-box"><p><b>Actualizando JEANO Gestión…</b></p><p class="muted">Si tenés la app abierta en otra ventana o pestaña, cerrala.</p>${RETRY_BTN}</div></div>`);
  });
}

/** Abre la base y carga todo en memoria (las búsquedas quedan instantáneas). */
export async function open() {
  if (idb) return;
  if (!('indexedDB' in globalThis)) throw new Error('Este navegador no permite guardar datos (IndexedDB).');
  idb = await openIdb(DB_VERSION);
  // Cuando otra pestaña actualiza la base, esta se cierra y se recarga para no trabar la actualización
  idb.onversionchange = () => {
    // Otra pestaña actualiza la base: esta suelta la conexión y se recarga. Lo que se intente guardar en este
    // instante queda esperando (no se guarda a medias ni tira errores): al recargar, el carrito se recupera.
    closing = true;
    try { idb.close(); } catch (e) { /* ya cerrada */ }
    setTimeout(() => location.reload(), 300);
  };
  const first = COLLECTIONS.filter(c => !LAZY.includes(c));
  for (const c of LAZY) cache[c] = new Map();
  const tx = idb.transaction(first, 'readonly');
  await Promise.all(first.map(async c => {
    const rows = await req2promise(tx.objectStore(c).getAll());
    cache[c] = new Map(rows.map(r => [r.id, r]));
  }));
  lazyDone = false;
  // Se empieza a leer cuando la primera pantalla ya se mostró (loadRest) o, como mucho, a los 2 s: el navegador
  // atiende de a un pedido por vez y si no, las lecturas chicas del arranque (sesión, nube, carrito) quedarían en cola.
  let start;
  const started = new Promise(r => { start = r; });
  restStarted = started;
  loadRest = () => start();
  setTimeout(loadRest, 2000);
  lazyReady = (async () => {
    await started;
    const t2 = idb.transaction(LAZY, 'readonly');
    const got = await Promise.all(LAZY.map(c => req2promise(t2.objectStore(c).getAll())));
    LAZY.forEach((c, i) => {
      // Lo que se haya escrito mientras tanto (no debería: las escrituras esperan) queda por encima de lo leído
      const m = new Map(got[i].map(r => [r.id, r]));
      for (const [id, r] of cache[c]) m.set(id, r);
      cache[c] = m;
    });
    lazyDone = true;
    if (cache.product_photos.size) emit(['product_photos'], { fromSync: true, lazy: true });
  })();
  lazyReady.catch(e => { if (!closing) console.error('No se pudieron leer los movimientos de stock / auditoría / fotos', e); });
}

/** Empieza a leer las colecciones de segundo plano (la app lo llama al mostrar la primera pantalla) */
export let loadRest = () => {};
/** Se resuelve cuando empieza esa lectura (la primera sincronización espera a que la app ya esté en pantalla) */
export let restStarted = Promise.resolve();
/** Espera a que estén leídas también las colecciones de segundo plano (LAZY); si todavía no empezó, la empieza */
export function whenLoaded() { if (!lazyDone) loadRest(); return lazyReady; }
/** ¿Ya están leídas todas las colecciones? */
export function isLoaded() { return lazyDone; }

/** Registros vivos (no borrados) de una colección */
export function all(coll, { includeDeleted = false } = {}) {
  const out = [];
  for (const r of cache[coll].values()) if (includeDeleted || !r.deleted) out.push(r);
  return out;
}

/** Un registro por id (incluye borrados, útil para mostrar nombres históricos) */
export function get(coll, id) {
  if (!id) return null;
  return cache[coll].get(id) || null;
}

export function count(coll) {
  let n = 0;
  for (const r of cache[coll].values()) if (!r.deleted) n++;
  return n;
}

/** Prepara un registro: id, updated_at estrictamente creciente, deleted */
function stamp(coll, rec) {
  const prev = rec.id ? cache[coll].get(rec.id) : null;
  const now = Date.now();
  const r = { ...rec };
  if (!r.id) r.id = uuid();
  r.updated_at = prev && prev.updated_at >= now ? prev.updated_at + 1 : now;
  r.deleted = r.deleted ? 1 : 0;
  return r;
}

/**
 * Guarda varios registros de distintas colecciones en UNA transacción (todo o nada).
 * ops: [{coll, rec}] — rec puede ser parcial si trae id existente (se mezcla con lo guardado).
 * opts.fromSync: viene de la nube → no se marca pendiente ni se cambia updated_at.
 */
async function putBatch_(ops, { fromSync = false } = {}) {
  if (!ops.length) return [];
  const stores = [...new Set(ops.map(o => o.coll))];
  // Un cambio parcial se mezcla con lo guardado: si toca una colección de segundo plano, primero hay que tenerla leída
  if (!lazyDone && stores.some(c => LAZY.includes(c))) await whenLoaded();
  const tx = rwTx(fromSync ? stores : [...stores, 'outbox'], !fromSync);
  const saved = ops.map(({ coll, rec }) => {
    if (!cache[coll]) throw new Error('Colección desconocida: ' + coll);
    const base = rec.id ? cache[coll].get(rec.id) : null;
    const merged = fromSync ? { ...rec } : stamp(coll, { ...(base || {}), ...rec });
    tx.objectStore(coll).put(merged);
    if (!fromSync) tx.objectStore('outbox').put({ key: coll + '|' + merged.id, coll, id: merged.id, updated_at: merged.updated_at, by: author });
    return { coll, rec: merged };
  });
  await txDone(tx);
  for (const { coll, rec } of saved) cache[coll].set(rec.id, rec);
  emit(stores, { fromSync });
  return saved.map(s => s.rec);
}

/** Guarda (crea o actualiza) un registro y lo devuelve */
export async function put(coll, rec, opts) {
  const [r] = await putBatch([{ coll, rec }], opts);
  return r;
}

/** Borrado lógico (deleted = 1) */
export async function remove(coll, id) {
  return put(coll, { id, deleted: 1 });
}

// ---------- meta (datos solo de este dispositivo: nube, sesión, impresora) ----------

async function getMeta_(key, def = null) {
  const tx = idb.transaction('meta', 'readonly');
  const r = await req2promise(tx.objectStore('meta').get(key));
  return r ? r.value : def;
}
async function setMeta_(key, value) {
  const tx = rwTx('meta');
  tx.objectStore('meta').put({ key, value });
  await txDone(tx);
}

// ---------- outbox (pendientes de sincronizar) ----------

async function outboxList_() {
  const tx = idb.transaction('outbox', 'readonly');
  return req2promise(tx.objectStore('outbox').getAll());
}
async function outboxCount_() {
  const tx = idb.transaction('outbox', 'readonly');
  return req2promise(tx.objectStore('outbox').count());
}
/**
 * Saca de la bandeja los registros enviados, salvo que hayan cambiado EN ESTE EQUIPO mientras tanto.
 * Cada cambio local reescribe su entrada de la bandeja con el updated_at nuevo: si la entrada guardada sigue igual a
 * la que se leyó, lo que se mandó (la versión de memoria, siempre la última) la cubre y se saca.
 * Antes se comparaba contra la versión en memoria: si en el medio bajaba de la nube una versión más nueva del mismo
 * registro (otro equipo lo cambió después), la entrada quedaba para siempre ("1 cambios por subir" eterno, y
 * "Empezar de cero" no dejaba seguir).
 */
async function outboxAck_(entries) {
  const tx = idb.transaction('outbox', 'readwrite');
  const st = tx.objectStore('outbox');
  for (const e of entries) {
    const r = st.get(e.key);
    r.onsuccess = () => { const cur = r.result; if (cur && Number(cur.updated_at) === Number(e.updated_at)) st.delete(e.key); };
  }
  await txDone(tx);
}
/**
 * Deja esperando (sin autor: los sube el dueño o el encargado) los registros que la nube no aceptó de este usuario
 * porque los cargó otro (hold), salvo que hayan cambiado en este equipo mientras tanto.
 */
async function outboxHold_(entries) {
  const tx = idb.transaction('outbox', 'readwrite');
  const st = tx.objectStore('outbox');
  for (const e of entries) {
    const r = st.get(e.key);
    r.onsuccess = () => { const cur = r.result; if (cur && Number(cur.updated_at) === Number(e.updated_at)) st.put({ ...cur, by: '', held: 1 }); };
  }
  await txDone(tx);
}
/** Marca todo como pendiente (por ejemplo al conectar la nube por primera vez) */
async function markAllPending_() {
  await whenLoaded();
  const tx = idb.transaction('outbox', 'readwrite');
  const st = tx.objectStore('outbox');
  for (const c of COLLECTIONS) for (const r of cache[c].values()) st.put({ key: c + '|' + r.id, coll: c, id: r.id, updated_at: r.updated_at });
  await txDone(tx);
}

/**
 * Aplica registros que vienen de la nube con "gana el updated_at mayor".
 * Devuelve cuántos se aplicaron.
 */
async function applyRemote_(changes) {
  if (!lazyDone) await whenLoaded(); // para comparar contra lo local hay que tenerlo leído
  const ops = [];
  for (const [coll, rows] of Object.entries(changes || {})) {
    if (!cache[coll] || !Array.isArray(rows)) continue;
    for (const r of rows) {
      if (!r || !r.id) continue;
      const local = cache[coll].get(r.id);
      if (!local || Number(r.updated_at) > Number(local.updated_at)) ops.push({ coll, rec: { ...r, updated_at: Number(r.updated_at), deleted: r.deleted ? 1 : 0 } });
    }
  }
  if (ops.length) await putBatch(ops, { fromSync: true });
  return ops.length;
}

// ---------- copia de seguridad ----------

/** Copia completa. Antes de llamarla: await whenLoaded() (si no, faltarían los movimientos de stock). */
export function exportAll() {
  if (!lazyDone) throw new Error('Todavía se están leyendo los datos. Probá de nuevo en un segundo.');
  const data = {};
  for (const c of COLLECTIONS) data[c] = [...cache[c].values()];
  return { app: 'jeano-gestion', version: 1, exported_at: Date.now(), data };
}

/** Importa una copia: mezcla por updated_at y deja todo pendiente de sincronizar */
export async function importAll(backup) {
  await whenLoaded();
  if (!backup || backup.app !== 'jeano-gestion' || !backup.data) throw new Error('El archivo no es una copia de JEANO Gestión.');
  let n = 0;
  const ops = [];
  for (const c of COLLECTIONS) {
    for (const r of backup.data[c] || []) {
      if (!r || !r.id) continue;
      const local = cache[c].get(r.id);
      if (!local || Number(r.updated_at) > Number(local.updated_at)) { ops.push({ coll: c, rec: r }); n++; }
    }
  }
  // En tandas para no hacer transacciones gigantes
  for (let i = 0; i < ops.length; i += 1000) {
    const chunk = ops.slice(i, i + 1000);
    await putBatch(chunk, { fromSync: true });
    const tx = idb.transaction('outbox', 'readwrite');
    for (const { coll, rec } of chunk) tx.objectStore('outbox').put({ key: coll + '|' + rec.id, coll, id: rec.id, updated_at: rec.updated_at });
    await txDone(tx);
  }
  return n;
}

// ---------- eventos ----------

export function onChange(fn) { listeners.add(fn); return () => listeners.delete(fn); }
function emit(colls, info = {}) { for (const fn of listeners) { try { fn(colls, info); } catch (e) { console.warn(e); } } }

// Todas las operaciones con la base pasan por guard(): durante una actualización desde otra pestaña no tiran errores.
export const putBatch = (...a) => guard(() => putBatch_(...a));
export const getMeta = (...a) => guard(() => getMeta_(...a));
export const setMeta = (...a) => guard(() => setMeta_(...a));
export const outboxList = (...a) => guard(() => outboxList_(...a));
export const outboxCount = (...a) => guard(() => outboxCount_(...a));
export const outboxAck = (...a) => guard(() => outboxAck_(...a));
export const outboxHold = (...a) => guard(() => outboxHold_(...a));
export const markAllPending = (...a) => guard(() => markAllPending_(...a));
export const applyRemote = (...a) => guard(() => applyRemote_(...a));
