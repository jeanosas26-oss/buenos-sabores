// =====================================================================
// atajos.js — Atajos de teclado estilo SGI: Alt + letra.
//   Pantallas: Alt+V Vender, Alt+H Hoy, Alt+J Caja, Alt+P Productos, Alt+T Ventas,
//   Alt+L Clientes, Alt+O Compras/Proveedores, Alt+R Reportes, Alt+M Remitos,
//   Alt+K Contar stock, Alt+A Ajustes, Alt+U Cambiar usuario.
//   Alt+S = Salir: cierra la ventana abierta (o vuelve a Vender).
//   En Vender: F2 buscar, F3 cámara, F4 cliente, F6 descuento, F7 monto libre, F8 vaciar, F9/F12 cobrar, F10 abrir caja.
//   En cualquier ventana: Alt + la letra subrayada del botón (Alt+G Guardar, Alt+C Cancelar…).
//   F1 o Alt+Y: ayuda con todos los atajos. Al mantener Alt se ven las letras subrayadas.
// =====================================================================
import { html, modal, $ } from './ui.js';

export const NAV = [
  ['v', 'vender', 'Vender'], ['h', 'hoy', 'Hoy (tablero)'], ['j', 'caja', 'Caja'], ['p', 'productos', 'Productos'],
  ['t', 'ventas', 'Ventas'], ['l', 'clientes', 'Clientes'], ['o', 'compras', 'Compras'], ['q', 'proveedores', 'Proveedores'], ['r', 'reportes', 'Reportes'],
  ['m', 'remitos', 'Remitos'], ['k', 'conteo', 'Contar stock'], ['d', 'auditoria', 'Auditoría'], ['a', 'ajustes', 'Ajustes'],
];
export const VENDER_KEYS = [
  ['F2', '#s-in', 'Buscar producto / código'], ['F3', '[data-act="scan"]', 'Escanear con la cámara'],
  ['F4', '[data-act="cliente"]', 'Elegir cliente'], ['F6', '[data-act="descuento"]', 'Descuento'],
  ['F7', '[data-act="libre"]', 'Monto libre'], ['F8', '[data-act="vaciar"]', 'Vaciar carrito'],
  ['F9', '[data-act="cobrar"]', 'Cobrar'], ['F12', '[data-act="cobrar"]', 'Cobrar'], ['F10', '[data-act="abrir-caja"]', 'Abrir caja'],
];

const visible = el => !!el && !el.disabled && el.offsetParent !== null;
const topModal = () => [...document.querySelectorAll('.modal-wrap')].pop() || null;

/** Letra de atajo de un botón: data-key, o la primera letra libre de su texto */
function assignKeys(buttons, taken = new Set()) {
  const out = [];
  for (const b of buttons) {
    const label = (b.textContent || '').trim();
    if (!label) continue;
    let k = (b.dataset.key || '').toLowerCase();
    if (!k) {
      const words = label.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').split(/\s+/);
      const cands = [...words.map(w => w[0]), ...label.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')];
      k = cands.find(c => /[a-z0-9]/.test(c || '') && !taken.has(c)) || '';
    }
    if (!k || taken.has(k)) continue;
    taken.add(k);
    out.push([k, b]);
  }
  return out;
}

function modalButtons(wrap) {
  const foot = [...wrap.querySelectorAll('.modal-foot button')].filter(visible);
  const body = [...wrap.querySelectorAll('.modal-body button.btn')].filter(visible);
  // Cancelar/Cerrar siempre con S (salir) y Escape; el resto por su letra
  const taken = new Set(['s']);
  return assignKeys([...foot, ...body].filter(b => !/^(cancelar|cerrar)$/i.test(b.textContent.trim())), taken);
}

function screenButtons() {
  const main = document.querySelector('#main');
  if (!main) return [];
  const navKeys = new Set(NAV.map(n => n[0]).concat(['s', 'u', 'y']));
  return assignKeys([...main.querySelectorAll('.page-head button, .toolbar button, .btn-row button, header button.btn')].filter(visible), navKeys);
}

let hintsOn = false;
function showHints(on) {
  if (on === hintsOn) return;
  hintsOn = on;
  document.querySelectorAll('.kbd-hint').forEach(x => x.remove());
  document.body.classList.toggle('alt-held', on);
  if (!on) return;
  const wrap = topModal();
  const pairs = wrap ? modalButtons(wrap) : screenButtons();
  for (const [k, b] of pairs) {
    const s = document.createElement('span');
    s.className = 'kbd-hint'; s.textContent = k.toUpperCase(); s.setAttribute('aria-hidden', 'true');
    b.appendChild(s);
  }
  if (!wrap) {
    for (const [k, route] of NAV) {
      document.querySelectorAll(`[data-route="${route}"]`).forEach(a => {
        if (a.offsetParent === null) return;
        const s = document.createElement('span'); s.className = 'kbd-hint'; s.textContent = k.toUpperCase(); s.setAttribute('aria-hidden', 'true'); a.appendChild(s);
      });
    }
  }
}

export function helpDialog() {
  const row = (k, t) => html`<li class="row" style="min-height:0;padding:.35rem .2rem"><span class="grow">${t}</span><kbd>${k}</kbd></li>`;
  return modal({
    title: 'Atajos de teclado',
    size: 'wide',
    body: html`<p class="muted">Como en SGI: mantené <kbd>Alt</kbd> apretada y vas a ver la letra de cada botón.</p>
      <h3>Ir a</h3><ul class="list">${NAV.map(([k, , t]) => row('Alt + ' + k.toUpperCase(), t))}${row('Alt + U', 'Cambiar usuario')}</ul>
      <h3>General</h3><ul class="list">${row('Alt + S', 'Salir: cierra la ventana (o vuelve a Vender)')}${row('Esc', 'Cerrar la ventana')}${row('Alt + letra', 'Botón de la ventana (Alt+G Guardar, Alt+C Cobrar…)')}${row('F1', 'Esta ayuda')}</ul>
      <h3>En Vender</h3><ul class="list">${VENDER_KEYS.filter(v => v[0] !== 'F12').map(([k, , t]) => row(k, t))}${row('Enter', 'Agregar lo buscado / confirmar')}</ul>`,
    actions: [{ label: 'Entendido', kind: 'primary', value: true }],
  });
}

export function initAtajos(app) {
  document.addEventListener('keydown', e => {
    if (e.key === 'Alt') { showHints(true); return; }
    // F1: ayuda
    if (e.key === 'F1') { e.preventDefault(); if (app.loggedIn()) helpDialog(); return; }
    if (!app.loggedIn()) return;
    const wrap = topModal();
    if (e.altKey && !e.ctrlKey && !e.metaKey && e.key.length === 1) {
      const k = e.key.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
      if (wrap) {
        if (k === 's') { e.preventDefault(); const c = wrap.querySelector('[data-close]') || [...wrap.querySelectorAll('.modal-foot button')].find(b => /^(cancelar|cerrar|listo)$/i.test(b.textContent.trim())); if (c) c.click(); else document.dispatchEvent(new KeyboardEvent('keydown', { key: 'Escape' })); showHints(false); return; }
        const hit = modalButtons(wrap).find(([kk]) => kk === k);
        if (hit) { e.preventDefault(); showHints(false); hit[1].click(); }
        return;
      }
      if (k === 'y') { e.preventDefault(); showHints(false); helpDialog(); return; }
      if (k === 's') { e.preventDefault(); showHints(false); app.navigate('vender'); return; }
      if (k === 'u') { e.preventDefault(); showHints(false); app.logout(); return; }
      const nav = NAV.find(([kk]) => kk === k);
      if (nav) { e.preventDefault(); showHints(false); app.navigate(nav[1]); return; }
      const hit = screenButtons().find(([kk]) => kk === k);
      if (hit) { e.preventDefault(); showHints(false); hit[1].click(); }
      return;
    }
    // Teclas F en Vender (sin ventana abierta)
    if (!wrap && /^F\d+$/.test(e.key) && app.current() === 'vender') {
      const v = VENDER_KEYS.find(([kk]) => kk === e.key);
      if (!v) return;
      const el = document.querySelector('#main ' + v[1]) || document.querySelector(v[1]);
      e.preventDefault();
      if (!visible(el)) return;
      if (el.matches('input')) { el.focus(); el.select(); } else el.click();
    }
  }, true);
  document.addEventListener('keyup', e => { if (e.key === 'Alt') e.preventDefault(); if (e.key === 'Alt' || !e.altKey) showHints(false); }, true);
  window.addEventListener('blur', () => showHints(false));
}
