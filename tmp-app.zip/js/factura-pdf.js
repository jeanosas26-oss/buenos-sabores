// =====================================================================
// factura-pdf.js — PDF de una factura (formato ticket 80 mm, con el QR de ARCA) para mandarla
// por WhatsApp o mail cuando el cliente ya se fue (por ejemplo, si ARCA estaba caído al vender).
// El PDF se arma acá mismo, sin librerías: texto en Courier y el QR dibujado con cuadraditos.
// =====================================================================
import * as db from './db.js';
import { loadScript } from './ui.js';
import { settings, userName } from './ops.js';
import { fmtMoney, fmtQty, fmtDateTime, payLabel, cbteNombre, fmtCbteNro, ivaBreakdown, discriminaIva, arcaQrUrl } from './logic.js';

const QR_LIB = 'https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js';
const IVA_NAMES = { RI: 'IVA Responsable Inscripto', MT: 'Responsable Monotributo', EX: 'IVA Exento', CF: 'Consumidor Final' };

/** ¿Hay que mandarle esta factura al cliente? (se autorizó tarde o quedó un contacto, y todavía no se mandó) */
export function facturaParaMandar(s) {
  const d = (s && s.doc) || {};
  if (!s || s.status !== 'ok' || s.test || d.kind !== 'factura' || d.status !== 'autorizado' || s.doc_sent_at) return false;
  const tarde = Number(d.authorized_at) && Number(d.authorized_at) - Number(s.created_at) > 2 * 60 * 1000;
  return !!(tarde || s.doc_contact);
}

const W = 226.77; // 80 mm en puntos
const M = 12;
const SIZE = 7.5;
const CHAR = SIZE * 0.6; // Courier: ancho fijo
const COLS = Math.floor((W - 2 * M) / CHAR);
const LH = SIZE * 1.35;

function wrap(text, cols = COLS) {
  const out = [];
  for (const para of String(text).split('\n')) {
    let line = '';
    for (const w of para.split(/\s+/).filter(Boolean)) {
      if ((line ? line.length + 1 : 0) + w.length > cols) {
        if (line) out.push(line);
        let rest = w;
        while (rest.length > cols) { out.push(rest.slice(0, cols)); rest = rest.slice(cols); }
        line = rest;
      } else line = line ? line + ' ' + w : w;
    }
    out.push(line);
  }
  return out;
}
const two = (a, b) => {
  a = String(a); b = String(b);
  if (a.length + b.length + 1 > COLS) return [...wrap(a), ' '.repeat(Math.max(0, COLS - b.length)) + b];
  return [a + ' '.repeat(COLS - a.length - b.length) + b];
};
const center = s => wrap(s).map(l => ' '.repeat(Math.max(0, Math.floor((COLS - l.length) / 2))) + l);
const sep = () => ['-'.repeat(COLS)];

/** Renglones del comprobante: [{t, b}] (b = negrita) */
export function facturaLines(sale) {
  const st = settings();
  const d = sale.doc || {};
  const cust = sale.customer_id ? db.get('customers', sale.customer_id) : null;
  const br = ivaBreakdown(sale.items, discriminaIva(st.iva_condition));
  const L = [];
  const add = (arr, b = false) => { for (const t of arr) L.push({ t, b }); };
  add(center(st.business_name || 'Comercio'), true);
  if (st.legal_name) add(center(st.legal_name));
  if (st.address) add(center(st.address));
  if (st.cuit) add(center('CUIT ' + String(st.cuit).replace(/^(\d{2})(\d{8})(\d)$/, '$1-$2-$3')));
  if (st.iva_condition) add(center(IVA_NAMES[st.iva_condition] || st.iva_condition));
  if (st.iibb) add(center(`IIBB ${st.iibb}${st.start_date ? ' - Inicio act. ' + st.start_date : ''}`));
  add(sep());
  add(center(cbteNombre(d.cbte_tipo) || 'FACTURA'), true);
  add(center('N° ' + fmtCbteNro(d.pto_vta, d.cbte_nro)), true);
  add(center(`Fecha ${fmtDateTime(sale.created_at)}`));
  add(center(`Venta N° ${sale.number} - Atendió ${userName(sale.user_id)}`));
  if (cust) { add(wrap(`Cliente: ${cust.name}${cust.doc_number ? ` - ${cust.doc_type} ${cust.doc_number}` : ''}`)); if (cust.iva_condition) add(wrap(IVA_NAMES[cust.iva_condition] || cust.iva_condition)); }
  add(sep());
  for (const it of sale.items || []) {
    add(wrap(it.name));
    add(two(`  ${fmtQty(it.qty)} x ${fmtMoney(it.unit_price)}`, fmtMoney(it.subtotal + (it.discount || 0) - (it.surcharge || 0))));
    if (it.promo_discount) add(two(`  Promo ${it.promo_name || ''}`, '-' + fmtMoney(it.promo_discount)));
  }
  add(sep());
  if (sale.discount > 0) add(two('Descuento', '-' + fmtMoney(sale.discount)));
  if (sale.surcharge > 0) add(two('Recargo tarjeta', fmtMoney(sale.surcharge)));
  add(two('TOTAL', fmtMoney(sale.total)), true);
  if (d.cbte_tipo === 1) for (const [r, v] of Object.entries(br)) if (Number(r) > 0) { add(two(`Neto gravado ${r}%`, fmtMoney(v.net))); add(two(`IVA ${r}%`, fmtMoney(v.iva))); }
  if (d.cbte_tipo === 6) add(two('IVA contenido (Ley 27.743)', fmtMoney(sale.iva)));
  add(sep());
  for (const p of sale.payments || []) add(two(p.card_name ? `${p.card_name} (${payLabel(p.method)})` : payLabel(p.method), fmtMoney(p.amount)));
  add(sep());
  add(wrap(`CAE: ${d.cae}`), true);
  add(wrap(`Vto. CAE: ${d.cae_vto}`));
  return L;
}

/** Matriz del QR de ARCA (null si no se pudo cargar la librería, por ejemplo sin internet) */
async function qrMatrix(text) {
  try {
    await loadScript(QR_LIB);
    const div = document.createElement('div');
    const q = new window.QRCode(div, { text, width: 64, height: 64, correctLevel: window.QRCode.CorrectLevel.M });
    const m = q._oQRCode;
    if (!m || !m.getModuleCount) return null;
    const n = m.getModuleCount();
    const rows = [];
    for (let r = 0; r < n; r++) { const row = []; for (let c = 0; c < n; c++) row.push(!!m.isDark(r, c)); rows.push(row); }
    return rows;
  } catch (e) { return null; }
}

const esc = s => String(s).replace(/[^\x20-\x7e\xa0-\xff]/g, '?').replace(/([\\()])/g, '\\$1');

/** Arma el PDF (bytes) a partir de los renglones y la matriz del QR */
export function buildPdf(lines, qr = null, title = 'Factura') {
  const qrSize = qr ? 110 : 0;
  const H = Math.ceil(M * 2 + lines.length * LH + (qr ? qrSize + 18 : 0));
  let content = '';
  let y = H - M - SIZE;
  for (const l of lines) {
    content += `BT /${l.b ? 'F2' : 'F1'} ${SIZE} Tf ${M.toFixed(2)} ${y.toFixed(2)} Td (${esc(l.t)}) Tj ET\n`;
    y -= LH;
  }
  if (qr) {
    const n = qr.length, cell = qrSize / n, x0 = (W - qrSize) / 2, top = y - 6;
    content += '0 0 0 rg\n';
    for (let r = 0; r < n; r++) for (let c = 0; c < n; c++) if (qr[r][c]) content += `${(x0 + c * cell).toFixed(2)} ${(top - (r + 1) * cell).toFixed(2)} ${cell.toFixed(3)} ${cell.toFixed(3)} re f\n`;
  }
  const objs = [
    '<< /Type /Catalog /Pages 2 0 R >>',
    '<< /Type /Pages /Kids [3 0 R] /Count 1 >>',
    `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${W.toFixed(2)} ${H}] /Resources << /Font << /F1 4 0 R /F2 5 0 R >> >> /Contents 6 0 R >>`,
    '<< /Type /Font /Subtype /Type1 /BaseFont /Courier /Encoding /WinAnsiEncoding >>',
    '<< /Type /Font /Subtype /Type1 /BaseFont /Courier-Bold /Encoding /WinAnsiEncoding >>',
    `<< /Length ${content.length} >>\nstream\n${content}endstream`,
    `<< /Title (${esc(title)}) /Producer (JEANO Gestion) >>`,
  ];
  let out = '%PDF-1.4\n%\xe2\xe3\xcf\xd3\n';
  const offs = [];
  objs.forEach((o, i) => { offs.push(out.length); out += `${i + 1} 0 obj\n${o}\nendobj\n`; });
  const xref = out.length;
  out += `xref\n0 ${objs.length + 1}\n0000000000 65535 f \n` + offs.map(o => String(o).padStart(10, '0') + ' 00000 n \n').join('');
  out += `trailer\n<< /Size ${objs.length + 1} /Root 1 0 R /Info 7 0 R >>\nstartxref\n${xref}\n%%EOF\n`;
  const bytes = new Uint8Array(out.length);
  for (let i = 0; i < out.length; i++) bytes[i] = out.charCodeAt(i) & 0xff;
  return bytes;
}

/** PDF de la factura de una venta (File listo para compartir o bajar) */
export async function facturaPdf(sale) {
  const d = sale.doc || {};
  if (d.kind !== 'factura' || d.status !== 'autorizado' || !d.cae) throw new Error('La factura todavía no está autorizada por ARCA.');
  const st = settings();
  const cust = sale.customer_id ? db.get('customers', sale.customer_id) : null;
  const qr = await qrMatrix(arcaQrUrl(sale, st, cust));
  const name = `${(cbteNombre(d.cbte_tipo) || 'Factura').replace(/\s+/g, '-')}-${fmtCbteNro(d.pto_vta, d.cbte_nro)}.pdf`;
  const bytes = buildPdf(facturaLines(sale), qr, `${cbteNombre(d.cbte_tipo)} ${fmtCbteNro(d.pto_vta, d.cbte_nro)}`);
  return { file: new File([bytes], name, { type: 'application/pdf' }), qr: !!qr };
}

/** ¿El contacto es un mail? */
export const isEmail = s => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(s || '').trim());
