// =====================================================================
// informes.js — Informes como SGI (lógica pura, sin DOM): caja diaria, stock valorizado, ventas por período,
// por cliente, artículos por cliente, ventas y compras por artículo, ventas promedio y novedades de precios.
// Las devoluciones / notas de crédito RESTAN (en su fecha). No cuentan las anuladas, las borradas ni las "de prueba".
// Montos en centavos enteros por dentro.
// =====================================================================
import { round2, round3, computeArqueo, toISODate, fmtDate, norm } from './logic.js';

const C = x => Math.round(round2(x) * 100);
const P = c => round2(c / 100);
const inRange = (t, from, to) => Number(t) >= from && Number(t) <= to;
export const okSale = s => s && !s.deleted && !s.test && s.status === 'ok';
const okRet = r => r && !r.deleted && !r.test;

/** Ventas válidas y devoluciones de un rango */
function pick(sales, returns, from, to) {
  return {
    S: (sales || []).filter(s => okSale(s) && inRange(s.created_at, from, to)),
    R: (returns || []).filter(r => okRet(r) && inRange(r.created_at, from, to)),
  };
}

const WEEKDAYS = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
export { WEEKDAYS };

/**
 * Ventas por período (día, semana o mes): cantidad, vendido, devuelto, neto, IVA, intereses de tarjeta.
 * → {rows: [{key, label, count, gross, returns, total, iva, surcharge, avg}], totals}
 */
export function salesByPeriod(sales, returns, { from = -Infinity, to = Infinity, group = 'day' } = {}) {
  const { S, R } = pick(sales, returns, from, to);
  const keyOf = t => {
    const d = new Date(t);
    if (group === 'month') return toISODate(t).slice(0, 7);
    if (group === 'week') { const m = new Date(d.getFullYear(), d.getMonth(), d.getDate() - ((d.getDay() + 6) % 7)); return toISODate(m.getTime()); }
    return toISODate(t);
  };
  const m = new Map();
  const row = k => { if (!m.has(k)) m.set(k, { key: k, count: 0, g: 0, r: 0, iva: 0, sur: 0 }); return m.get(k); };
  for (const s of S) { const x = row(keyOf(s.created_at)); x.count++; x.g += C(s.total); x.iva += C(s.iva); x.sur += C(s.surcharge || 0); }
  for (const r of R) { const x = row(keyOf(r.created_at)); x.r += C(r.total); x.iva -= C(r.iva); }
  const label = k => (group === 'month' ? `${k.slice(5, 7)}/${k.slice(0, 4)}` : (group === 'week' ? 'Semana del ' : '') + fmtDate(new Date(k + 'T12:00').getTime()));
  const rows = [...m.values()].sort((a, b) => (a.key < b.key ? -1 : 1)).map(x => ({
    key: x.key, label: label(x.key), count: x.count, gross: P(x.g), returns: P(x.r), total: P(x.g - x.r), iva: P(x.iva), surcharge: P(x.sur), avg: x.count ? P(Math.round(x.g / x.count)) : 0,
  }));
  return { rows, totals: sumRows(rows, ['count', 'gross', 'returns', 'total', 'iva', 'surcharge']) };
}

function sumRows(rows, keys) {
  const t = {};
  for (const k of keys) t[k] = k === 'count' || k === 'qty' ? round3(rows.reduce((a, r) => a + (Number(r[k]) || 0), 0)) : P(rows.reduce((a, r) => a + C(r[k] || 0), 0));
  return t;
}

/**
 * Ventas por cliente: cantidad de compras, total, devuelto, neto, última compra, saldo de cuenta corriente.
 * Las ventas sin cliente van como "Consumidor final".
 */
export function salesByCustomer(sales, returns, { from = -Infinity, to = Infinity, customerOf = () => null } = {}) {
  const { S, R } = pick(sales, returns, from, to);
  const m = new Map();
  const row = id => {
    const k = id || '';
    if (!m.has(k)) { const c = id ? customerOf(id) : null; m.set(k, { customer_id: id || null, name: c ? c.name : (id ? '(cliente borrado)' : 'Consumidor final'), balance: c ? round2(c.balance || 0) : 0, count: 0, g: 0, r: 0, last: 0 }); }
    return m.get(k);
  };
  for (const s of S) { const x = row(s.customer_id); x.count++; x.g += C(s.total); x.last = Math.max(x.last, s.created_at); }
  for (const r of R) { const x = row(r.customer_id); x.r += C(r.total); }
  const rows = [...m.values()].map(x => ({ customer_id: x.customer_id, name: x.name, balance: x.balance, count: x.count, gross: P(x.g), returns: P(x.r), total: P(x.g - x.r), last: x.last || null, avg: x.count ? P(Math.round(x.g / x.count)) : 0 }))
    .sort((a, b) => b.total - a.total || a.name.localeCompare(b.name, 'es'));
  return { rows, totals: sumRows(rows, ['count', 'gross', 'returns', 'total']) };
}

/** Artículos por cliente: qué compró cada cliente (cantidad y total), neto de devoluciones */
export function itemsByCustomer(sales, returns, { from = -Infinity, to = Infinity, customerId = null, customerOf = () => null } = {}) {
  const { S, R } = pick(sales, returns, from, to);
  const m = new Map();
  const add = (cid, it, sign) => {
    if (customerId && (cid || '') !== customerId) return;
    const k = (cid || '') + '|' + (it.product_id || 'libre:' + it.name);
    if (!m.has(k)) { const c = cid ? customerOf(cid) : null; m.set(k, { customer_id: cid || null, customer: c ? c.name : (cid ? '(cliente borrado)' : 'Consumidor final'), product_id: it.product_id || null, name: it.name, qty: 0, c: 0, times: 0 }); }
    const x = m.get(k);
    x.qty = round3(x.qty + sign * Number(it.qty)); x.c += sign * C(it.subtotal); if (sign > 0) x.times++;
  };
  for (const s of S) for (const it of s.items || []) add(s.customer_id, it, 1);
  for (const r of R) for (const it of r.items || []) add(r.customer_id, it, -1);
  const rows = [...m.values()].filter(x => x.qty || x.c).map(x => ({ customer_id: x.customer_id, customer: x.customer, product_id: x.product_id, name: x.name, qty: x.qty, total: P(x.c), times: x.times }))
    .sort((a, b) => a.customer.localeCompare(b.customer, 'es') || b.total - a.total);
  return { rows, totals: sumRows(rows, ['total']) };
}

/**
 * Ventas por artículo: cantidad, total vendido (neto de devoluciones), costo actual, ganancia y margen.
 * filtro opcional por rubro (category) o proveedor.
 */
export function salesByArticle(sales, returns, { from = -Infinity, to = Infinity, productOf = () => null, category = '', supplierId = '' } = {}) {
  const { S, R } = pick(sales, returns, from, to);
  const m = new Map();
  const add = (it, sign) => {
    const p = it.product_id ? productOf(it.product_id) : null;
    if (category && norm(p && p.category) !== norm(category)) return;
    if (supplierId && (!p || p.supplier_id !== supplierId)) return;
    const k = it.product_id || 'libre:' + it.name;
    if (!m.has(k)) m.set(k, { product_id: it.product_id || null, name: p ? p.name : it.name, category: p ? p.category || '' : 'Monto libre', code: p ? p.barcode || p.sku || '' : '', cost: p ? round2(p.cost || 0) : 0, qty: 0, c: 0, n: 0 });
    const x = m.get(k);
    x.qty = round3(x.qty + sign * Number(it.qty)); x.c += sign * C(it.subtotal); if (sign > 0) x.n++;
  };
  for (const s of S) for (const it of s.items || []) add(it, 1);
  for (const r of R) for (const it of r.items || []) add(it, -1);
  const rows = [...m.values()].filter(x => x.qty || x.c).map(x => {
    const costC = Math.round(C(x.cost) * x.qty);
    return { product_id: x.product_id, name: x.name, category: x.category, code: x.code, qty: x.qty, total: P(x.c), avg_price: x.qty ? round2(x.c / 100 / x.qty) : 0, cost: P(costC), profit: x.cost ? P(x.c - costC) : null, margin: x.cost && x.c ? Math.round(((x.c - costC) / x.c) * 1000) / 10 : null, tickets: x.n };
  }).sort((a, b) => b.total - a.total);
  return { rows, totals: { ...sumRows(rows, ['total', 'cost']), profit: P(rows.reduce((a, r) => a + (r.profit === null ? 0 : C(r.profit)), 0)) } };
}

/** Compras por artículo: cantidad comprada, total, costo promedio y último costo (NC de proveedor restan) */
export function purchasesByArticle(purchases, { from = -Infinity, to = Infinity, productOf = () => null, supplierOf = () => null, supplierId = '' } = {}) {
  const m = new Map();
  for (const pu of purchases || []) {
    if (!pu || pu.deleted || pu.status === 'anulada' || !inRange(pu.created_at, from, to)) continue;
    if (supplierId && pu.supplier_id !== supplierId) continue;
    const sign = pu.doc_type === 'NC' ? -1 : 1;
    for (const it of pu.items || []) {
      const k = it.product_id || 'libre:' + it.name;
      const p = it.product_id ? productOf(it.product_id) : null;
      if (!m.has(k)) m.set(k, { product_id: it.product_id || null, name: p ? p.name : it.name, qty: 0, c: 0, last: 0, lastCost: 0, supplier: '' });
      const x = m.get(k);
      const unit = Number(it.unit_net ?? it.unit_cost) || 0;
      x.qty = round3(x.qty + sign * Number(it.qty)); x.c += sign * Math.round(C(unit) * Number(it.qty));
      if (sign > 0 && pu.created_at >= x.last) { x.last = pu.created_at; x.lastCost = round2(unit); const s = supplierOf(pu.supplier_id); x.supplier = s ? s.name : ''; }
    }
  }
  const rows = [...m.values()].filter(x => x.qty || x.c).map(x => ({ product_id: x.product_id, name: x.name, qty: x.qty, total: P(x.c), avg_cost: x.qty ? round2(x.c / 100 / x.qty) : 0, last_cost: x.lastCost, last: x.last || null, supplier: x.supplier }))
    .sort((a, b) => b.total - a.total);
  return { rows, totals: sumRows(rows, ['total']) };
}

/**
 * Ventas promedio: por día de la semana, por hora y por día. Promedio por día = total ÷ días del período con esa
 * condición (los días sin ventas también cuentan, como en SGI).
 */
export function salesAverages(sales, returns, { from, to } = {}) {
  const { S, R } = pick(sales, returns, from, to);
  const days = Math.max(1, Math.round((new Date(toISODate(to)).getTime() - new Date(toISODate(from)).getTime()) / 86400000) + 1);
  // Cuántas veces aparece cada día de la semana en el período
  const wdCount = Array(7).fill(0);
  for (let i = 0; i < days; i++) { const d = new Date(from); d.setDate(d.getDate() + i); wdCount[d.getDay()]++; }
  const wd = Array.from({ length: 7 }, (_, i) => ({ day: i, label: WEEKDAYS[i], count: 0, c: 0 }));
  const hr = Array.from({ length: 24 }, (_, i) => ({ hour: i, label: `${String(i).padStart(2, '0')}:00`, count: 0, c: 0 }));
  let tot = 0, n = 0;
  for (const s of S) { const d = new Date(s.created_at); wd[d.getDay()].count++; wd[d.getDay()].c += C(s.total); hr[d.getHours()].count++; hr[d.getHours()].c += C(s.total); tot += C(s.total); n++; }
  for (const r of R) { const d = new Date(r.created_at); wd[d.getDay()].c -= C(r.total); hr[d.getHours()].c -= C(r.total); tot -= C(r.total); }
  const byWeekday = [1, 2, 3, 4, 5, 6, 0].map(i => ({ label: wd[i].label, count: wd[i].count, total: P(wd[i].c), days: wdCount[i], per_day: wdCount[i] ? P(Math.round(wd[i].c / wdCount[i])) : 0, avg_ticket: wd[i].count ? P(Math.round(wd[i].c / wd[i].count)) : 0 }));
  const byHour = hr.filter(h => h.count || h.c).map(h => ({ label: h.label, count: h.count, total: P(h.c), per_day: P(Math.round(h.c / days)), avg_ticket: h.count ? P(Math.round(h.c / h.count)) : 0 }));
  return { days, total: P(tot), count: n, per_day: P(Math.round(tot / days)), avg_ticket: n ? P(Math.round(tot / n)) : 0, byWeekday, byHour };
}

/** Stock valorizado a costo y a venta. Los negativos no suman (se cuentan aparte). */
export function stockValued(products, { stockOf, category = '', supplierId = '', onlyWithStock = false } = {}) {
  const rows = [];
  let cost = 0, sale = 0, neg = 0;
  for (const p of products || []) {
    if (!p || p.deleted || p.active === 0) continue;
    if (category && norm(p.category) !== norm(category)) continue;
    if (supplierId && p.supplier_id !== supplierId) continue;
    const st = round3(Number(stockOf(p)) || 0);
    if (onlyWithStock && st <= 0) continue;
    const q = Math.max(0, st);
    const cv = Math.round(C(p.cost || 0) * q), sv = Math.round(C(p.price || 0) * q);
    if (st < 0) neg++;
    cost += cv; sale += sv;
    rows.push({ product_id: p.id, name: p.name, category: p.category || '', code: p.barcode || p.sku || '', unit: p.unit || 'u', stock: st, cost: round2(p.cost || 0), price: round2(p.price || 0), cost_value: P(cv), sale_value: P(sv) });
  }
  rows.sort((a, b) => a.category.localeCompare(b.category, 'es') || a.name.localeCompare(b.name, 'es'));
  return { rows, totals: { cost_value: P(cost), sale_value: P(sale), profit: P(sale - cost), negatives: neg, count: rows.length } };
}

/**
 * Novedades: cambios de precio recientes (auditoría "producto_precio" y cambios en lote). Uno por producto y cambio.
 * → [{at, product_id, name, old, price, pct, user_id}] más nuevo primero
 */
export function priceNovelties(audits = [], { from = -Infinity, to = Infinity, productOf = () => null } = {}) {
  const out = [];
  for (const a of audits) {
    if (!a || a.deleted || !inRange(a.created_at, from, to)) continue;
    const d = a.detail || {};
    const push = (id, name, old, price) => {
      if (old === undefined || price === undefined || round2(old) === round2(price)) return;
      const p = id ? productOf(id) : null;
      out.push({ at: a.created_at, product_id: id || null, name: (p && p.name) || name || '', old: round2(old), price: round2(price), pct: Number(old) > 0 ? Math.round(((price - old) / old) * 1000) / 10 : null, user_id: a.user_id || null, current: p ? round2(p.price) : null });
    };
    if (a.action === 'producto_precio') push(a.entity_id, d.name, d.old, d.price);
    else if (a.action === 'lote_precio' || a.action === 'precios_sgi') for (const r of d.sample || d.rows || []) push(r.id, r.name, r.old, r.price);
  }
  return out.sort((a, b) => b.at - a.at);
}

/**
 * Caja diaria: cada caja del día (abiertas ese día) con su arqueo, ventas por medio de pago y movimientos.
 * data: {sessions, sales, movements, returns}
 */
export function cashDaily({ sessions = [], sales = [], movements = [], returns = [] }, { from, to } = {}) {
  const list = sessions.filter(s => s && !s.deleted && inRange(s.opened_at, from, to)).sort((a, b) => a.opened_at - b.opened_at);
  const byMethod = {};
  let tot = { opening: 0, cashSales: 0, salesTotal: 0, ingresos: 0, egresos: 0, devoluciones: 0, expected: 0, counted: 0, difference: 0, count: 0 };
  const rows = list.map(s => {
    const S = sales.filter(x => x.session_id === s.id && !x.test);
    const M = movements.filter(x => x.session_id === s.id);
    const R = returns.filter(x => x.session_id === s.id);
    const a = computeArqueo({ opening: s.opening_amount, sales: S, movements: M, returns: R, counted: s.closed_at ? s.counted_amount : null });
    for (const [k, v] of Object.entries(a.byMethod)) byMethod[k] = round2((byMethod[k] || 0) + v);
    for (const k of ['opening', 'cashSales', 'salesTotal', 'ingresos', 'egresos', 'devoluciones', 'expected']) tot[k] = round2(tot[k] + a[k]);
    if (a.counted !== null) { tot.counted = round2(tot.counted + a.counted); tot.difference = round2(tot.difference + a.difference); }
    tot.count += a.count;
    return { session: s, arqueo: a, movements: M.filter(m => !m.deleted).sort((x, y) => x.created_at - y.created_at) };
  });
  return { rows, byMethod, totals: tot };
}

/** Convierte filas a tabla (para Excel): cols [{k, h}] */
export function toTable(rows, cols) {
  return [cols.map(c => c.h), ...rows.map(r => cols.map(c => (typeof c.f === 'function' ? c.f(r) : r[c.k] ?? '')))];
}
