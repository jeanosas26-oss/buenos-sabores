// Service worker de JEANO Gestión: guarda la app para que funcione sin internet y abra al instante.
// Estrategia (v15): cada versión baja TODOS sus archivos juntos al instalarse (sin la caché HTTP) y los sirve
// siempre de su copia: nunca se mezclan archivos de dos versiones (antes, "se actualiza en segundo plano" podía
// dejar app.js nuevo con una pantalla vieja y la app no arrancaba). La versión nueva queda esperando y la app
// le avisa (SKIP_WAITING) cuando no hay una venta ni una ventana a medio hacer; ahí se recarga sola.
// Librerías de cdnjs se guardan la primera vez que se usan. La API de la nube nunca se cachea.
// IMPORTANTE: si cambiás cualquier archivo de la app, subí VERSION (y agregá los archivos nuevos a SHELL).
const VERSION = 'jg-v38';
const SHELL = [
  './',
  './index.html',
  './manifest.webmanifest',
  './css/app.css',
  // Ventas como SGI (tarjetas, promociones, presupuestos, pedidos, rubros, vencimientos, etiquetas, informes)
  './css/ventas.css',
  './js/comercial.js',
  './js/comercial-ops.js',
  './js/informes.js',
  './js/lotes.js',
  './js/views/cobro.js',
  './js/views/presupuestos.js',
  './js/views/promociones.js',
  './js/views/pedidos-prov.js',
  './js/views/vencimientos.js',
  './js/views/informes.js',
  './js/views/rubros.js',
  './js/views/etiquetas.js',
  './js/views/medios.js',
  './js/views/nota-debito.js',
  // Compras como SGI, gastos, cheques, tesorería (esquema 0006)
  './css/compras.css',
  './js/compras-calc.js',
  './js/compras-ops.js',
  './js/tesoreria-calc.js',
  './js/tesoreria-ops.js',
  './js/views/cheque-ui.js',
  './js/views/gastos.js',
  './js/views/tesoreria.js',
  './config.js',
  './js/app.js',
  './js/atajos.js',
  './js/autoriza.js',
  './js/cierre.js',
  './js/control.js',
  './js/cuentas-ops.js',
  './js/cuentas.js',
  './js/fotos.js',
  // Importar fotos y fotos faltantes (v22)
  './js/fotos-match.js',
  './js/zip.js',
  './js/views/fotos.js',
  './js/seguridad.js',
  './js/views/auditoria.js',
  './js/views/clientes-cuenta.js',
  './js/views/comisiones.js',
  './js/views/ctacte.js',
  './js/views/productos-lote.js',
  './js/views/proveedores.js',
  './js/logic.js',
  './js/db.js',
  // PIN seguro (v26): verificador local PBKDF2
  './js/pin.js',
  './js/sync.js',
  './js/ui.js',
  './js/ops.js',
  './js/print.js',
  './js/backup.js',
  './js/csr.js',
  './js/factura-pdf.js',
  './js/views/mandar-factura.js',
  './js/barcode.js',
  './js/scanner.js',
  './js/negocio.js',
  './js/durability.js',
  './js/views/login.js',
  './js/views/vender.js',
  './js/views/caja.js',
  './js/views/productos.js',
  './js/views/compras.js',
  './js/views/clientes.js',
  './js/views/ventas.js',
  './js/views/reportes.js',
  './js/views/ajustes.js',
  './js/views/hoy.js',
  './js/views/remitos.js',
  './js/views/conteo.js',
  // IA (v31): leer comprobantes y vencimientos con foto, asistente
  './js/ia.js',
  './js/ia-match.js',
  './js/ia-context.js',
  './js/views/ia.js',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './icons/maskable-512.png',
  './icons/apple-touch-icon.png',
  './icons/favicon-32.png',
];

// Cloudflare Pages redirige /index.html -> /: una respuesta "redirigida" guardada en la copia hace que Chrome
// muestre ERR_FAILED al abrir la app. Por eso se guarda siempre una copia LIMPIA (sin la marca de redirección).
async function limpia(res) {
  if (!res || !res.redirected) return res;
  const body = await res.blob();
  return new Response(body, { status: res.status, statusText: res.statusText, headers: res.headers });
}

self.addEventListener('install', event => {
  // cache: 'reload' = directo del servidor (no de la caché HTTP del navegador, que podría tener un archivo viejo)
  event.waitUntil(caches.open(VERSION).then(c => Promise.all(SHELL.map(async u => {
    const res = await fetch(new Request(u, { cache: 'reload' }));
    if (!res.ok) throw new Error('No se pudo bajar ' + u + ' (' + res.status + ')');
    await c.put(u, await limpia(res));
  }))));
  // v15 a v19 podían no abrir (copia redirigida) y no podían pedir la actualización: si hay una, esta se activa sola.
  event.waitUntil(caches.keys().then(keys => { if (keys.some(k => /^jg-v1[5-9]$/.test(k))) return self.skipWaiting(); }));
});

// La app pide activar la versión nueva cuando es un buen momento (no hay venta a medio cargar)
self.addEventListener('message', event => {
  if (event.data && event.data.type === 'SKIP_WAITING') self.skipWaiting();
});

self.addEventListener('activate', event => {
  event.waitUntil(
    caches.keys()
      .then(keys => Promise.all(keys.filter(k => k !== VERSION && k !== 'jg-cdn').map(k => caches.delete(k))))
      .then(() => self.clients.claim())
  );
});

self.addEventListener('fetch', event => {
  const req = event.request;
  if (req.method !== 'GET') return;
  const url = new URL(req.url);

  // Librerías externas (xlsx, qrcode) desde cdnjs: primero caché
  if (url.hostname === 'cdnjs.cloudflare.com') {
    event.respondWith(caches.open('jg-cdn').then(async c => {
      const hit = await c.match(req);
      if (hit) return hit;
      const res = await fetch(req);
      if (res.ok) c.put(req, res.clone());
      return res;
    }));
    return;
  }

  if (url.origin !== self.location.origin) return; // API de la nube y otros: directo a la red
  if (url.pathname.includes('/api/')) return;

  event.respondWith(caches.open(VERSION).then(async c => {
    const key = req.mode === 'navigate' ? './index.html' : req;
    const hit = await c.match(key, { ignoreSearch: req.mode === 'navigate' });
    if (hit) return limpia(hit); // primero la copia de ESTA versión: abre al instante y sin mezclar
    // Lo que no está en la copia (un archivo nuevo, un ícono): de la red, y se guarda para usarlo sin internet
    try {
      const res = await fetch(req);
      if (res.ok && res.type === 'basic' && req.mode !== 'navigate') c.put(req, res.clone());
      return res;
    } catch (e) {
      return new Response('Sin conexión', { status: 503, headers: { 'Content-Type': 'text/plain; charset=utf-8' } });
    }
  }));
});
